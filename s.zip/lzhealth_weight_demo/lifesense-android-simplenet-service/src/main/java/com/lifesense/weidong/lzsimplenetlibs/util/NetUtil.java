package com.lifesense.weidong.lzsimplenetlibs.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;

import com.lifesense.weidong.lzsimplenetlibs.R;
import com.lifesense.weidong.lzsimplenetlibs.common.ApplicationHolder;

/**
 * Created by luoxf on 2016/1/26.
 */
public class NetUtil {

    /**
     * 检查网络是否已连接
     *
     * @return
     */
    public static boolean checkNetworkConnection() {
        final ConnectivityManager connMgr = (ConnectivityManager) ApplicationHolder.getmApplication().getSystemService(Context.CONNECTIVITY_SERVICE);

//        final android.net.NetworkInfo wifi = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
//        final android.net.NetworkInfo mobile = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

        NetworkInfo mNetworkInfo = connMgr.getActiveNetworkInfo();
        if (mNetworkInfo == null) {

        } else {
            return mNetworkInfo.isAvailable();

        }
        return false;

    }

    public static boolean checkWifiNetworkState(Context context) {
        boolean flag = false;
        boolean temp = false;
        //得到网络连接信息
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //去进行判断网络是否连接
        if (manager.getActiveNetworkInfo() != null) {
            temp = manager.getActiveNetworkInfo().isAvailable();
        }
        if (temp) {
            NetworkInfo.State wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
            //判断为wifi状态下才加载广告，如果是GPRS手机网络则不加载！
            if (wifi == NetworkInfo.State.CONNECTED || wifi == NetworkInfo.State.CONNECTING) {
                flag = true;
            }
        }
        return flag;
    }

    public static String getWifiSSID(Context context) {
        String ssid = "";
        WifiManager mWifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if (mWifi.isWifiEnabled()) {
            WifiInfo wifiInfo = mWifi.getConnectionInfo();
            ssid = wifiInfo.getSSID(); //获取被连接网络的名称
            if (Build.VERSION.SDK_INT >= 17 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                ssid = ssid.replaceAll("^\"|\"$", "");
            }
        }
        return ssid;
    }

    public static WifiInfo getConnectedWifiInfo(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if (wifiManager.isWifiEnabled()) {
            return wifiManager.getConnectionInfo();
        }
        return null;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static boolean isWifi24GHz(WifiInfo info) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            throw  new IllegalStateException("SDK must >= 21");
        }
        if (info == null) {
            return false;
        }
        return isWifi24GHz(info.getFrequency());
    }

    public static boolean isWifi24GHz(int freq) {
        return freq > 2400 && freq < 2500;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static boolean isWifi5GHz(WifiInfo info) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            throw  new IllegalStateException("SDK must >= 21");
        }
        if (info == null) {
            return false;
        }
        return isWifi5GHz(info.getFrequency());
    }
    public static boolean isWifi5GHz(int freq) {
        return freq > 4900 && freq < 5900;
    }


    //判断是否有网络连接
    public static boolean isNetworkAvailable(Context context)
    {
        // 获取手机所有连接管理对象（包括对wi-fi,net等连接的管理）
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager == null)
        {
            return false;
        }
        else
        {
            // 获取NetworkInfo对象
            NetworkInfo[] networkInfo = connectivityManager.getAllNetworkInfo();

            if (networkInfo != null && networkInfo.length > 0)
            {
                for (int i = 0; i < networkInfo.length; i++)
                {
                    System.out.println(i + "===状态===" + networkInfo[i].getState());
                    System.out.println(i + "===类型===" + networkInfo[i].getTypeName());
                    // 判断当前网络状态是否为连接状态
                    if (networkInfo[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    public static boolean isNetWorkCanUse(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        return isPerferNetWorkCanUse(connectivity);
    }

    private static boolean isPerferNetWorkCanUse(ConnectivityManager connectivity) {
        NetworkInfo info = connectivity.getActiveNetworkInfo();
        return info != null
                && (info.getState() == NetworkInfo.State.CONNECTING || info.getState() == NetworkInfo.State.CONNECTED);
    }

    public static boolean isNetWorkErrorShow(Context context) {
        if (context == null) {
            return true;
        }
        if (!isNetworkAvailable(context)) {
            return true;
        }
        return false;
    }

    public static boolean isNetworkAvailable() {

        ConnectivityManager mConnectivityManager = (ConnectivityManager) ApplicationHolder.getmApplication()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (mNetworkInfo != null) {
            return mNetworkInfo.isAvailable();
        }
        return false;
    }
}
