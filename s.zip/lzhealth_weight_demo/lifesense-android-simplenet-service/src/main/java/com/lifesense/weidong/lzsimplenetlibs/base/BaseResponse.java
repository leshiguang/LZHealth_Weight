package com.lifesense.weidong.lzsimplenetlibs.base;


import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;

/**
 * Response基类
 */

public class BaseResponse {
    private static final String TAG = "BaseResponse";
    protected BaseRequest mRequest = null;
    protected String content;
    protected int mRet;
    private String mMsg = "";
    private long responseTime; //响应时间

    public long getResponseTime() {
        return responseTime;
    }

    public BaseResponse setResponseTime(long responseTime) {
        this.responseTime = responseTime;
        return this;
    }

    /**
     * @return the mRequest
     */
    public BaseRequest getmRequest() {
        return mRequest;
    }

    /**
     * @param mRequest the mRequest to set
     */
    public void setmRequest(BaseRequest mRequest) {
        this.mRequest = mRequest;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the mRet
     */
    public int getmRet() {
        return mRet;
    }


    public void setmMsg(String mMsg) {
        this.mMsg = mMsg;
    }

    public String getmMsg() {
        return mMsg;
    }

    /**
     * @param mRet the mRet to set
     */
    public void setmRet(int mRet) {
        this.mRet = mRet;
    }


    /**
     *
     */
    public BaseResponse() {
        super();
    }

    /**
     * 解决数据
     *
     * @throws ProtocolException
     */
    public void parse() throws ProtocolException {
    }


}
