package com.lifesense.weidong.lzsimplenetlibs.net.invoker;


import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;

public interface ApiInvoker {

    /**
     * 执行调用
     *
     * @param request
     * @return
     */
    void executeCall(BaseRequest request, BaseResponse response);
}
