package com.lifesense.weidong.lzsimplenetlibs.net.exception;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;

/**
 * Create by qwerty
 * Create on 2020/5/28
 **/
public class ErrorResponse extends BaseResponse {

}
