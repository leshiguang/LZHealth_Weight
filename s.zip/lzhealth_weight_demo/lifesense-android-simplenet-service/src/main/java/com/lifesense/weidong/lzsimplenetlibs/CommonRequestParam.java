package com.lifesense.weidong.lzsimplenetlibs;

public class CommonRequestParam {
    public static String Cookie = "";
}
