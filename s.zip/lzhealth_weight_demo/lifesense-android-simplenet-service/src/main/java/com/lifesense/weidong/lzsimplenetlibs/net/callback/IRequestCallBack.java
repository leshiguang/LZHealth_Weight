package com.lifesense.weidong.lzsimplenetlibs.net.callback;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;

public interface IRequestCallBack<O extends BaseResponse> {
        void onRequestSuccess(O response);

        void onRequestError(int code, String msg, O response);
}
