package com.lifesense.weidong.lzsimplenetlibs.cookie;


import android.content.Context;

import android.util.Log;
import com.lifesense.weidong.lzsimplenetlibs.common.ApplicationHolder;
import com.lifesense.weidong.lzsimplenetlibs.net.HttpResponse;
import com.lifesense.weidong.lzsimplenetlibs.util.PreferencesUtils;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LZCookieManager {
    private CookieManager mCookieManager = null;
    private PersistentCookieStore sPersistentCookieStore = null;
    private static final String SET_COOKIE = "Set-cookie";
    private static final String SET_COOKIE2 = "Set-cookie2";

    public static LZCookieManager getInstance() {
        return SingleHolder.getSingleton();
    }

    private static class SingleHolder {
        private static LZCookieManager lzCookieManager = new LZCookieManager();

        private static LZCookieManager getSingleton() {
            return lzCookieManager;
        }
    }

    public void saveCookie(HttpResponse response) {
        try {
            if (response.getUrl() != null && response.getHeaderFields() != null) {
                getCookieManager().put(response.getUrl().toURI(), response.getHeaderFields());
            }
        } catch (Exception e) {
            Log.e("COOKIE_ERROR", e.getMessage());
        }
    }

    public List<HttpCookie> getUriCookie(URI uri) {
        if (sPersistentCookieStore != null) {
            return sPersistentCookieStore.get(uri);
        }
        return new ArrayList<>();
    }

    public void addUriCookiesToHeads(Map<String, String> heads, URI uri) {
        if (uri == null) {
            return;
        }
        Map<String, List<String>> simulateHeads = new HashMap<>();
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.GINGERBREAD) {
                Map<String, List<String>> cookieMap = getCookieManager().
                        get(uri, simulateHeads);
                if (cookieMap != null) {
                    addCookiesToHeads(heads, cookieMap);
                }
            }
        } catch (Exception e) {
            Log.e("COOKIE_ERROR", e.getMessage());
        }
    }

    private void addCookiesToHeads(Map<String, String> heads, Map<String, List<String>> cookieHeaders) {
        for (Map.Entry<String, List<String>> entry : cookieHeaders.entrySet()) {
            String key = entry.getKey();
            if (("Cookie".equalsIgnoreCase(key) || "Cookie2".equalsIgnoreCase(key))
                    && !entry.getValue().isEmpty()) {
                heads.put(key, buildCookieHeader(entry.getValue()));
            }
        }
    }

    /**
     * Send all cookies in one big header, as recommended by
     * <a href="http://tools.ietf.org/html/rfc6265#section-4.2.1">RFC 6265</a>.
     */
    private String buildCookieHeader(List<String> cookies) {
        if (CollectionUtils.isEmpty(cookies)) {
            return "";
        }
        if (cookies.size() == 1) return cookies.get(0);
        return StringUtils.join(cookies, "; ");
    }

    public String getCookies() {
        return PreferencesUtils.getString(ApplicationHolder.getmApplication(), SET_COOKIE, "");
    }

    public CookieManager getCookieManager() {
        if (mCookieManager == null) {
            initSelfCookieManager(ApplicationHolder.getmApplication());
        }
        return mCookieManager;
    }

    private synchronized void initSelfCookieManager(Context context) {
        if (sPersistentCookieStore == null) {
            sPersistentCookieStore = new PersistentCookieStore(context);
        }

        if (mCookieManager == null) {
            mCookieManager = new CookieManager
                    (sPersistentCookieStore, CookiePolicy.ACCEPT_ALL);
        }
    }

}
