package com.lifesense.weidong.lzsimplenetlibs.net.invoker;

import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;
import com.lifesense.weidong.lzsimplenetlibs.cookie.LZCookieManager;
import com.lifesense.weidong.lzsimplenetlibs.file.DownloadRequest;
import com.lifesense.weidong.lzsimplenetlibs.net.HttpResponse;

import org.apache.commons.collections4.MapUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLConnection;
import java.util.Map;

/**
 * Create by qwerty
 * Create on 2020/6/1
 **/
public abstract class BaseApiInvoker implements ApiInvoker {
    private final String TAG = getClass().getSimpleName();

    protected abstract URLConnection getURLConnection(String uri, String method) throws IOException;

    private byte[] getBytesFromStream(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] kb = new byte[1024];
        int len;
        while ((len = is.read(kb)) != -1) {
            baos.write(kb, 0, len);
        }
        byte[] bytes = baos.toByteArray();
        baos.close();
        is.close();
        return bytes;
    }

    private void setBytesToStream(OutputStream os, byte[] bytes) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
        byte[] kb = new byte[1024];
        int len;
        while ((len = bais.read(kb)) != -1) {
            os.write(kb, 0, len);
        }
        os.flush();
        os.close();
        bais.close();
    }


    @Override
    public void executeCall(BaseRequest request, BaseResponse response) {
        try {
            if ("get".equalsIgnoreCase(request.getRequestMethod())) {
                doGet(request, response);
            } else if ("post".equalsIgnoreCase(request.getRequestMethod())) {
                doPost(request, response);
            }
        } catch (Exception e) {
            response.setmRet(404);
            response.setmMsg(e.getMessage());
        }
    }


    public void doGet(BaseRequest request, BaseResponse response) throws IOException {
        HttpResponse httpResponse = performRequest(request);
        byte[] resultBytes;
        if (request instanceof DownloadRequest) {
            DownloadRequest downloadRequest = (DownloadRequest) request;
            if (downloadRequest.isResume() && !isSupportRange(httpResponse)) {
                downloadRequest.setResume(false);
            }
            resultBytes = getBytesFromStreamWithLoading(downloadRequest, httpResponse);
        } else {
            resultBytes = getBytesFromStream(httpResponse.getResponseContent());
        }
        LZCookieManager.getInstance().saveCookie(httpResponse);
        if (resultBytes != null && resultBytes.length > 0) {
            response.setContent(new String(resultBytes));
            response.setmRet(200);
        }
    }

    private void doPost(BaseRequest request, BaseResponse response) throws IOException {
        HttpResponse httpResponse = performRequest(request);
        byte[] resultBytes;
        if (request instanceof DownloadRequest) {
            DownloadRequest downloadRequest = (DownloadRequest) request;
            if (downloadRequest.isResume() && !isSupportRange(httpResponse)) {
                downloadRequest.setResume(false);
            }
            resultBytes = getBytesFromStreamWithLoading(downloadRequest, httpResponse);
        } else {
            resultBytes = getBytesFromStream(httpResponse.getResponseContent());
        }
        LZCookieManager.getInstance().saveCookie(httpResponse);
        if (resultBytes != null && resultBytes.length > 0) {
            response.setContent(new String(resultBytes));
            response.setmRet(200);
        }
    }

    private byte[] getBytesFromStreamWithLoading(DownloadRequest request, HttpResponse httpResponse) throws IOException {
        long time = SystemClock.uptimeMillis();
        final String target = request.getTarget();
        if (TextUtils.isEmpty(target) || target.trim().length() == 0)
            return null;

        Log.e(TAG, " getBytesFromStreamWithLoading target" + target);

        File targetFile = new File(target);
        if (!targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }
        if (!targetFile.exists()) {
            targetFile.createNewFile();
        }

        if (request.isCanceled() || httpResponse.getResponseStatus() == HttpStatus.SC_REQUESTED_RANGE_NOT_SATISFIABLE) {
            return target.getBytes();
        }
        FileOutputStream os = null;
        InputStream input = null;
        try {
            long current = 0;
            if (request.isResume()) {
                current = targetFile.length();
                os = new FileOutputStream(target, true);
            } else {
                os = new FileOutputStream(target);
            }
            if (request.isCanceled()) {
                return target.getBytes();
            }

            input = httpResponse.getResponseContent();
            long count = httpResponse.getContentLength() + current;

            if (current >= count || request.isCanceled()) {
                return target.getBytes();
            }
            DownloadRequest.OnLoadingListener listener = request.getOnLoadingListener();
            int readLen = 0;
            byte[] buffer = new byte[1024];
            while (!request.isCanceled() && !(current >= count) && ((readLen = input.read(buffer, 0, 1024)) > 0)) {//��??????
                os.write(buffer, 0, readLen);
                current += readLen;
                if (listener != null) {
                    Log.d(TAG, "total=" + count + ",current=" + current);
                    listener.onLoading(count, current);
                }
            }
            if (listener != null) {
                listener.onLoading(count, current);
            }
            if (request.isCanceled() && current < count) { //?????????
                throw new IOException("user stop download thread");
            }
        } finally {
            if (input != null) {
                input.close();
            }
            if (os != null) {
                os.close();
            }
        }
        return target.getBytes();
    }

    private String preHandler(BaseRequest httpRequest) {
        return String.format("%s%s", httpRequest.getUrl(), httpRequest.formatUrlParams());
    }

    public boolean isSupportRange(HttpResponse httpResponse) {
        if (TextUtils.equals(httpResponse.getHeaderField("Accept-Ranges"), "bytes")) {
            return true;
        }
        String value = getHeader(httpResponse, "Content-Range");
        return value != null && value.startsWith("bytes");
    }

    private String getHeader(HttpResponse response, String key) {
        return response.getHeaderField(key);
    }

    protected HttpResponse performRequest(BaseRequest request) throws IOException {
        int continueCount = 0;
        while (true) {
            if (continueCount >= 3) {
                throw new IOException();
            }
            String newApiName = preHandler(request);
            LZCookieManager.getInstance().addUriCookiesToHeads(request.getHeaderParams(), URI.create(newApiName));
            Log.i(TAG, request.getRequestMethod() + ":" + newApiName + "\nheader:" + request.getHeaderParams() + "\nparams:" + request.getCustomParamString());
            String method = request.getRequestMethod();
            HttpURLConnection httpURLConnection = (HttpURLConnection) getURLConnection(newApiName, method);
            if (MapUtils.isNotEmpty(request.getHeaderParams())) {
                for (Map.Entry<String, String> header : request.getHeaderParams().entrySet())
                    httpURLConnection.setRequestProperty(header.getKey(), header.getValue());
            }
            if ("POST".equals(method)) {
                httpURLConnection.setRequestProperty("Content-Type", BaseRequest.CONTENT_TYPE_JSON);
                if (!TextUtils.isEmpty(request.dictToBody())) {
                    setBytesToStream(httpURLConnection.getOutputStream(), request.dictToBody().getBytes());
                } else {
                    setBytesToStream(httpURLConnection.getOutputStream(), new byte[0]);
                }
            }
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == -1) {
                // -1 is returned by getResponseCode() if the response code could not be retrieved.
                // Signal to the caller that something was wrong with the connection.
                throw new IOException("Could not retrieve response code from HttpUrlConnection.");
            }
            HttpResponse response = new HttpResponse();
            response.setResponseStatus(responseCode);
            response.setUrl(httpURLConnection.getURL());
            if (request instanceof DownloadRequest) {
                DownloadRequest downloadRequest = (DownloadRequest) request;
                if (downloadRequest.isResume() && !isSupportRange(response)) {
                    downloadRequest.setResume(false);
                }
                if (responseCode == HttpStatus.SC_REQUESTED_RANGE_NOT_SATISFIABLE) {
                    return response;
                } else if (responseCode == HttpStatus.SC_MOVED_PERMANENTLY || responseCode == HttpStatus.SC_MOVED_TEMPORARILY) {
                    request.setUrl(httpURLConnection.getHeaderField("Location"));
                    continueCount++;
                    continue;
                }
            }
            response.setErrorMessage(httpURLConnection.getResponseMessage());
            response.setContentLength(httpURLConnection.getContentLength());
            response.setContentType(httpURLConnection.getContentType());
            if (hasResponseBody(httpURLConnection.getRequestMethod(), responseCode)) {
                InputStream inputStream;
                try {
                    inputStream = httpURLConnection.getInputStream();
                } catch (IOException ioe) {
                    inputStream = httpURLConnection.getErrorStream();
                }
                response.setResponseContent(inputStream);
            }
            response.setHeaderFields(httpURLConnection.getHeaderFields());

            return response;
        }
    }

    private static boolean hasResponseBody(String requestMethod, int responseCode) {
        return requestMethod != BaseRequest.HTTP_GET
                && !(HttpStatus.SC_CONTINUE <= responseCode && responseCode < HttpStatus.SC_OK)
                && responseCode != HttpStatus.SC_NO_CONTENT
                && responseCode != HttpStatus.SC_NOT_MODIFIED;
    }

}
