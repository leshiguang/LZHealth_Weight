package com.lifesense.weidong.lzsimplenetlibs.net.dispatcher;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;
import com.lifesense.weidong.lzsimplenetlibs.file.DownloadRequest;
import com.lifesense.weidong.lzsimplenetlibs.file.DownloadResponse;
import com.lifesense.weidong.lzsimplenetlibs.file.IDownloadRequestCallback;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.ApiInvoker;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.HttpInvoker;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.HttpsInvoker;

import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DefaultApiDispatcher implements ApiDispatcher {

    private final String TAG = getClass().getSimpleName();

    /**
     * 对客户端而言这种线程池理论上不存在风险
     */
    private static ExecutorService service = Executors.newCachedThreadPool();

    private static String DEFAULT_DOMAIN = "https://sports.lifesense.com";

    public static void changeDomain(String newDomain) {
        DEFAULT_DOMAIN = newDomain;
    }

    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private static class ApiDispatcherHolder {
        private static DefaultApiDispatcher defaultApiDispatcher = new DefaultApiDispatcher();

        private static DefaultApiDispatcher getSingleton() {
            return defaultApiDispatcher;
        }
    }

    public static DefaultApiDispatcher sharedInstance() {
        return ApiDispatcherHolder.getSingleton();
    }

    @Override
    public void dispatch(final BaseRequest request, final IRequestCallBack callBack) {
        //默认域名设置
        if (StringUtils.isEmpty(request.getDomain())) {
            request.setDomain(DEFAULT_DOMAIN);
        }
        String className = request.getResponseClassName();
        Class clazz = null;
        BaseResponse response = null;
        try {
            clazz = Class.forName(className);
            response = (BaseResponse) clazz.newInstance();
            response.setmRequest(request);
            if (request instanceof DownloadRequest && response instanceof DownloadResponse && callBack instanceof IDownloadRequestCallback) {
                ((DownloadResponse) response).setFilePath(((DownloadRequest) request).getTarget());
                ((DownloadRequest) request).setOnLoadingListener(new DownloadRequest.OnLoadingListener() {
                    @Override
                    public void onLoading(final long count, final long current) {
                        runOnUIThread(new Runnable() {
                            @Override
                            public void run() {
                                ((IDownloadRequestCallback) callBack).onDownloading((int) (((double) current / count) * 100));
                            }
                        });
                    }
                });
            }
        } catch (Exception e) {
            postRequestError(callBack, 1001, "initialize response instance error, " + e.getMessage(), null);
            return;
        }
        try {
            final ApiInvoker invoker = wrapInvoker(request);
            final BaseResponse finalResponse = response;
            service.execute(new Runnable() {
                @Override
                public void run() {
                    //这里的修改对外层是不可见的（线程可见性）
                    invoker.executeCall(request, finalResponse);
                    if (finalResponse.getmRet() == 200) {
                        Log.i(TAG, "Response 200:" + finalResponse.getContent());
                    } else {
                        Log.i(TAG, "Response " + finalResponse.getmRet() + ":" + finalResponse.getmMsg());
                    }
                    handlerResult(finalResponse, callBack);
                }
            });
        } catch (Exception e) {
            postRequestError(callBack, 1002, "invoke api" + request.getUrl() + " error, " + e.getMessage(), response);
        }
    }

    private void handlerResult(BaseResponse response, IRequestCallBack callBack) {
        if (response.getmRet() == 200) {
            try {
                response.parse();
                if (response.getmRet() == 200) {
                    postRequestSuccess(callBack, response);
                } else {
                    postRequestError(callBack, response.getmRet(),response.getmMsg(),response);
                }
                return;
            } catch (Exception e) {
                postRequestError(callBack, 1003, "response deserizalizer error : " + e.getMessage(), response);
                return;
            }
        }
        postRequestError(callBack, response.getmRet(),response.getmMsg(),response);
    }

    private void postRequestSuccess(final IRequestCallBack callBack, final BaseResponse response) {
        runOnUIThread(new Runnable() {
            @Override
            public void run() {
                if(callBack != null) {
                    callBack.onRequestSuccess(response);
                }
            }
        });
    }

    private void postRequestError(final IRequestCallBack callBack, final int code, final String msg, final BaseResponse response) {
        runOnUIThread(new Runnable() {
            @Override
            public void run() {
                if(callBack != null) {
                    callBack.onRequestError(code, msg, response);
                }
            }
        });
    }

    private void runOnUIThread(Runnable action) {
        mainHandler.post(action);
    }

    private ApiInvoker wrapInvoker(BaseRequest request) {
        ApiInvoker apiInvoker;
        if (request.getDomain().startsWith("https")) {
            apiInvoker = new HttpsInvoker();
        } else {
            apiInvoker = new HttpInvoker();
        }
        return apiInvoker;
    }


}
