package com.lifesense.weidong.lzsimplenetlibs.net.invoker;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class HttpInvoker extends BaseApiInvoker {
    private final String TAG = getClass().getSimpleName();

    @Override
    protected URLConnection getURLConnection(String uri, String method) throws IOException {
        URL url = new URL(uri);
        HttpURLConnection httpsConn = (HttpURLConnection) url.openConnection();
        httpsConn.setRequestMethod(method);
        httpsConn.setDoInput(true);
        httpsConn.setDoOutput(true);
        return httpsConn;
    }
}
