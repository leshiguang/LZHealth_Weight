package com.lifesense.weidong.lzsimplenetlibs.common;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.text.TextUtils;

public class ApplicationHolder {
    private static final String TAG = "ApplicationHolder";
    private static Application mApplication = null;
    private static String mCurrentUserName = null;
    private static int mMaxBitmapWidth = 0;
    private static int mMaxBitmapHeight = 0;
    private static String appVersionName;
    private static String appVersionFullName;

    public static String getApplicationId() {
        if (getmApplication() != null) {
            return getmApplication().getPackageName();
        }
        return "null";
    }

    /**
     * 获得Application
     *
     * @return the mapplication
     */
    public static Application getmApplication() {
        if (mApplication == null) {
        }
        return mApplication;
    }

    private static PackageInfo getPackageInfo(Context context) {
        PackageInfo pi = null;

        try {
            PackageManager pm = context.getPackageManager();
            pi = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_CONFIGURATIONS);

            return pi;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pi;
    }

    /**
     * 设置Application
     *
     * @param mapplication the mapplication to set
     */
    public static void setmApplication(Application mapplication) {
        if (mapplication == null) {
            return;
        }
        if (mapplication != mApplication) {
            mApplication = mapplication;
        }
        if (threadHandler == null) {
            HandlerThread bgThread = new HandlerThread(ApplicationHolder.class.getName());
            bgThread.start();
            threadHandler = new Handler(bgThread.getLooper());//初始化在子线程的handler,
        }
    }

    private static Handler threadHandler;

    private static Handler mainHanlder = new Handler(Looper.getMainLooper());

    /**
     * 运行在工作线程的任务
     *
     * @param runnable
     */
    public static void postWorkerRunnable(Runnable runnable) {
        threadHandler.post(runnable);
    }

    public static Handler getWorkerRunnable() {
        return threadHandler;
    }

    /**
     * 获得当前登录用户名
     * 若未登录则为空
     *
     * @return the mCurrentUserName
     */
    public static String getmCurrentUserName() {
        return mCurrentUserName;
    }

    /**
     * 设置当前登录用户名
     * 方便底层其他代码调用
     *
     * @param mCurrentUserName the mCurrentUserName to set
     */
    public static void setmCurrentUserName(String mCurrentUserName) {
        ApplicationHolder.mCurrentUserName = mCurrentUserName;
    }

    public static Handler getMainHandler() {
        return mainHanlder;
    }

    public static void postMainRunner(Runnable runnable) {
        mainHanlder.post(runnable);
    }

    /**
     * @return the mMaxBitmapWidth
     */
    public static int getmMaxBitmapWidth() {
        return mMaxBitmapWidth;
    }

    /**
     * @param mMaxBitmapWidth the mMaxBitmapWidth to set
     */
    public static void setmMaxBitmapWidth(int mMaxBitmapWidth) {
        if (ApplicationHolder.mMaxBitmapWidth != mMaxBitmapWidth)
            ApplicationHolder.mMaxBitmapWidth = mMaxBitmapWidth;
    }

    /**
     * @return the mMaxBitmapHeight
     */
    public static int getmMaxBitmapHeight() {
        return mMaxBitmapHeight;
    }

    /**
     * @param mMaxBitmapHeight the mMaxBitmapHeight to set
     */
    public static void setmMaxBitmapHeight(int mMaxBitmapHeight) {
        if (ApplicationHolder.mMaxBitmapHeight != mMaxBitmapHeight)
            ApplicationHolder.mMaxBitmapHeight = mMaxBitmapHeight;
    }

    private static String sChannel = null;

    /**
     * 获取application中指定的meta-data
     *
     * @param ctx
     * @param key
     */
    public static String getAppMetaData(Context ctx, String key) {
        if (ctx == null || TextUtils.isEmpty(key)) {
            return null;
        }
        String resultData = null;
        try {
            PackageManager packageManager = ctx.getPackageManager();
            if (packageManager != null) {
                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(ctx.getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo != null) {
                    if (applicationInfo.metaData != null) {
                        resultData = applicationInfo.metaData.getString(key);
                    }
                }

            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return resultData;
    }

    public static String getAppVersionName() {
        String appVersionName = getAppVersionFullName();
        if (appVersionName.contains("(")) {
            appVersionName = appVersionName.split("\\(")[0];
        }

        return appVersionName;
    }

    public static String getAppVersionFullName() {
        if (getmApplication() == null) {
            return "";
        }
        return getPackageInfo(getmApplication(), getmApplication().getPackageName()).versionName;
    }

    protected static PackageInfo getPackageInfo(Context app, String packageName) {
        if (app == null) return null;
        PackageManager packageManager = app.getPackageManager();
        PackageInfo packInfo = null;
        try {
            packInfo = packageManager.getPackageInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
        }
        return packInfo;
    }
}
