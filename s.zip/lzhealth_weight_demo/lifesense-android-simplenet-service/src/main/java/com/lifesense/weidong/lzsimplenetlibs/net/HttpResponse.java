package com.lifesense.weidong.lzsimplenetlibs.net;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class HttpResponse {
//    response.setResponseStatus(httpConn.getResponseCode());
//            response.setContentLength(httpConn.getContentLength());
//            response.setContentType(httpConn.getContentType());
//            response.setHeaderFields(httpConn.getHeaderFields());
    private URL url;
    private int responseStatus;
    private int contentLength;
    private String contentType;
    private Map<String, List<String>> headerFields;
    private String errorMessage;
    private String context;
    private InputStream responseContent;

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public int getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(int responseStatus) {
        this.responseStatus = responseStatus;
    }

    public InputStream getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(InputStream responseContent) {
        this.responseContent = responseContent;
    }

    public int getContentLength() {
        return contentLength;
    }

    public void setContentLength(int contentLength) {
        this.contentLength = contentLength;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Map<String, List<String>> getHeaderFields() {
        return headerFields;
    }

    public void setHeaderFields(Map<String, List<String>> headerFields) {
        this.headerFields = headerFields;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getHeaderField(String key) {
        if(headerFields != null) {
            List<String> headerList =  headerFields.get(key);
            if(headerList != null && headerList.size() > 0) {
                headerList.get(0);
            }
        }
        return null;
    }
    @Override
    public String toString() {
        return "HttpResponse{" +
                "responseStatus=" + responseStatus +
                ", contentLength=" + contentLength +
                ", contentType='" + contentType + '\'' +
                ", headerFields=" + headerFields +
                ", errorMessage='" + errorMessage + '\'' +
                ", context='" + context + '\'' +
                ", responseContent=" + responseContent +
                '}';
    }
}
