package com.lifesense.weidong.lzsimplenetlibs.base;

import android.text.TextUtils;
import android.util.Log;

import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;
import com.lifesense.weidong.lzsimplenetlibs.net.dispatcher.DefaultApiDispatcher;
import com.lifesense.weidong.lzsimplenetlibs.util.RequestCommonParamsUtils;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public abstract class BaseRequest {
    public static final String HTTP_GET = "GET";
    public static final String HTTP_POST = "POST";
    public static final String PROTOCOL_CHARSET = "utf-8";
    public static final String CONTENT_TYPE_JSON = String.format("application/json; charset=%s",
            PROTOCOL_CHARSET);
    protected String requestMethod;
    protected String url;
    protected String mRequestName;
    protected String domain;
    protected Map<String, Object> mDataDict;
    protected Map<String, String> mUrlParams;
    protected Map<String, String> headerParams;

    public enum Method {
        GET("GET"),
        POST("POST");
        private String method;

        Method(String method) {
            this.method = method;
        }

        public String getMethod() {
            return method;
        }
    }

    public BaseRequest() {
        requestMethod = HTTP_POST;
        mDataDict = new HashMap<>();
        mUrlParams = new HashMap<>();
        headerParams = new HashMap<>();
        addCommonParams();
        this.setRequestName(this.getClass().getSimpleName());
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    /**
     * @return the mRequestName
     */
    public String getRequestName() {
        return mRequestName;
    }

    /**
     * @param mRequestName the mRequestName to set
     */
    public void setRequestName(String mRequestName) {
        this.mRequestName = mRequestName;
    }

    /**
     * 获得请求的url，子类可以重写该方法
     *
     * @return
     */
    public String getUrl() {
        if (TextUtils.isEmpty(url)) {
            return getDomain() + getUrlWithoutProtocol();
        }
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public abstract String getUrlWithoutProtocol();

    public abstract String getResponseClassName();

    /**
     * 获取url domain地址默认是读取配置文件
     * 如果有特殊的domain request可以重写该函数，重定向.
     *
     * @return
     */
    public String getDomain() {
        return this.domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    /**
     * 添加url param
     *
     * @param key
     * @param value
     */
    public void addUrlParams(String key, String value) {
        mUrlParams.put(key, value);
    }

    public void addHeaderParams(String key, String value) {
        headerParams.put(key, value);
    }

    public Map<String, String> getHeaderParams() {
        return headerParams;
    }

    public void addCommonParams() {
        RequestCommonParamsUtils.addCommonParams(this);
        mUrlParams.put("requestId", UUID.randomUUID().toString().replace("-", ""));
    }

    public void addStringValue(String key, String value) {
        if (key == null || value == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    public void addValue(String key, Object value) {
        if (key == null || value == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    /**
     * 添加整数值到参数
     *
     * @param key
     * @param value
     */
    public void addIntValue(String key, int value) {
        if (key == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    /**
     * 添加长整数值到参数
     *
     * @param key
     * @param value
     */
    public void addLongValue(String key, Long value) {
        if (key == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    /**
     * 添加双精度浮点值到参数
     *
     * @param key
     * @param value
     */
    public void addDoubleValue(String key, double value) {
        if (key == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    /**
     * 添加布尔值到参数
     *
     * @param key
     * @param value
     */
    public void addBoolValue(String key, boolean value) {
        if (key == null) {
            return;
        }
        this.mDataDict.put(key, value);
    }

    /**
     * 格式化dict到string
     * 默认实现:把mDataDict转换成json结构
     *
     * @return
     */
    public String dictToBody() {
        Set<Map.Entry<String, Object>> entrySet = mDataDict.entrySet();
        org.json.JSONObject jsonObject = new org.json.JSONObject();
        for (Map.Entry<String, Object> entry : entrySet) {
            String key = entry.getKey();
            Object value = entry.getValue();
            try {
                jsonObject.put(key, value);
            } catch (JSONException e) {
                Log.i("JSON_PARSE_ERROR", e.getMessage());
            }
        }
        return jsonObject.toString();
    }

    /**
     * 格式化 mUrlParams
     * 默认实现是key=value
     *
     * @return key=value格式，append到url后面
     */
    public String formatUrlParams() {
        Set<Map.Entry<String, String>> entrySet = mUrlParams.entrySet();
        String url = "";
        for (Map.Entry<String, String> entry : entrySet) {
            String key = entry.getKey();
            String value = entry.getValue();
            try {
                value = URLEncoder.encode(value, PROTOCOL_CHARSET);
                key = URLEncoder.encode(key, PROTOCOL_CHARSET);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            url = appendingKeyValue(url, key, value);
        }
        return url;
    }

    private String appendingKeyValue(String url, String key, String value) {
        if (TextUtils.isEmpty(url)) {
            url = "";
        }
        String dataString = String.format("%s=%s", key, value);
        if (!url.contains("?")) {
            url = String.format("%s?%s", url, dataString);
        } else {
            url = String.format("%s&%s", url, dataString);
        }
        return url;
    }

    /**
     * 如果是get请求，会调用此函数，append到url后面
     *
     * @return
     */
    public String getCustomParamString() {
        if (mDataDict == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        Set<Map.Entry<String, Object>> entrySet = mDataDict.entrySet();
        Iterator<Map.Entry<String, Object>> iterator = entrySet.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Object> entry = iterator.next();
            String key = entry.getKey();
            String value = entry.getValue().toString();
            try {
                value = URLEncoder.encode(value, PROTOCOL_CHARSET);
                key = URLEncoder.encode(key, PROTOCOL_CHARSET);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            sb.append("&").append(key).append("=").append(value);
        }
        return sb.toString();
    }

    public <T extends BaseResponse> void execute(IRequestCallBack<T> callBack) {
        DefaultApiDispatcher.sharedInstance().dispatch(this, callBack);
    }

}
