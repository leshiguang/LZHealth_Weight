package com.lifesense.component.devicemanager.constant;

import android.text.TextUtils;

/**
 * Created by lee on 2016/2/1.
 */
public enum SaleType {
    Unknown,
    InterConnection,   // 乐心互联
    S5Mini,//官方互联体脂称
    S9Fit,//fit秤
    S12Fit;//s12体脂秤


    public static SaleType getSaleType(String model) {
        if (TextUtils.isEmpty(model)) {
            return SaleType.Unknown;
        }

        if (model.equalsIgnoreCase("LS112-B") ||
                model.equalsIgnoreCase("112") || model.contains("LS112-B")
                || model.contains("LS212-B") || model.equalsIgnoreCase("LS213-B1")) {
            return SaleType.InterConnection;
        }
        if (model.equalsIgnoreCase("LS215-B1")) { //先过滤 避免和s9冲突
            return SaleType.S12Fit;
        }
        if (model.contains("LS215-B")) {
            return SaleType.S9Fit;
        }
        if (model.contains("LS213-B")) {
            return SaleType.S5Mini;
        }

        return SaleType.Unknown;
    }
}
