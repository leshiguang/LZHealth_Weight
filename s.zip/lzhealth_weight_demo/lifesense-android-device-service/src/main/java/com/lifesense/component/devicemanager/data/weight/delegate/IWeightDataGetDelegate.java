package com.lifesense.component.devicemanager.data.weight.delegate;

import com.lifesense.component.devicemanager.device.dto.receive.WeightData;

import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 14:20
 * @describe:
 */
public interface IWeightDataGetDelegate {
    void onWeightGetSucceed(List<WeightData> weightDatas);

}
