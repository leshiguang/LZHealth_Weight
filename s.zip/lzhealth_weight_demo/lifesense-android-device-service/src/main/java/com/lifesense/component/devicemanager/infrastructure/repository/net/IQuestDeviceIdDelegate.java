package com.lifesense.component.devicemanager.infrastructure.repository.net;

import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

/**
 * Created by rolandxu on 2017/7/3.
 */

public interface IQuestDeviceIdDelegate extends IRequestCallBack {
    public void onSuccess(String deviceId, String mac);
    public void onFailed(String errmsg, int errcode);
}
