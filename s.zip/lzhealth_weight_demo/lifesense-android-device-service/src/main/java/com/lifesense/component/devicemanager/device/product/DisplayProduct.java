package com.lifesense.component.devicemanager.device.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.alibaba.fastjson.annotation.JSONField;
import com.lifesense.ble.bean.constant.DeviceType;
import com.lifesense.ble.enums.ProtocolType;

import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Transient;

import java.util.ArrayList;
import java.util.List;

/**
 * 展示产品
 */
//@Entity
public class DisplayProduct implements Parcelable {
    @Id(autoincrement = true)
    private Long id;

    private long displayProductId;
    //展示名称
    private String name;
    //展示图片
    private String imageUrl;
    //展示分类,1:手环 2:手表
    //3:智能秤 4:血压计 5:乐心互联
    private int productTypeCode;
    //默认绑定方式,1.二维码，2.sn号，3.蓝牙,4.1597
    private int defaultBindMode;
    //其他绑定方式
    private String otherBindModes;
    //包含的工厂产品
    @Transient
    @JSONField(name = "factoryProducts")
    private List<FactoryProduct> factoryProducts;

    @Generated(hash = 829568006)
    public DisplayProduct(Long id, long displayProductId, String name,
                          String imageUrl, int productTypeCode, int defaultBindMode,
                          String otherBindModes) {
        this.id = id;
        this.displayProductId = displayProductId;
        this.name = name;
        this.imageUrl = imageUrl;
        this.productTypeCode = productTypeCode;
        this.defaultBindMode = defaultBindMode;
        this.otherBindModes = otherBindModes;
    }

    @Generated(hash = 54855621)
    public DisplayProduct() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getDisplayProductId() {
        return this.displayProductId;
    }

    public void setDisplayProductId(long displayProductId) {
        this.displayProductId = displayProductId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getProductTypeCode() {
        return this.productTypeCode;
    }

    public void setProductTypeCode(int productTypeCode) {
        this.productTypeCode = productTypeCode;
    }

    public int getDefaultBindMode() {
        return this.defaultBindMode;
    }

    public void setDefaultBindMode(int defaultBindMode) {
        this.defaultBindMode = defaultBindMode;
    }

    public String getOtherBindModes() {
        return this.otherBindModes;
    }

    public void setOtherBindModes(String otherBindModes) {
        this.otherBindModes = otherBindModes;
    }

    public List<FactoryProduct> getFactoryProducts() {
        return factoryProducts;
    }

    public void setFactoryProducts(List<FactoryProduct> factoryProducts) {
        this.factoryProducts = factoryProducts;
    }

    public DisplayProductType getDisplayProductType(){
        return DisplayProductType.toProductType(productTypeCode);
    }

    public DisplayBindType getDisplayBindType(){
        return DisplayBindType.toDisplayBindType(defaultBindMode);
    }

    /**
     * 获取当前设备类型支持的广播名集合
     * @return
     */
    public List<String> getBroadcastNames() {
        List<String> broadcastNames = new ArrayList<>();
        for (FactoryProduct factoryProduct : this.getFactoryProducts()) {
            String broadcastName = factoryProduct.getBluetoothBroadcastName();
            broadcastNames.add(broadcastName.toUpperCase());
        }
        return broadcastNames;
    }

    /**
     * 根据广播名获取真实显示的名称
     * @param defaultName
     * @return
     */
    public String getFactoryNameByBroadCastName(String defaultName) {
        for (FactoryProduct factoryProduct : this.getFactoryProducts()) {
            if (factoryProduct.getBluetoothBroadcastName().equalsIgnoreCase(defaultName)) {
                return factoryProduct.getName();
            }
        }
        return defaultName;
    }


    //设备配置的协议转成蓝牙sdk的协议
    public ProtocolType getProtocolType() {
        ProtocolType protocolType = ProtocolType.UNKNOWN;
        FactoryProtocol protocal = this.getFactoryProducts().get(0).getFactoryProtocal();
        switch (protocal) {
            case A6:
            case InterConnection:
                protocolType = ProtocolType.A6;
                break;
        }
        return protocolType;
    }

    //转换成蓝牙要搜索的类型
    public List<DeviceType> getDeviceTypes() {
        List<DeviceType> deviceTypes = new ArrayList<>();
        switch (this.getDisplayProductType()){
            case weight:
            case interconnection:
                deviceTypes.add(DeviceType.FAT_SCALE);
                break;
        }
        return deviceTypes;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.id);
        dest.writeLong(this.displayProductId);
        dest.writeString(this.name);
        dest.writeString(this.imageUrl);
        dest.writeInt(this.productTypeCode);
        dest.writeInt(this.defaultBindMode);
        dest.writeString(this.otherBindModes);
        dest.writeTypedList(this.factoryProducts);
    }

    protected DisplayProduct(Parcel in) {
        this.id = (Long) in.readValue(Long.class.getClassLoader());
        this.displayProductId = in.readLong();
        this.name = in.readString();
        this.imageUrl = in.readString();
        this.productTypeCode = in.readInt();
        this.defaultBindMode = in.readInt();
        this.otherBindModes = in.readString();
        this.factoryProducts = in.createTypedArrayList(FactoryProduct.CREATOR);
    }

    public static final Creator<DisplayProduct> CREATOR = new Creator<DisplayProduct>() {
        @Override
        public DisplayProduct createFromParcel(Parcel source) {
            return new DisplayProduct(source);
        }

        @Override
        public DisplayProduct[] newArray(int size) {
            return new DisplayProduct[size];
        }
    };

    @Override
    public String toString() {
        return "DisplayProduct{" +
                "id=" + id +
                ", displayProductId=" + displayProductId +
                ", name='" + name + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", productTypeCode=" + productTypeCode +
                ", defaultBindMode=" + defaultBindMode +
                ", otherBindModes='" + otherBindModes + '\'' +
                ", factoryProducts=" + factoryProducts +
                '}';
    }
}
