package com.lifesense.component.devicemanager.infrastructure.domain.service;


import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.OnDeviceUpgradeListener;
import com.lifesense.ble.bean.constant.DeviceUpgradeStatus;
import com.lifesense.ble.bean.constant.ManagerStatus;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.constant.ErrorCode;
import com.lifesense.component.devicemanager.constant.ErrorMsg;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnCheckUpgradeCallback;
import com.lifesense.component.devicemanager.application.interfaces.listener.UpgradeStateListener;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.GetLastFirmwareResponse;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;
import com.lifesense.component.devicemanager.utils.ObjectConvertTool;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.io.File;

/**
 * Create by qwerty
 * Create on 2020/5/29
 * 设备Ota管理
 **/
public class DeviceOTAService {

    private LsBleManager bleManager = LsBleManager.getInstance();

    private final static int NEWEST_FIRMWARE = 10008;

    public static DeviceOTAService getInstance() {
        return SingleHolder.getSingleton();
    }

    private static class SingleHolder {

        private static DeviceOTAService iDeviceOTAService = new DeviceOTAService();

        private static DeviceOTAService getSingleton() {
            return iDeviceOTAService;
        }
    }

    private DeviceOTAService() {

    }

    /**
     * 检查固件更新
     *
     * @param deviceId
     */
    public void checkFirmwareUpgrade(final String deviceId, final OnCheckUpgradeCallback callBack) {
        runOnBackgroundThread(new Runnable() {
            @Override
            public void run() {
                final Device device = RepositoryRegistry.deviceRepository().get(deviceId);
                DeviceNetManager.getInstance().checkNewFirmware(device, new IRequestCallBack<GetLastFirmwareResponse>() {
                    @Override
                    public void onRequestSuccess(GetLastFirmwareResponse response) {
                        if (callBack == null) {
                            return;
                        }
                        if (response != null && response.getFirmwareInfo() != null) {
                            callBack.onCheckUpgradeSuccess(response.getFirmwareInfo());
                        } else {
                            callBack.onCheckUpgradeFail(response.getmRet(), "No Upgrade!");
                        }
                    }

                    @Override
                    public void onRequestError(int var1, String var2, GetLastFirmwareResponse response) {
                        if (callBack == null) {
                            return;
                        }
                        if (response.getmRet() == NEWEST_FIRMWARE) {
                            callBack.onCheckUpgradeFail(response.getmRet(), "No Upgrade!");
                        } else {
                            callBack.onCheckUpgradeFail(var1, var2);
                        }
                    }
                });
            }
        });
    }

    /**
     * 升级固件
     *
     * @param deviceId
     * @param filePath
     * @param listener
     */
    public void upgradeDevice(final String deviceId, final String filePath, final UpgradeStateListener listener) {
        runOnBackgroundThread(new Runnable() {
            @Override
            public void run() {
                final Device device = RepositoryRegistry.deviceRepository().get(deviceId);
                final File file = new File(filePath);
                if (!checkUpgradeCondition(device, file, listener)) {
                    return;
                }
                postUpgradeStart(listener);
                //为避免设备进入升级流程时，之前建立的数据同步连接未完全断开，因此延时5秒，再执行升级处理
                delay5sRunOnBackgroundThread(new Runnable() {
                    @Override
                    public void run() {
                        onUpgradeDevice(device, file, listener);
                    }
                });
            }
        });
    }

    /**
     * 中断升级
     *
     * @param deviceId
     */
    public void interruptUpgrade(final String deviceId) {
        runOnBackgroundThread(new Runnable() {
            @Override
            public void run() {
                final Device device = RepositoryRegistry.deviceRepository().get(deviceId);
                if(device != null) {
                    bleManager.interruptUpgradeProcess(device.getMacConvert());
                }
            }
        });
    }

    private void onUpgradeDevice(final Device device, File file, final UpgradeStateListener listener) {
        bleManager.interruptUpgradeProcess(device.getMacConvert());
        bleManager.upgradeDeviceFirmware(ObjectConvertTool.device2LsDeviceInfo(device), file, new OnDeviceUpgradeListener() {
            @Override
            public void onDeviceUpgradeStateChange(final String s, DeviceUpgradeStatus deviceUpgradeStatus, final int i) {
                if (deviceUpgradeStatus == DeviceUpgradeStatus.UPGRADE_SUCCESS) {
                    //ota成功后,应保存当前设备的ota状态
                    setOTAStatus(device.getId(), DeviceUpgradeStatus.UPGRADE_SUCCESS);
                    postUpgradeResult(listener, s, i, true);
                } else if (deviceUpgradeStatus == DeviceUpgradeStatus.UPGRADE_FAILURE) {
                    postUpgradeResult(listener, s, i, false);
                } else if (deviceUpgradeStatus == DeviceUpgradeStatus.ENTER_UPGRADE_MODE) {
                    //手环进入升级模式后,应修改当前升级状态为未完成,防止App退出或被系统杀死后,无回调的问题
                    setOTAStatus(device.getId(), DeviceUpgradeStatus.UPGRADE_FAILURE);
                }
            }

            @Override
            public void onDeviceUpgradeProcess(final int i) {
                postUpgradeProgress(listener, i);
            }
        });
    }

    private void setOTAStatus(String deviceId, DeviceUpgradeStatus upgradeStatus) {
        DeviceManagerPreference.setOTAStatus(deviceId, upgradeStatus);
    }

    public DeviceUpgradeStatus isOTASuccess(String deviceId) {
        String upgradeStatusStr = DeviceManagerPreference.getOTAStatus(deviceId);
        //兼容旧App版本所定义的升级失败  "UPGRAGE_FAILURE"
        if (upgradeStatusStr != null && upgradeStatusStr.equalsIgnoreCase("UPGRAGE_FAILURE")) {
            return DeviceUpgradeStatus.UPGRADE_FAILURE;
        }
        return DeviceUpgradeStatus.valueOf(upgradeStatusStr);

    }

    private synchronized boolean canUpdate() {
        return isBleEnable() && bleManager.getLsBleManagerStatus() != ManagerStatus.UPGRADE_FIRMWARE_VERSION;
    }

    private boolean isBleEnable() {
        return bleManager.isOpenBluetooth();
    }

    private void runOnBackgroundThread(Runnable action) {
        Task.execute(action);
    }

    private void runOnMainThread(Runnable action) {
        Task.runOnMainThreadAsync(action);
    }

    private void delay5sRunOnBackgroundThread(Runnable action) {
        Task.handlerPostDelay(action
                , 5000);
    }

    private boolean checkUpgradeCondition(Device device, File file, final UpgradeStateListener listener) {
        if (device == null) {
            postUpgradeResult(listener, ErrorMsg.DEV_NOT_FOUND, ErrorCode.DEVICE_NOT_FOUND, false);
            return false;
        }
        if (!file.exists()) {
            postUpgradeResult(listener, ErrorMsg.FILE_NOT_FOUND, ErrorCode.FILE_NOT_FOUND, false);
            return false;
        }
        return true;
    }

    private void postUpgradeStart(final UpgradeStateListener listener) {
        runOnMainThread(new Runnable() {
            @Override
            public void run() {
                if (listener != null) {
                    listener.onStart();
                }
            }
        });
    }

    private void postUpgradeResult(final UpgradeStateListener listener, final String s, final int i, final boolean success) {
        runOnMainThread(new Runnable() {
            @Override
            public void run() {
                if (listener != null) {
                    listener.onFinish(success, i, s);
                }
            }
        });
    }

    private void postUpgradeProgress(final UpgradeStateListener listener, final int progress) {
        runOnMainThread(new Runnable() {
            @Override
            public void run() {
                if (listener != null) {
                    listener.onProgress(progress);
                }
            }
        });
    }
}
