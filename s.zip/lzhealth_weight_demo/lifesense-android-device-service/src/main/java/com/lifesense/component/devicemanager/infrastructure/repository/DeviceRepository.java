package com.lifesense.component.devicemanager.infrastructure.repository;

import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceDao;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;

import org.apache.commons.collections4.CollectionUtils;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class DeviceRepository extends DefaultDatabaseRepository<Device> {


    @Override
    public Device get(String uniqueKey) {
        Device device = getDaoSession().getDeviceDao().load(uniqueKey.toLowerCase());
        if (device == null) {
            device = getDaoSession().getDeviceDao().load(uniqueKey.toUpperCase());
        }
        return device;
    }

    @Override
    public List<Device> queryByUser(long userId) {
        try {
            QueryBuilder<Device> qb = getDaoSession().getDeviceDao().queryBuilder();
            qb.where(DeviceDao.Properties.UserId.eq(userId),
                    DeviceDao.Properties.Deleted.eq(false))
                    .orderDesc(DeviceDao.Properties.Created);
            return qb.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Device> queryByUniqueIds(List<String> uniqueIds) {
        return null;
    }

    @Override
    public List<Device> queryByUser(long userId, Filter<Device> filter) {
        List<Device> devices = this.queryByUser(userId);
        if (CollectionUtils.isEmpty(devices)) {
            return Collections.emptyList();
        }
        Iterator<Device> iterator = devices.iterator();
        while (iterator.hasNext()) {
            if (!filter.doTest(iterator.next())) {
                iterator.remove();
            }
        }
        return devices;
    }

    @Override
    public void save(Device instance) {
        instance.setUserId(LDAppHolder.getUserId());
        getDaoSession().getDeviceDao().insertOrReplace(instance);

    }

    @Override
    public void save(List<Device> instances) {
        if (CollectionUtils.isNotEmpty(instances)) {
            for (Device device : instances) {
                device.setUserId(LDAppHolder.getUserId());
            }
            getDaoSession().getDeviceDao().insertOrReplaceInTx(instances);
        }
    }

    @Override
    public void update(Device instance) {

    }

    @Override
    public void delete(String uniqueId, long userId) {
        QueryBuilder<Device> qb = getDaoSession().getDeviceDao().queryBuilder();
        qb.where(DeviceDao.Properties.Id.eq(uniqueId))
                .buildDelete()
                .executeDeleteWithoutDetachingEntities();
        DeviceManagerPreference.deleteDevicePreferenceCache(uniqueId);

    }
}
