package com.lifesense.component.devicemanager.data.weight.db;

import com.lifesense.component.devicemanager.device.dto.receive.WeightData;

import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 14:39
 * @describe:
 */
public interface IWeightDataDbInterface {
	/**
	 * 添加蓝牙过来的原始数据
	 * @param weightData
	 */
	void addWeightData(WeightData weightData);

	/**
	 * 设置这笔数据处理过
	 * @param weightDatas
	 */
	void setWeightDataProcessed(List<WeightData> weightDatas);
	void setWeightDataProcessedById(String id);
	void setWeightDataProcessedByIds(List<String> ids);
	/**
	 * 获取未经处理过的原始数据
	 * @return
	 */
	List<WeightData> getUntreatedWeightData();

	/**
	 * 获取未处理过的原始数据个数
	 * @return
	 */
	int getUntreatedWeightDataCount();

	/**
	 * 删除已经处理过，并且是7天前的原始数据。
	 */
	void delete7DayBeforeWeightData();
}
