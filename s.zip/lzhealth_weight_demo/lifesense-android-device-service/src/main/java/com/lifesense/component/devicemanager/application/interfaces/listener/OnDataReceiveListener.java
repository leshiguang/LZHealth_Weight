package com.lifesense.component.devicemanager.application.interfaces.listener;


import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;

/**
 * Created by lee on 2016/1/16.
 */
public interface OnDataReceiveListener {

    void onReceiveWeightData(WeightData data);


    void onDeviceStatusChange(DeviceStatus deviceStatus);





}
