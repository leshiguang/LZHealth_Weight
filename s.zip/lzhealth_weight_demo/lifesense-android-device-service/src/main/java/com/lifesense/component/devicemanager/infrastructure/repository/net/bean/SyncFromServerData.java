package com.lifesense.component.devicemanager.infrastructure.repository.net.bean;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;

import java.util.List;

/**
 * Created by lee on 2016/1/20.
 */
public class SyncFromServerData implements LSJSONSerializable {
    private List<Device> devices;

    private List<DeviceUser> deviceUsers;

    private List<DeviceSetting> deviceSettings;

    private List<DeviceStatus> deviceStatus;

    private long maxTs;

    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }

    public List<DeviceUser> getDeviceUsers() {
        return deviceUsers;
    }

    public void setDeviceUsers(List<DeviceUser> deviceUsers) {
        this.deviceUsers = deviceUsers;
    }

    public List<DeviceSetting> getDeviceSettings() {
        return deviceSettings;
    }

    public void setDeviceSettings(List<DeviceSetting> deviceSettings) {
        this.deviceSettings = deviceSettings;
    }

    public List<DeviceStatus> getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(List<DeviceStatus> deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public long getMaxTs() {
        return maxTs;
    }

    public void setMaxTs(long maxTs) {
        this.maxTs = maxTs;
    }
}
