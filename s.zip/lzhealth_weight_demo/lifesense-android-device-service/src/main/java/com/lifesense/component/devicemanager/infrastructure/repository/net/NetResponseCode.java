package com.lifesense.component.devicemanager.infrastructure.repository.net;

/**
 * 这个错误码要沉下去，UserManager已经有1个了
 * Created by lee on 2016/1/17.
 */
public class NetResponseCode {
    public final static int SUCCESS = 200;
    public final static int PARAM_ERROR1 = 400;    //请求参数格式有误
    public final static int NO_LOGIN = 401;    //客户端未登录
    public final static int NO_PERMISSION = 403;    //无权访问
    public final static int NET_ERROR = 404;//网络异常
    public final static int DATA_CLAIMED = 405;    //该记录已被认领
    public final static int ACCOUNT_PASSWORD_ERROR = 406;    //账号或密码错误
    public final static int USER_EXIST = 409;    //用户已注册
    public final static int AUTH_CODE_ERROR = 412;    //验证码不正确
    public final static int USER_NOT_EXIST = 460;    //用户不存在
    public final static int MOBILE_EXIST = 461;//手机号已存在
    public final static int ACCOUNT_HAS_BIND = 463;    //该账号已绑定
    public final static int ACCOUNT_HAS_NOT_BIND = 464;    //用户尚未绑定手机
    public final static int NOT_BIND_EMAIL = 465;    //用户尚未绑定邮箱
    public final static int LOGIN_ON_OTHER_CLIENT = 466;    //用户已在其他设备登录


    public final static int SERVER_ERROR = 500;    //服务器内部错误
    public final static int SERVER_SAVE_DATA_ERROR = 501;    //服务器数据保存失败
    public final static int NO_LOGIN_OR_TIME_OUT = 506; //用户登录未登录或已超时
    public final static int PARAM_EMPTY = 521;//参数不能为空
    public final static int PARAM_ERROR2 = 5001;//参数格式错误
    public final static int DEVICE_NOT_EXIST = 6001;//设备不存在
    public final static int SERVER_BUSY = 999;//系统繁忙（未知错误）

    public final static int WECHAT_NOT_SUPPORT = 10001;
    public final static int WECHAT_ERROR = 10002;
    public final static int NEWEST_FIRMWARE = 10008;

}
