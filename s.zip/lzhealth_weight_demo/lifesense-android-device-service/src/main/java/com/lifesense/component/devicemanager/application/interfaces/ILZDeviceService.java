package com.lifesense.component.devicemanager.application.interfaces;


import android.content.Context;

import com.lifesense.ble.OnSettingCallBack;
import com.lifesense.ble.bean.constant.HeartRateSwitch;
import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnCheckUpgradeCallback;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDeviceConnectStateListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.UpgradeStateListener;

public interface ILZDeviceService extends ILZDeviceBindService {

    /**
     * 初始化蓝牙SDK
     * @param context
     * @param userId 用户ID
     * @param stateListener 蓝牙设备状态变更监听
     */
    void init(Context context, long userId, OnDeviceConnectStateListener stateListener, OnDataReceiveListener dataReceiveListener);

    /**
     * 获取设备单位
     * @param deviceId
     * @return 单位类型， 默认为KG
     *      @see UnitType
     */
    int getUnit(String deviceId);

    /**
     * 设置体重单位
     * @param deviceId
     * @param unitType
     * @param callBack
     */
    void setUnit(String deviceId, UnitType unitType, OnSettingCallBack callBack);

    /**
     * 检查设备固件更新
     * @param deviceId
     * @param callback
     */
    void checkDeviceFirmwareUpgrade(String deviceId, OnCheckUpgradeCallback callback);

    /**
     * 升级设备
     * @param deviceId
     * @param listener
     */
    void upgradeDeviceFirmware(String deviceId, String filePath, UpgradeStateListener listener);

     /**
     * 中断升级
     * @param deviceId
     */
    public void interruptUpgradeDeviceFirmware(String deviceId);

    /**
     * 设置心率开关
     * @param deviceId
     * @param heartRateSwitch
     * @param onSettingCallBack
     */
    public void setHeartRateSwitch(String deviceId, HeartRateSwitch heartRateSwitch, OnSettingCallBack onSettingCallBack);

    /**
     * 获取心率开关
     * @param deviceId
     * @return
     */
    public int getHeartRateSwitch(String deviceId);
}



