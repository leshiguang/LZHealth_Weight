package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class SetUnitRequest extends BaseRequest {
    private static final String kRequestParam_DeviceId = "deviceId";
    private static final String kRequestParam_Unit = "unit";

    public SetUnitRequest(int unitType,String deviceId) {
        super();
        setRequestMethod(HTTP_POST);
        addStringValue(kRequestParam_DeviceId, deviceId);
        addIntValue(kRequestParam_Unit, unitType);
    }

    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/device_info/setUnit";
    }

    @Override
    public String getResponseClassName() {
        return SetUnitResponse.class.getName();
    }
}
