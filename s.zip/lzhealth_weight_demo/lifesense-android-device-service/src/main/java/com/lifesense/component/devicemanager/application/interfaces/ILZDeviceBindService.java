package com.lifesense.component.devicemanager.application.interfaces;


import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.component.devicemanager.device.product.GetProductListRespond;
import com.lifesense.component.devicemanager.application.interfaces.callback.BindResultCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnResultCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.SearchResultCallback;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.List;

public interface ILZDeviceBindService {


    /**
     * 获取所有允许接入的产品列表
     * @param callback
     */
    void getProduct(IRequestCallBack<GetProductListRespond> callback);

    /**
     * 开始搜索设备，搜索时间大概需要10秒左右
     *
     * @param callback 搜索的回调
     */
    void searchDevice(DisplayProduct displayProduct, SearchResultCallback callback);

    /**
     * 停止搜索
     */
    void stopSearch();

    /**
     * 根据搜索选中的蓝牙设备来绑定；
     *
     * @param lseDeviceInfo
     * @param callback
     */
    void bindDeviceBySearchResult(LSEDeviceInfo lseDeviceInfo, BindResultCallback callback);

    /**
     * 取消搜索绑定流程
     *
     * @param lseDeviceInfo
     */
    void interruptBindDevice(LSEDeviceInfo lseDeviceInfo);

    /**
     * 解绑
     * @param deviceId
     * @param callback
     */
    void unBindDevice(String deviceId, OnResultCallback callback);


    /**
     * 获取用户已绑定的设备列表
     * @return
     */
    List<Device> getBondedDevices();



}
