package com.lifesense.component.devicemanager.component.alive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.lifesense.utils.LSLog;

/**
 * Created by maiweibiao on 16/10/27.
 */

public class ScreenBroadcastReceiver extends BroadcastReceiver {
    private String action = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }

        action = intent.getAction();
        LSLog.i(KeepAliveUtils.TAG, "action = " + action);
        if (Intent.ACTION_SCREEN_ON.equals(action)) {
            KeepAliveUtils.finishKeepAliveActivitys();
        } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {
            KeepAliveActivity.startActivity(context);
        }
    }
}
