package com.lifesense.component.devicemanager.component.alive;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;

import com.lifesense.component.devicemanager.component.service.DeviceKeepAliveService;
import com.lifesense.utils.LSLog;

/**
 * Created by maiweibiao on 16/10/25.
 */

public class CoreService extends GrayService {

    private static final long TIME_INTERVAL = 10 * 60 * 1000L;
    private volatile boolean mIsPolling = false;
    private ScreenBroadcastReceiver mBroadcastReceiver;
    private Handler mHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        startPoll();
        //KeepAliveUtils.setComponentDefault(this, KeepAliveReceiver.class.getName());
        //CoreNotificationService.startService(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CoreJobService.startService(this);
        }
        registerBroadcastReceiver();
        KeepAliveUtils.setCoreServiceAlive(true);
        LSLog.i(KeepAliveUtils.TAG, "CoreService onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(final Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(final Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        ((AlarmManager) getSystemService(Context.ALARM_SERVICE))
                .set(AlarmManager.RTC, System.currentTimeMillis() + 500, PendingIntent
                        .getService(this, 3, new Intent(this, CoreService.class), 0));
    }


    private void startPoll() {
        if (mIsPolling) {
            return;
        }

        mIsPolling = true;

        HandlerThread bgThread = new HandlerThread(CoreService.class.getName());
        bgThread.start();
        mHandler = new Handler(bgThread.getLooper());
        mHandler.postDelayed(backgroundRunnable, TIME_INTERVAL);
    }

    Runnable backgroundRunnable = new Runnable() {
        @Override
        public void run() {
            checkService();
            if (mHandler != null) {
                mHandler.removeCallbacks(backgroundRunnable);
                mHandler.postDelayed(backgroundRunnable, TIME_INTERVAL);
            }
        }
    };

    private void checkService() {
        boolean isAlive = KeepAliveUtils.isServiceWork(CoreService.this, DeviceKeepAliveService.class.getName());
        if (!isAlive) {
            KeepAliveUtils.startDeviceService(CoreService.this);
            LSLog.i(KeepAliveUtils.TAG, "Pull DeviceService");
        }
    }

    private void registerBroadcastReceiver() {
        if (mBroadcastReceiver == null) {
            mBroadcastReceiver = new ScreenBroadcastReceiver();
        }

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mBroadcastReceiver, filter);

    }

    private void unregisterBroadcastReceiver() {
        if (mBroadcastReceiver != null) {
            unregisterReceiver(mBroadcastReceiver);
        }
    }

    public static void startService(Context context) {
        if (context == null || KeepAliveUtils.isCoreServiceAlive()) {
            return;
        }

        Intent intent = new Intent(context, CoreService.class);
        context.startService(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterBroadcastReceiver();
        LSLog.i(KeepAliveUtils.TAG, "CoreService onDestroy");

    }
}
