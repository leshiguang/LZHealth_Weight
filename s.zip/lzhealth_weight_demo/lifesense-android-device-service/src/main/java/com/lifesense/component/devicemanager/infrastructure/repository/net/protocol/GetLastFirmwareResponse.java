package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.alibaba.fastjson.JSON;
import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class GetLastFirmwareResponse extends JsonResponse {
    FirmwareInfo info;

    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
        if (jsonData == null) {
            return;
        }
        info = JSON.parseObject(jsonData.toString(), FirmwareInfo.class);
    }

    public FirmwareInfo getFirmwareInfo(){
        return info;
    }
}
