package com.lifesense.component.devicemanager.infrastructure.repository.database.entity;

import android.os.Parcel;
import android.os.Parcelable;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Property;

import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class DeviceStatus implements Parcelable {

    public final static int NET_GPRS = 1;
    public final static int NET_WIFI = 2;
    public final static int NET_BLUETOOTH = 3;

    @Id
    @Property(nameInDb = "ID")
    private String id;
    @NotNull
    private String deviceId;
    private Date batteryChangeTime;     //电池状态更改时间
    private int battery;
    private int netType;                //通讯类型：1GPRS，2WIFI，3蓝牙
    private boolean online;             //是否在线
    private long statusChangeTime;      //设备状态更新时间
    private Date created;       //数据创建时间
    private long updated;       //数据更新时间
    private boolean uploadFlag; //数据是否已更新到服务器
    private boolean deleted;    //数据是否已删除


    @Generated(hash = 823182436)
    public DeviceStatus(String id, @NotNull String deviceId, Date batteryChangeTime,
                        int battery, int netType, boolean online, long statusChangeTime,
                        Date created, long updated, boolean uploadFlag, boolean deleted) {
        this.id = id;
        this.deviceId = deviceId;
        this.batteryChangeTime = batteryChangeTime;
        this.battery = battery;
        this.netType = netType;
        this.online = online;
        this.statusChangeTime = statusChangeTime;
        this.created = created;
        this.updated = updated;
        this.uploadFlag = uploadFlag;
        this.deleted = deleted;
    }

    @Generated(hash = 1820306817)
    public DeviceStatus() {
    }


    public static DeviceStatus getBatteryStatus(String deviceId, int battery) {
        Date date = new Date(System.currentTimeMillis());
        DeviceStatus deviceStatus = new DeviceStatus();
        deviceStatus.setId(deviceId);
        deviceStatus.setDeviceId(deviceId);
        deviceStatus.setBatteryChangeTime(date);
        deviceStatus.setBattery(battery);
        deviceStatus.setNetType(3);
        deviceStatus.setOnline(true);
        deviceStatus.setStatusChangeTime(date.getTime());
        deviceStatus.setUploadFlag(false);
        deviceStatus.setDeleted(false);
        deviceStatus.setCreated(date);
        return deviceStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Date getBatteryChangeTime() {
        return batteryChangeTime;
    }

    public void setBatteryChangeTime(Date batteryChangeTime) {
        this.batteryChangeTime = batteryChangeTime;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public int getNetType() {
        return netType;
    }

    public void setNetType(int netType) {
        this.netType = netType;
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public long getStatusChangeTime() {
        return statusChangeTime;
    }

    public void setStatusChangeTime(long statusChangeTime) {
        this.statusChangeTime = statusChangeTime;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public long getUpdated() {
        return updated;
    }

    public void setUpdated(long updated) {
        this.updated = updated;
    }

    public void setUploadFlag(boolean uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean getOnline() {
        return this.online;
    }

    public boolean getUploadFlag() {
        return this.uploadFlag;
    }

    public boolean getDeleted() {
        return this.deleted;
    }

    @Override
    public String toString() {
        return "DeviceStatus{" +
                "id='" + id + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", batteryChangeTime=" + batteryChangeTime +
                ", battery=" + battery +
                ", netType=" + netType +
                ", online=" + online +
                ", statusChangeTime=" + statusChangeTime +
                ", created=" + created +
                ", updated=" + updated +
                ", uploadFlag=" + uploadFlag +
                ", deleted=" + deleted +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.deviceId);
        dest.writeLong(this.batteryChangeTime != null ? this.batteryChangeTime.getTime() : -1);
        dest.writeInt(this.battery);
        dest.writeInt(this.netType);
        dest.writeByte(this.online ? (byte) 1 : (byte) 0);
        dest.writeLong(this.statusChangeTime);
        dest.writeLong(this.created != null ? this.created.getTime() : -1);
        dest.writeLong(this.updated);
        dest.writeByte(this.uploadFlag ? (byte) 1 : (byte) 0);
        dest.writeByte(this.deleted ? (byte) 1 : (byte) 0);
    }

    protected DeviceStatus(Parcel in) {
        this.id = in.readString();
        this.deviceId = in.readString();
        long tmpBatteryChangeTime = in.readLong();
        this.batteryChangeTime = tmpBatteryChangeTime == -1 ? null : new Date(tmpBatteryChangeTime);
        this.battery = in.readInt();
        this.netType = in.readInt();
        this.online = in.readByte() != 0;
        this.statusChangeTime = in.readLong();
        long tmpCreated = in.readLong();
        this.created = tmpCreated == -1 ? null : new Date(tmpCreated);
        this.updated = in.readLong();
        this.uploadFlag = in.readByte() != 0;
        this.deleted = in.readByte() != 0;
    }

    public static final Creator<DeviceStatus> CREATOR = new Creator<DeviceStatus>() {
        @Override
        public DeviceStatus createFromParcel(Parcel source) {
            return new DeviceStatus(source);
        }

        @Override
        public DeviceStatus[] newArray(int size) {
            return new DeviceStatus[size];
        }
    };
}
