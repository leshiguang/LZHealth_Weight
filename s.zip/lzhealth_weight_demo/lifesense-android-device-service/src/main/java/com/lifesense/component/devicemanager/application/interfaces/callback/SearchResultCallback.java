package com.lifesense.component.devicemanager.application.interfaces.callback;


import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;

/**
 * Created by Xwei on 2017/3/1/0001.
 */

public interface SearchResultCallback {
    /**
     * 搜索设备的回调
     *
     * @param lseDeviceInfo
     * @param rssi          信号强度 越大信号越强，负数
     */
    void onSearchResult(LSEDeviceInfo lseDeviceInfo, int rssi);
}
