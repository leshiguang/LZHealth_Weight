package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

public class UploadDeviceInformationResponse extends JsonResponse {
    @Override
    protected void parseJsonData(JSONObject jsonObject) throws ProtocolException {

    }
}
