package com.lifesense.component.devicemanager.infrastructure.repository.net.bean;

import com.lifesense.component.devicemanager.device.dto.device.ActiveDeviceInfo;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;

import java.util.List;

/**
 * Created by lee on 2016/1/20.
 */
public class BindRespondData implements LSJSONSerializable {
    Device device;
    DeviceStatus deviceStatus;
    List<DeviceUser> deviceUsers;
    List<DeviceSetting> deviceSettings;
    //活动设备列表
    List<ActiveDeviceInfo> deviceUserExts;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public List<DeviceUser> getDeviceUsers() {
        return deviceUsers;
    }

    public void setDeviceUsers(List<DeviceUser> deviceUsers) {
        this.deviceUsers = deviceUsers;
    }

    public DeviceStatus getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(DeviceStatus deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public List<DeviceSetting> getDeviceSettings() {
        return deviceSettings;
    }

    public void setDeviceSettings(List<DeviceSetting> deviceSettings) {
        this.deviceSettings = deviceSettings;
    }

    public List<ActiveDeviceInfo> getDeviceUserExts() {
        return deviceUserExts;
    }

    public void setDeviceUserExts(List<ActiveDeviceInfo> deviceUserExts) {
        this.deviceUserExts = deviceUserExts;
    }

    @Override
    public String toString() {
        return "BindRespondData{" +
                "device=" + device +
                ", deviceStatus=" + deviceStatus +
                ", deviceUsers=" + deviceUsers +
                ", deviceSettings=" + deviceSettings +
                ", deviceUserExts=" + deviceUserExts +
                '}';
    }
}
