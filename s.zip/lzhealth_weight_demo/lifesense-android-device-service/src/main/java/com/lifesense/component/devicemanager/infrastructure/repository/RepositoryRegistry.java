package com.lifesense.component.devicemanager.infrastructure.repository;

public class RepositoryRegistry {


    private RepositoryRegistry() {

    }


    public static DeviceRepository deviceRepository() {
        return SingletonRepository.getDeviceRepository();
    }


    public static DeviceUserRepository deviceUserRepository() {
        return SingletonRepository.getDeviceUserRepository();
    }

    public static DeviceSettingRepository getDeviceSettingRepository() {
        return SingletonRepository.getDeviceSettingRepository();
    }

    private static class SingletonRepository {
        private static DeviceRepository deviceRepository = new DeviceRepository();

        private static DeviceUserRepository deviceUserRepository = new DeviceUserRepository();

        private static DeviceSettingRepository deviceSettingRepository = new DeviceSettingRepository();

        private static DeviceRepository getDeviceRepository() {
            return deviceRepository;
        }

        private static DeviceUserRepository getDeviceUserRepository() {
            return deviceUserRepository;
        }

        public static DeviceSettingRepository getDeviceSettingRepository() {
            return deviceSettingRepository;
        }
    }
}
