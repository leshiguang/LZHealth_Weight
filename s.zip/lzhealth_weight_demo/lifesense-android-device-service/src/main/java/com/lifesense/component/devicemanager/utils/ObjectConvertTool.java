package com.lifesense.component.devicemanager.utils;

import android.text.TextUtils;
import android.util.Log;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.ble.bean.WeightData_A3;

import com.lifesense.ble.enums.ProtocolType;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.constant.SaleType;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;


/**
 * Created by lee on 2016/1/19.
 */
public class ObjectConvertTool {

    private ObjectConvertTool() {

    }

    public static LsDeviceInfo device2LsDeviceInfo(Device device) {
        LsDeviceInfo deviceInfo = new LsDeviceInfo();
        deviceInfo.setDeviceId(device.getId());
        deviceInfo.setDeviceSn(device.getSn());
        deviceInfo.setDeviceType(device.getProductTypeCode());
        deviceInfo.setModelNumber(device.getModel());
        if (TextUtils.isEmpty(device.getBroadcastId())) {
            deviceInfo.setBroadcastID(device.getMac());
        } else {
            deviceInfo.setBroadcastID(device.getBroadcastId());
        }
        deviceInfo.setHardwareVersion(device.getHardwareVersion());
        deviceInfo.setFirmwareVersion(device.getSoftwareVersion());
        deviceInfo.setMacAddress(device.getMacConvert());
        String softVersion = device.getSoftwareVersion();
        //根据设备类型,设备固件版本与软件版本设置相应的协议类型
        deviceInfo.setProtocolType(ProtocolType.A6.name());
        if (!TextUtils.isEmpty(device.getPassword())) {
            deviceInfo.setPassword(device.getPassword());
        }
        if (TextUtils.isEmpty(deviceInfo.getProtocolType())) {
            Log.e("ObjectConvertTools ", "failed to parse device protocol....");
        }
        return deviceInfo;
    }



    public static WeightData toWeightData(WeightData_A3 data_a3) {
        WeightData weightData = new WeightData();
        weightData.setDeviceId(data_a3.getDeviceId());
        weightData.setUserNo(data_a3.getUserId());
        weightData.setMeasurementTime(data_a3.getUtc());
        weightData.setBattery(data_a3.getBattery());
        weightData.setResistance50k(data_a3.getImpedance());
        weightData.setWeight(data_a3.getWeight());
        showMsg(weightData);
        return weightData;
    }



    public static void showMsg(Object o) {
        String msg = "onReceive" + o.getClass().getSimpleName() + ":" + o.toString();
        DMLog.e(msg);
        LsBleManager.getInstance().setLogMessage(msg);
    }


}
