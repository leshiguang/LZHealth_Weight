package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class UploadWeightRequest extends BaseRequest {

    private static final String kRequestParam_UserId = "userId";
    private static String RECORD_LIST = "recordList";

    public UploadWeightRequest(List<WeightData> weightDataList, long userId) {
        super();
        setRequestMethod(HTTP_POST);
        addLongValue(kRequestParam_UserId, userId);
        JSONArray jsonArray = new JSONArray();
        for (WeightData weightRecord : weightDataList) {
            try {
                JSONObject jsonObject = new JSONObject(JSON.toJSONString(weightRecord));
                jsonObject.remove("measurementDate");
                jsonObject.put("measurementDate", weightRecord.getMeasurementTime());
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                Log.e("ERROR", e.getMessage(), e);
            }
        }
        addValue(RECORD_LIST, jsonArray);

    }
    @Override
    public String getUrlWithoutProtocol() {
        return "/weight_service/weight/syncToServer";
    }

    @Override
    public String getResponseClassName() {
        return UploadWeightResponse.class.getName();
    }
}
