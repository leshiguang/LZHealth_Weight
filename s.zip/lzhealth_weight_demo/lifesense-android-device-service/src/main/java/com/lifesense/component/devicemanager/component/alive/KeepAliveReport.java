package com.lifesense.component.devicemanager.component.alive;


/**
 * Created by maiweibiao on 16/11/2.
 */

public final class KeepAliveReport {

    private static KeepAliveReport mInstance;
    private IDataReport mIDataReport;

    public static KeepAliveReport getInstance() {
        if (mInstance == null) {
            synchronized (KeepAliveReport.class) {
                if (mInstance == null) {
                    mInstance = new KeepAliveReport();
                }
            }
        }

        return mInstance;
    }

    public void setDataReport(IDataReport dataReport) {
        mIDataReport = dataReport;
    }


    public void reportPull() {
        if (mIDataReport != null) {
            mIDataReport.reportPullAlive();
        }
    }


    public interface IDataReport {
        void reportPullAlive();
    }
}
