package com.lifesense.component.devicemanager.constant;

/**
 * Created by lee on 2016/1/28.
 */
public class ErrorCode {


    /**
     * 手机蓝牙被禁用或蓝牙已关闭
     */
    public static final int BLUETOOTH_STATE_DISABLE = com.lifesense.ble.bean.constant.ErrorCode.BlLUETOOTH_DISABLE.getCode();

    /**
     * 设备错误
     */
    public static final int DEVICE_NOT_FOUND = 101;

    /**
     * 文件不存在
     */
    public static final int FILE_NOT_FOUND = 103;

    //ble异常
    public static final int BLE_ABNORMAL = 108;


}
