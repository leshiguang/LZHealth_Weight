package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class GetLastFirmwareRequest extends BaseRequest {
    private static final String kRequestParam_Model = "model";
    private static final String kRequestParam_HardwareVersion = "hardwareVersion";
    private static final String kRequestParam_SoftwareVersion = "softwareVersion";
    private static final String kRequestParam_DeviceId = "deviceId";

    public GetLastFirmwareRequest(Device device){
        super();
        setRequestMethod(HTTP_POST);
        addStringValue(kRequestParam_Model,device.getModel());
        addStringValue(kRequestParam_HardwareVersion,device.getHardwareVersion());
        addStringValue(kRequestParam_SoftwareVersion,device.getSoftwareVersion());
        addStringValue(kRequestParam_DeviceId,device.getId());
    }


    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/device_info/getLastFirmware";
    }

    @Override
    public String getResponseClassName() {
        return GetLastFirmwareResponse.class.getName();
    }
}
