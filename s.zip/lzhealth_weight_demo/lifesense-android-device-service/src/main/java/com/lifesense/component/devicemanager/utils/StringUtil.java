package com.lifesense.component.devicemanager.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by rolandxu on 2017/7/11.
 */

public class StringUtil {
    /**
     * 获取设备的版本
     *
     * @param softwareVersion
     * @return
     */
    public static int getSoftwareVersion(String softwareVersion) {
        int version = 0;
        //检查设备固件版本是为空
        if (softwareVersion != null && softwareVersion.length() >= 4) {
            //截取固件编号
            softwareVersion = softwareVersion.substring(1, 4);
            try {
                version = Integer.parseInt(softwareVersion);
            } catch (Exception e) {
            }
        }
        return version;
    }

    public static String getMacWithoutColon(String mac) {
        return mac.replaceAll(":", "");
    }



    /**
     *   
     *      * 使用java正则表达式去掉多余的.与0  
     *      * @param s  
     *      * @return   
     *      
     */
    @Deprecated
    public static String subZeroAndDot(String s) {
        if (s.indexOf(".") > 0) {
            s = s.replaceAll("0+?$", "");//去掉多余的0    
            s = s.replaceAll("[.]$", "");//如最后一位是.则去掉    
        }
        return s;
    }

    /**
     * 生成16位UUID
     *
     * @return
     */
    public static String genUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }


}
