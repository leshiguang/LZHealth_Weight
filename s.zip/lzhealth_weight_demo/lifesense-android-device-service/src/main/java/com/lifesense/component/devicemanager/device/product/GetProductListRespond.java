package com.lifesense.component.devicemanager.device.product;

import com.alibaba.fastjson.JSON;
import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class GetProductListRespond extends JsonResponse {

	private List<DisplayProductCategory> data;

	public List<DisplayProductCategory> getData() {
		return data;
	}

	public void setData(List<DisplayProductCategory> data) {
		this.data = data;
	}

	@Override
	protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
		if (jsonData == null) {
			return;
		}
		try {
			data = JSON.parseArray(jsonData.getString(PROTOCOL_JSON_KEY_LIST_IN_DATA), DisplayProductCategory.class);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "DisplayProductCategory{" +
				"data=" + data +
				'}';
	}
}
