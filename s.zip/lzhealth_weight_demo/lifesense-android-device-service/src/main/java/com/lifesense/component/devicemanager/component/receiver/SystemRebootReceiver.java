package com.lifesense.component.devicemanager.component.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import com.lifesense.component.devicemanager.context.LDAppHolder;


public class SystemRebootReceiver extends BroadcastReceiver {
    private Handler mBroadcastReceiverHandler = new Handler();
    private static boolean isApplicationStart = false;

    //设置app是否给打开过
    public static void setApplicationStart(boolean state) {
        isApplicationStart = state;
    }


    @Override
    public void onReceive(final Context context, Intent intent) {
        Log.e("sky", "sky-test broadcast >>" + intent);

        if (context == null || intent == null || isApplicationStart) {
            return;
        }
        isApplicationStart = true;
        //判断当前用户的登录状态
        if (LDAppHolder.getUserId() <= 0) {
            Log.e("sky", "sky-test no user >>");

            return;
        }

        //当手机重启或开机后,修改设备的连接模式
        mBroadcastReceiverHandler.post(new Runnable() {
            @Override
            public void run() {
                //启动数据同步服务
                BluetoothStatusChangeTrigger.getInstance().startBluetoothBroadcastReceiver();
            }
        });

    }
}
