package com.lifesense.component.devicemanager.infrastructure.repository.net.bean;

/**
 * JSON序列化接口，仅作为一个标记
 * Created by lee on 2016/8/26.
 */
public interface LSJSONSerializable {
}
