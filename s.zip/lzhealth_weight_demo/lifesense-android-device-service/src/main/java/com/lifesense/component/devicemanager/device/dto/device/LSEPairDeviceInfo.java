package com.lifesense.component.devicemanager.device.dto.device;

/**
 * Created by Xwei on 2017/3/6/0006.
 */

public class LSEPairDeviceInfo {
    private String name;
    private String macAddress;

    public void setName(String name) {
        this.name = name;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getName() {
        return name;
    }

    public String getMacAddress() {
        return macAddress;
    }

    @Override
    public String toString() {
        return "LSEPairDeviceInfo{" +
                "name=" + name +
                ", macAddress='" + macAddress +
                "}";
    }
}
