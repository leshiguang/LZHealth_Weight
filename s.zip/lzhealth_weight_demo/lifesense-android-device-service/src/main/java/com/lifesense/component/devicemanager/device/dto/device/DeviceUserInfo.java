package com.lifesense.component.devicemanager.device.dto.device;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by lee on 2016/2/16.
 */
public class DeviceUserInfo implements Parcelable {

    private static final int DEFAULT_WEIGHT = 65;

    public int sex;//1男，2女
    public long userId;
    public int height;//单位：cm
    public double weight;//单位：kg
    public int age;
    private int targetSteps;
    private float waistline;
    private float goalWeight;

    public DeviceUserInfo() {
        this.sex = 1;
        this.userId = 0;
        this.height = 175;
        this.weight = DEFAULT_WEIGHT;
        this.age = 20;
        this.targetSteps = 6000;
        waistline=80;
    }

    public float getWaistline() {
        return waistline;
    }

    public void setWaistline(float waistline) {
        this.waistline = waistline;
    }

    public float getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(float goalWeight) {
        this.goalWeight = goalWeight;
    }

    public DeviceUserInfo(int sex, long userId, int height, int age, int weight, int targetSteps) {
        this.targetSteps = targetSteps;
//        this.targetSteps = 6000;
        this.sex = sex;
        this.userId = userId;
        this.height = height;
        this.age = age;
        this.weight = weight;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getTargetSteps() {
        return targetSteps;
    }

    public void setTargetSteps(int targetSteps) {
        this.targetSteps = targetSteps * 7;
    }



    @Override
    public String toString() {
        return "DeviceUserInfo{" +
                "sex=" + sex +
                ", userId=" + userId +
                ", height=" + height +
                ", weight=" + weight +
                ", age=" + age +
                ", targetSteps=" + targetSteps +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.sex);
        dest.writeLong(this.userId);
        dest.writeInt(this.height);
        dest.writeDouble(this.weight);
        dest.writeInt(this.age);
        dest.writeInt(this.targetSteps);
        dest.writeFloat(this.waistline);
        dest.writeFloat(this.goalWeight);
    }

    protected DeviceUserInfo(Parcel in) {
        this.sex = in.readInt();
        this.userId = in.readLong();
        this.height = in.readInt();
        this.weight = in.readDouble();
        this.age = in.readInt();
        this.targetSteps = in.readInt();
        this.waistline = in.readFloat();
        this.goalWeight = in.readFloat();
    }

    public static final Parcelable.Creator<DeviceUserInfo> CREATOR = new Parcelable.Creator<DeviceUserInfo>() {
        @Override
        public DeviceUserInfo createFromParcel(Parcel source) {
            return new DeviceUserInfo(source);
        }

        @Override
        public DeviceUserInfo[] newArray(int size) {
            return new DeviceUserInfo[size];
        }
    };
}
