package com.lifesense.component.devicemanager.device.dto.receive;

import android.os.Parcel;
import android.os.Parcelable;

import com.alibaba.fastjson.annotation.JSONField;
import com.lifesense.utils.DateUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by lee on 2016/1/16.
 */
public class MeasureData implements Parcelable {

	protected long userId;//0为找不到匹配用户

	private SimpleDateFormat dateFormat;
	private Date date;

	protected String deviceId;
	@JSONField(name = "id")
	private String dbId;



	protected long measurementTime;//测量时间(s)
	//因为app强烈要求，在健走和跑步、游泳加入这个字段
	protected String deviceMode;

	public MeasureData() {
	}

	public static final Creator<MeasureData> CREATOR = new Creator<MeasureData>() {
		@Override
		public MeasureData createFromParcel(Parcel in) {
			return new MeasureData(in);
		}

		@Override
		public MeasureData[] newArray(int size) {
			return new MeasureData[size];
		}
	};

	public String getDbId() {
        return dbId;
    }

    public MeasureData setDbId(String dbId) {
        this.dbId = dbId;
        return this;
    }
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public long getMeasurementTime() {
		return measurementTime;
	}

	public void setMeasurementTime(long measurementTime) {
		this.measurementTime = measurementTime;
	}

	public String getDeviceMode() {
		return deviceMode;
	}

	public void setDeviceMode(String deviceMode) {
		this.deviceMode = deviceMode;
	}

	protected String formatDate(long time) {
		if (dateFormat == null) {
			dateFormat = DateUtil.getSimpleFormat("[yyyy-MM-dd HH:mm:ss]");
		}
		if (date == null) {
			date = new Date();
		}
		date.setTime(time * 1000);
		return dateFormat.format(date);
	}

	@Override
	public String toString() {
		return "MeasureData{" + "userId=" + userId + ", deviceId='" + deviceId + '\''
				+ ", measurementTime=" + measurementTime + ", deviceMode='" + deviceMode + '\''
				+ '}';
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeLong(this.userId);
		dest.writeSerializable(this.dateFormat);
		dest.writeLong(this.date != null ? this.date.getTime() : -1);
		dest.writeString(this.deviceId);
		dest.writeLong(this.measurementTime);
		dest.writeString(this.deviceMode);
	}

	protected MeasureData(Parcel in) {
		this.userId = in.readLong();
		this.dateFormat = (SimpleDateFormat) in.readSerializable();
		long tmpDate = in.readLong();
		this.date = tmpDate == -1 ? null : new Date(tmpDate);
		this.deviceId = in.readString();
		this.measurementTime = in.readLong();
		this.deviceMode = in.readString();
	}

}
