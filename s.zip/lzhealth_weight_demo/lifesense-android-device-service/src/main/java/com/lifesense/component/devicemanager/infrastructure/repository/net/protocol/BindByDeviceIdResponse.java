package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.alibaba.fastjson.JSON;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.BindRespondData;
import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class BindByDeviceIdResponse extends JsonResponse {

    private BindRespondData mBindRespondData;

    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
        if (jsonData == null) {
            return;
        }
        mBindRespondData = JSON.parseObject(jsonData.toString(), BindRespondData.class);
    }

    public BindRespondData getBindRespondData() {
        return mBindRespondData;
    }
}
