package com.lifesense.component.devicemanager.device.product;

import android.os.Parcel;
import android.os.Parcelable;


import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * 工厂产品
 */
//@Entity
public class FactoryProduct implements Parcelable {

	@Id(autoincrement = true)
	private Long id;
	//产品名称
	private String name;
	//工厂型号
	private String model;
	//工厂产品类型,体重秤("01"),体重脂肪测量仪("02")
	//手环("04"),血糖仪("06")
	//血压计("08"),人体成分分析仪("09"),支付卡("11")
	private String productTypeCode;
	//通讯方式,1:网络,2: WIFI,3:GPRS,4:蓝牙,5:WIFI_GPRS,6: NB_IOT
	private String communicationType;
	//传输协议
	private String transferProtocal;
	//蓝牙广播名字
	private String bluetoothBroadcastName;
	//是否需要随机码
	private boolean randomCode;

	private String serviceUUID;
	//配网方式,通讯方式为wifi时使用
	//0:airkiss 和 Smartlink
	//1:airkiss
	//2:Smartlink
	//3:SmartlinkAndSoftAP(ap配网)
	private int configureManne;

	private long displayProductId;

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeValue(this.id);
		dest.writeString(this.name);
		dest.writeString(this.model);
		dest.writeString(this.productTypeCode);
		dest.writeString(this.communicationType);
		dest.writeString(this.transferProtocal);
		dest.writeString(this.bluetoothBroadcastName);
		dest.writeByte(this.randomCode ? (byte) 1 : (byte) 0);
		dest.writeString(this.serviceUUID);
		dest.writeInt(this.configureManne);
		dest.writeLong(this.displayProductId);
	}

	public Long getId() {
					return this.id;
	}

	public void setId(Long id) {
					this.id = id;
	}

	public String getName() {
					return this.name;
	}

	public void setName(String name) {
					this.name = name;
	}

	public String getModel() {
					return this.model;
	}

	public void setModel(String model) {
					this.model = model;
	}

	public String getProductTypeCode() {
					return this.productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
					this.productTypeCode = productTypeCode;
	}

	public String getCommunicationType() {
					return this.communicationType;
	}

	public void setCommunicationType(String communicationType) {
					this.communicationType = communicationType;
	}

	public String getTransferProtocal() {
					return this.transferProtocal;
	}

	public void setTransferProtocal(String transferProtocal) {
					this.transferProtocal = transferProtocal;
	}

	public String getBluetoothBroadcastName() {
					return this.bluetoothBroadcastName;
	}

	public void setBluetoothBroadcastName(String bluetoothBroadcastName) {
					this.bluetoothBroadcastName = bluetoothBroadcastName;
	}

	public boolean getRandomCode() {
					return this.randomCode;
	}

	public void setRandomCode(boolean randomCode) {
					this.randomCode = randomCode;
	}

	public String getServiceUUID() {
					return this.serviceUUID;
	}

	public void setServiceUUID(String serviceUUID) {
					this.serviceUUID = serviceUUID;
	}

	public int getConfigureManne() {
					return this.configureManne;
	}

	public void setConfigureManne(int configureManne) {
					this.configureManne = configureManne;
	}

	public long getDisplayProductId() {
					return this.displayProductId;
	}

	public void setDisplayProductId(long displayProductId) {
					this.displayProductId = displayProductId;
	}

	public FactoryProduct() {
	}

	protected FactoryProduct(Parcel in) {
		this.id = (Long) in.readValue(Long.class.getClassLoader());
		this.name = in.readString();
		this.model = in.readString();
		this.productTypeCode = in.readString();
		this.communicationType = in.readString();
		this.transferProtocal = in.readString();
		this.bluetoothBroadcastName = in.readString();
		this.randomCode = in.readByte() != 0;
		this.serviceUUID = in.readString();
		this.configureManne = in.readInt();
		this.displayProductId = in.readLong();
	}

	@Generated(hash = 2108781452)
	public FactoryProduct(Long id, String name, String model, String productTypeCode,
									String communicationType, String transferProtocal, String bluetoothBroadcastName,
									boolean randomCode, String serviceUUID, int configureManne,
									long displayProductId) {
					this.id = id;
					this.name = name;
					this.model = model;
					this.productTypeCode = productTypeCode;
					this.communicationType = communicationType;
					this.transferProtocal = transferProtocal;
					this.bluetoothBroadcastName = bluetoothBroadcastName;
					this.randomCode = randomCode;
					this.serviceUUID = serviceUUID;
					this.configureManne = configureManne;
					this.displayProductId = displayProductId;
	}

	public static final Creator<FactoryProduct> CREATOR = new Creator<FactoryProduct>() {
		@Override
		public FactoryProduct createFromParcel(Parcel source) {
			return new FactoryProduct(source);
		}

		@Override
		public FactoryProduct[] newArray(int size) {
			return new FactoryProduct[size];
		}
	};

	public FactoryProtocol getFactoryProtocal(){
		return FactoryProtocol.toFactoryProtocal(transferProtocal);
	}
    @Override
    public String toString() {
        return "FactoryProduct{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", model='" + model + '\'' +
                ", productTypeCode='" + productTypeCode + '\'' +
                ", communicationType='" + communicationType + '\'' +
                ", transferProtocal='" + transferProtocal + '\'' +
                ", bluetoothBroadcastName='" + bluetoothBroadcastName + '\'' +
                ", randomCode=" + randomCode +
                ", serviceUUID='" + serviceUUID + '\'' +
                ", configureManne=" + configureManne +
                ", displayProductId=" + displayProductId +
                '}';
    }
}
