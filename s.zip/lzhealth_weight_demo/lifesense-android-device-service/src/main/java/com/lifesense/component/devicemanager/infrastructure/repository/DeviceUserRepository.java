package com.lifesense.component.devicemanager.infrastructure.repository;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUserDao;

import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

public class DeviceUserRepository extends DefaultDatabaseRepository<DeviceUser> {
    @Override
    public DeviceUser get(String uniqueKey) {
        return null;
    }

    @Override
    public List<DeviceUser> queryByUser(long userId) {
        try {
            QueryBuilder<DeviceUser> qb = getDaoSession().getDeviceUserDao().queryBuilder();
            qb.where(DeviceUserDao.Properties.UserId.eq(userId),
                    DeviceUserDao.Properties.Deleted.eq(false))
                    .orderDesc(DeviceUserDao.Properties.Created);
            return qb.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<DeviceUser> queryByUniqueIds(List<String> uniqueIds) {
        return null;
    }

    @Override
    public List<DeviceUser> queryByUser(long userId, Filter<DeviceUser> filter) {
        return null;
    }

    @Override
    public void save(DeviceUser instance) {

    }

    public List<DeviceUser> queryByDeviceId(String deviceId) {
        try {
            QueryBuilder<DeviceUser> qb = getDaoSession().getDeviceUserDao().queryBuilder();
            qb.where(DeviceUserDao.Properties.DeviceId.eq(deviceId),
                    DeviceUserDao.Properties.Deleted.eq(false))
                    .orderDesc(DeviceUserDao.Properties.Created);
            return qb.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void save(List<DeviceUser> instances) {
        getDaoSession().getDeviceUserDao().insertOrReplaceInTx(instances);
    }

    @Override
    public void update(DeviceUser instance) {

    }

    @Override
    public void delete(String uniqueId, long userId) {
        QueryBuilder<DeviceUser> qb = getDaoSession().getDeviceUserDao().queryBuilder();
        qb.where(DeviceUserDao.Properties.DeviceId.eq(uniqueId))
                .buildDelete()
                .executeDeleteWithoutDetachingEntities();
    }
}
