package com.lifesense.component.devicemanager.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.lifesense.ble.bean.WeightUserInfo;
import com.lifesense.ble.bean.constant.DeviceUpgradeStatus;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.device.dto.device.DeviceUserInfo;
import com.lifesense.foundation.ApplicationHolder;

/**
 * Created by lee on 2016/1/17.
 */
public class DeviceManagerPreference {

    private static final String FILE_NAME = "_device_manager.cfg";
    private static final String OTA_FILE = "ota.cfg";
    private static final String MAX_TS = "maxTs";
    private static final String USER_INFO = "userInfo";
    private static final String CRASH_FILE_NAME = "crash_file_name";
    private static final String A6_DEVICE_USER_INFO = "a6_device_user_info";



    private DeviceManagerPreference() {
    }

    public static void saveMaxTs(long managerId, long value) {
        saveProperty(managerId + MAX_TS, value);
    }

    public static void saveUserInfo(DeviceUserInfo userInfo) {
        saveProperty(USER_INFO, JSON.toJSONString(userInfo));
    }

    public static DeviceUserInfo readUserInfo() {
        String userInfo = readStringProperty(USER_INFO);
        if (TextUtils.isEmpty(userInfo)) {
            return new DeviceUserInfo();
        }
        return JSON.parseObject(userInfo, DeviceUserInfo.class);
    }
    public static WeightUserInfo readLastSetWeightUserInfo(String deviceId){
        String weightUserInfo=readStringProperty(deviceId+A6_DEVICE_USER_INFO);
        if (TextUtils.isEmpty(weightUserInfo)) {
            return new WeightUserInfo();
        }
        return JSON.parseObject(weightUserInfo, WeightUserInfo.class);
    }

    public static void saveLastSetWeightUserInfo(String deviceId, WeightUserInfo weightUserInfo) {
        saveProperty(deviceId + A6_DEVICE_USER_INFO, JSON.toJSONString(weightUserInfo));
    }

    public static void deleteDevicePreferenceCache(String deviceId) {
        saveProperty(deviceId + A6_DEVICE_USER_INFO, "");
    }

    public static long readMaxTs(long managerId) {
        return readLongProperty(managerId + MAX_TS);
    }

    public static void saveFileName() {
        saveProperty(CRASH_FILE_NAME, getFileName());
    }

    public static String readFileName() {
        return readStringProperty(CRASH_FILE_NAME, "BleLog");
    }


    public static synchronized void saveProperty(String key, String value) {
        SharedPreferences.Editor editor = getSharedPreferences().edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static synchronized String readStringProperty(String key, String defaultVal) {
        return getSharedPreferences().getString(key, defaultVal);
    }

    public static synchronized String readStringProperty(String key) {
        return readStringProperty(key, "");
    }


    public static synchronized void saveProperty(String key, long value) {
        SharedPreferences.Editor editor = getSharedPreferences().edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public static synchronized long readLongProperty(String key) {
        return getSharedPreferences().getLong(key, 0);
    }


    private static SharedPreferences getSharedPreferences() {
        return getSharedPreferences(LDAppHolder.getUserId() + FILE_NAME);
    }

    private static SharedPreferences getSharedPreferences(String file) {
        return ApplicationHolder.getmApplication().getSharedPreferences(file, Context.MODE_PRIVATE);
    }

    public static String getOTAStatus(String deviceId) {
        return getSharedPreferences(OTA_FILE).getString(deviceId, DeviceUpgradeStatus.UNKNOWN.toString());
    }

    public static void setOTAStatus(String deviceId, DeviceUpgradeStatus upgradeStatus) {
//      SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        /**
         * 修复记录,由于保存设备ota状态与读取ota状态所用的sharedPreference对应的key不致,导致取出来的状态有问题
         * 原保存所用的key是FILE_NAME,读取时用的key是OTA_FILE
         */
        SharedPreferences.Editor editor = getSharedPreferences(OTA_FILE).edit();
        editor.putString(deviceId, upgradeStatus.toString());
        editor.apply();
    }

    private static String getFileName() {
        return "[id=" + LDAppHolder.getUserId() + "]";
    }
}
