package com.lifesense.component.devicemanager.application.interfaces.listener;


import com.lifesense.ble.bean.constant.DeviceConnectState;

/**
 * Created by lee on 2016/1/19.
 */
public interface OnDeviceConnectStateListener {
    void onDeviceConnectStateChange(String mac, DeviceConnectState state);
}
