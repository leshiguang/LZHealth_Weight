package com.lifesense.component.devicemanager.device.dto.device;

import android.os.Parcel;
import android.os.Parcelable;

import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.component.devicemanager.device.product.FactoryProtocol;

/**
 * Created by Xwei
 * on 2017/3/6/0006.
 */

public class LSEDeviceInfo implements Parcelable {
    //设备的硬件地址
    private String macAddress;
    // 设备名称
    private String deviceName;
    //协议类型，A2表示使用A2协议的设备，A3表示使用A3协议的类型
    private FactoryProtocol protocolType;
    //乐心设备特有字段
    private LsDeviceInfo lsDeviceInfo;

    private byte[] scanRecord;

    public LSEDeviceInfo(DisplayProduct displayProduct, String macAddress, String deviceName, byte[] scanRecord) {
        this.macAddress = macAddress;
        this.deviceName = deviceName;
        this.protocolType = displayProduct.getFactoryProducts().get(0).getFactoryProtocal();
        this.scanRecord = scanRecord;
    }

    public LSEDeviceInfo(DisplayProduct displayProduct, LsDeviceInfo lsDeviceInfo) {
        this.macAddress = lsDeviceInfo.getMacAddress();
        this.deviceName = lsDeviceInfo.getDeviceName();
        this.protocolType = displayProduct.getFactoryProducts().get(0).getFactoryProtocal();
        this.lsDeviceInfo = lsDeviceInfo;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public String getDeviceId() {
        return lsDeviceInfo.getDeviceId();
    }

    public FactoryProtocol getProtocolType() {
        return protocolType;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public LsDeviceInfo getLsDeviceInfo() {
        return lsDeviceInfo;
    }

    public byte[] getScanRecord() {
        return scanRecord;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.macAddress);
        dest.writeString(this.deviceName);
        dest.writeInt(this.protocolType == null ? -1 : this.protocolType.ordinal());
        dest.writeParcelable(this.lsDeviceInfo, flags);
        dest.writeByteArray(this.scanRecord);
    }

    protected LSEDeviceInfo(Parcel in) {
        this.macAddress = in.readString();
        this.deviceName = in.readString();
        int tmpProtocolType = in.readInt();
        this.protocolType = tmpProtocolType == -1 ? null : FactoryProtocol.values()[tmpProtocolType];
        this.lsDeviceInfo = in.readParcelable(LsDeviceInfo.class.getClassLoader());
        this.scanRecord = in.createByteArray();
    }

    public static final Parcelable.Creator<LSEDeviceInfo> CREATOR = new Parcelable.Creator<LSEDeviceInfo>() {
        @Override
        public LSEDeviceInfo createFromParcel(Parcel source) {
            return new LSEDeviceInfo(source);
        }

        @Override
        public LSEDeviceInfo[] newArray(int size) {
            return new LSEDeviceInfo[size];
        }
    };
}
