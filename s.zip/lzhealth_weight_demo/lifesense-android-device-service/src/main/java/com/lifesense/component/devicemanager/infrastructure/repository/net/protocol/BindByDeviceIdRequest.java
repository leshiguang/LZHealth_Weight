package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class BindByDeviceIdRequest extends BaseRequest {
    private static final String kRequestParam_DeviceId = "deviceId";
    private static final String kRequestParam_UserId = "userId";

    public BindByDeviceIdRequest(String deviceId,long userId){
        super();
        setRequestMethod(HTTP_POST);
        addStringValue(kRequestParam_DeviceId,deviceId);
        addLongValue(kRequestParam_UserId,userId);
    }


    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/device_user/bind_by_deviceid";
    }

    @Override
    public String getResponseClassName() {
        return BindByDeviceIdResponse.class.getName();
    }
}
