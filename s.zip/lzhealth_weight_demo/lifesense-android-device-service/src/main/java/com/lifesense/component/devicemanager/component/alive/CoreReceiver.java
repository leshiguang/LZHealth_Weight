package com.lifesense.component.devicemanager.component.alive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by maiweibiao on 16/10/25.
 */

public class CoreReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }

        CoreService.startService(context);
    }
}
