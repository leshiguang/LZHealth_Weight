package com.lifesense.component.devicemanager.application.interfaces.listener;


import com.lifesense.ble.bean.constant.DeviceConnectState;

/**
 * Created by lee on 2016/2/2.
 */
public interface DeviceConnectionListener {
    void onConnectionState(DeviceConnectState state);
}
