package com.lifesense.component.devicemanager.component.alive;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;

import com.lifesense.component.devicemanager.component.service.DeviceKeepAliveService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by maiweibiao on 16/10/26.
 */

public class KeepAliveUtils {

    public static final String TAG = "KeepAliveUtils";

    private static volatile boolean isCoreServiceAlive = false;
    private static List<AppCompatActivity> sKeepAliveActivitys = new ArrayList<>();

    public static boolean isServiceWork(Context mContext, String serviceName) {
        ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningServiceInfo> list = am.getRunningServices(Integer.MAX_VALUE);
        if (list == null || list.isEmpty()) {
            return false;
        }

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == null || list.get(i).service == null) {
                continue;
            }

            String mName = list.get(i).service.getClassName();
            if (serviceName.equals(mName)) {
                return true;
            }
        }

        return false;
    }

    public static void setComponentDefault(Context context, String componentClassName) {
        PackageManager pm = context.getPackageManager();
        ComponentName componentName = new ComponentName(context.getPackageName(), componentClassName);
        pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DEFAULT, PackageManager.DONT_KILL_APP);
    }

    public static void addKeepAliveActivitys(AppCompatActivity activity) {
        if (activity == null) {
            return;
        }

        sKeepAliveActivitys.add(activity);

    }

    public static void removeKeepAliveActivitys(AppCompatActivity activity) {
        sKeepAliveActivitys.remove(activity);
    }

    public static void finishKeepAliveActivitys() {
        for (int i = 0; i < sKeepAliveActivitys.size(); i++) {
            sKeepAliveActivitys.get(i).finish();
        }
        sKeepAliveActivitys.clear();
    }

    public static void setCoreServiceAlive(boolean isAlive) {
        isCoreServiceAlive = isAlive;
    }

    public static boolean isCoreServiceAlive() {
        return isCoreServiceAlive;
    }

    public static void stopAllKeepAlive(Context context) {
        Intent intent = new Intent(context, CoreService.class);
        context.stopService(intent);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            intent = new Intent(context, CoreJobService.class);
            context.stopService(intent);
        }

        //intent = new Intent(context, CoreNotificationService.class);
        //context.stopService(intent);

    }

    public static void startDeviceService(Context context) {
        Intent intent = new Intent(context, DeviceKeepAliveService.class);
        intent.putExtra(DeviceKeepAliveService.INTENT_FROM, DeviceKeepAliveService.INTENT_FROM_KEEPALIVE);
        context.startService(intent);
        DeviceServiceReport.report();
    }


}
