package com.lifesense.component.devicemanager.device.settings.config;

/**
 * Created by lee on 2016/1/28.
 */
public class WiFiCfg {
    private String ssid;

    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    @Override
    public String toString() {
        return "WiFiCfg{" +
                "ssid='" + ssid + '\'' +
                '}';
    }
}
