package com.lifesense.component.devicemanager.infrastructure.repository.database.entity;

import android.os.Parcel;
import android.os.Parcelable;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Keep;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Property;

import java.util.Calendar;
import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class DeviceUser implements Parcelable {

    @Id
    @Property(nameInDb = "ID")
    private String id;
    private String deviceId;
    @NotNull
    private Long userId;
    private int userNo;
    private String nickname;        //昵称
    private Date birthday;
    private int sex;
    private double weight;
    private double height;
    private String headimg;     //头像url
    private Date created;       //数据创建时间
    private long updated;       //数据更新时间
    private boolean uploadFlag; //数据是否已更新到服务器
    private boolean deleted;    //数据是否已删除

    @Generated(hash = 1507738183)
    public DeviceUser(String id, String deviceId, @NotNull Long userId, int userNo,
                      String nickname, Date birthday, int sex, double weight, double height,
                      String headimg, Date created, long updated, boolean uploadFlag,
                      boolean deleted) {
        this.id = id;
        this.deviceId = deviceId;
        this.userId = userId;
        this.userNo = userNo;
        this.nickname = nickname;
        this.birthday = birthday;
        this.sex = sex;
        this.weight = weight;
        this.height = height;
        this.headimg = headimg;
        this.created = created;
        this.updated = updated;
        this.uploadFlag = uploadFlag;
        this.deleted = deleted;
    }

    @Generated(hash = 846503461)
    public DeviceUser() {
    }

    public boolean isMale() {
        return this.sex == 1;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public int getUserNo() {
        return userNo;
    }

    public void setUserNo(int userNo) {
        this.userNo = userNo;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getHeadimg() {
        return headimg;
    }

    public void setHeadimg(String headimg) {
        this.headimg = headimg;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public long getUpdated() {
        return updated;
    }

    public void setUpdated(long updated) {
        this.updated = updated;
    }

    public void setUploadFlag(boolean uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean getUploadFlag() {
        return this.uploadFlag;
    }

    public boolean getDeleted() {
        return this.deleted;
    }
    private static final int DEFAULT_AGE = 40;

    @Keep
    public int getAge() {
        int age = DEFAULT_AGE;
        Calendar born = Calendar.getInstance();
        Calendar now = Calendar.getInstance();
        if (birthday != null) {
            now.setTime(new Date());
            born.setTime(birthday);
            if (born.after(now)) {
                return DEFAULT_AGE;
            }
            age = now.get(Calendar.YEAR) - born.get(Calendar.YEAR);
            if (now.get(Calendar.DAY_OF_YEAR) < born.get(Calendar.DAY_OF_YEAR)) {
                age -= 1;
            }
        }
        return age;
    }
    @Override
    public String toString() {
        return "DeviceUser{" +
                "id='" + id + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", userId=" + userId +
                ", userNo=" + userNo +
                ", nickname='" + nickname + '\'' +
                ", birthday=" + birthday +
                ", sex=" + sex +
                ", weight=" + weight +
                ", height=" + height +
                ", headimg='" + headimg + '\'' +
                ", created=" + created +
                ", updated=" + updated +
                ", uploadFlag=" + uploadFlag +
                ", deleted=" + deleted +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.deviceId);
        dest.writeValue(this.userId);
        dest.writeInt(this.userNo);
        dest.writeString(this.nickname);
        dest.writeLong(this.birthday != null ? this.birthday.getTime() : -1);
        dest.writeInt(this.sex);
        dest.writeDouble(this.weight);
        dest.writeDouble(this.height);
        dest.writeString(this.headimg);
        dest.writeLong(this.created != null ? this.created.getTime() : -1);
        dest.writeLong(this.updated);
        dest.writeByte(this.uploadFlag ? (byte) 1 : (byte) 0);
        dest.writeByte(this.deleted ? (byte) 1 : (byte) 0);
    }

    protected DeviceUser(Parcel in) {
        this.id = in.readString();
        this.deviceId = in.readString();
        this.userId = (Long) in.readValue(Long.class.getClassLoader());
        this.userNo = in.readInt();
        this.nickname = in.readString();
        long tmpBirthday = in.readLong();
        this.birthday = tmpBirthday == -1 ? null : new Date(tmpBirthday);
        this.sex = in.readInt();
        this.weight = in.readDouble();
        this.height = in.readDouble();
        this.headimg = in.readString();
        long tmpCreated = in.readLong();
        this.created = tmpCreated == -1 ? null : new Date(tmpCreated);
        this.updated = in.readLong();
        this.uploadFlag = in.readByte() != 0;
        this.deleted = in.readByte() != 0;
    }

    public static final Creator<DeviceUser> CREATOR = new Creator<DeviceUser>() {
        @Override
        public DeviceUser createFromParcel(Parcel source) {
            return new DeviceUser(source);
        }

        @Override
        public DeviceUser[] newArray(int size) {
            return new DeviceUser[size];
        }
    };
}
