package com.lifesense.component.devicemanager.application.interfaces;

public interface ILZDeviceSyncService {

    /**
     * 停止接收数据
     * @return
     */
    boolean stopDataReceive();

    /**
     * 开始接收数据
     */
    void startDataReceive();

    /**
     * 重启接收数据服务， 一般用于设备变更， 蓝牙权限、状态变更等
     */
    void restartDataReceive();
}
