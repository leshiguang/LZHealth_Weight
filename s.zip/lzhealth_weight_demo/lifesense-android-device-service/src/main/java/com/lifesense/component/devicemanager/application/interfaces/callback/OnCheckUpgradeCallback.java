package com.lifesense.component.devicemanager.application.interfaces.callback;

import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;

public interface OnCheckUpgradeCallback {
    void onCheckUpgradeSuccess(FirmwareInfo firmwareInfo);

    void onCheckUpgradeFail(int code, String msg);
}