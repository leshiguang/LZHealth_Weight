package com.lifesense.component.devicemanager.infrastructure.repository.database.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.ble.enums.ProtocolType;
import com.lifesense.component.devicemanager.device.dto.product.PdctProertyValue;
import com.lifesense.component.devicemanager.device.dto.product.ProductProperty;
import com.lifesense.component.devicemanager.constant.SaleType;
import com.lifesense.component.devicemanager.device.settings.function.LSDeviceFunction;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.LSJSONSerializable;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Keep;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Transient;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class Device implements LSJSONSerializable, Parcelable {


    public final static int COMM_BLE = 4;


    public final static String PRODUCT_FAT_SCALE = "02";


    @Id
    @Property(nameInDb = "ID")
    private String id;
    private String name;
    private String sn;
    private String sn8;
    private String qrcode;
    private String mac;
    private String protocolType;        //协议类型
    private String broadcastId;
    private String picture;
    private String productTypeCode;     //产品类型：体重秤("01"),脂肪秤("02"), 手环("04"), 血糖仪("06"), 血压计("08")
    private int communicationType;      //设备通讯类型：网络(1), WIFI(2), GPRS(3), 蓝牙(4), WIFI_GPRS(5)
    private int maxUserQuantity;        //允许最大用户数
    private String hardwareVersion;     //硬件版本号
    private String softwareVersion;     //软件版本号
    private String password;
    private String model;               //工厂型号
    private String salesModel;          //销售信号
    private String imsi;
    private int battery;                //电池电量（0-100）
    private boolean sleepSupport;       //是否支持睡眠
    private String imgUrl;
    private String bindTime;            //设备的绑定时间
    @JSONField(serialize = false)
    private String productProperties;        //设备产品属性信息
    private String venderId;            //产商ID
    private Integer isActive = 1;       //设备是否是数据来源（激活的设备）1-激活，0-非激活
    private Date lastDataTime;          //最后同步数据时间，单位ms
    private Boolean isForeign;          //是否是国际版
    @JSONField(serialize = false)
    private String simpleName;          //简单名字
    private Date created;               //数据创建时间
    private long updated;               //数据更新时间
    private boolean uploadFlag;         //数据是否已更新到服务器
    private boolean deleted;            //数据是否已删除
    private String operationGuide;      //操作指南
    private Long userId; //用户ID

    @Keep
    @Generated(hash = 1469582394)
    public Device() {
    }

    public Device(String id) {
        this.id = id;
    }

    public String getMacConvert() {
        if (!TextUtils.isEmpty(mac)) {
            try {
                StringBuilder sb = new StringBuilder(mac);
                for (int i = 2; i < sb.length(); i += 2) {
                    sb.insert(i, ':');
                    ++i;
                }
                return sb.toString();
            } catch (Exception e) {
                Log.e("GET_MAC_CONVERT_ERROR", e.getMessage());
            }
        }
        return null;
    }

    public List<PdctProertyValue> getDialProperties() {
        if (TextUtils.isEmpty(productProperties)) {
            return null;
        }
        List<ProductProperty> list = JSON.parseArray(productProperties, ProductProperty.class);
        List<PdctProertyValue> properties = new ArrayList<>();
        for (ProductProperty property : list) {
            if (property.getKey() == 1) {
                PdctProertyValue pdctProertyValue = JSON.parseObject(property.getValue(), PdctProertyValue.class);
                if (pdctProertyValue != null) {
                    properties.add(pdctProertyValue);
                }
            }
        }
        return properties;
    }


    public SaleType getSaleType() {
        return SaleType.getSaleType(model);
    }

    public boolean isWeight() {
        return !TextUtils.isEmpty(productTypeCode) && productTypeCode.equals(PRODUCT_FAT_SCALE);
    }

    public boolean isFatScale() {
        return !TextUtils.isEmpty(productTypeCode) && productTypeCode.equals(PRODUCT_FAT_SCALE);
    }

    public boolean isBluetooth() {
        return communicationType == COMM_BLE;
    }

    //是否是国际版
    public boolean isForeign() {
        if (isForeign == null) {
            return false;
        }
        return isForeign;
    }

    @Keep
    @Transient
    private LSDeviceFunction mLSDeviceFunction;

    public LSDeviceFunction getFunction() {
        if (mLSDeviceFunction == null) {
            mLSDeviceFunction = LSDeviceFunction.getInstance(this);
        }
        return mLSDeviceFunction;
    }

    public boolean hasChangeInfo(LsDeviceInfo deviceInfo) {
        boolean hasChanged = false;
        if (TextUtils.isEmpty(softwareVersion) || !softwareVersion.equals(deviceInfo.getFirmwareVersion())) {
            if (!TextUtils.isEmpty(deviceInfo.getFirmwareVersion())) {
                hasChanged = true;
                softwareVersion = deviceInfo.getFirmwareVersion();
            }
        }

        if (TextUtils.isEmpty(hardwareVersion) || !hardwareVersion.equals(deviceInfo.getHardwareVersion())) {
            if (!TextUtils.isEmpty(deviceInfo.getHardwareVersion())) {
                hasChanged = true;
                hardwareVersion = deviceInfo.getHardwareVersion();
            }
        }

        if (!uploadFlag || hasChanged) {
            hasChanged = true;
            uploadFlag = false;
        }
        return hasChanged;
    }

    /**
     * 是否是活跃设备
     *
     * @return
     */
    @JSONField(serialize = false)
    public boolean isActive() {
        if (isActive == null)
            return true;
        return isActive == 1;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getSn8() {
        return sn8;
    }

    public void setSn8(String sn8) {
        this.sn8 = sn8;
    }

    public String getQrcode() {
        return qrcode;
    }

    public void setQrcode(String qrcode) {
        this.qrcode = qrcode;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(String protocolType) {
        this.protocolType = protocolType;
    }

    public String getBroadcastId() {
        return broadcastId;
    }

    public void setBroadcastId(String broadcastId) {
        this.broadcastId = broadcastId;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getProductTypeCode() {
        return productTypeCode;
    }

    public void setProductTypeCode(String productTypeCode) {
        this.productTypeCode = productTypeCode;
    }

    public int getCommunicationType() {
        return communicationType;
    }

    public void setCommunicationType(int communicationType) {
        this.communicationType = communicationType;
    }

    public int getMaxUserQuantity() {
        return maxUserQuantity;
    }

    public void setMaxUserQuantity(int maxUserQuantity) {
        this.maxUserQuantity = maxUserQuantity;
    }

    public String getHardwareVersion() {
        return hardwareVersion;
    }

    public void setHardwareVersion(String hardwareVersion) {
        this.hardwareVersion = hardwareVersion;
    }

    public String getSoftwareVersion() {
        return softwareVersion;
    }

    public void setSoftwareVersion(String softwareVersion) {
        this.softwareVersion = softwareVersion;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSalesModel() {
        return salesModel;
    }

    public void setSalesModel(String salesModel) {
        this.salesModel = salesModel;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public boolean isSleepSupport() {
        return sleepSupport;
    }

    public void setSleepSupport(boolean sleepSupport) {
        this.sleepSupport = sleepSupport;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getBindTime() {
        return bindTime;
    }

    public void setBindTime(String bindTime) {
        this.bindTime = bindTime;
    }

    public String getProductProperties() {
        return productProperties;
    }

    public void setProductProperties(String productProperties) {
        this.productProperties = productProperties;
    }

    public String getVenderId() {
        return venderId;
    }

    public void setVenderId(String venderId) {
        this.venderId = venderId;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public long getUpdated() {
        return updated;
    }

    public void setUpdated(long updated) {
        this.updated = updated;
    }

    public boolean isUploadFlag() {
        return uploadFlag;
    }

    public void setUploadFlag(boolean uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean getSleepSupport() {
        return this.sleepSupport;
    }

    public boolean getUploadFlag() {
        return this.uploadFlag;
    }

    public boolean getDeleted() {
        return this.deleted;
    }

    public LsDeviceInfo toDeviceInfo() {
        LsDeviceInfo deviceInfo = new LsDeviceInfo();
        deviceInfo.setDeviceId(this.getId());
        deviceInfo.setDeviceSn(this.getSn());
        deviceInfo.setDeviceType(this.getProductTypeCode());
        deviceInfo.setModelNumber(this.getModel());
        if (TextUtils.isEmpty(this.getBroadcastId())) {
            deviceInfo.setBroadcastID(this.getMac());
        } else {
            deviceInfo.setBroadcastID(this.getBroadcastId());
        }
        deviceInfo.setHardwareVersion(this.getHardwareVersion());
        deviceInfo.setFirmwareVersion(this.getSoftwareVersion());
        deviceInfo.setMacAddress(this.getMacConvert());
        String softVersion = this.getSoftwareVersion();
        //根据设备类型,设备固件版本与软件版本设置相应的协议类型
        deviceInfo.setProtocolType(ProtocolType.A6.name());
        if (!TextUtils.isEmpty(this.getPassword())) {
            deviceInfo.setPassword(this.getPassword());
        }
        if (TextUtils.isEmpty(deviceInfo.getProtocolType())) {
            Log.e("ObjectConvertTools ", "failed to parse device protocol....");
        }
        return deviceInfo;
    }

    @Override
    public String toString() {
        return "Device{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", sn='" + sn + '\'' +
                ", sn8='" + sn8 + '\'' +
                ", qrcode='" + qrcode + '\'' +
                ", mac='" + mac + '\'' +
                ", protocolType='" + protocolType + '\'' +
                ", broadcastId='" + broadcastId + '\'' +
                ", picture='" + picture + '\'' +
                ", productTypeCode='" + productTypeCode + '\'' +
                ", communicationType=" + communicationType +
                ", maxUserQuantity=" + maxUserQuantity +
                ", hardwareVersion='" + hardwareVersion + '\'' +
                ", softwareVersion='" + softwareVersion + '\'' +
                ", password='" + password + '\'' +
                ", model='" + model + '\'' +
                ", salesModel='" + salesModel + '\'' +
                ", imsi='" + imsi + '\'' +
                ", battery=" + battery +
                ", sleepSupport=" + sleepSupport +
                ", imgUrl='" + imgUrl + '\'' +
                ", bindTime='" + bindTime + '\'' +
                ", productProperties='" + productProperties + '\'' +
                ", venderId='" + venderId + '\'' +
                ", created=" + created +
                ", updated=" + updated +
                ", uploadFlag=" + uploadFlag +
                ", deleted=" + deleted +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.name);
        dest.writeString(this.sn);
        dest.writeString(this.sn8);
        dest.writeString(this.qrcode);
        dest.writeString(this.mac);
        dest.writeString(this.protocolType);
        dest.writeString(this.broadcastId);
        dest.writeString(this.picture);
        dest.writeString(this.productTypeCode);
        dest.writeInt(this.communicationType);
        dest.writeInt(this.maxUserQuantity);
        dest.writeString(this.hardwareVersion);
        dest.writeString(this.softwareVersion);
        dest.writeString(this.password);
        dest.writeString(this.model);
        dest.writeString(this.salesModel);
        dest.writeString(this.imsi);
        dest.writeInt(this.battery);
        dest.writeByte(this.sleepSupport ? (byte) 1 : (byte) 0);
        dest.writeString(this.imgUrl);
        dest.writeString(this.bindTime);
        dest.writeString(this.venderId);
        dest.writeLong(this.created != null ? this.created.getTime() : -1);
        dest.writeLong(this.updated);
        dest.writeByte(this.uploadFlag ? (byte) 1 : (byte) 0);
        dest.writeByte(this.deleted ? (byte) 1 : (byte) 0);
    }

    public Integer getIsActive() {
        return this.isActive;
    }

    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    public Date getLastDataTime() {
        return this.lastDataTime;
    }

    public void setLastDataTime(Date lastDataTime) {
        this.lastDataTime = lastDataTime;
    }

    public Boolean getIsForeign() {
        return this.isForeign;
    }

    public void setIsForeign(Boolean isForeign) {
        this.isForeign = isForeign;
    }

    public String getSimpleName() {
        String tmp = "";
        if (simpleName != null) {
            tmp = simpleName;
        } else {
            if (name != null) {
                tmp = name;
            }
        }
        return tmp;
    }

    public void setSimpleName(String simpleName) {
        this.simpleName = simpleName;
    }

    public String getOperationGuide() {
        return this.operationGuide;
    }

    public void setOperationGuide(String operationGuide) {
        this.operationGuide = operationGuide;
    }

    public Long getUserId() {
        return this.userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    protected Device(Parcel in) {
        this.id = in.readString();
        this.name = in.readString();
        this.sn = in.readString();
        this.sn8 = in.readString();
        this.qrcode = in.readString();
        this.mac = in.readString();
        this.protocolType = in.readString();
        this.broadcastId = in.readString();
        this.picture = in.readString();
        this.productTypeCode = in.readString();
        this.communicationType = in.readInt();
        this.maxUserQuantity = in.readInt();
        this.hardwareVersion = in.readString();
        this.softwareVersion = in.readString();
        this.password = in.readString();
        this.model = in.readString();
        this.salesModel = in.readString();
        this.imsi = in.readString();
        this.battery = in.readInt();
        this.sleepSupport = in.readByte() != 0;
        this.imgUrl = in.readString();
        this.bindTime = in.readString();
        this.venderId = in.readString();
        long tmpCreated = in.readLong();
        this.created = tmpCreated == -1 ? null : new Date(tmpCreated);
        this.updated = in.readLong();
        this.uploadFlag = in.readByte() != 0;
        this.deleted = in.readByte() != 0;
    }

    @Keep
    @Generated(hash = 1809630272)
    public Device(String id, String name, String sn, String sn8, String qrcode, String mac, String protocolType, String broadcastId, String picture,
                  String productTypeCode, int communicationType, int maxUserQuantity, String hardwareVersion, String softwareVersion, String password,
                  String model, String salesModel, String imsi, int battery, boolean sleepSupport, String imgUrl, String bindTime, String productProperties,
                  String venderId, Integer isActive, Date lastDataTime, Boolean isForeign, String simpleName, Date created, long updated, boolean uploadFlag,
                  boolean deleted) {
        this.id = id;
        this.name = name;
        this.sn = sn;
        this.sn8 = sn8;
        this.qrcode = qrcode;
        this.mac = mac;
        this.protocolType = protocolType;
        this.broadcastId = broadcastId;
        this.picture = picture;
        this.productTypeCode = productTypeCode;
        this.communicationType = communicationType;
        this.maxUserQuantity = maxUserQuantity;
        this.hardwareVersion = hardwareVersion;
        this.softwareVersion = softwareVersion;
        this.password = password;
        this.model = model;
        this.salesModel = salesModel;
        this.imsi = imsi;
        this.battery = battery;
        this.sleepSupport = sleepSupport;
        this.imgUrl = imgUrl;
        this.bindTime = bindTime;
        this.productProperties = productProperties;
        this.venderId = venderId;
        this.isActive = isActive;
        this.lastDataTime = lastDataTime;
        this.isForeign = isForeign;
        this.simpleName = simpleName;
        this.created = created;
        this.updated = updated;
        this.uploadFlag = uploadFlag;
        this.deleted = deleted;

    }

    @Generated(hash = 133488170)
    public Device(String id, String name, String sn, String sn8, String qrcode, String mac, String protocolType, String broadcastId, String picture,
                  String productTypeCode, int communicationType, int maxUserQuantity, String hardwareVersion, String softwareVersion, String password, String model,
                  String salesModel, String imsi, int battery, boolean sleepSupport, String imgUrl, String bindTime, String productProperties, String venderId,
                  Integer isActive, Date lastDataTime, Boolean isForeign, String simpleName, Date created, long updated, boolean uploadFlag, boolean deleted,
                  String operationGuide, Long userId) {
        this.id = id;
        this.name = name;
        this.sn = sn;
        this.sn8 = sn8;
        this.qrcode = qrcode;
        this.mac = mac;
        this.protocolType = protocolType;
        this.broadcastId = broadcastId;
        this.picture = picture;
        this.productTypeCode = productTypeCode;
        this.communicationType = communicationType;
        this.maxUserQuantity = maxUserQuantity;
        this.hardwareVersion = hardwareVersion;
        this.softwareVersion = softwareVersion;
        this.password = password;
        this.model = model;
        this.salesModel = salesModel;
        this.imsi = imsi;
        this.battery = battery;
        this.sleepSupport = sleepSupport;
        this.imgUrl = imgUrl;
        this.bindTime = bindTime;
        this.productProperties = productProperties;
        this.venderId = venderId;
        this.isActive = isActive;
        this.lastDataTime = lastDataTime;
        this.isForeign = isForeign;
        this.simpleName = simpleName;
        this.created = created;
        this.updated = updated;
        this.uploadFlag = uploadFlag;
        this.deleted = deleted;
        this.operationGuide = operationGuide;
        this.userId = userId;
    }

    public static final Creator<Device> CREATOR = new Creator<Device>() {
        @Override
        public Device createFromParcel(Parcel source) {
            return new Device(source);
        }

        @Override
        public Device[] newArray(int size) {
            return new Device[size];
        }
    };
}
