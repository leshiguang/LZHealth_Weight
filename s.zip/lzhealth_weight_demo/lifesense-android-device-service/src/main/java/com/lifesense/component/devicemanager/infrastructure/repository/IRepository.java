package com.lifesense.component.devicemanager.infrastructure.repository;

import java.util.List;

public interface IRepository<T> {


    T get(String uniqueKey);


    List<T> queryByUser(long userId);

    List<T> queryByUniqueIds(List<String> uniqueIds);

    List<T> queryByUser(long userId, Filter<T> filter);

    void save(T instance);

    void save(List<T> instances);

    void update(T instance);

    void delete(String uniqueId, long userId);
}




