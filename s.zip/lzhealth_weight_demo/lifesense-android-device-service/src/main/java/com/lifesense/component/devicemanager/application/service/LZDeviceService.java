package com.lifesense.component.devicemanager.application.service;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.lifesense.ble.LsBleInterface;
import com.lifesense.ble.LsBleManager;


import com.lifesense.ble.OnSettingCallBack;
import com.lifesense.ble.bean.constant.HeartRateSwitch;
import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.component.devicemanager.constant.ErrorCode;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.device.settings.config.DeviceHeartRateCfg;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;

import com.lifesense.component.devicemanager.data.DataReceiveListenerHook;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.device.settings.config.DeviceUnitCfg;
import com.lifesense.component.devicemanager.application.interfaces.callback.BleReceiveCallback;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceService;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnCheckUpgradeCallback;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDeviceConnectStateListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.UpgradeStateListener;
import com.lifesense.component.devicemanager.infrastructure.domain.service.DeviceOTAService;
import com.lifesense.component.devicemanager.infrastructure.domain.service.DevicePushClient;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.SyncDownloadResponse;
import com.lifesense.component.devicemanager.utils.DeviceManagerUtils;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;


/**
 * 设备组件
 * <p/>
 * Version v1.0.0
 * Update   2016.05.30
 * <p/>
 * Created by lee on 2016/1/16.
 */
public class LZDeviceService extends LZDeviceBindService implements ILZDeviceService {


    /**
     * 蓝牙连接管理
     */
    private LsBleManager bleManager = LsBleManager.getInstance();

    private DeviceOTAService deviceOTAService = DeviceOTAService.getInstance();

    private static boolean hasInit = false;

    private LZDeviceService() {
        enableWriteDebug(true);
    }

    public static ILZDeviceService getInstance() {
        return SingleHolder.getSingleton();
    }

    private static class SingleHolder {
        private static ILZDeviceService ilzDeviceService = new LZDeviceService();
        private static ILZDeviceService getSingleton() {
            return ilzDeviceService;
        }
    }


    @Override
    public  void init(Context context, final long userId, OnDeviceConnectStateListener stateListener, OnDataReceiveListener dataReceiveListener) {
        if (!hasInit) {
            /**
             * context信息保留
             */
            LDAppHolder.init(context, userId);

            /**
             * 蓝牙模块初始化
             */
            bleManager.initialize(LDAppHolder.getContext());

            /**
             * 初始化日志
             */
            initializeBleLog(userId);

            DataReceiveListenerHook.getInstance().setOnDataReceiveListener(dataReceiveListener);

            //注册消息通知服务
            receiveCallback = new BleReceiveCallback();
            receiveCallback.setConnectStateListener(stateListener);
            receiveCallback.setReceiveListener(DataReceiveListenerHook.getInstance().getDataReceiveListener());
            /**
             * 获取上次数据同步时间
             */
            DeviceNetManager.getInstance().syncDownload(0, new IRequestCallBack<SyncDownloadResponse>() {
                @Override
                public void onRequestSuccess(SyncDownloadResponse response) {
                    DeviceManagerUtils.saveSyncDataFromServer(response.getSyncFromServerData());
                    //设备变更了， 重启开启数据接收服务
                    startDataReceive();
                }
                @Override
                public void onRequestError(int code, String msg, SyncDownloadResponse response) {

                }
            });
            hasInit = true;
        }
    }

    private  void initializeBleLog(long userId) {

    }


    @Override
    public int getUnit(String deviceId) {
        DeviceSetting deviceSetting = RepositoryRegistry.getDeviceSettingRepository().get(deviceId, DeviceUnitCfg.class.getSimpleName());
        if (deviceSetting == null) {
            return UnitType.UNIT_KG.getCommand();
        }
        DeviceUnitCfg cfg = JSON.parseObject(deviceSetting.getContent(), DeviceUnitCfg.class);
        return cfg.getUnit();
    }

    @Override
    public void setUnit(String deviceId, UnitType unitType, OnSettingCallBack settingCallBack) {
        Device device = RepositoryRegistry.deviceRepository().get(deviceId);
        if (device == null) {
            settingCallBack.onFailure(ErrorCode.DEVICE_NOT_FOUND);
            return;
        }
        DevicePushClient.setWeightUnit(device, unitType, settingCallBack);
    }

    @Override
    public void checkDeviceFirmwareUpgrade(String deviceId, OnCheckUpgradeCallback callback) {
        deviceOTAService.checkFirmwareUpgrade(deviceId,callback);
    }

    @Override
    public void upgradeDeviceFirmware(String deviceId, String filePath, final UpgradeStateListener listener) {
        if(!hasInit) return;
        deviceOTAService.upgradeDevice(deviceId, filePath, new UpgradeStateListener() {
            @Override
            public void onStart() {
                stopDataReceive();
                if(listener != null) {
                    listener.onStart();
                }
            }

            @Override
            public void onFinish(boolean success, int errorCode, String msg) {
                restartDataReceive();
                if(listener != null) {
                    listener.onFinish(success, errorCode, msg);
                }
            }

            @Override
            public void onProgress(int progress) {
                if(listener != null) {
                    listener.onProgress(progress);
                }
            }
        });
    }

    @Override
    public void interruptUpgradeDeviceFirmware(String deviceId) {
        if(!hasInit) return;
        deviceOTAService.interruptUpgrade(deviceId);
    }

    @Override
    public void setHeartRateSwitch(String deviceId, HeartRateSwitch heartRateSwitch, OnSettingCallBack onSettingCallBack) {
        Device device = RepositoryRegistry.deviceRepository().get(deviceId);
        if (device == null) {
            onSettingCallBack.onFailure(ErrorCode.DEVICE_NOT_FOUND);
            return;
        }
        DevicePushClient.setHeartRateSwitch(device, heartRateSwitch, onSettingCallBack);
    }

    @Override
    public int getHeartRateSwitch(String deviceId) {
        DeviceSetting deviceSetting = RepositoryRegistry.getDeviceSettingRepository().get(deviceId, DeviceHeartRateCfg.class.getSimpleName());
        if (deviceSetting == null) {
            return HeartRateSwitch.CLOSE.getCommand();
        }
        DeviceHeartRateCfg cfg = JSON.parseObject(deviceSetting.getContent(), DeviceHeartRateCfg.class);
        return cfg.getState();
    }

    /**
     * 是否允许写蓝牙日志文件
     */
    private void enableWriteDebug(boolean enable) {
        if (bleManager != null) {
            if (enable) {
                bleManager.enableWriteDebugMessageToFiles(true, LsBleInterface.PERMISSION_WRITE_LOG_FILE);
            } else {
                bleManager.enableWriteDebugMessageToFiles(false, null);
            }
        }
    }


}
