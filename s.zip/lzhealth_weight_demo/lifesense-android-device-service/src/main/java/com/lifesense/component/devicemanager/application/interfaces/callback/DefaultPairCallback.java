package com.lifesense.component.devicemanager.application.interfaces.callback;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.PairCallback;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.ble.bean.PairedConfirmInfo;
import com.lifesense.ble.bean.constant.DeviceRegisterState;
import com.lifesense.ble.bean.constant.OperationCommand;
import com.lifesense.ble.bean.constant.PairedConfirmState;
import com.lifesense.ble.bean.constant.PairedResultsCode;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.constant.ErrorCode;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
import com.lifesense.component.devicemanager.device.dto.device.DeviceUserInfo;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceSyncService;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.BindRespondData;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.ApplyDeviceIdResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.BindByDeviceIdResponse;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import org.apache.commons.collections4.CollectionUtils;

import java.util.List;


public class DefaultPairCallback extends PairCallback {


    private BindResultCallback callback;

    private boolean isBindCallback;

    private LsDeviceInfo lsDeviceInfo;

    private LsBleManager lsBleManager = LsBleManager.getInstance();

    private boolean success;

    private int error;

    private String msg;

    public DefaultPairCallback(BindResultCallback callback, LsDeviceInfo lsDeviceInfo) {
        this.callback = callback;
        this.lsDeviceInfo = lsDeviceInfo;
        isBindCallback = false;
    }

    @Override
    public void onPairResults(final LsDeviceInfo lsDeviceInfo, final int status) {
        if (callback != null) {
            switch (status) {
                case PairedResultsCode.PAIR_SUCCESSFULLY:
                    success = true;
                    msg = "bind successfully";
                    break;
                case PairedResultsCode.PAIR_FAILED_BLUETOOTH_CLOSE:
                    success = false;
                    //蓝牙关闭
                    error = ErrorCode.BLUETOOTH_STATE_DISABLE;
                    msg = "bluetooth disable";
                    break;
                default:
                    success = false;
                    error = ErrorCode.BLE_ABNORMAL;
                    msg = "bluetooth sdk callback status:" + status;
                    break;
            }
            doCallback();
        }
    }

    @Override
    public void onDeviceOperationCommandUpdate(final String macAddress, final OperationCommand cmd, Object obj) {
        if (callback != null) {
            switch (cmd) {
                case CMD_DEVICE_ID:
                    //请求deviceId
                    DeviceNetManager.getInstance().questDeviceId(lsDeviceInfo, new IRequestCallBack<ApplyDeviceIdResponse>() {
                        @Override
                        public void onRequestSuccess(ApplyDeviceIdResponse response) {
                            //设置DeviceID
                            lsDeviceInfo.setDeviceId(response.getDeviceId());
                            lsBleManager.registeringDeviceID(macAddress, response.getDeviceId(), DeviceRegisterState.NORMAL_UNREGISTER);
                        }

                        @Override
                        public void onRequestError(int code, String msg, final ApplyDeviceIdResponse response) {
                            lsBleManager.cancelDevicePairing(lsDeviceInfo);
                            setSuccess(false);
                            setError(code);
                            setMsg(msg);
                            doCallback();
                        }
                    });
                    break;
                case CMD_PAIRED_CONFIRM:
                    DeviceNetManager.getInstance().pairDevice(lsDeviceInfo.getDeviceId(), LDAppHolder.getUserId(), new IRequestCallBack<BindByDeviceIdResponse>() {
                        @Override
                        public void onRequestSuccess(BindByDeviceIdResponse bindByDeviceIdResponse) {
                            BindRespondData data = bindByDeviceIdResponse.getBindRespondData();
                            if (data == null) {
                                return;
                            }
                            saveBindRespondData(data);
                            PairedConfirmInfo pairedConfirmInfo = new PairedConfirmInfo(PairedConfirmState.PAIRING_SUCCESS);
                            pairedConfirmInfo.setUserNumber(1);
                            List<DeviceUser> deviceUsers = data.getDeviceUsers();
                            if (CollectionUtils.isNotEmpty(deviceUsers)) {
                                DeviceUserInfo deviceUserInfo = DeviceManagerPreference.readUserInfo();
                                for (DeviceUser deviceUser : deviceUsers) {
                                    if (deviceUser.getUserId().longValue() != deviceUserInfo.getUserId()) {
                                        continue;
                                    }
                                    pairedConfirmInfo.setUserNumber(deviceUser.getUserNo());
                                    break;
                                }
                            }
                            lsBleManager.inputOperationCommand(macAddress, OperationCommand.CMD_PAIRED_CONFIRM, pairedConfirmInfo);
                        }

                        @Override
                        public void onRequestError(int code, String msg, final BindByDeviceIdResponse bindByDeviceIdResponse) {
                            lsBleManager.cancelDevicePairing(lsDeviceInfo);
                            setSuccess(false);
                            setError(code);
                            setMsg(msg);
                            doCallback();
                        }
                    });

                    break;
            }

        }
    }

    private void doCallback() {
        Task.runOnMainThreadAsync(new Runnable() {
            @Override
            public void run() {
                if (!isBindCallback) {
                    isBindCallback = true;
                    if (callback != null) {
                        if (success) {
                            callback.onSuccess(RepositoryRegistry.deviceRepository().get(lsDeviceInfo.getDeviceId()), RepositoryRegistry.deviceUserRepository().queryByUser(LDAppHolder.getUserId()));
                        } else {
                            callback.onFailed(error, msg);
                        }
                    }
                    ILZDeviceSyncService lzDeviceService = (ILZDeviceSyncService) LZDeviceService.getInstance();
                    lzDeviceService.startDataReceive();
                }
            }
        });
    }



    //保存绑定的数据
    private void saveBindRespondData(BindRespondData data) {
        Device device = data.getDevice();
        device.setUploadFlag(true);
        RepositoryRegistry.deviceUserRepository().delete(device.getId(), LDAppHolder.getUserId());
        List<DeviceUser> netDeviceUsers = data.getDeviceUsers();
        if (netDeviceUsers != null && netDeviceUsers.size() > 0) {
            for (DeviceUser deviceUser : netDeviceUsers) {
                deviceUser.setUploadFlag(true);
            }
        }
        RepositoryRegistry.getDeviceSettingRepository().delete(device.getId(), LDAppHolder.getUserId());
        List<DeviceSetting> deviceSettings = data.getDeviceSettings();
        if (CollectionUtils.isNotEmpty(deviceSettings)) {
            for (DeviceSetting deviceSetting : deviceSettings) {
                deviceSetting.setUploadFlag(true);
            }
            RepositoryRegistry.getDeviceSettingRepository().save(deviceSettings);
        }
        //保存设备图片
        RepositoryRegistry.deviceRepository().save(device);
        RepositoryRegistry.deviceUserRepository().save(netDeviceUsers);

    }



    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
