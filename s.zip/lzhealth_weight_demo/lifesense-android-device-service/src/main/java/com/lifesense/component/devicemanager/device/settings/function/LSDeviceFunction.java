package com.lifesense.component.devicemanager.device.settings.function;


import com.lifesense.component.devicemanager.constant.SaleType;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.utils.StringUtil;

/**
 * Created by zhouzhaoyan on 2017/7/20.
 * 设备功能
 */

public abstract class LSDeviceFunction {

    protected Device device;
    protected int softwareVersion;
    protected SaleType saleType;

    public static LSDeviceFunction getInstance(Device device){
        LSDeviceFunction function = new LSDeviceFunctionChinese(device);
        return function;

    }

    protected LSDeviceFunction(Device device) {
        this.device = device;
        saleType = device.getSaleType();
        softwareVersion = StringUtil.getSoftwareVersion(device.getSoftwareVersion());
    }



    //获取默认称的单位
    public abstract int getWeightUnitDefault();


}
