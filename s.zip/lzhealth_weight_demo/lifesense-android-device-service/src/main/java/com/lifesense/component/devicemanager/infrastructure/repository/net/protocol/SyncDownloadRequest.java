package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class SyncDownloadRequest extends BaseRequest {
    private static final String kRequestParam_Ts = "ts";

    public SyncDownloadRequest(long ts) {
        super();
        setRequestMethod(HTTP_POST);
        addLongValue(kRequestParam_Ts, ts);
    }


    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/sync/download";
    }

    @Override
    public String getResponseClassName() {
        return SyncDownloadResponse.class.getName();
    }
}
