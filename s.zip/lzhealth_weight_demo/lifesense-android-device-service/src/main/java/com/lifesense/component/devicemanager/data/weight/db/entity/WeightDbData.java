package com.lifesense.component.devicemanager.data.weight.db.entity;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Keep;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 14:30
 * @describe:
 */
@Entity
public class WeightDbData {
    @Id
    private String id;
    private long userId;
    protected String deviceId;
    protected long measurementTime;//测量时间(s) 单位秒
    protected String deviceMode;
    private int userNo;
    private double weight;
    private double bmi;
    private boolean hasPbf;
    private double pbf;
    private double bone;
    private double water;
    private double muscle;
    private double weightLevel;//体重水平
    private double resistance5K;//电阻值
    private double resistance50K;//电阻值
    private int battery;//电量1-10，不支持为0
    private boolean isTreated;//是否处理过  true已经处理，false未处理。
    @Keep
    @Generated(hash = 1666665310)
    public WeightDbData(String id, long userId, String deviceId,
            long measurementTime, String deviceMode, int userNo, double weight,
            double bmi, boolean hasPbf, double pbf, double bone, double water,
            double muscle, double weightLevel, double resistance5K,
            double resistance50K, int battery, boolean isTreated) {
        this.id = id;
        this.userId = userId;
        this.deviceId = deviceId;
        this.measurementTime = measurementTime;
        this.deviceMode = deviceMode;
        this.userNo = userNo;
        this.weight = weight;
        this.bmi = bmi;
        this.hasPbf = hasPbf;
        this.pbf = pbf;
        this.bone = bone;
        this.water = water;
        this.muscle = muscle;
        this.weightLevel = weightLevel;
        this.resistance5K = resistance5K;
        this.resistance50K = resistance50K;
        this.battery = battery;
        this.isTreated = isTreated;
    }
    @Keep
    @Generated(hash = 76473896)
    public WeightDbData() {
    }
    public String getId() {
        return this.id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public long getUserId() {
        return this.userId;
    }
    public void setUserId(long userId) {
        this.userId = userId;
    }
    public String getDeviceId() {
        return this.deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    public long getMeasurementTime() {
        return this.measurementTime;
    }
    public void setMeasurementTime(long measurementTime) {
        this.measurementTime = measurementTime;
    }
    public String getDeviceMode() {
        return this.deviceMode;
    }
    public void setDeviceMode(String deviceMode) {
        this.deviceMode = deviceMode;
    }
    public int getUserNo() {
        return this.userNo;
    }
    public void setUserNo(int userNo) {
        this.userNo = userNo;
    }
    public double getWeight() {
        return this.weight;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }
    public double getBmi() {
        return this.bmi;
    }
    public void setBmi(double bmi) {
        this.bmi = bmi;
    }
    public boolean getHasPbf() {
        return this.hasPbf;
    }
    public void setHasPbf(boolean hasPbf) {
        this.hasPbf = hasPbf;
    }
    public double getPbf() {
        return this.pbf;
    }
    public void setPbf(double pbf) {
        this.pbf = pbf;
    }
    public double getBone() {
        return this.bone;
    }
    public void setBone(double bone) {
        this.bone = bone;
    }
    public double getWater() {
        return this.water;
    }
    public void setWater(double water) {
        this.water = water;
    }
    public double getMuscle() {
        return this.muscle;
    }
    public void setMuscle(double muscle) {
        this.muscle = muscle;
    }
    public double getWeightLevel() {
        return this.weightLevel;
    }
    public void setWeightLevel(double weightLevel) {
        this.weightLevel = weightLevel;
    }
    public double getResistance5K() {
        return this.resistance5K;
    }
    public void setResistance5K(double resistance5K) {
        this.resistance5K = resistance5K;
    }
    public double getResistance50K() {
        return this.resistance50K;
    }
    public void setResistance50K(double resistance50K) {
        this.resistance50K = resistance50K;
    }
    public int getBattery() {
        return this.battery;
    }
    public void setBattery(int battery) {
        this.battery = battery;
    }
    public boolean getIsTreated() {
        return this.isTreated;
    }
    public void setIsTreated(boolean isTreated) {
        this.isTreated = isTreated;
    }

}
