package com.lifesense.component.devicemanager.component.alive;

import android.content.Context;
import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import com.lifesense.utils.LSLog;


/**
 * Created by maiweibiao on 16/10/26.
 */

public class CoreNotificationService extends NotificationListenerService {

    @Override
    public void onCreate() {
        super.onCreate();
        LSLog.i(KeepAliveUtils.TAG, "CoreNotificationService onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public static void startService(Context context) {
        if (context == null) {
            return;
        }


        Intent intent = new Intent(context, CoreNotificationService.class);
        context.startService(intent);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {

    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
    }
}
