package com.lifesense.component.devicemanager.data.weight.observer;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 14:26
 * @describe:
 */
public interface IWeightDataUpdateObserver {
    void onWeightDataUpdate();

}
