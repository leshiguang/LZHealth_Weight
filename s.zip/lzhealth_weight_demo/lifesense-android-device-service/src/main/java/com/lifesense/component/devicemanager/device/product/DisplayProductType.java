package com.lifesense.component.devicemanager.device.product;

/**
 * 产品类型
 */
public enum DisplayProductType {
    pedometer(1), watches(2), weight(3),
    bloodPressure(4), interconnection(5);
    public int code;

    DisplayProductType(int code) {
        this.code = code;
    }

    public static DisplayProductType toProductType(int code){
        DisplayProductType displayProductType = DisplayProductType.pedometer;
        for (DisplayProductType displayProductTypeTmp : DisplayProductType.values()) {
            if (displayProductTypeTmp.code == code){
                displayProductType = displayProductTypeTmp;
                break;
            }
        }
        return displayProductType;
    }
}
