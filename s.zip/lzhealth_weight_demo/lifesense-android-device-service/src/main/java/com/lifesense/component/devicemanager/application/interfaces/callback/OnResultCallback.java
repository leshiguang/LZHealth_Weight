package com.lifesense.component.devicemanager.application.interfaces.callback;

/**
 * Created by lee on 2016/1/19.
 */
public interface OnResultCallback {
    void onSuccess();

    void onFailed(int errorCode, String msg);
}
