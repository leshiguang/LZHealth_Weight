package com.lifesense.component.devicemanager.application.service;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceSyncService;
import com.lifesense.component.devicemanager.application.interfaces.callback.BleReceiveCallback;
import com.lifesense.component.devicemanager.component.receiver.BluetoothStatusChangeTrigger;
import com.lifesense.component.devicemanager.utils.DeviceManagerUtils;



import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class LZDeviceSyncService implements ILZDeviceSyncService {


    /**
     * 底层的蓝牙设备管理
     */
    protected LsBleManager bleManager = LsBleManager.getInstance();

    /**
     * 当前缓存的设备列表
     */
    protected Map<String, LsDeviceInfo> cacheDeviceInfos = new HashMap<>();

    /**
     * 回调
     */
    protected BleReceiveCallback receiveCallback;

    /**
     * 开启数据接收服务
     */
    @Override
    public void startDataReceive() {
        if (canStart()) {
            Task.execute(new Runnable() {
                @Override
                public void run() {
                    Map<String, LsDeviceInfo> newMap = DeviceManagerUtils.getAllBluetoothDevice();
                    if (newMap == null || newMap.size() == 0) {
                        cacheDeviceInfos.clear();
                        return;
                    }
                    if (DeviceManagerUtils.diffDeviceInfos(cacheDeviceInfos, newMap)) {
                        cacheDeviceInfos = newMap;
                        DeviceManagerUtils.setDevices();
                        if (BluetoothStatusChangeTrigger.getInstance().isRegisted()) {
                            bleManager.startDataReceiveService(receiveCallback);
                        }
                    }

                }
            });
        }
    }

    @Override
    public boolean stopDataReceive() {
        if (bleManager != null) {
            boolean result = bleManager.stopDataReceiveService();
            bleManager.setMeasureDevice(null);
            return result;
        }
        return false;
    }

    @Override
    public void restartDataReceive() {
        this.cacheDeviceInfos.clear();
        stopDataReceive();
        if (canStart()) {
            Map<String, LsDeviceInfo> deviceInfoMap = DeviceManagerUtils.getAllBluetoothDevice();
            if (deviceInfoMap != null && deviceInfoMap.size() > 0) {
                Iterator iterator = deviceInfoMap.entrySet().iterator();

                while(iterator.hasNext()) {
                    Map.Entry<String, LsDeviceInfo> entry = (Map.Entry<String, LsDeviceInfo>) iterator.next();
                    cacheDeviceInfos.put(entry.getKey(), entry.getValue());
                }
                DeviceManagerUtils.setDevices();
                bleManager.startDataReceiveService(receiveCallback);
            }
        }
    }


    private boolean canStart() {
        return LDAppHolder.getUserId() > 0 && bleManager.isSupportLowEnergy() && bleManager.isOpenBluetooth();
    }


    public BleReceiveCallback getReceiveCallback() {
        return receiveCallback;
    }

    public void setReceiveCallback(BleReceiveCallback receiveCallback) {
        this.receiveCallback = receiveCallback;
    }
}
