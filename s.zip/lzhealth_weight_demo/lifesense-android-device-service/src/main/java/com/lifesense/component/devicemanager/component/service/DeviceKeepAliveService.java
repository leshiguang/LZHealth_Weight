package com.lifesense.component.devicemanager.component.service;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.constant.ManagerStatus;
import com.lifesense.component.devicemanager.component.alive.GrayService;
import com.lifesense.component.devicemanager.component.alive.KeepAliveReport;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceSyncService;
import com.lifesense.component.devicemanager.component.receiver.BluetoothStateReceiver;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;

public class DeviceKeepAliveService extends GrayService {

    public static final String INTENT_FROM = "from";
    public static final String INTENT_FROM_KEEPALIVE = "keepalive";

    private BluetoothStateReceiver bluetoothStateReceiver;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(final Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(final Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        handleFromKeepAlive(intent);
        if (bluetoothStateReceiver == null) {
            bluetoothStateReceiver = new BluetoothStateReceiver();
            IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(bluetoothStateReceiver, filter);
        }
        ManagerStatus status = LsBleManager.getInstance().getLsBleManagerStatus();
        if (status == null || status.equals(ManagerStatus.FREE)) {
            ILZDeviceSyncService lzDeviceService = (ILZDeviceSyncService) LZDeviceService.getInstance();
            lzDeviceService.restartDataReceive();
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(final Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // Restart service in 500 ms
    }

    private void handleFromKeepAlive(final Intent intent) {
        if (intent == null || !INTENT_FROM_KEEPALIVE.equals(intent.getStringExtra(INTENT_FROM))) {
            return;
        }
        DeviceManagerPreference.saveFileName();
        if (LsBleManager.getInstance().isSupportLowEnergy()) {
            LsBleManager.getInstance().registerBluetoothBroadcastReceiver(this);
        }
        KeepAliveReport.getInstance().reportPull();
        Log.i("DeviceService", "start from keeplive");
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (bluetoothStateReceiver != null) {
            unregisterReceiver(bluetoothStateReceiver);
        }
        try {
            if (Build.VERSION.SDK_INT < 26) {
                startService(new Intent(this, DeviceKeepAliveService.class));
            }
        } catch (Exception e) {
            Log.i("DeviceKeepAliveService", e.getMessage());
        }

    }
}
