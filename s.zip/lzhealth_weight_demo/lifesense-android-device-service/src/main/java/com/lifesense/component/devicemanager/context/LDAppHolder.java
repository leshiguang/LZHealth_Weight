package com.lifesense.component.devicemanager.context;

import android.content.Context;
import android.content.pm.PackageManager;

/**
 * Created by lee
 * On Date 2017/2/24
 */

public class LDAppHolder {
    private static Context mContext;

    /**
     * 用户ID
     */
    private static long userId;


    public static void init(Context context, long userId) {
        mContext = context.getApplicationContext();
        LDAppHolder.userId = userId;
    }

    public static Context getContext() {
        return mContext;
    }

    /**
     * 清除用户身份
     */
    public static void clear() {
        userId = 0;
    }

    public static long getUserId() {
        return userId;
    }


    public static String getAppName() {
        Context context = LDAppHolder.getContext();
        return context.getApplicationInfo().loadLabel(context.getPackageManager()).toString();
    }

    public static String getVersionCode() {
        try {
            Context context = LDAppHolder.getContext();
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode + "";
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String getVersionName() {
        try {
            Context context = LDAppHolder.getContext();
            String versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            if (versionName != null && versionName.lastIndexOf("(") != -1) {
                versionName = versionName.substring(0, versionName.lastIndexOf("("));
            }
            return versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String getAppMsg() {
        return "[" + getAppName() + "]["
                + getVersionName() + "]["
                + getVersionCode() + "]";
    }
}
