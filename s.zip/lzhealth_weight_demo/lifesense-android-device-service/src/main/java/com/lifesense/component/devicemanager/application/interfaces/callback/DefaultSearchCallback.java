package com.lifesense.component.devicemanager.application.interfaces.callback;

import android.bluetooth.BluetoothDevice;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lifesense.ble.SearchCallback;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.ble.bean.constant.DeviceType;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;

import java.util.List;

import static com.lifesense.component.devicemanager.utils.StringUtil.getMacWithoutColon;

public class DefaultSearchCallback extends SearchCallback {

    private SearchResultCallback callback;

    private DisplayProduct displayProduct;

    public DefaultSearchCallback(SearchResultCallback callback, DisplayProduct displayProduct) {
        this.callback = callback;
        this.displayProduct = displayProduct;
    }

    @Override
    public void onSearchResults(final LsDeviceInfo lsDeviceInfo) {
        if (lsDeviceInfo == null) {
            return;
        }
        Log.i("-onSearchResults-", JSON.toJSONString(lsDeviceInfo));

        doCallback(lsDeviceInfo, lsDeviceInfo.getRssi());

    }

    @Override
    public void onSystemBindedDevice(final BluetoothDevice bluetoothDevice) {
        Log.i("-SysBinded-", JSON.toJSONString(bluetoothDevice));
        handleSystemHolderDevices(bluetoothDevice.getName(), bluetoothDevice.getAddress());
    }

    @Override
    public void onSystemConnectedDevice(String name, String macAddress) {
        if (macAddress != null) {
            Log.i("-SysConnected-", name + macAddress);
            handleSystemHolderDevices(name, macAddress);
        }
    }

    private void handleSystemHolderDevices(String name, String macAddress) {
        final LsDeviceInfo lsDeviceInfo = new LsDeviceInfo();
        lsDeviceInfo.setMacAddress(macAddress);
        lsDeviceInfo.setDeviceName(name);
        lsDeviceInfo.setBroadcastID(getMacWithoutColon(macAddress));
        lsDeviceInfo.setProtocolType(displayProduct.getProtocolType().name());
        lsDeviceInfo.setDeviceType(DeviceType.FAT_SCALE.name());
        doCallback(lsDeviceInfo, 99);
    }


    private boolean isBoundDevice(LsDeviceInfo lsDeviceInfo) {
        List<Device> bindDevices = RepositoryRegistry.deviceRepository().queryByUser(LDAppHolder.getUserId());
        if (bindDevices != null) {
            for (Device device : bindDevices) {
                if (device == null) {
                    continue;
                }
                return device.getMacConvert() != null && lsDeviceInfo.getMacAddress() != null && device.getMacConvert().equalsIgnoreCase(lsDeviceInfo.getMacAddress());
            }
        }
        return false;
    }


    private void doCallback(final LsDeviceInfo lsDeviceInfo, final int rSSI) {
        if (callback == null || isBoundDevice(lsDeviceInfo)) {
            return;
        }
        List<String> broadcastNames = displayProduct.getBroadcastNames();

        if (!broadcastNames.contains(lsDeviceInfo.getDeviceName().toUpperCase())) {
            return;
        }
        String displayDeviceName = displayProduct.getFactoryNameByBroadCastName(lsDeviceInfo.getDeviceName());
        //重设设备名称为显示名
        lsDeviceInfo.setDeviceName(displayDeviceName);
        runOnMainThread(new Runnable() {
            @Override
            public void run() {
                callback.onSearchResult(new LSEDeviceInfo(displayProduct, lsDeviceInfo), rSSI);
            }
        });
    }

    private void runOnMainThread(Runnable action) {
        Task.runOnMainThreadAsync(action);
    }
}
