package com.lifesense.component.devicemanager.device.settings.config;

import android.os.Parcel;
import android.os.Parcelable;


/**
 * Created by lee on 2016/1/21.
 */
public class DeviceHeartRateCfg implements Parcelable {
    /**
     * {@link com.lifesense.ble.bean.constant.UnitType}
     */
    private int state;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.state);
    }

    public DeviceHeartRateCfg() {
    }

    protected DeviceHeartRateCfg(Parcel in) {
        this.state = in.readInt();
    }

    public static final Creator<DeviceHeartRateCfg> CREATOR = new Creator<DeviceHeartRateCfg>() {
        @Override
        public DeviceHeartRateCfg createFromParcel(Parcel source) {
            return new DeviceHeartRateCfg(source);
        }

        @Override
        public DeviceHeartRateCfg[] newArray(int size) {
            return new DeviceHeartRateCfg[size];
        }
    };

    @Override
    public String toString() {
        return "DeviceHeartRateCfg{" +
                "state=" + state +
                '}';
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
