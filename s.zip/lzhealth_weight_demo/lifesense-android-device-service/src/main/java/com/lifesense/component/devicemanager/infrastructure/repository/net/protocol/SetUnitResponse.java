package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class SetUnitResponse extends JsonResponse {
    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {

    }
}
