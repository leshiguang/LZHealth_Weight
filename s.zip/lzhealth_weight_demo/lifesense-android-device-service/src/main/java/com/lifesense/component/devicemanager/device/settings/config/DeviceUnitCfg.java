package com.lifesense.component.devicemanager.device.settings.config;

import android.os.Parcel;
import android.os.Parcelable;


/**
 * Created by lee on 2016/1/21.
 */
public class DeviceUnitCfg implements Parcelable {
    /**
     * {@link com.lifesense.ble.bean.constant.UnitType}
     */
    private int unit;

    public DeviceUnitCfg() {
    }

    protected DeviceUnitCfg(Parcel in) {
        unit = in.readInt();
    }

    public static final Creator<DeviceUnitCfg> CREATOR = new Creator<DeviceUnitCfg>() {
        @Override
        public DeviceUnitCfg createFromParcel(Parcel in) {
            return new DeviceUnitCfg(in);
        }

        @Override
        public DeviceUnitCfg[] newArray(int size) {
            return new DeviceUnitCfg[size];
        }
    };

    public int getUnit() {
        return unit;
    }

    public void setUnit(int unit) {
        this.unit = unit;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(unit);
    }

    @Override
    public String toString() {
        return "DeviceUnitCfg{" +
                "unit=" + unit +
                '}';
    }
}
