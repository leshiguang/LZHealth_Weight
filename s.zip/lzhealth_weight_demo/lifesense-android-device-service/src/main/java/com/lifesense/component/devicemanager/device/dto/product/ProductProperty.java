package com.lifesense.component.devicemanager.device.dto.product;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xwei
 * on 2017/3/29/0029.
 */

public class ProductProperty implements Parcelable {

    private long id;
    private String productId;
    private int key;
    private String value;
    private long created;
    private String memo;
    private int sort;

    public ProductProperty() {
    }

    protected ProductProperty(Parcel in) {
        id = in.readLong();
        productId = in.readString();
        key = in.readInt();
        value = in.readString();
        created = in.readLong();
        memo = in.readString();
        sort = in.readInt();
    }

    public static final Creator<ProductProperty> CREATOR = new Creator<ProductProperty>() {
        @Override
        public ProductProperty createFromParcel(Parcel in) {
            return new ProductProperty(in);
        }

        @Override
        public ProductProperty[] newArray(int size) {
            return new ProductProperty[size];
        }
    };

    public long getId() {
        return id;
    }

    public String getProductId() {
        return productId;
    }

    public int getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public long getCreated() {
        return created;
    }

    public String getMemo() {
        return memo;
    }

    public int getSort() {
        return sort;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(productId);
        dest.writeInt(key);
        dest.writeString(value);
        dest.writeLong(created);
        dest.writeString(memo);
        dest.writeInt(sort);
    }

    @Override
    public String toString() {
        return "ProductProperty{" +
                "id=" + id +
                " productId=" + productId +
                " key=" + key +
                " value=" + value +
                " created=" + created +
                " memo=" + memo +
                " sort=" + sort +
                '}';
    }
}
