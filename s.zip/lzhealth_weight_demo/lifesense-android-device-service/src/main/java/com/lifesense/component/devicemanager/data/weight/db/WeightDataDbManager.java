package com.lifesense.component.devicemanager.data.weight.db;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.data.weight.db.entity.WeightDbData;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.WeightDbDataDao;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadWeightResponse;
import com.lifesense.component.devicemanager.utils.StringUtil;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import org.greenrobot.greendao.database.StandardDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 14:40
 * @describe:
 */
public class WeightDataDbManager implements IWeightDataDbInterface {
    private WeightDbDataDao mWeightDbDataDao;

    public WeightDataDbManager(WeightDbDataDao weightDbDataDao) {
        mWeightDbDataDao = weightDbDataDao;
    }

    @Override
    public void addWeightData(WeightData weightData) {
        WeightDbData weightDbData = toWeightDbData(weightData);
        weightDbData.setIsTreated(false);
        //重复数据过滤
        List<WeightDbData> dbDatas = mWeightDbDataDao.queryBuilder().where
                (WeightDbDataDao.Properties.MeasurementTime.eq(weightData.getMeasurementTime()),
                        WeightDbDataDao.Properties.Weight.eq(weightData.getWeight())
                ).limit(1).list();
        if (dbDatas != null && dbDatas.size() > 0) {
            return;
        }
        mWeightDbDataDao.insertOrReplace(weightDbData);
    }

    @Override
    public void setWeightDataProcessed(List<WeightData> weightDatas) {
        //        mWeightDbDataDao.
        final List<String> ids = new ArrayList<>();
        for (int i = 0; i < weightDatas.size(); i++) {
            WeightData weightData = weightDatas.get(i);
            if (weightData != null && weightData.getDbId() != null) {
                ids.add(weightData.getDbId());
            }
        }
        //使用事务
        mWeightDbDataDao.getSession().runInTx(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < ids.size(); i++) {
                    String id = ids.get(i);
                    setWeightDataIsTreated(id,true);
                }
            }
        });

    }
	private void setWeightDataIsTreated(String id, boolean IsTreated) {
        ContentValues values = new ContentValues();
        //数据库0代表false 1代表true
        values.put(WeightDbDataDao.Properties.IsTreated.columnName, IsTreated?1:0);
        getDb().update(mWeightDbDataDao.getTablename(), values,
                WeightDbDataDao.Properties.Id.columnName + "=?", new String[]{id});

    }
    @Override
    public void setWeightDataProcessedById(String id) {
        setWeightDataIsTreated(id,true);
    }

    @Override
    public void setWeightDataProcessedByIds(final List<String> ids) {
        if(ids==null||ids.isEmpty()){
            return;
        }
        //使用事务
        mWeightDbDataDao.getSession().runInTx(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < ids.size(); i++) {
                    String id = ids.get(i);
                    setWeightDataIsTreated(id,true);
                }
            }
        });
    }


    @Override
    public List<WeightData> getUntreatedWeightData() {
        List<WeightDbData> weightDbDatas = mWeightDbDataDao.queryBuilder().where(
                WeightDbDataDao.Properties.IsTreated.eq(0)).limit(20).build().list();
        List<WeightData> weightDatas = new ArrayList<>();
        for (int i = 0; i < weightDbDatas.size(); i++) {
            weightDatas.add(toWeightData(weightDbDatas.get(i)));
        }
        return weightDatas;
    }


    @Override
    public int getUntreatedWeightDataCount() {
        return (int) mWeightDbDataDao.queryBuilder().where(WeightDbDataDao.Properties.IsTreated.eq(0)).count();
    }

    @Override
    public void delete7DayBeforeWeightData() {
        final long currentTime = System.currentTimeMillis() / 1000; //数据库存的是秒
        final long beforeDay7 = currentTime - (86400 * 7); //1天是86400秒
        List<WeightDbData> weightDbDatas = mWeightDbDataDao.queryBuilder().where(WeightDbDataDao.Properties.IsTreated.eq(1),
                WeightDbDataDao.Properties.MeasurementTime.le(beforeDay7)).list();
        mWeightDbDataDao.deleteInTx(weightDbDatas);
    }

    public SQLiteDatabase getDb() {
        StandardDatabase standardDatabase = (StandardDatabase) mWeightDbDataDao.getDatabase();
        return standardDatabase.getSQLiteDatabase();
    }

    public WeightData toWeightData(WeightDbData weightDbData) {
        WeightData weightData = new WeightData();
        //1
        weightData.setUserId(weightDbData.getUserId());

        //4
        weightData.setDeviceId(weightDbData.getDeviceId());
        //5
        weightData.setDeviceMode(weightDbData.getDeviceMode());
        //6
        //7
        weightData.setDbId(weightDbData.getId());
        //8
        weightData.setMeasurementTime(weightDbData.getMeasurementTime() * 1000);
        //9
        //10
        //11
        weightData.setResistance5k(weightDbData.getResistance5K());
        //12
        weightData.setResistance50k(weightDbData.getResistance50K());
        //13
        weightData.setUserNo(weightDbData.getUserNo());
        //14
        //15
        weightData.setWeight(weightDbData.getWeight());
        //16
        weightData.setWeightLevel(weightDbData.getWeightLevel());
        //17
        weightData.setBattery(weightDbData.getBattery());
        weightData.setDbId(weightDbData.getId());
        return weightData;
    }

    public WeightDbData toWeightDbData(WeightData weightData) {
        WeightDbData weightDbData = new WeightDbData();
        //1
        weightDbData.setUserId(weightData.getUserId());
        //2
        //3
        //4
        weightDbData.setDeviceId(weightData.getDeviceId());
        //5
        weightDbData.setDeviceMode(weightData.getDeviceMode());
        //6
        //7
        weightDbData.setId(weightData.getDbId());
        //8
        weightDbData.setMeasurementTime(weightData.getMeasurementTime());
        //9
        //10
        //11
        weightDbData.setResistance5K(weightData.getResistance5K());
        //12
        weightDbData.setResistance50K(weightData.getResistance50k());
        //13
        weightDbData.setUserNo(weightData.getUserNo());
        //14
        //15
        weightDbData.setWeight(weightData.getWeight());
        //16
        weightDbData.setWeightLevel(weightData.getWeightLevel());
        //17
        weightDbData.setBattery(weightData.getBattery());
        if (TextUtils.isEmpty(weightDbData.getId())) {
            weightDbData.setId(StringUtil.genUUID());
        }
        return weightDbData;
    }

}
