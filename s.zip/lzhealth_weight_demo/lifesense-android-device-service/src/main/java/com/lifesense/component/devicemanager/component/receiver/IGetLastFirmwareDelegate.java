package com.lifesense.component.devicemanager.component.receiver;

import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

/**
 * Created by rolandxu on 2017/7/4.
 */

public interface IGetLastFirmwareDelegate extends IRequestCallBack {
    public void onSuccess(FirmwareInfo info);
    public void onFailed(String errmsg, int errcode);
}
