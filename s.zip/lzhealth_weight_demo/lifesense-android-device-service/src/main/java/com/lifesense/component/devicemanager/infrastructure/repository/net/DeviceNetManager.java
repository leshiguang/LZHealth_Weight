package com.lifesense.component.devicemanager.infrastructure.repository.net;

import android.util.Log;

import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.data.weight.db.entity.WeightDbData;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.device.product.GetProductListRequest;
import com.lifesense.component.devicemanager.device.product.GetProductListRespond;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.BindByDeviceIdResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.GetLastFirmwareRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.GetLastFirmwareResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.SetUnitRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.SyncDownloadRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.SyncDownloadResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UnBindDeviceResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.ApplyDeviceIdRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.ApplyDeviceIdResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.BindByDeviceIdRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UnBindDeviceRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadDeviceInformationRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadDeviceInformationResponse;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadWeightRequest;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadWeightResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.List;

/**
 * Created by rolandxu on 2017/7/3.
 */

public class DeviceNetManager {
    private static DeviceNetManager gInstance;

    public static DeviceNetManager getInstance() {
        if (gInstance == null) {
            gInstance = new DeviceNetManager();
        }
        return gInstance;
    }

    public void getProductList(IRequestCallBack<GetProductListRespond> callBack) {
        GetProductListRequest request = new GetProductListRequest();
        request.execute(callBack);
    }

    public void pairDevice(String deviceId, long userId, IRequestCallBack<BindByDeviceIdResponse> callBack) {
        BindByDeviceIdRequest request = new BindByDeviceIdRequest(deviceId, userId);
        Log.i("BIND_DEVICE", "--------------- bindDevice -------------\n" + "request url >>" + request.getUrl() + "\r\n"
                + "request json >>" + request.dictToBody() + "\r\n"
                + "deviceId >>" + deviceId + ",userId >>" + userId + "\r\n");
        request.execute(callBack);
    }

    public void questDeviceId(LsDeviceInfo lsDeviceInfo, IRequestCallBack<ApplyDeviceIdResponse> callBack) {
        ApplyDeviceIdRequest request = new ApplyDeviceIdRequest(lsDeviceInfo);
        request.execute(callBack);
    }


    public void unbindDevice(String deviceId, IRequestCallBack<UnBindDeviceResponse> callBack) {
        UnBindDeviceRequest request = new UnBindDeviceRequest(deviceId, LDAppHolder.getUserId());
        request.execute(callBack);
    }


    public void setWeightUnit(String deviceId, int unitType) {
        SetUnitRequest request = new SetUnitRequest(unitType, deviceId);
        request.execute(null);
    }

    public void uploadWeightData(List<WeightData> weightDataList, IRequestCallBack<UploadWeightResponse> callBack) {
        UploadWeightRequest uploadWeightRequest = new UploadWeightRequest(weightDataList, LDAppHolder.getUserId());
        uploadWeightRequest.execute(callBack);
    }

    public void checkNewFirmware(Device device, IRequestCallBack<GetLastFirmwareResponse> callBack) {
        GetLastFirmwareRequest request = new GetLastFirmwareRequest(device);
        request.execute(callBack);
    }

    public void syncDownload(long ts, IRequestCallBack<SyncDownloadResponse> callBack) {
        SyncDownloadRequest request = new SyncDownloadRequest(ts);
        request.execute(callBack);
    }

    public void updateDeviceInformation(List<Device> devices, List<DeviceSetting> deviceSettings, IRequestCallBack<UploadDeviceInformationResponse> callBack) {
        UploadDeviceInformationRequest uploadDeviceInformationRequest = new UploadDeviceInformationRequest(devices, deviceSettings);
        uploadDeviceInformationRequest.execute(callBack);
    }

}