package com.lifesense.component.devicemanager.device.product;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;
import com.lifesense.weidong.lzsimplenetlibs.common.ApplicationHolder;

import java.util.Locale;

public class GetProductListRequest extends BaseRequest {

    /**
     * 精准匹配（1:手环 2:手表
     * 3:智能秤 4:血压计 5:乐心互联，null默认查询所有类型）
     */
    private String productClassify = "productClassify";

    /**
     * app版本
     * header中获取
     */
    private String APPVERSION = "appVersion";

    /**
     * app类型
     * header中获取
     */
    private String APPTYPE = "appType";

    /**
     * 语言
     * header中获取
     */
    private String LANGUAGE = "language";

    /**
     * 地区
     * header中获取
     */
    private String AREA = "area";

    public GetProductListRequest() {
        super();
        setRequestMethod(HTTP_POST);
        addHeaderParams(APPVERSION, ApplicationHolder.getAppVersionName());
        addHeaderParams(APPTYPE, String.valueOf(6));
        String area = Locale.getDefault().getCountry();
        if (area == null) {//key值不一样
            area = "";
        }
        String langs = Locale.getDefault().getLanguage();
        if (langs == null) {
            langs = "";
        }
        addHeaderParams(LANGUAGE, langs);
        addHeaderParams(AREA, area);
    }

    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/appIotProduct/getProductList";
    }

    @Override
    public String getResponseClassName() {
        return GetProductListRespond.class.getName();
    }
}
