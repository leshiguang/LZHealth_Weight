package com.lifesense.component.devicemanager.component.alive;


import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.lifesense.utils.LSLog;

/**
 * Created by maiweibiao on 16/10/25.
 */
@SuppressLint("NewApi")
public class CoreJobService extends JobService {
    private static final long SYNC_INTERVAL = 10 * 60 * 1000L;


    @Override
    public void onCreate() {
        super.onCreate();
        startJobSheduler();
        LSLog.i(KeepAliveUtils.TAG, "CoreJobService onCreate");

    }

    private void startJobSheduler() {
        if (Build.VERSION.SDK_INT >= 26) {
            return;
        }
        try {
            int jobId = 1;
            JobInfo.Builder builder = new JobInfo.Builder(jobId,
                    new ComponentName(this,
                            CoreJobService.class));
            builder.setPeriodic(SYNC_INTERVAL);
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
            builder.setPersisted(true);
            builder.setRequiresCharging(false);

            builder.setRequiresDeviceIdle(false);
            JobScheduler jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
            jobScheduler.schedule(builder.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        LSLog.i(KeepAliveUtils.TAG, "执行了onStartJob方法");
        boolean isAlive = KeepAliveUtils.isServiceWork(this, CoreService.class.getName());
        if (!isAlive) {
            CoreService.startService(this);
        }
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        LSLog.i(KeepAliveUtils.TAG, "onStopJob");
        return false;
    }

    public static void startService(Context context) {
        if (context == null) {
            return;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }

        Intent intent = new Intent(context, CoreJobService.class);
        context.startService(intent);
    }

}
