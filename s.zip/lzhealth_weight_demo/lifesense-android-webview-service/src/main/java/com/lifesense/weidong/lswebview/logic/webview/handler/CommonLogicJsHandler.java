package com.lifesense.weidong.lswebview.logic.webview.handler;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lifesense.weidong.lswebview.logic.webview.base.BaseLSBridgeJs;
import com.lifesense.weidong.lswebview.logic.webview.delegate.ICommonLogicDelegate;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsRefreshDataForSilentAuto;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsWebViewPullToRefreshData;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.CallBackFunction;
import com.lifesense.weidong.lswebview.webview.LSWebView;

/**
 * 处理WebView一些公共逻辑
 */
public class CommonLogicJsHandler extends BaseLSBridgeJs<ICommonLogicDelegate> {
    public static final String TAG = "CommonLogicJsHandler";
    public static String SHOW_LOADING = "showLoading";
    public static String HIDE_LOADING = "hideLoading";
    public static String BIND_WECHAT = "bindWechat";
    public static String BIND_WECHAT_CALLBACK = "bindWechatCallback";
    public static String SET_WEBVIEW_PULL_REFRESH = "setWebViewPullToRefresh";
    public static String ON_SHOW = "onShow";
    public static String ON_HIDE_OR_CLOSE = "onHideOrClose";
    public static String REFRESH_DATA_FOR_SILENT_AUTO = "refreshDataForSilentAuto";
    public CommonLogicJsHandler(LSWebView lsWebView, ICommonLogicDelegate delegate) {
        super(lsWebView, delegate);
    }

    @Override
    public void registerHandler(LSWebView lsWebView) {
        lsWebView.registerHandler(SHOW_LOADING,this);
        lsWebView.registerHandler(HIDE_LOADING,this);
        lsWebView.registerHandler(BIND_WECHAT,this);
        lsWebView.registerHandler(SET_WEBVIEW_PULL_REFRESH,this);
        lsWebView.registerHandler(REFRESH_DATA_FOR_SILENT_AUTO,this);
    }

    @Override
    public void handler(String handlerName, String data, CallBackFunction function) {
        if (SHOW_LOADING.equals(handlerName)){
//            DialogUtil.getInstance().showProcessDialog(mLSWebView.getContext());
        }else if (HIDE_LOADING.equals(handlerName)){
//            DialogUtil.getInstance().dismissProcessDialog();
        }else if(SET_WEBVIEW_PULL_REFRESH.equals(handlerName)){
            handleSetWebViewPullToRefresh(data,function);
        }else if (REFRESH_DATA_FOR_SILENT_AUTO.equals(handlerName)) {
            handleSetRefreshDataForSilentAuto(data,function);
        }
    }

    private boolean handleSetWebViewPullToRefresh(String data, CallBackFunction function){
        JSONObject jsonObject = JSON.parseObject(data);
        JsWebViewPullToRefreshData jsWebViewPullToRefreshData  = new JsWebViewPullToRefreshData();
        if (jsonObject.containsKey("enable")){
            jsWebViewPullToRefreshData.setEnabled(jsonObject.getBoolean("enable"));
        }else if (jsonObject.containsKey("enabled")){
            jsWebViewPullToRefreshData.setEnabled(jsonObject.getBoolean("enabled"));
        }
        if (jsonObject.containsKey("refreshType")) {
            jsWebViewPullToRefreshData.setRefreshType(jsonObject.getIntValue("refreshType"));
        }
        if (jsonObject.containsKey("reload")) {
            jsWebViewPullToRefreshData.setReload(jsonObject.getIntValue("reload"));
        } else {
            jsWebViewPullToRefreshData.setReload(1);
        }
        if (isInvalidObj(jsWebViewPullToRefreshData, function)) {
            return false;
        }
        getDelegate().handleSetWebViewPullToRefresh(jsWebViewPullToRefreshData);
        return true;
    }

    private boolean handleSetRefreshDataForSilentAuto(String data, CallBackFunction function){
        JSONObject jsonObject = JSON.parseObject(data);
        JsRefreshDataForSilentAuto jsRefreshDataForSilentAuto  = new JsRefreshDataForSilentAuto();

        jsRefreshDataForSilentAuto.setRefreshType(jsonObject.getIntValue("refreshType"));
        if (isInvalidObj(jsRefreshDataForSilentAuto, function)) {
            return false;
        }
        getDelegate().handleSetRefreshDataForSilentAuto(jsRefreshDataForSilentAuto);
        return true;
    }

    public void onShow(){
        mLSWebView.callHandler(ON_SHOW, "", new CallBackFunction() {
            @Override
            public void onCallBack(Object data) {
                Log.v(TAG,"onShow Callback"+data.toString());
            }
        });
    }
    public void onHideOrClose(){
        mLSWebView.callHandler(ON_HIDE_OR_CLOSE, "", new CallBackFunction() {
            @Override
            public void onCallBack(Object data) {
                Log.v(TAG,"onHideOrClose Callback"+data.toString());
            }
        });
    }
}
