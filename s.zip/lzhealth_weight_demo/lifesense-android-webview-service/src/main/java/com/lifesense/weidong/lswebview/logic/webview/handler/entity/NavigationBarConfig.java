package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;
import com.lifesense.weidong.lswebview.logic.webview.handler.NavigationBarJsHandler;

/**
 * @author Sinyi.liu
 * @date 2017/8/14 11:14
 * @describe:
 */
public class NavigationBarConfig extends JsEntity {
	private String title;
	private String subTitle;
	private JsColor color;//导航栏背景颜色，默认为导航栏App配色
	private int tintColorType= NavigationBarJsHandler.TINT_COLOR_BLACK;
	private double topPadding;
	private boolean barLineHidden ;
	private boolean autoResetToDefaultConfigWhtenOpenLink;
    @Override
    public boolean isInvalid() {

        return false;
    }
    public String getTitle() {
        return title;
    }

    public NavigationBarConfig setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public NavigationBarConfig setSubTitle(String subTitle) {
        this.subTitle = subTitle;
        return this;
    }

    public JsColor getColor() {
        return color;
    }

    public NavigationBarConfig setColor(JsColor color) {
        this.color = color;
        return this;
    }

    public int getTintColorType() {
        return tintColorType;
    }

    public NavigationBarConfig setTintColorType(int tintColorType) {
        this.tintColorType = tintColorType;
        return this;
    }

    public double getTopPadding() {
        return topPadding;
    }

    public NavigationBarConfig setTopPadding(double topPadding) {
        this.topPadding = topPadding;
        return this;
    }

    public boolean isBarLineHidden() {
        return barLineHidden;
    }

    public NavigationBarConfig setBarLineHidden(boolean barLineHidden) {
        this.barLineHidden = barLineHidden;
        return this;
    }

    public boolean isAutoResetToDefaultConfigWhtenOpenLink() {
        return autoResetToDefaultConfigWhtenOpenLink;
    }

    public NavigationBarConfig setAutoResetToDefaultConfigWhtenOpenLink(boolean autoResetToDefaultConfigWhtenOpenLink) {
        this.autoResetToDefaultConfigWhtenOpenLink = autoResetToDefaultConfigWhtenOpenLink;
        return this;
    }


}
