package com.lifesense.weidong.lswebview.webview.engine;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.ColorInt;
import android.view.View;

import com.lifesense.weidong.lswebview.logic.webview.LSWebViewManager;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.WebViewJavascriptBridge;
import com.lifesense.weidong.lswebview.webview.ILSWebViewInterface;
import com.lifesense.weidong.lswebview.webview.LSWebViewClient;
import com.lifesense.weidong.lswebview.webview.WebSettings;


import java.net.HttpCookie;

import java.util.List;

/**
 * Created by liuxinyi on 2017/4/13.
 */

public abstract class BaseWebViewEngine<T extends View> implements ILSWebViewInterface {
	protected T mWebView;
	protected LSWebViewClient mLSWebViewClient;
	protected WebViewJavascriptBridge mJSBridgeEngine;
	public BaseWebViewEngine(T t, LSWebViewClient lsWebViewClient) {
		this.mWebView = t;
		this.mLSWebViewClient = lsWebViewClient;
	}

	public BaseWebViewEngine setLSWebViewClient(LSWebViewClient LSWebViewClient) {
		mLSWebViewClient = LSWebViewClient;
		return this;
	}

	public BaseWebViewEngine setJSBridgeEngine(WebViewJavascriptBridge JSBridgeEngine) {
		mJSBridgeEngine = JSBridgeEngine;
		return this;
	}

	public T getWebView() {
		return mWebView;
	}

	public abstract WebSettings getWebViewSettings();

	public abstract int getScrollY();

	public void init() {
		LSWebViewManager.getInstance().syncWebViewCookie(this);
	}

    public static final String cookieUrl="//.lifesense.com/";

	private List<HttpCookie> mHttpCookies;

	public List<HttpCookie> getHttpCookies() {
		return mHttpCookies;
	}

	public void syncCookieToWebView(String url, List<HttpCookie> httpCookieList) {

	}

	public abstract void addJavascriptInterface(Object object, String name);

	public void onListenerDownloadStart(Context context, String url) {
		//打开系统下载器
		Uri uri = Uri.parse(url);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		try {
			context.startActivity(intent);
		} catch (Exception e) {

		}

	}

	public static Intent getAppIntent(Context paramContext) {
		StringBuilder localStringBuilder = new StringBuilder().append("market://details?id=");
		String str = paramContext.getPackageName();
		localStringBuilder.append(str);
		Uri localUri = Uri.parse(localStringBuilder.toString());
		return new Intent("android.intent.action.VIEW", localUri);
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {

	}
	public void setBackgroundColor(@ColorInt int color) {
		getWebView().setBackgroundColor(color);
	}

}
