package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import android.text.TextUtils;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsAlertData extends JsEntity {
	@Override
	public boolean isInvalid() {
		if (TextUtils.isEmpty(cancleButtonTitle) && TextUtils.isEmpty(confirmButtonTitle)) {
			return true;
		}
		return TextUtils.isEmpty(message) && TextUtils.isEmpty(title);
	}
	String id;
	boolean tapButtonToDismissOnly;
	String title;
	String message;
	String cancleButtonTitle;
	String confirmButtonTitle;
	String callBackHandlerName;

	public boolean isTitle() {
		return !TextUtils.isEmpty(title);
	}
	public boolean isTwoButton() {
        return !TextUtils.isEmpty(cancleButtonTitle) && !TextUtils.isEmpty(confirmButtonTitle);
    }

	public String getId() {
		return id;
	}

	public JsAlertData setId(String id) {
		this.id = id;
		return this;
	}

	public boolean isTapButtonToDismissOnly() {
		return tapButtonToDismissOnly;
	}

	public JsAlertData setTapButtonToDismissOnly(boolean tapButtonToDismissOnly) {
		this.tapButtonToDismissOnly = tapButtonToDismissOnly;
		return this;
	}

	public String getTitle() {
		return title;
	}

	public JsAlertData setTitle(String title) {
		this.title = title;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public JsAlertData setMessage(String message) {
		this.message = message;
		return this;
	}

	public String getCancleButtonTitle() {
		return cancleButtonTitle;
	}

	public JsAlertData setCancleButtonTitle(String cancleButtonTitle) {
		this.cancleButtonTitle = cancleButtonTitle;
		return this;
	}

	public String getConfirmButtonTitle() {
		return confirmButtonTitle;
	}

	public JsAlertData setConfirmButtonTitle(String confirmButtonTitle) {
		this.confirmButtonTitle = confirmButtonTitle;
		return this;
	}

	public String getCallBackHandlerName() {
		return callBackHandlerName;
	}

	public JsAlertData setCallBackHandlerName(String callBackHandlerName) {
		this.callBackHandlerName = callBackHandlerName;
		return this;
	}
}
