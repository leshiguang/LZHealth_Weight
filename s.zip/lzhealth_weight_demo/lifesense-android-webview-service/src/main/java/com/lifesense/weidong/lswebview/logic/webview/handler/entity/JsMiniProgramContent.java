package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import android.graphics.Bitmap;
import android.text.TextUtils;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;


/**
 * @author Sinyi.liu
 * @date 2017/10/19 09:43
 * @describe:
 */
public class JsMiniProgramContent extends JsEntity {
	private String title;
	private String desc;
	private String thumbUrl;
	private String webpageUrl;
	private String userName;
	private String path;
	private Bitmap mBitmap;
	private String hdImageUrl;
    private boolean withShareTicket;
    private int miniprogramType;

	public Bitmap getBitmap() {
		return mBitmap;
	}

	public JsMiniProgramContent setBitmap(Bitmap bitmap) {
		mBitmap = bitmap;
		return this;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getThumbUrl() {
		return thumbUrl;
	}

	public void setThumbUrl(String thumbUrl) {
		this.thumbUrl = thumbUrl;
	}

	public String getWebpageUrl() {
		return webpageUrl;
	}

	public void setWebpageUrl(String webpageUrl) {
		this.webpageUrl = webpageUrl;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Bitmap getmBitmap() {
		return mBitmap;
	}

	public void setmBitmap(Bitmap mBitmap) {
		this.mBitmap = mBitmap;
	}

	public String getHdImageUrl() {
		return hdImageUrl;
	}

	public void setHdImageUrl(String hdImageUrl) {
		this.hdImageUrl = hdImageUrl;
	}

	public boolean isWithShareTicket() {
		return withShareTicket;
	}

	public void setWithShareTicket(boolean withShareTicket) {
		this.withShareTicket = withShareTicket;
	}

	//js协议桥定义的乐心// 正式版:1，测试版:2，体验版:3
	//微信的类型 // 正式版:0，测试版:1，体验版:2
	public int getMiniprogramType() {
		return miniprogramType-1;
	}

	public void setMiniprogramType(int miniprogramType) {
		this.miniprogramType = miniprogramType;
	}

	@Override
	public boolean isInvalid() {
		return TextUtils.isEmpty(path);
	}
}
