package com.lifesense.weidong.lswebview.webview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;

import android.net.Uri;
import android.support.annotation.ColorInt;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lswebview.R;
import com.lifesense.weidong.lswebview.activity.WebViewActivity;
import com.lifesense.weidong.lswebview.logic.webview.base.BaseLSJavascriptInterface;
import com.lifesense.weidong.lswebview.logic.webview.js.CookieJavaScript;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.BridgeHandler;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.CallBackFunction;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.JSBridgeEngine;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.WebViewJavascriptBridge;
import com.lifesense.weidong.lswebview.util.DialogUtil;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lswebview.util.WechatUtils;
import com.lifesense.weidong.lswebview.webview.engine.BaseWebViewEngine;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 这个对上层封装webview的显示，以后APP所有的webview都使用这个
 * 如果有使用到webview的一些函数，但是这里没有，可以在 ILSWebViewInterface进行新增，然后在Engine进行实现
 * <p>
 * 该LSWebView只做代理
 * <p>
 * Created by liuxinyi on 2017/4/12.
 */

public class LSWebView extends LinearLayout implements LSWebViewClient, ILSWebViewInterface {
    private BaseWebViewEngine mWebViewEngine;
    private LSWebViewClient mLSWebViewClient;
    private WebViewJavascriptBridge mJSBridgeEngine;

    public LSWebView(Context context) {
        this(context,null);
    }

    public LSWebView(Context context, AttributeSet attrs) {
        this(context,attrs,0);
    }

    public LSWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }
    @SuppressLint("SetJavaScriptEnabled")
    private void init() {
        mWebViewEngine = LSWebViewFactory.createWebViewEngine(this);
        if (mWebViewEngine == null) {
            return;
        }
        getSettings().setJavaScriptEnabled(true);
        getSettings().setDefaultFontSize(16);
        getSettings().setCacheMode(android.webkit.WebSettings.LOAD_DEFAULT);
        getSettings().setDomStorageEnabled(true);    //开启DOM形式存储
        getSettings().setDatabaseEnabled(true);   //开启数据库形式存储
        getSettings().setAppCacheEnabled(true);  //开启缓存功能
        getSettings().setAllowFileAccess(true);

        mJSBridgeEngine = new JSBridgeEngine(this);
        mWebViewEngine.init();
        mWebViewEngine.setJSBridgeEngine(mJSBridgeEngine);
        mCookieJavaScript = new CookieJavaScript(getContext(), this);
        mCookieJavaScript.bindWebView();
    }


    private CookieJavaScript mCookieJavaScript;

    public void callHandler(String handlerName, Object data, CallBackFunction callBack) {
        if (mJSBridgeEngine == null) {
            return;
        }
        mJSBridgeEngine.callHandler(handlerName, data, callBack);
    }

    public void registerHandler(String handlerName, BridgeHandler handler) {
        if (mJSBridgeEngine == null) {
            return;
        }
        mJSBridgeEngine.registerHandler(handlerName, handler);
    }

    @Override
    public boolean canGoBack() {
        if (mWebViewEngine == null) {
            return false;
        }
        return mWebViewEngine.canGoBack();
    }

    @Override
    public void goBack() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.goBack();
    }

    @Override
    public void onResume() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.onResume();
    }

    @Override
    public void resumeTimers() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.resumeTimers();
    }

    @Override
    public void onPause() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.onPause();
    }

    @Override
    public void destroy() {
        try {
            removeAllViews();
            mWebViewEngine.destroy();
            mCookieJavaScript.unbindWebView();
        } catch (Exception e) {
        }
    }

    @Override
    public void reload() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.reload();
    }

    @Override
    public void pauseTimers() {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.pauseTimers();
    }

    @Override
    public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding,
                                    String historyUrl) {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, historyUrl);
    }

    public BaseWebViewEngine getWebViewEngine() {
        return mWebViewEngine;
    }

    @Override
    public void loadUrl(String url) {
        Map<String, String> additionalHttpHeaders = new HashMap<>();
        additionalHttpHeaders.put("Cache-Control", "max-age=0");
        loadUrl(url, additionalHttpHeaders);
    }

    @Override
    public void loadUrl(String url, Map<String, String> additionalHttpHeaders) {
        if (additionalHttpHeaders == null) {
            additionalHttpHeaders = new HashMap<>();
        }
        if (!additionalHttpHeaders.containsKey("Cache-Control")) {
            additionalHttpHeaders.put("Cache-Control", "max-age=0");
        }
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.loadUrl(url, additionalHttpHeaders);
    }

    @Override
    public void setCookie(String url, List<String> cookielist) {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.setCookie(url, cookielist);
    }

    public void addJavascriptInterface(BaseLSJavascriptInterface javascriptInterface) {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.addJavascriptInterface(javascriptInterface, javascriptInterface.getName());
    }

    public void addJavascriptInterface(Object object, String name) {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.addJavascriptInterface(object, name);
    }

    public WebSettings getSettings() {
        if (mWebViewEngine == null) {
            return null;
        }

        return mWebViewEngine.getWebViewSettings();
    }

    public LSWebView setLSWebViewClient(LSWebViewClient webViewClient) {
        mLSWebViewClient = webViewClient;
        if (mWebViewEngine == null) {
            return this;
        }
        if (mLSWebViewClient == null) {
            mWebViewEngine.setLSWebViewClient(this);
        } else {
            mWebViewEngine.setLSWebViewClient(mLSWebViewClient);
        }
        return this;
    }

    @Override
    public boolean shouldOverrideUrlLoading(String url) {
        System.out.println();
        return false;
    }

    @Override
    public void onPageStarted(String url, Bitmap favicon) {

    }

    @Override
    public void onPageFinished(String url) {
        loadUrl("javascript：window.HTMLOUT.getContentWidth(document.getElementsByTagName('html')[0].scrollWidth);");
    }

    @Override
    public void onReceivedError(int errorCode, String description, String failingUrl) {

    }

    @Override
    public void onReceivedTitle(String title) {

    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onConsoleMessage(String message) {
        return false;
    }

    @Override
    public void onShowCustomView(View view, Object callback) {

    }

    @Override
    public void onHideCustomView() {

    }

    public float getViewScrollY() {
        if (mWebViewEngine == null) {
            return 0;
        }
        return mWebViewEngine.getScrollY();
    }

    @Override
    public void setBackgroundColor(@ColorInt int color) {
        super.setBackgroundColor(color);
        if (mWebViewEngine == null) {
            return;
        }
        mWebViewEngine.setBackgroundColor(color);
    }

    @Override
    public boolean canScrollVertically(int direction) {
        if (mWebViewEngine.getWebView() instanceof WebView) {
            WebView webView = (WebView) mWebViewEngine.getWebView();
            return direction < 0 ? webView.getScrollY() > 0
                    : webView.getScrollY() < webView
                    .getMeasuredHeight();
        } else {
            return super.canScrollVertically(direction);
        }
    }

	@Override
	public boolean onShowFileChooser(ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
		return false;
	}

	@Override
    public void setOnLongClickListener(OnLongClickListener onLongClickListener) {
        mWebViewEngine.getWebView().setOnLongClickListener(onLongClickListener);
    }

}
