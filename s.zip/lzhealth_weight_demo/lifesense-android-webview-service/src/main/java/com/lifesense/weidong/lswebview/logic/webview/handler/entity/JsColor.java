package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import android.graphics.Color;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsColor extends JsEntity {
    int red;
    int green;
    int blue;
    int alpha;

    public int toColor() {
        return Color.argb(alpha, red, green, blue);
    }

    public int getRed() {
        return red;
    }

    public JsColor setRed(int red) {
        this.red = red;
        return this;
    }

    public int getGreen() {
        return green;
    }

    public JsColor setGreen(int green) {
        this.green = green;
        return this;
    }

    public int getBlue() {
        return blue;
    }

    public JsColor setBlue(int blue) {
        this.blue = blue;
        return this;
    }

    public int getAlpha() {
        return alpha;
    }

    public JsColor setAlpha(int alpha) {
        this.alpha = alpha;
        return this;
    }

    @Override
    public boolean isInvalid() {
        return false;
    }

}
