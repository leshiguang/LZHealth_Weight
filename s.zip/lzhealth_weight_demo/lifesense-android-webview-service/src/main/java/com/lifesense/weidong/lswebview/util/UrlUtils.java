package com.lifesense.weidong.lswebview.util;

public class UrlUtils {
    public static final String OPERATION_URL = "%1$s/raw/guide/app/explainPage-jump.html?modelNum=%2$s&softwareVersion=%3$s&from=%4$s&hardWareVersion=%5$s";

}
