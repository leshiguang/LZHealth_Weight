package com.lifesense.weidong.lswebview.logic.webview.handler;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lifesense.weidong.lswebview.logic.webview.base.BaseLSBridgeJs;
import com.lifesense.weidong.lswebview.logic.webview.delegate.INavigationBarDelegate;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsButton;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsColor;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsMenu;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsTitle;
import com.lifesense.weidong.lswebview.logic.webview.handler.entity.JsTransition;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.CallBackFunction;
import com.lifesense.weidong.lswebview.webview.LSWebView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxinyi on 2017/3/22.
 * 接口定义地址
 * https://wiki.lifesense.com/doku.php?id=%E6%96%B0%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%8E%A5%E5%8F%A3
 */

public class NavigationBarJsHandler extends BaseLSBridgeJs<INavigationBarDelegate> {
	public static final int TINT_COLOR_BLACK = 2;
	public static final int TINT_COLOR_WHITE = 1;
	public static final int ILLEGAL_TOP_PADDING = 5000;

	/**
	 * 处理前端设置title
	 * 跳转到其他URL时自动重置为“”
	 */
	public static final String SET_BAR_TITLE = "setNavigationBarTitle";

	/**
	 * 对象,设置导航栏背景颜色 ，跳转到其他URL时自动重置为App主色
	 */
	public static final String SET_NAVIGATION_BAR_COLOR = "setNavigationBarColor";
	/**
	 * Int，设置导航栏标题文本,返回键及状态栏等样式，仅能设置为白色样式或黑色样式，默认白色, 1:白色，2:黑色 ，跳转到其他URL时自动重置为白色
	 */
	public static final String SET_NAVIGATION_BAR_TINT_COLOR_TYPE = "setNavigationBarTintColorType";
	/**
	 * Double，设置WebView顶部到屏幕缩进，默认缩进为内容刚好在导航栏下方，设0整个webView内容填充屏幕，跳转到其他URL时自动重置为到导航栏下方
	 */
	public static final String SET_WEBVIEW_TOP_PADDING = "setWebViewTopPadding";
	/**
	 * 对象，设置导航栏随webView滑动时的颜色变化 ，跳转到其他URL时自动重置
	 */
	public static final String SET_NAVIGATION_BAR_SCROLLING_TRANSITION = "setNavigationBarScrollingTransition";
	/**
	 * Button配置对象数组，多次设置则替换上次设置结果，最多允许设置两个，按数组顺序从右往左布局，跳转到其他URL时自动重置为空
	 */
	public static final String SET_NAVIGATION_BAR_BUTTONS = "setNavigationBarButtons";
	/**
	 * Menu配置对象，跳转到其他URL时自动重置为空
	 */
	public static final String SHOW_NAVIGATION_BAR_MENU = "showNavigationBarMenu";
	/**
	 * 退出当前WebView控制器
	 */
	public static final String POP_VIEW_CONTROLLER = "popViewController";
	/**
	 * 跳转到根控制（所选tabBar的Tab的第一个控制器）
	 */
	public static final String POP_TOROOTVIEW_CONTROLLER = "popToRootViewController";

	//----------------3.1版本支持----------------------
	/**
	 * 隐藏导航栏那条线
	 */
	public static final String SET_BAR_LINE_HIDDEN = "setBarLineHidden";

	/**
	 * NavigationBarConfig配置对象，设置Title，导航栏颜色等 新增是否记住上次状态标记。
	 */
	public static final String SET_NAVIGATION_BAR_CONFIG = "setNavigationBarConfig";

	/**
	 * App开放给前端的注册app_webview事件回调接口,3.1版本支持返回键。
	 */
	public static final String REGISTER_WEBVIEW_EVENT_DELEGATE = "registerWebViewEventDelegate";

	//-------------3.2版本支持
	/**
	 * 跳转界面并结束WebView
	 */
	public static final String PUSH_VIEW_CONTROLLER = "pushViewController";



	public NavigationBarJsHandler(LSWebView lsWebView, INavigationBarDelegate delegate) {
		super(lsWebView, delegate);
	}
	@Override
	public void registerHandler(LSWebView lsWebView) {
		//1
		lsWebView.registerHandler(SET_BAR_TITLE, this);
		//2
		lsWebView.registerHandler(SET_NAVIGATION_BAR_COLOR, this);
		//3
		lsWebView.registerHandler(SET_WEBVIEW_TOP_PADDING, this);
		//4
		lsWebView.registerHandler(SET_NAVIGATION_BAR_SCROLLING_TRANSITION, this);
		//5
		lsWebView.registerHandler(SET_NAVIGATION_BAR_BUTTONS, this);
		//6
		lsWebView.registerHandler(SHOW_NAVIGATION_BAR_MENU, this);
		//7
		lsWebView.registerHandler(POP_VIEW_CONTROLLER, this);
		//8
		lsWebView.registerHandler(POP_TOROOTVIEW_CONTROLLER, this);
		//9
		lsWebView.registerHandler(SET_NAVIGATION_BAR_TINT_COLOR_TYPE, this);
		//10
		lsWebView.registerHandler(SET_BAR_LINE_HIDDEN, this);
		//11
		lsWebView.registerHandler(SET_NAVIGATION_BAR_CONFIG, this);
		// 12   3.2版本支持
		lsWebView.registerHandler(REGISTER_WEBVIEW_EVENT_DELEGATE, this);
		lsWebView.registerHandler(PUSH_VIEW_CONTROLLER,this);
	}

	public void clickButton(JsButton jsButton) {
		if (jsButton != null && !jsButton.isInvalid()) {
			mLSWebView.callHandler(jsButton.getCallbackHandlerName(), jsButton.getButtonId(),
					new CallBackFunction() {
						@Override
						public void onCallBack(Object data) {

						}
					});
		}

	}
	public void clickMenuItem(JsMenu jsMenu, int index) {
		if (jsMenu != null && !TextUtils.isEmpty(jsMenu.getCallbackHandlerName())) {
			//            jsMenu.getCallbackHandlerName()
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("selectedIndex", index);
			jsonObject.put("menuId", jsMenu.getMenuId());
			mLSWebView.callHandler(jsMenu.getCallbackHandlerName(), jsonObject,
					new CallBackFunction() {
						@Override
						public void onCallBack(Object data) {

						}
					});
		}
	}
	private boolean handlerSetTitle(String data, CallBackFunction function) {
		JsTitle jsTitle = JSON.parseObject(data, JsTitle.class);
		if (isInvalidObj(jsTitle, function)) {
			return false;
		}
		getDelegate().handlerSetTitle(jsTitle);
		return true;
	}

	private boolean handlerSetNavigationBarColor(String data, CallBackFunction function) {
		JsColor jsColor = JSON.parseObject(data, JsColor.class);
		if (isInvalidObj(jsColor, function)) {
			return false;
		}
		getDelegate().handlerSetNavigationBarColor(jsColor.toColor());
		return true;
	}

	private boolean handlerSetWebViewTopPadding(String data, CallBackFunction function) {
		if (data == null) {
			return false;
		}
		float dp = ILLEGAL_TOP_PADDING;
		try {
			dp = Float.parseFloat(data);
			getDelegate().handlerSetWebViewTopPadding(dp);
			return true;
		} catch (NumberFormatException e) {
			callBackParseError(function);
			return false;
		}
	}

	private boolean handlerSetNavigationBarScrollingTransition(String data,
                                                               CallBackFunction function) {
		JsTransition jsTransition = JSON.parseObject(data, JsTransition.class);
		if (isInvalidObj(jsTransition, function)) {
			return false;
		}
		getDelegate().handlerSetNavigationBarScrollingTransition(jsTransition);
		return true;
	}

	private boolean handlerSetNavigationBarButtons(String data, CallBackFunction function) {
		List<JsButton> buttons = JSON.parseArray(data, JsButton.class);
		//		if (isInvalidArray(buttons, function)) {
		//			return false;
		//		}
		getDelegate().handlerSetNavigationBarButtons(buttons);
		return true;
	}

	private boolean handlerPopViewController(String data, CallBackFunction function) {
		getDelegate().handlerPopViewController();
		return true;

	}

	private boolean handlerSetNavigationBarTintColorType(String data, CallBackFunction function) {
		try {
			int type = Integer.parseInt(data);
			//等于2才是黑色
			getDelegate().handlerSetNavigationBarTintColorType(type == TINT_COLOR_BLACK);

		} catch (NumberFormatException e) {
			getDelegate().handlerSetNavigationBarTintColorType(true); //3.1版本默认颜色是黑色主题
		}
		return true;

	}
	private boolean handlerSetBarLineHidden(String data, CallBackFunction function) {
		if (data != null) {
			boolean hidden = data.contains("1") || data.contains("true");//不强装了，协议里面1是隐藏, 0是显示,就判断这个data里面是否有1
			getDelegate().handlerSetBarLineHidden(hidden);
		}
		return true;
	}
	private boolean handlerRegisterWebViewEventDelegate(String data, CallBackFunction function){
		if (data == null) {
			callBackParseError(function);
			return false;
		}
		getDelegate().handlerRegisterWebViewEventDelegate(data);

		return true;
	}

	private boolean handlerSetNavigationBarConfig(String data, CallBackFunction function) {
		if (data != null) {
			JSONObject jsonObject = JSON.parseObject(data);
			boolean autoResetToDefaultConfigWhtenOpenLink;
			if (jsonObject.containsKey("autoResetToDefaultConfigWhtenOpenLink")) {
				try {
					autoResetToDefaultConfigWhtenOpenLink = jsonObject
							.getBooleanValue("autoResetToDefaultConfigWhtenOpenLink");
				} catch (Exception e) {
					autoResetToDefaultConfigWhtenOpenLink = true;
				}

			} else {
				return false;
			}
			getDelegate().handlerNavigationBarConfig(autoResetToDefaultConfigWhtenOpenLink);

			//------取标题
			String title = jsonObject.getString("title");
			String subTitle = jsonObject.getString("subTitle");
			String titleLeftImage = jsonObject.getString("titleLeftImage");	//标题栏左侧图片
			String titleRightImage = jsonObject.getString("titleRightImage");	//标题栏右侧图片
			JsTitle jsTitle = new JsTitle();
			jsTitle.setTitle(title);
			jsTitle.setSubTitle(subTitle);
			jsTitle.setTitleLeftImage(titleLeftImage);
			jsTitle.setTitleRightImage(titleRightImage);
			//------取导航栏标题点击事件
			List<JsButton> titleJsButton = new ArrayList<>();
			try{
				String s = jsonObject.getString("titleCallback");
				if(!TextUtils.isEmpty(s)){
					titleJsButton = JSON.parseArray(s, JsButton.class);
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			//------取导航栏颜色
			String color = jsonObject.getString("color");
			JsColor jsColor = JSON.parseObject(color, JsColor.class);
			//-------取tintColorType
			if (jsonObject.containsKey("tintColorType")) {
				handlerSetNavigationBarTintColorType(jsonObject.getString("tintColorType"),
						function);
			}
			if (jsonObject.containsKey("topPadding")) {
				handlerSetWebViewTopPadding(jsonObject.getString("topPadding"), function);
			}
			if (jsonObject.containsKey("barLineHidden")) {
				handlerSetBarLineHidden(jsonObject.getString("barLineHidden"), function);
			}

			if (!jsTitle.isInvalid()) {
				getDelegate().handlerSetTitle(jsTitle);
			}

			if (jsColor != null && !jsColor.isInvalid()) {
				getDelegate().handlerSetNavigationBarColor(jsColor.toColor());
			}

			getDelegate().handlerNavigationBarTitleEvent(titleJsButton);
		}

		return true;
	}

	@Override
	public void handler(String handlerName, String data, CallBackFunction function) {
		if (TextUtils.isEmpty(handlerName)) {
			Log.e("sinyi", "NavigationBarJsHandler handler: error handlerName==null" + data);
			callBackFunction(function, FAILURE, "handlerName is null");
			return;
		}
		if (getDelegate() == null) {
			callBackFunction(function, FAILURE, "app error delegate is null");
			return;
		}
		//		if (data == null) {
		//			callBackFunction(function, FAILURE, "data is null");
		//			return;
		//		}
		boolean ret = false;
		if (handlerName.equals(SET_BAR_TITLE)) {
			ret = handlerSetTitle(data, function);
		} else if (handlerName.equals(SET_NAVIGATION_BAR_COLOR)) {
			ret = handlerSetNavigationBarColor(data, function);
		} else if (handlerName.equals(SET_WEBVIEW_TOP_PADDING)) {
			ret = handlerSetWebViewTopPadding(data, function);
		} else if (handlerName.equals(SET_NAVIGATION_BAR_SCROLLING_TRANSITION)) {
			ret = handlerSetNavigationBarScrollingTransition(data, function);
		} else if (handlerName.equals(SET_NAVIGATION_BAR_BUTTONS)) {
			ret = handlerSetNavigationBarButtons(data, function);
		} else if (handlerName.equals(POP_VIEW_CONTROLLER)) {
			ret = handlerPopViewController(data, function);
		} else if (handlerName.equals(SET_NAVIGATION_BAR_TINT_COLOR_TYPE)) {
			ret = handlerSetNavigationBarTintColorType(data, function);
		} else if (handlerName.equals(SET_BAR_LINE_HIDDEN)) {
			ret = handlerSetBarLineHidden(data, function);
		} else if (handlerName.equals(SET_NAVIGATION_BAR_CONFIG)) {
			ret = handlerSetNavigationBarConfig(data, function);
		}else if(handlerName.equals(REGISTER_WEBVIEW_EVENT_DELEGATE)){
			handlerRegisterWebViewEventDelegate(data, function);
//		} else if(handlerName.equals(PUSH_VIEW_CONTROLLER)) {
//			ret =handlerPushViewController(data,function);
		}
		if (ret) {
			//回调给前端，设置成功
			callBackFunction(function, SUCCEED, "");
		}
	}

	private boolean handlerShowNavigationBarMenu(String data, CallBackFunction function) {
		JsMenu jsMenu = JSON.parseObject(data, JsMenu.class);
		if (isInvalidObj(jsMenu, function)) {
			return false;
		}
		getDelegate().handlerShowNavigationBarMenu(jsMenu);
		return true;

	}
//	private boolean handlerPushViewController(String data, CallBackFunction function) {
//		JsPushConfig jsPushConfig = JSON.parseObject(data, JsPushConfig.class);
//		if (jsPushConfig == null) {
//			callBackParseError(function);
//			return false;
//		}
//		if (TextUtils.isEmpty(jsPushConfig.getViewType())) {
//			callBackParseError(function);
//			return false;
//		}
//		org.json.JSONObject jsonObject =new org.json.JSONObject();
//		try {
//			jsonObject.put("viewType",jsPushConfig.getViewType());
//			jsonObject.put("data",JSON.parseObject(data).getJSONObject("data"));
//		} catch (JSONException e) {
//			e.printStackTrace();
//		}
//
//		try {
//			JumpActionManage.getInstance().parseJpushJump(mLSWebView.getContext(),jsPushConfig.getViewType(),jsonObject,null);
//		} catch (JSONException e) {
//			e.printStackTrace();
//		}
//		getDelegate().handlerPushViewControllerDelegate(jsPushConfig);
//		if (jsPushConfig.isShouldCloseWebViewControllerAfterPush()) {
//			Activity activity = (Activity) mLSWebView.getContext();
//			activity.finish();
//		}
//		return true;
//	}
}
