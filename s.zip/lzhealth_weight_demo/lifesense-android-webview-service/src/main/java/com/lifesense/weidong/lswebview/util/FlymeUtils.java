package com.lifesense.weidong.lswebview.util;

import android.os.Build;

import java.lang.reflect.Method;

/**
 * Created by lee on 16-7-15.
 */
public class FlymeUtils {
    public static boolean isFlyme() {
        try {
            // Invoke Build.hasSmartBar()
            final Method method = Build.class.getMethod("hasSmartBar");
            return method != null;
        } catch (final Exception e) {
            return false;
        }
    }

}
