package com.lifesense.weidong.lswebview.webview.toolbar;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lswebview.R;


/**
 * @author Sinyi.liu
 * @date 2017/6/12
 */

public class MenuView extends RelativeLayout {
	public MenuView(Context context) {
		super(context);
		init();

	}

	public MenuView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();

	}

	public MenuView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();

	}

	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
	public MenuView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr, defStyleRes);
		init();
	}
	private ImageView ivMenu;
	private TextView tvMenu;
	private void init() {
		LayoutInflater.from(getContext()).inflate(R.layout.menu_view, this);
		ivMenu = findViewById(R.id.iv_menu);
		tvMenu = findViewById(R.id.tv_menu);
	}

	public ImageView getIvMenu() {
		return ivMenu;
	}

	public void setImageUrl(String url) {
		Uri uri = Uri.parse(url);
		if (TextUtils.isEmpty(url) || uri == null) {
			return;
		}
		String scheme = uri.getScheme();
		if (scheme.equalsIgnoreCase("localImage")) {
			//显示本地图片
			String name = uri.getHost();
			ivMenu.setVisibility(View.VISIBLE);
			ivMenu.setImageResource(getImgResidByName(name));
			//这里根据name 映射本地图片
		} else {
			ivMenu.setVisibility(View.VISIBLE);
			url = url.replace("https","http");
			ImageUtil.displayImage(url, ivMenu);
		}
	}
	public void setTextVisibility(int visibility){
		tvMenu.setVisibility(visibility);
	}
	public void setText(String text) {
		if(text==null){
			text="";
		}
		tvMenu.setVisibility(View.VISIBLE);
		if(!TextUtils.isEmpty(text)){
			ivMenu.setVisibility(View.GONE);
		}
		tvMenu.setText(text);
	}
	public void setTextColor(int color){
		tvMenu.setTextColor(color);
	}
	public void setNull(){
		ivMenu.setVisibility(View.GONE);
		tvMenu.setText("");
	}
	public void setImageResId(@DrawableRes int resId) {
		if(resId != 0) {
			ivMenu.setVisibility(View.VISIBLE);
			ivMenu.setImageResource(resId);
			tvMenu.setText("");

		}else{
			ivMenu.setVisibility(View.GONE);
		}
	}
	public int getImgResidByName(String name) {

		return R.mipmap.icon_more;
	}

}
