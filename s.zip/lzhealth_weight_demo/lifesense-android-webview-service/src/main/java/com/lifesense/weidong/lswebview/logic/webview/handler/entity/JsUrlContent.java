package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import android.graphics.Bitmap;
import android.text.TextUtils;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/10/19 09:43
 * @describe:
 */
public class JsUrlContent extends JsEntity {
	private String title;
	private String url;
	private String imgUrl;
	private String qrImgUrl;
	private String desc;
	private Bitmap mBitmap;
	private String userName;
	private String path;

	public Bitmap getBitmap() {
		return mBitmap;
	}

	public JsUrlContent setBitmap(Bitmap bitmap) {
		mBitmap = bitmap;
		return this;
	}

	public String getTitle() {
		return title;
	}

	public JsUrlContent setTitle(String title) {
		this.title = title;
		return this;
	}

	public String getUrl() {
		return url;
	}

	public JsUrlContent setUrl(String url) {
		this.url = url;
		return this;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public JsUrlContent setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
		return this;
	}

	public String getDesc() {
		return desc;
	}

	public JsUrlContent setDesc(String desc) {
		this.desc = desc;
		return this;
	}

	public JsUrlContent setUserName(String userName) {
		this.userName = userName;
		return this;
	}

	public String getUserName() {
		return userName;
	}

	public JsUrlContent setPath(String path) {
		this.path = path;
		return this;
	}

	public String getPath() {
		return path;
	}

	@Override
	public boolean isInvalid() {
		return TextUtils.isEmpty(url);
	}

	public String getQrImgUrl() {
		return qrImgUrl;
	}

	public void setQrImgUrl(String qrImgUrl) {
		this.qrImgUrl = qrImgUrl;
	}
}
