package com.lifesense.weidong.lswebview.webview;


import android.graphics.Bitmap;
import android.net.Uri;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;


/**
 * WebView的事件回调都抽到这里来了，如有需要用，可以在这里新增
 * Created by liuxinyi on 2017/4/13.
 */

public interface LSWebViewClient {
    boolean shouldOverrideUrlLoading(String url);

    void onPageStarted(String url, Bitmap favicon);

    void onPageFinished(String url);

    void onReceivedError(int errorCode, String description, String failingUrl);

    void onReceivedTitle(String title);

    boolean onConsoleMessage(String message);

    void onShowCustomView(View view, Object callback);

    void onHideCustomView();

    boolean onShowFileChooser(ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams);

}
