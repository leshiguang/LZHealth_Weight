package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsTransition extends JsEntity {
    JsColor finalColor;
    int finalTintColorType;
    double scrollDistance;
    int startColor;

    public int getStartColor() {
        return startColor;
    }

    public JsTransition setStartColor(int startColor) {
        this.startColor = startColor;
        return this;
    }

    public JsColor getFinalColor() {
        return finalColor;
    }

    public JsTransition setFinalColor(JsColor finalColor) {
        this.finalColor = finalColor;
        return this;
    }

    public int getFinalTintColorType() {
        return finalTintColorType;
    }
    public boolean isDark(){
        return finalTintColorType==2;
    }

    public JsTransition setFinalTintColorType(int finalTintColorType) {
        this.finalTintColorType = finalTintColorType;
        return this;
    }

    public double getScrollDistance() {
        return scrollDistance;
    }

    public JsTransition setScrollDistance(double scrollDistance) {
        this.scrollDistance = scrollDistance;
        return this;
    }

    @Override
    public boolean isInvalid() {
        return finalColor == null;
    }

}
