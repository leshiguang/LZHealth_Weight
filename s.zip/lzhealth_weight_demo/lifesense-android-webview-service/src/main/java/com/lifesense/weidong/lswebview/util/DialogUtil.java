package com.lifesense.weidong.lswebview.util;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.lifesense.weidong.lswebview.R;
import com.lifesense.weidong.lswebview.dialog.CustomDialog;

public class DialogUtil {
	public static DialogUtil dialogUtil;
	private PopupWindow mPopupWindow = null;
	private Dialog dialog;
	private View view;
	private ImageView mIvDelete;
	private TextView mTvToConfirm;
	private TextView mTvTips;

	public static DialogUtil getInstance() {
		if (dialogUtil == null) {
			dialogUtil = new DialogUtil();
		}
		return dialogUtil;
	}

	public View getPopView() {
		return view;
	}

	public Dialog getDialog() {
		return dialog;
	}

	public void setToConfirmOnClickListener(View.OnClickListener listener) {
		if (mTvToConfirm == null) {
			return;
		}
		mTvToConfirm.setOnClickListener(listener);
	}

	public void setIvDeleteOnClickListener(View.OnClickListener listener) {
		if (mIvDelete == null) {
			return;
		}
		mIvDelete.setOnClickListener(listener);
	}

	public void setTvTipsText(String s) {
		if (mTvTips == null) {
			return;
		}
		mTvTips.setText(s);
	}

	public void showNoTitleTwoBtnDialog(DialogConfig dialogConfig) {
		dismissDialog();
		dialog = DialogUtilImp.getInstance().showNoTitleTwoBtnDialog(dialogConfig);
		showDialog(dialog);

	}
//	public Window showTopConfirmInfoPop(Activity context) {
//		if (context == null) {
//			return null;
//		}
//		dialog = new AlertDialog.Builder(context).create();
//		try {
//			dialog.show();
//		} catch (Exception e) {
//		}
//		Window window = dialog.getWindow();
//		if (window == null) {
//			return null;
//		}
//		window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
//				LinearLayout.LayoutParams.WRAP_CONTENT);
//		window.setGravity(Gravity.BOTTOM);
//		window.setBackgroundDrawable(
//				new ColorDrawable(context.getResources().getColor(R.color.white)));
//		window.setContentView(R.layout.show_top_pop);
//		dialog.setCanceledOnTouchOutside(false);
//		dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
//			@Override
//			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
//                return keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0;
//			}
//		});
//		mTvToConfirm = window.findViewById(R.id.tvToConfirm);
//		mTvTips = window.findViewById(R.id.tvTips);
//		mIvDelete = window.findViewById(R.id.ivDelete);
//		mIvDelete.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				dismissProcessDialog();
//			}
//		});
//		return window;
//	}
	public void showBottomPop(AppCompatActivity context, int layoutId) {
		// 一个自定义的布局，作为显示的内容
		view = LayoutInflater.from(context).inflate(layoutId, null);
		LinearLayout layout_pic = view.findViewById(R.id.layout_pic);
		layout_pic.startAnimation(AnimationUtils.loadAnimation(context, R.anim.push_bottom_in));

		mPopupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT, true);
		//        mPopupWindow.setAnimationStyle(R.style.popupwindow_anim);
		mPopupWindow.setBackgroundDrawable(new ColorDrawable(0));
		View parentView = context.getWindow().findViewById(Window.ID_ANDROID_CONTENT);
		mPopupWindow.showAtLocation(parentView, Gravity.BOTTOM, 0, 0);
	}

//	public void showUnbindDialog(Context context, String text) {
//		if (context == null) {
//			return;
//		}
//		dismissProcessDialog();
//		try {
//			dialog = CustomDialog.createMicroDialog(context, R.layout.dialog_unbind);
//			TextView textView = dialog.findViewById(R.id.dhf_content_tv);
//			textView.setText(text);
//			dialog.findViewById(R.id.dhf_confirm_tv).setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					dismissProcessDialog();
//				}
//			});
//			showDialog(dialog);
//		} catch (Exception e) {
//
//		}
//
//	}

	/**
	 *
	 * 捕获对话框显示异常
	 *
	 * @param dialog
	 */
	public static void showDialog(Dialog dialog) {
		if (dialog == null) {
			return;
		}
		try {
			dialog.show();
			isShowDialog=true;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 捕获对话框取消异常
	 * @param dialog
	 */
	public static void dismissDialog(Dialog dialog) {
		if (dialog == null) {
			return;
		}
		try {
			if (dialog.isShowing()) {
				dialog.dismiss();
			}
		} catch (Exception e) {

		}
	}
	public void showNoTitleOneBtnDialog(DialogConfig dialogConfig) {
		dismissDialog();
		dialog = DialogUtilImp.getInstance().showNoTitleOneBtnDialog(dialogConfig);
		showDialog(dialog);

	}
//	public void showNoTitleTwoBtnDialog(DialogConfig dialogConfig) {
//		dismissDialog();
//		dialog = DialogUtilImp.getInstance().showNoTitleTwoBtnDialog(dialogConfig);
//		showDialog(dialog);
//
//	}
//	public void showTitleOneBtnDialog(DialogConfig dialogConfig) {
//		dismissDialog();
//		dialog = DialogUtilImp.getInstance().showTitleOneBtnDialog(dialogConfig);
//		showDialog(dialog);
//	}
//	public void showTitleTwoBtnDialog(DialogConfig dialogConfig) {
//		dismissDialog();
//		dialog = DialogUtilImp.getInstance().showTitleTwoBtnDialog(dialogConfig);
//		showDialog(dialog);
//	}

	private static boolean isShowDialog;

	public boolean isShowDialog() {
		return isShowDialog;
	}
//	/**
//	 * 废弃，使用功能使用 showNoTitleOneBtnDialog 、showNoTitleTwoBtnDialog
//	 *   showTitleOneBtnDialog，showTitleTwoBtnDialog 这4个调用
//	 * @param context
//	 * @param title
//	 * @param content
//	 * @param btnText
//	 * @param onClickListener
//	 * @param isCancelable
//	 */
//	@Deprecated
//	public void showTipsDialog(Context context, String title, String content, String btnText,
//                               View.OnClickListener onClickListener, boolean isCancelable) {
//		dismissProcessDialog();
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context).setTitle(title)
//				.setContent(content).setConfirmBtn(btnText).setConfirmClickListener(onClickListener)
//				.setCancelable(isCancelable).build();
//		if (TextUtils.isEmpty(title)) {
//			showNoTitleOneBtnDialog(dialogConfig);
//		} else {
//			showTitleOneBtnDialog(dialogConfig);
//		}
//	}
//	@Deprecated
//	public void showTipsTwoDialog(Context context, String title, String content, String btnText,
//                                  View.OnClickListener onClickListener, boolean isCancelable) {
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context).setTitle(title)
//				.setContent(content).setConfirmBtn(btnText).setConfirmClickListener(onClickListener)
//				.setCancelable(isCancelable).build();
//		showTitleTwoBtnDialog(dialogConfig);
//		//		showTipsTwoDialog(context, title, content, btnText, onClickListener, null, null,
//		//				isCancelable);
//	}
//	@Deprecated
//	public void showTipsTwoDialog(Context context, String title, String content, String btnText,
//                                  View.OnClickListener onClickListener, String cancelBtnText,
//                                  final View.OnClickListener cancelBtnListener, boolean isCancelable) {
//		dismissProcessDialog();
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context).setTitle(title)
//				.setContent(content).setConfirmBtn(btnText).setConfirmClickListener(onClickListener)
//				.setCancelBtn(cancelBtnText).setCancelClickListener(cancelBtnListener)
//				.setCancelable(isCancelable).build();
//		showTitleTwoBtnDialog(dialogConfig);
		//		
		//		
		//		dialog = CustomDialog.createStandardDialogWrapContent(context, R.layout.dialog_tips);
		//		TextView title_tv = (TextView) dialog.findViewById(R.id.dhof_title_tv);
		//		TextView dhof_subTitle_tv = (TextView) dialog.findViewById(R.id.dhof_subTitle_tv);
		//		TextView dhof_confirm_tv = (TextView) dialog.findViewById(R.id.dhof_confirm_tv);
		//		if (TextUtils.isEmpty(title)) {
		//			title_tv.setVisibility(View.GONE);
		//		} else {
		//			title_tv.setText(title);
		//		}
		//		if (TextUtils.isEmpty(content)) {
		//			dhof_subTitle_tv.setVisibility(View.GONE);
		//		} else {
		//			dhof_subTitle_tv.setText(content);
		//		}
		//		dhof_confirm_tv.setText(btnText);
		//		dhof_confirm_tv.setOnClickListener(onClickListener);
		//		dialog.setCancelable(isCancelable);
		//		dialog.setCanceledOnTouchOutside(isCancelable);
		//		TextView tvCancel = (TextView) dialog.findViewById(R.id.umeng_update_id_cancel);
		//		if (!TextUtils.isEmpty(cancelBtnText)) {
		//			tvCancel.setText(cancelBtnText);
		//		}
		//		tvCancel.setOnClickListener(new View.OnClickListener() {
		//			@Override
		//			public void onClick(View v) {
		//				if (cancelBtnListener == null) {
		//					dismissProcessDialog();
		//				} else {
		//					cancelBtnListener.onClick(v);
		//				}
		//			}
		//		});
		//		showDialog(dialog);
		//dialog.show();
//	}
//	@Deprecated
//	public void showTipsTwoNoTitleDialog(Context context, String content, String btnText1,
//                                         String btnText2, View.OnClickListener onClickListener) {
//
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context)
//				.setContent(content).setCancelBtn(btnText1).setConfirmBtn(btnText2)
//				.setConfirmClickListener(onClickListener).build();
//		showNoTitleTwoBtnDialog(dialogConfig);

		//		
		//		dismissProcessDialog();
		//		dialog = CustomDialog.createStandardDialog(context, R.layout.dialog_two_button);
		//		TextView tv_content = (TextView) dialog.findViewById(R.id.tv_content);
		//		TextView tv_cancel = (TextView) dialog.findViewById(R.id.tv_cancel);
		//		TextView tv_confirm = (TextView) dialog.findViewById(R.id.tv_confirm);
		//
		//		tv_content.setText(content);
		//		tv_cancel.setText(btnText1);
		//		tv_confirm.setText(btnText2);
		//		tv_confirm.setOnClickListener(onClickListener);
		//		tv_cancel.setBackgroundResource(R.drawable.common_dialog_confirm_bg_click);
		//		tv_cancel.setTextColor(ApplicationHolder.getmApplication().getResources()
		//				.getColor(R.color.common_dialog_cancel_click));
		//		tv_cancel.setOnClickListener(new View.OnClickListener() {
		//			@Override
		//			public void onClick(View v) {
		//				dismissProcessDialog();
		//			}
		//		});
		//		//dialog.show();
		//		showDialog(dialog);
//	}
//	@Deprecated
//	public void showTipsTwoNoTitleBigDialog(Context context, String content, String btnText1,
//                                            String btnText2, View.OnClickListener onClickListener,
//                                            final View.OnClickListener onClickListenerCancel) {
//
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context)
//				.setContent(content).setCancelBtn(btnText1).setConfirmBtn(btnText2)
//				.setConfirmClickListener(onClickListener)
//				.setCancelClickListener(onClickListenerCancel).build();
//		showNoTitleTwoBtnDialog(dialogConfig);
		//		dismissProcessDialog();
		//		dialog = CustomDialog.createStandardDialog(context, R.layout.dialog_two_button_big);
		//		TextView tv_content = (TextView) dialog.findViewById(R.id.tv_content);
		//		TextView tv_cancel = (TextView) dialog.findViewById(R.id.tv_cancel);
		//		TextView tv_confirm = (TextView) dialog.findViewById(R.id.tv_confirm);
		//
		//		tv_content.setText(content);
		//		tv_cancel.setText(btnText1);
		//		tv_confirm.setText(btnText2);
		//		tv_confirm.setOnClickListener(onClickListener);
		//		tv_cancel.setBackgroundResource(R.drawable.common_dialog_confirm_bg_click);
		//		tv_cancel.setOnClickListener(onClickListenerCancel);
		//		showDialog(dialog);
//	}
//	@Deprecated
//	public void showTipsTwoNoTitleDialog(Context context, String content, String btnText1,
//                                         String btnText2, View.OnClickListener tv_cancelOnClickListener,
//                                         View.OnClickListener onClickListener) {
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context)
//				.setContent(content).setCancelBtn(btnText1).setConfirmBtn(btnText2)
//				.setConfirmClickListener(onClickListener)
//				.setCancelClickListener(tv_cancelOnClickListener).build();
//		showNoTitleTwoBtnDialog(dialogConfig);
//	}
//	@Deprecated
//	public void showTipsTwoNoTitleDialog(Context context, String content, String btnText1,
//                                         String btnText2, View.OnClickListener tv_cancelOnClickListener,
//                                         View.OnClickListener onClickListener, boolean isCancelable) {
//		DialogConfig dialogConfig = new DialogConfig.Builder(context).setContext(context)
//				.setContent(content).setCancelBtn(btnText1).setConfirmBtn(btnText2)
//				.setConfirmClickListener(onClickListener)
//				.setCancelClickListener(tv_cancelOnClickListener).setCancelable(isCancelable)
//				.build();
//		showNoTitleTwoBtnDialog(dialogConfig);
//	}
//	public void showCenterPop(Activity context, int layoutId) {
//		// 一个自定义的布局，作为显示的内容
//		view = LayoutInflater.from(context).inflate(layoutId, null);
//		mPopupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
//				LinearLayout.LayoutParams.MATCH_PARENT, true);
//		mPopupWindow.setAnimationStyle(R.style.popupwindow_anim);
//		mPopupWindow.setBackgroundDrawable(new ColorDrawable(0));
//		View parentView = context.getWindow().findViewById(Window.ID_ANDROID_CONTENT);
//		mPopupWindow.showAtLocation(parentView, Gravity.CENTER, 0, 0);
//	}
//
	public void dismissPopupWindow() {
		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
			mPopupWindow = null;
		}
	}

//	public boolean isExitPopupWindow() {
//		boolean result = false;
//		if (mPopupWindow != null && mPopupWindow.isShowing()) {
//			result = true;
//		}
//		return result;
//	}

	public void showProcessDialog(Context context) {
		showProcessDialog(context, null, true);
	}

	/**
	 * @param context
	 * @param content
	 * @param isCancelable 设置为false，按返回键不能退出。默认为true。
	 */
	public void showProcessDialog(Context context, String content, boolean isCancelable) {
		dismissProcessDialog();
		if (context == null) {
			return;
		}
		Resources resources = context.getResources();
		DisplayMetrics dm = resources.getDisplayMetrics();
		int w = (int) (dm.widthPixels * 0.5);
		int h = (int) (dm.heightPixels * 0.2);
		//        dialog = new CustomDialog(context, w, h, R.layout.dialog_hint_loading);
		dialog = CustomDialog.createStandardDialog(context, R.layout.dialog_hint_loading);
		dialog.setCancelable(isCancelable);
		TextView loadint_text = dialog.findViewById(R.id.loadint_text);
		if (!TextUtils.isEmpty(content)) {
			loadint_text.setText(content);
		}

		showDialog(dialog);
	}

	/**
	 * @param context
	 * @param isCancelable 设置为false，按返回键不能退出。默认为true。
	 */
	public void showProcessDialog(Context context, boolean isCancelable, int layoutId) {
		dismissProcessDialog();
		Resources resources = context.getResources();
		DisplayMetrics dm = resources.getDisplayMetrics();
		int w = (int) (dm.widthPixels * 0.5);
		int h = (int) (dm.heightPixels * 0.2);
		//        dialog = new CustomDialog(context, w, h, R.layout.dialog_hint_loading);
		dialog = CustomDialog.createStandardDialog(context, layoutId);
		dialog.setCancelable(isCancelable);
		//dialog.show();
		showDialog(dialog);
	}

	public void dismissProcessDialog() {

		if (dialog != null) {
			boolean isDismiss = false;
			if (dialog.isShowing() && dialog.getContext() instanceof AppCompatActivity) { // 3重保护
				AppCompatActivity activity = (AppCompatActivity) dialog.getContext();
				if (!activity.isFinishing()) { // 依附的activity未结束
					dialog.dismiss();
					isDismiss = true;
				}
			}
			if (!isDismiss) {// 如果没经过上述流程，则try catch 处理
				try {
					dialog.dismiss();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		dialog = null;
		isShowDialog=false;
	}

	public void dismissDialog() {
		dismissProcessDialog();
	}
	public Dialog showFullscreenDialog(int layoutId, Context context) {
		CustomDialog customDialog = new CustomDialog(context, layoutId,true);
		return customDialog;
	}

}
