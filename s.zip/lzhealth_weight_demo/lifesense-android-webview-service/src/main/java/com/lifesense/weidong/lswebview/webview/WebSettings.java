package com.lifesense.weidong.lswebview.webview;


import com.lifesense.weidong.lswebview.webview.engine.BaseWebViewEngine;

/**
 * Created by liuxinyi on 2017/4/13.
 */

public abstract class WebSettings<T> extends android.webkit.WebSettings {
    protected BaseWebViewEngine mBaseWebViewEngine;
    protected T mSettings;

    public WebSettings(BaseWebViewEngine baseWebViewEngine, T t) {
        mBaseWebViewEngine = baseWebViewEngine;
        mSettings = t;
    }
}
