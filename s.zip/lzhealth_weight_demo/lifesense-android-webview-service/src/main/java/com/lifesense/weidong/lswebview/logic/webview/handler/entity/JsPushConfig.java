package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import org.json.JSONObject;

/**
 * @author Sinyi.liu
 * @date 2017/10/31 15:05
 * @describe:
 */
public class JsPushConfig {
    private String viewType;
    private JSONObject data;
    private boolean shouldCloseWebViewControllerAfterPush;
    private boolean shouldRefreshWebViewControllerWhenBack;
    public String getViewType() {
        return viewType;
    }

    public JsPushConfig setViewType(String viewType) {
        this.viewType = viewType;
        return this;
    }

    public JSONObject getData() {
        return data;
    }

    public JsPushConfig setData(JSONObject data) {
        this.data = data;
        return this;
    }

    public boolean isShouldCloseWebViewControllerAfterPush() {
        return shouldCloseWebViewControllerAfterPush;
    }

    public JsPushConfig setShouldCloseWebViewControllerAfterPush(boolean shouldCloseWebViewControllerAfterPush) {
        this.shouldCloseWebViewControllerAfterPush = shouldCloseWebViewControllerAfterPush;
        return this;
    }

    public boolean isShouldRefreshWebViewControllerAfterBack() {
        return shouldRefreshWebViewControllerWhenBack;
    }

    public JsPushConfig setShouldRefreshWebViewControllerWhenBack(boolean shouldRefreshWebViewControllerAfterBack) {
        this.shouldRefreshWebViewControllerWhenBack = shouldRefreshWebViewControllerAfterBack;
        return this;
    }
}
