package com.lifesense.weidong.lswebview.util;

import android.text.TextUtils;

import com.lifesense.utils.sys.SysUtils;

/**
 * Created by lee on 16-7-15.
 */
public class MIUIUtils {

    private static final String KEY_MIUI_VERSION_NAME = "ro.miui.ui.version.name";

    public static boolean isMIUI() {
        return !TextUtils.isEmpty(getMIUIVersion());
    }

    public static String getMIUIVersion() {
        return SysUtils.getSystemProperty(KEY_MIUI_VERSION_NAME);
    }

    /**
     * 是否为MIUI6或者之后的系统
     * @return
     */
    public static boolean isOverMIUI6() {
        String version = getMIUIVersion();
        if (!TextUtils.isEmpty(version)) {
            try {
                return Integer.parseInt(version.substring(1)) > 5;
            } catch (Exception e) {

            }

        }
        return false;
    }

    /**
     * 判断MIUI版本号 [6 , 7.7.13)
     * @return
     */
    public static boolean isOldMiuiVersion() {
        String version = getMIUIVersion();
        if (!TextUtils.isEmpty(version)) {
            try {
                boolean bool = Integer.parseInt(version.substring(1)) > 5
                        && !compareVersion("7.7.13",version.substring(1));
                return bool;
            } catch (Exception e) {

            }

        }
        return false;
    }

    /**
     * 比较版本号大小
     *  firstVersion <= secondVersion true
     * @param firstVersion
     * @param secondVersion
     */
    public static boolean compareVersion(String firstVersion, String secondVersion) {
        if (firstVersion.equals(secondVersion)) {
            return true;
        }
        String[] firstArray = firstVersion.split(".");
        String[] secondArray = secondVersion.split(".");
        int length = firstArray.length < secondArray.length ? firstArray.length : secondArray.length;
        for (int i = 0; i < length; i++) {
            if (Integer.parseInt(secondArray[i]) > Integer.parseInt(firstArray[i])) {
                return true;
            } else if (Integer.parseInt(secondArray[i]) < Integer.parseInt(firstArray[i])) {
                return false;
            }
        }
        return true;
    }
}
