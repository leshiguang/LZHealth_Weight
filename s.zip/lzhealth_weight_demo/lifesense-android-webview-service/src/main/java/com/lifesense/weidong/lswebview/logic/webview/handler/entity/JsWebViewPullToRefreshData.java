package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * Create by qwerty
 * Create on 2019-09-02
 **/
public class JsWebViewPullToRefreshData extends JsEntity {
    boolean enabled;
    int refreshType;
    int reload;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public int getRefreshType() {
        return refreshType;
    }

    public void setRefreshType(int refreshType) {
        this.refreshType = refreshType;
    }

    public int getReload() {
        return reload;
    }

    public void setReload(int reload) {
        this.reload = reload;
    }

    @Override
    public boolean isInvalid() {
        return false;
    }
}
