package com.lifesense.weidong.lswebview.webview;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import com.lifesense.weidong.lswebview.R;
import com.lifesense.weidong.lswebview.webview.engine.BaseWebViewEngine;
import com.lifesense.weidong.lswebview.webview.engine.SystemWebViewEngine;

/**
 * Created by liuxinyi on 2017/4/13.
 */

public class LSWebViewFactory {
	private static final String TAG = LSWebViewFactory.class.getSimpleName();

	public static BaseWebViewEngine createWebViewEngine(LSWebView lsWebView) {
		BaseWebViewEngine webViewEngine = null;
		try {
			LayoutInflater.from(lsWebView.getContext()).inflate(R.layout.system_webview,
					lsWebView);
			android.webkit.WebView sysWebView = lsWebView
					.findViewById(R.id.sys_webview);
			webViewEngine = new SystemWebViewEngine(sysWebView, lsWebView);
		} catch (InflateException e) {
			Log.e(TAG,"create WebViewEngine error");
		}
		return webViewEngine;
	}

}
