package com.lifesense.weidong.lzbinddivicelibs.devicedetails.model;

import android.content.Context;
import android.text.TextUtils;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.bean.Cell;


/**
 * Create by qwerty
 * Create on 2020/6/8
 **/
public enum DeviceDetailModel {
    DEVICE_NAME(R.string.device,false),
    UNIT_SETTING(R.string.unit,true),
    HEART_RATE_SWITCH(R.string.heart_rate,false),
    MAC_ADDRESS(R.string.mac_address,false),
    FIRMWARE_UPGRADE(R.string.firmware_update,true),
    USER_MANUAL(R.string.user_manual,true),
    LEGAL_INFO(R.string.legal_info,true);
    private int titleRes;
    private boolean showArrow;

    DeviceDetailModel(int titleRes, boolean showArrow) {
        this.titleRes = titleRes;
        this.showArrow = showArrow;
    }

    public Cell createDeviceDetailsCell(Context context, String value) {
        Cell cell = new Cell();
        cell.setId(name());
        cell.setTitle(context.getString(titleRes));
        cell.setShowValue(true);
        cell.setShowSwitch(false);
        cell.setShowArrow(showArrow);
        cell.setValue(value);
        return cell;
    }

    public Cell createDeviceDetailsCell(Context context, String value, String tag) {
        Cell cell = new Cell();
        cell.setId(name());
        cell.setTitle(context.getString(titleRes));
        cell.setShowValue(!TextUtils.isEmpty(value));
        cell.setShowSwitch(false);
        cell.setShowArrow(showArrow);
        cell.setShowTag(!TextUtils.isEmpty(tag));
        cell.setTag(tag);
        cell.setValue(value);
        return cell;
    }


    public Cell createDeviceDetailsCell(Context context, boolean open) {
        Cell cell = new Cell();
        cell.setId(name());
        cell.setTitle(context.getString(titleRes));
        cell.setShowValue(false);
        cell.setShowSwitch(true);
        cell.setShowArrow(showArrow);
        cell.setOpenSwitch(open);
        return cell;
    }

}
