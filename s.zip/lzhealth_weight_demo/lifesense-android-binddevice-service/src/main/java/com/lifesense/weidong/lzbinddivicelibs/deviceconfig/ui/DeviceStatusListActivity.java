package com.lifesense.weidong.lzbinddivicelibs.deviceconfig.ui;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;


import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.constant.DeviceConnectState;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDeviceConnectStateListener;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.application.service.LZDeviceSyncService;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;
import com.lifesense.utils.PreferencesUtils;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter.DeviceStatusListAdapter;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity.DeviceDetailsActivity;
import com.lifesense.weidong.lzbinddivicelibs.logic.device.DeviceStateWrapper;
import com.lifesense.weidong.lzbinddivicelibs.logic.device.manage.BluetoothStateChangedObserver;
import com.lifesense.weidong.lzbinddivicelibs.logic.device.manage.DeviceStatusChangeObserver;
import com.lifesense.weidong.lzbinddivicelibs.logic.device.manage.SyncDeviceObserver;
import com.lifesense.weidong.lzbinddivicelibs.util.DeviceConstants;
import com.lifesense.weidong.lzbinddivicelibs.util.PermissionUtils;
import com.lifesense.weidong.lzbinddivicelibs.util.ToastUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * Author:  winds
 * Email:   heardown@163.com
 * Date:    2019/9/12.
 * Desc:    设备状态列表页
 */
public class DeviceStatusListActivity extends OlderBaseActivity implements View.OnClickListener, BluetoothStateChangedObserver, DeviceStatusChangeObserver, SyncDeviceObserver {

    public final static String TAG = DeviceStatusListActivity.class.getSimpleName();

    protected RecyclerView mRecyclerView;
    protected DeviceStatusListAdapter adapter;
    protected BroadcastReceiver deviceStateReceiver;
    protected DeviceStateWrapper activeDeviceWrapper;
    protected boolean isDestroyed = false;
    protected final static int TIMEOUT_RETRY_CONNECT = 20000; //连接超时时间
    protected final static int TIMEOUT_TOGGLE_DEVICE = 30000; //切换设备活跃设备 因为需要重新扫描 连接超时时间
    protected static int TIMEOUT_CONNECT = TIMEOUT_RETRY_CONNECT; //连接超时时间
    protected boolean isAutoConnect;
    protected Map<String, Integer> connectOutMap = new HashMap<>();
    protected DeviceStateMonitorRunnable deviceStateMonitorRunnable = new DeviceStateMonitorRunnable();

    public static Intent getIntent(Context context) {
        return new Intent(context, DeviceStatusListActivity.class);
    }

    @Override
    protected void initHeader() {
        setHeader_Title(R.string.mine_device);
        setHeader_RightText(R.string.device_help);
        setHeader_RightTextColor(Color.parseColor("#5D8DE4"));
        setHeader_RightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(WebViewActivity.makeIntent(mContext, getString(R.string.title_faq), WebViewActivity.FAQ_URL));
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCenterView(R.layout.activity_device_status_list);
        initView();
        initData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        LZDeviceSyncService syncService = (LZDeviceSyncService) LZDeviceService.getInstance();
        syncService.getReceiveCallback().setConnectStateListener(new OnDeviceConnectStateListener() {
            @Override
            public void onDeviceConnectStateChange(String s, DeviceConnectState deviceConnectState) {
                packingDeviceState();
            }
        });
        packingDeviceState();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_add) {//添加设备
                startActivity(DeviceConnectMenuActivity.makeIntent(mContext));
        }
    }

    @Override
    protected void onDestroy() {
        removeThread(deviceStateMonitorRunnable);
        removeBatteryStateListener();   //移除电量监听
        unRegisterDeviceStateListener();
        super.onDestroy();
    }

    @Override
    public void onBlueStateChanged(int blueState) {
        if (!LsBleManager.getInstance().isOpenBluetooth()) { //蓝牙不可用
            removeThread(deviceStateMonitorRunnable); //移除设备连接监听
            removeBatteryStateListener();
        }
        updateDeviceState();
    }

    @Override
    public void onDeviceStatusChange(DeviceStatus deviceStatus) {
        updateDeviceState();
    }

    /**
     * 设备同步成功
     */
    @Override
    public void syncDeviceSucceed() {
        packingDeviceState();
    }



    private void initView() {
        mRecyclerView = findViewById(R.id.mRecyclerView);
        findViewById(R.id.btn_add).setOnClickListener(this);
    }

    private void initData() {
        isAutoConnect = true;
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        adapter = new DeviceStatusListAdapter();
        mRecyclerView.setAdapter((adapter));
        mRecyclerView.addOnItemTouchListener(new OnItemChildClickListener() {
            @Override
            public void onSimpleItemChildClick(BaseQuickAdapter quickAdapter, View view, int position) {
                DeviceStateWrapper item = adapter.getItem(position);
                //重连
                if (view.getId() == R.id.tv_retry_connect) {
                    connectSelectedDeviceWithCheck(item);
                }
            }

            @Override
            public void onItemClick(BaseQuickAdapter quickAdapter, View view, int position) {
                DeviceStateWrapper item = adapter.getItem(position);
                startActivity(DeviceDetailsActivity.makeIntent(DeviceStatusListActivity.this,item.getDeviceId()));
            }
        });
        registerDeviceStateListener();
    }

    /**
     * 处理已绑定设备信息
     */
    private void packingDeviceState() {
        List<DeviceStateWrapper> list = new ArrayList<>();
        String userId = PreferencesUtils.getString(mContext,"userId","0");
        if (!TextUtils.isEmpty(userId)) {
            List<Device> devices = LZDeviceService.getInstance().getBondedDevices();
            if (devices != null && devices.size() > 0) {
                Iterator<Device> iterator = devices.iterator();
                while (iterator.hasNext()) {
                    Device device = iterator.next();
                    DeviceConnectState state = LsBleManager.getInstance().checkDeviceConnectState(device.getMac());
                    DeviceStateWrapper stateWrapper = new DeviceStateWrapper(device, state);
                    list.add(stateWrapper);
                }
            }
        }
//        //活跃设备未连接 执行重连逻辑
//        if (activeDeviceWrapper != null && !activeDeviceWrapper.isConnected()) {
//            connectSelectedDevice(activeDeviceWrapper);
//        }else{
//            adapter.setPedometerConnected();
//        }
        adapter.getData().clear();
        adapter.getData().addAll(list);
        notifyDataSetChanged();
        if (adapter.getData().isEmpty()) {
            setEmptyView();
        } else {
            updateDeviceBattery();
        }
    }

    /**
     * 更新活跃设备信息
     */
    private void updateDeviceState() {

    }


    /**
     * 移除设备电量状态监听
     */
    private void removeBatteryStateListener() {

    }

    /**
     * 连接选中的设备
     *
     * @param item
     */
    private void connectSelectedDevice(DeviceStateWrapper item) {
        if (item != null) {
            if (item.getDevice().isBluetooth()) { //是蓝牙设备
                //是否有蓝牙权限
                if (!PermissionUtils.checkPermission(mContext, Manifest.permission.BLUETOOTH)) {
                    if (isAutoConnect) {
                        isAutoConnect = false;
                        PermissionUtils.requestPermission(mContext, Manifest.permission.BLUETOOTH, 10001);
                    }
                    return;
                }
                //是否开启位置权限
                if (!PermissionUtils.checkPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (isAutoConnect) {
                        isAutoConnect = false;
                        PermissionUtils.requestPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION, 1002);
                    }
                    return;
                }


                if (!LsBleManager.getInstance().isOpenBluetooth()) { //蓝牙是否可用
                    if (isAutoConnect) {
                        isAutoConnect = false;
                        openBluetooth();
                    }
                    return;
                }
                //开始重连逻辑
                adapter.setConnectingStateWrapper(item); //设置连接中状态
                execRetryConnectDevice(item); //重连设备
            }
        }
    }

    private void connectSelectedDeviceWithCheck(DeviceStateWrapper item) {
        if (item != null) {
            if (item.getDevice().isBluetooth()) { //是蓝牙设备
                 //是否有蓝牙权限
                if (!PermissionUtils.checkPermission(mContext, Manifest.permission.BLUETOOTH)) {
                    PermissionUtils.requestPermission(mContext, Manifest.permission.BLUETOOTH, 10001);
                    return;
                }
                //是否开启位置权限
                if (!PermissionUtils.checkPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    PermissionUtils.requestPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION, 1002);
                    return;
                }

                if (!isGpsOpen(mContext)) { //是否打开定位服务
                    ToastUtil.showSingletonToast(mContext, "请开启定位服务");
                    boolean b = toGpsSettings();
                    if (b) {
                        return;
                    }
                }
                if (!LsBleManager.getInstance().isOpenBluetooth()) { //蓝牙是否可用
                    openBluetooth();
                    return;
                }
                //开始重连逻辑
                adapter.setConnectingStateWrapper(item); //设置连接中状态
                execRetryConnectDevice(item); //重连设备
            }
        }
    }

    /**
     * 执行重连逻辑
     * 若是手环或手表 非活跃设备 先设置为活跃设备 再进行连接
     *
     * @param wrapper
     */
    private void execRetryConnectDevice(final DeviceStateWrapper wrapper) {
        TIMEOUT_CONNECT = TIMEOUT_RETRY_CONNECT;
        //重连
        connectDevice(wrapper);
    }

    /**
     * 连接设备
     * 先判断当前连接状态 再进行连接
     *
     * @param wrapper
     */
    private void connectDevice(DeviceStateWrapper wrapper) {
        if (wrapper == null || wrapper.getDevice() == null) {
            onConnectFailed(wrapper);
            return;
        }
        Device device = wrapper.getDevice();
        //判断当前的连接状况
        DeviceConnectState state = LsBleManager.getInstance().checkDeviceConnectState(device.getMac());
        if (wrapper.checkDeviceConnectState()) {
            onConnectedSuccess(wrapper);
            return;
        }
        //没有获取到状态/非请求连接中/非蓝牙建立连接成功的状态 刷新蓝牙sdk状态
        if (state == null || (state != DeviceConnectState.CONNECTING && state != DeviceConnectState.CONNECTED_GATT)) {
            LsBleManager.getInstance().refreshBleState();
        }
        delayCheckDeviceState(wrapper);
    }

    /**
     * 延时检查连接状态
     *
     * @param wrapper
     */
    private void delayCheckDeviceState(DeviceStateWrapper wrapper) {
        if (deviceStateMonitorRunnable != null) {
            removeThread(deviceStateMonitorRunnable);
            deviceStateMonitorRunnable.setDevice(wrapper);
            execOnUiThread(deviceStateMonitorRunnable, TIMEOUT_CONNECT);
        }
    }

    /**
     * 连接失败回调
     *
     * @param wrapper
     */
    private void onConnectFailed(DeviceStateWrapper wrapper) {
        if(isDestroyed() || isFinishing()){
            return;
        }
        //设备已不存在/设备已不是活跃设备
        if(wrapper == null || wrapper.getDevice() == null || !wrapper.isActive()) {
            return;
        }
        //判断
//        Device device = DeviceManager.getInstance().getPedometer(UserManager.getInstance().getLoginUserId());
//        if(device == null || device.getId() == null || wrapper.getDeviceId() == null || !(device.getId().equalsIgnoreCase(wrapper.getDeviceId()))) {
//            return;
//        }
        execOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.setConnectingFailed();
                /*try{
                    if(wrapper.isPedometer()) {
                        int integer = 1;
                        String mac = wrapper.getDevice().getMac();
                        if (connectOutMap.containsKey(mac)) {
                            integer = connectOutMap.get(mac);
                            if (integer >= 3) {//三次连接失败
                                if(isForeground()){
                                    connectOutMap.clear();
                                    //提示连接失败 操作方法
                                    showPedometerHelpDialog();
                                    return;
                                }
                            }
                        }
                        integer++;
                        connectOutMap.clear();
                        connectOutMap.put(mac, integer);
                    }
                }catch (Exception e){}*/
//                if(isForeground()) {
                try {
                    ToastUtil.showSingletonToast(mContext, "设备连接失败");
                } catch (Exception e) {
                }
//                }
            }
        });
    }

//    private boolean isForeground() {
//        Activity activity = LifesenseApplication.getApp().getCurrentActivity();
//        if (activity != null && activity.getClass().getSimpleName().equals(this.getClass().getSimpleName())) {
//            return true;
//        }
//        return false;
//    }

    /**
     * 连接成功
     *
     * @param wrapper
     */
    private void onConnectedSuccess(DeviceStateWrapper wrapper) {
        if (deviceStateMonitorRunnable != null && wrapper != null && wrapper.getDeviceId() != null && deviceStateMonitorRunnable.getMonitorDevice() != null &&
                (deviceStateMonitorRunnable.getMonitorDevice() == wrapper || wrapper.getDeviceId().equals(deviceStateMonitorRunnable.getMonitorDevice().getDeviceId()))) {
            removeThread(deviceStateMonitorRunnable);
        }
        //1.读取电量信息
        //2.设置连接状态
        execOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (adapter != null) {
                    adapter.setConnectingSuccess();
                }
                updateDeviceBattery();
                /*if(wrapper.isPedometer()) { //移除手环超时连接监控
                    connectOutMap.clear();
                }*/
            }
        });
    }

    /**
     * 更新活跃设备电池电量信息
     */
    private void updateDeviceBattery() {
//        if (activeDeviceWrapper != null && activeDeviceWrapper.getDevice() != null && activeDeviceWrapper.isPedometer() && activeDeviceWrapper.isConnected()) { //存在活跃设备
//            LogicServicess.shareInstance().getDeviceManager().checkDeviceVoltageStatus(activeDeviceWrapper.getDeviceId(), new OnBatteryCallback() {
//                @Override
//                public void onReadBattery(final int state, final int battery) {
//                    updateDeviceBattery(state, battery);
//                    setBatteryStateListener();
//                }
//            });
//        }
    }

    /**
     * 更新电量状态信息
     *
     * @param state
     * @param battery
     */
    private void updateDeviceBattery(int state, int battery) {
//        if (activeDeviceWrapper != null) { //存在活跃设备
//            DeviceConnectState connectState = DeviceManager.getInstance().checkDeviceConnectState(activeDeviceWrapper.getDeviceId());
//            activeDeviceWrapper.setState(connectState);
//            if (connectState != null && connectState == DeviceConnectState.CONNECTED_SUCCESS) {
//                activeDeviceWrapper.setBattery(battery);
//                activeDeviceWrapper.setBatteryState(state);
//                notifyDataSetChanged();
//            }
//        }
    }

    private void notifyDataSetChanged() {
        execOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (adapter != null) {
                    adapter.notifyAdapterDataSetChanged();
                }
            }
        });
    }

    private void execOnUiThread(Runnable runnable) {
        execOnUiThread(runnable, 0);
    }

    private void execOnUiThread(Runnable runnable, int delay) {
        if (mRecyclerView != null) {
            mRecyclerView.postDelayed(runnable, delay);
        }
    }

    private void removeThread(Runnable runnable) {
        if (mRecyclerView != null) {
            mRecyclerView.removeCallbacks(runnable);
        }
    }

    /**
     * 注册设备状态监听
     */
    private void registerDeviceStateListener() {
//        LogicServicess.shareInstance().getDeviceManager().registerSyncObserver(this);
//        LogicServicess.shareInstance().getDeviceManager().addBluetoothStateChangedObserver(this);
//        LogicServicess.shareInstance().getDeviceManager().registerDeviceStatusChange(this);
        removeBatteryStateListener();
        IntentFilter filter = new IntentFilter();
        filter.addAction(DeviceConstants.DEVICE_CONNECT_STATE_CHANGE);
        deviceStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && intent.getAction() != null && DeviceConstants.DEVICE_CONNECT_STATE_CHANGE.equals(intent.getAction())) {
                    updateDeviceState();
                }
            }
        };
        try {
            registerReceiver(deviceStateReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注销设备监听
     */
    private void unRegisterDeviceStateListener() {
        try {
            unregisterReceiver(deviceStateReceiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        LogicServicess.shareInstance().getDeviceManager().unregisterSyncObserver(this);
//        LogicServicess.shareInstance().getDeviceManager().removeBluetoothStateChangedObserver(this);
//        LogicServicess.shareInstance().getDeviceManager().unregisterDeviceStatusChange(this);
    }

    private void setEmptyView() {
        execOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.setEmptyView(getEmptyView(R.layout.layout_empty_device_state, mRecyclerView));
            }
        });
    }

    private View getEmptyView(int layoutId, RecyclerView group) {
        return getLayoutInflater().inflate(layoutId, group == null ? null : group instanceof RecyclerView ? (ViewGroup) group.getParent() : group, false);
    }

    /**
     * 判断是否打开GPS
     *
     * @param context
     * @return
     */
    public static final boolean isGpsOpen(final Context context) {
        try {
            LocationManager locationManager
                    = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            // 通过GPS卫星定位，定位级别可以精确到街（通过24颗卫星定位，在室外和空旷的地方定位准确、速度快）
            boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            // 通过WLAN或移动网络(3G/2G)确定的位置（也称作AGPS，辅助GPS定位。主要用于在室内或遮盖物（建筑群或茂密的深林等）密集的地方定位）
            boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (gps || network) {
                return true;
            }
        } catch (Exception e) {

        }
        return false;
    }

    /**
     * 跳转GPS开关页面
     *
     * @return
     */
    private boolean toGpsSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 打开蓝牙
     */
    private void openBluetooth() {
        try {
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            return;
        } catch (Exception e) {

        }

    }

    public class DeviceStateMonitorRunnable implements Runnable {
        private DeviceStateWrapper wrapper;

        public void setDevice(DeviceStateWrapper wrapper) {
            this.wrapper = wrapper;
        }

        public DeviceStateWrapper getMonitorDevice() {
            return wrapper;
        }

        @Override
        public void run() {
            if (isFinishing()) {
                return;
            }
            if (wrapper == null) {
                wrapper = activeDeviceWrapper;
            }
            if (wrapper != null) {
                boolean connected = wrapper.checkDeviceConnectState();
                if (connected) { //连接成功
                    onConnectedSuccess(wrapper);
                } else {//依旧连接失败
                    onConnectFailed(wrapper);
                }
            }
        }
    }




}
