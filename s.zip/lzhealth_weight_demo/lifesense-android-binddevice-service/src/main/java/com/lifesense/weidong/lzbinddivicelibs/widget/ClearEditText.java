package com.lifesense.weidong.lzbinddivicelibs.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import com.lifesense.weidong.lzbinddivicelibs.R;

/**
 * 自定义带删除按钮的EditText
 * Created sanjay wrh on 16/1/13.
 */
public class ClearEditText extends EditText implements View.OnFocusChangeListener,
        TextWatcher {
    private static final String TAG = ClearEditText.class.getSimpleName();
    //EditText右侧的删除按钮
    private Drawable mClearDrawable;
    private boolean hasFoucs;

    private int inValidSizeImg = R.mipmap.icon_wrong;
    private int ValidSizeImg = R.mipmap.icon_right;
    private Drawable right;

    private boolean isShowInvalid = false;
    private boolean isShowValid = true;
    private OnContentChangeListener contentChangeListener;
    private OnFocusChangeListener focusChangeListener;

    //处于网络状态下，显示右边的按钮是不根据号码长度控制，而是由相关的set方法设置右边的内容
    private boolean inNetWorkState = false;
    private Paint mBottomLinePaint;


    public interface OnContentChangeListener {
        void contentChangeListener();
    }

    public interface OnFocusChangeListener {
        void focusChangeListener(boolean isFocus);
    }

    //设置编文本内容监听器
    public void setRightChangeListener(OnContentChangeListener contentChangeListener) {
        this.contentChangeListener = contentChangeListener;
    }

    //设置编焦点改变监听器
    public void setFocusChangeListener(OnFocusChangeListener focusChangeListener) {
        this.focusChangeListener = focusChangeListener;
    }

    public void setCurrenrRight(Drawable right) {
        this.right = right;
    }


    private int focusColor;
    private int noFocusColor;
    private boolean isShowLine;
    private boolean visible = false;

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public ClearEditText(Context context) {
        this(context, null);
    }

    public ClearEditText(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.editTextStyle);
    }

    public ClearEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        // 获取EditText的DrawableRight,假如没有设置我们就使用默认的图片,获取图片的顺序是左上右下（0,1,2,3,）
        mClearDrawable = getCompoundDrawables()[2];
        if (mClearDrawable == null) {
            mClearDrawable = getResources().getDrawable(
                    R.drawable.selector_delete_input);
        }


        setClearIconVisible(TextUtils.isEmpty(getText()));
        // 设置焦点改变的监听
        setOnFocusChangeListener(this);
        // 设置输入框里面内容发生改变的监听
        addTextChangedListener(this);
        // 默认设置隐藏图标
        setClearIconVisible(false);
//        setInputType(InputType.TYPE_CLASS_NUMBER);

        //设置最长11位长度
//        setFilters(new InputFilter[]{new InputFilter.LengthFilter(VALID_PHONE_SIZE)});

        mBottomLinePaint = new Paint();
        noFocusColor = getResources().getColor(R.color.divide_background);
        focusColor = getResources().getColor(R.color.main_blue);
        mBottomLinePaint.setColor(noFocusColor);
        mBottomLinePaint.setStyle(Paint.Style.STROKE);
        mBottomLinePaint.setStrokeWidth(3);

        TypedArray attrsArray =
                getContext().obtainStyledAttributes(attrs, R.styleable.ClearEditText);
        isShowLine = attrsArray.getBoolean(R.styleable.ClearEditText_ce_isShowLine, true);
        attrsArray.recycle();

    }


    public void setEditDefault() {
        removeTextChangedListener(this);
        setOnFocusChangeListener(null);
        setShowLine(false);
        setShowValid(false);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //画底线
        if (isShowLine) {
            canvas.drawLine(0, this.getHeight() - 1, this.getWidth(), this.getHeight() - 1, mBottomLinePaint);
        }
    }

    public void setShowLine(boolean isShowLine) {
        this.isShowLine = isShowLine;
    }

    /* @说明：isInnerWidth, isInnerHeight为ture，触摸点在删除图标之内，则视为点击了删除图标
     * event.getX() 获取相对应自身左上角的X坐标
     * event.getY() 获取相对应自身左上角的Y坐标
     * getWidth() 获取控件的宽度
     * getHeight() 获取控件的高度
     * getTotalPaddingRight() 获取删除图标左边缘到控件右边缘的距离
     * getPaddingRight() 获取删除图标右边缘到控件右边缘的距离
     * isInnerWidth:
     * 	getWidth() - getTotalPaddingRight() 计算删除图标左边缘到控件左边缘的距离
     * 	getWidth() - getPaddingRight() 计算删除图标右边缘到控件左边缘的距离
     * isInnerHeight:
     * 	distance 删除图标顶部边缘到控件顶部边缘的距离
     *  distance + height 删除图标底部边缘到控件顶部边缘的距离
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (getCompoundDrawables()[2] != null) {
                int x = (int) event.getX();
                int y = (int) event.getY();
                Rect rect = getCompoundDrawables()[2].getBounds();
                int height = rect.height();
                int distance = (getHeight() - height) / 2;
                boolean isInnerWidth = x > (getWidth() - getTotalPaddingRight()) && x < (getWidth() - getPaddingRight());
                boolean isInnerHeight = y > distance && y < (distance + height);
                if (isInnerWidth && isInnerHeight) {
                    this.setText("");
                }
            }
        }
        return super.onTouchEvent(event);
    }


    /**
     * 当ClearEditText焦点发生变化的时候，
     * 输入长度为零，隐藏删除图标，否则，显示删除图标
     */
    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        this.hasFoucs = hasFocus;
        if (hasFocus) {
//            mBottomLinePaint.setColor(focusColor);
            setClearIconVisible(getText().length() > 0);
        } else {
//            mBottomLinePaint.setColor(noFocusColor);
            setClearIconVisible(visible, false);
        }

        if (focusChangeListener != null) {
            focusChangeListener.focusChangeListener(hasFocus);
        }
    }


    public void setClearIconVisible(boolean visible) {
        Drawable right = visible ? mClearDrawable : null;

        setCompoundDrawablesWithIntrinsicBounds(getCompoundDrawables()[0],
                getCompoundDrawables()[1], right, getCompoundDrawables()[3]);
        postInvalidate();
    }

    public void setClearIconVisible(boolean visible, boolean hasFocus) {

        //    Drawable right = visible ? mClearDrawable : null;
        //      Drawable right = null;
        //      int charSize = getText().toString().length();

//
//
//        if (!hasFocus && !visible && !inNetWorkState) {
//            if ((charSize != VALID_PHONE_SIZE)) {
//                right = getResources().getDrawable(inValidSizeImg);
//            } else {
//                right = getResources().getDrawable(ValidSizeImg);
//            }
//        }

        if (isShowValid && !visible) {
            right = getResources().getDrawable(ValidSizeImg);
        } else if (isShowInvalid && !visible) {
            right = getResources().getDrawable(inValidSizeImg);
        } else {
            setClearIconVisible(false);
        }

//        if ((charSize != VALID_PHONE_SIZE)) {
//            right = getResources().getDrawable(inValidSizeImg);
//        }

        if (contentChangeListener != null) {
            contentChangeListener.contentChangeListener();
        }


        if (right != null) {
            setCompoundDrawablesWithIntrinsicBounds(getCompoundDrawables()[0],
                    getCompoundDrawables()[1], right, getCompoundDrawables()[3]);
            postInvalidate();
        }
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int count, int after) {
        if (hasFoucs) {
            setClearIconVisible(s.length() > 0);
        }

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
                                  int after) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }


    public void setRightImgError() {

        isShowInvalid = true;
        isShowValid = false;

        setCompoundDrawablesWithIntrinsicBounds(null,
                getCompoundDrawables()[1], getResources().getDrawable(inValidSizeImg), getCompoundDrawables()[3]);
        postInvalidate();
    }

    public void setRightImgValid() {

        isShowInvalid = false;
        isShowValid = true;

        setCompoundDrawablesWithIntrinsicBounds(null,
                getCompoundDrawables()[1], getResources().getDrawable(ValidSizeImg), getCompoundDrawables()[3]);
        postInvalidate();
    }

    public void setShowValid(boolean isShowValid) {
        this.isShowValid = isShowValid;
    }

    public void setInNetWorkState(boolean inNetWorkState) {
        this.inNetWorkState = inNetWorkState;
    }

    public boolean isInNetWorkState() {
        return inNetWorkState;
    }
}