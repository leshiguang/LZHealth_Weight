package com.lifesense.weidong.lzbinddivicelibs.common;

import android.content.Context;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * ListView 基类
 * Created by luoxf on 2016/1/19.
 */
public abstract class BaseListViewAdapter<T> extends BaseAdapter{
    protected Context mContext;
    protected List<T> datas;

    public BaseListViewAdapter(Context context) {
        this.mContext = context;
    }


    public void setDatas(List<T> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    public List<T> getDatas() {
        return datas;
    }

    @Override
    public int getCount() {
        if(null != datas) {
            return datas.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if(null != datas) {
            return datas.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
