package com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.lifesense.component.devicemanager.device.product.DisplayProductCategory;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;

import java.util.List;

public class DeviceTypeMenuAdapter extends RecyclerView.Adapter<DeviceTypeMenuAdapter.MenuViewHolder> {

    private Context context;
    private int clickPosition;
    private List<DisplayProductCategory> data;//数据
    private OnItemClickListener onItemClickListener;

    public DeviceTypeMenuAdapter(Context context, List<DisplayProductCategory> data){
        this.context = context;
        this.data = data;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setClickPosition(int clickPosition) {
        this.clickPosition = clickPosition;
        notifyDataSetChanged();
    }

    public void setData(List<DisplayProductCategory> data) {
        this.data = data;
    }


    @Override
    public MenuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_device_type,parent,false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MenuViewHolder holder, int position) {
        holder.initView(position);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout ll_device_type_item;
        private ImageView iv_device_type_item_icon;
        private TextView tv_device_type_item_name;
        public MenuViewHolder(View itemView) {
            super(itemView);
            ll_device_type_item = itemView.findViewById(R.id.ll_device_type_item);
            iv_device_type_item_icon = itemView.findViewById(R.id.iv_device_type_item_icon);
            tv_device_type_item_name = itemView.findViewById(R.id.tv_device_type_item_name);
        }

        public void initView(final int position){
            if (clickPosition == position){
                ImageUtil.displayImage(data.get(position).getHighlightImageUrl(),iv_device_type_item_icon);
                ll_device_type_item.setBackgroundResource(R.drawable.device_type_item_seletor_bg);
            }else if (position == clickPosition - 1){
                ImageUtil.displayImage(data.get(position).getNoHighlightImageUrl(),iv_device_type_item_icon);
                ll_device_type_item.setBackgroundResource(R.drawable.device_type_seletor_previous_bg);
            }else if (position == clickPosition + 1){
                ImageUtil.displayImage(data.get(position).getNoHighlightImageUrl(),iv_device_type_item_icon);
                ll_device_type_item.setBackgroundResource(R.drawable.device_type_seletor_next_bg);
            }else {
                ImageUtil.displayImage(data.get(position).getNoHighlightImageUrl(),iv_device_type_item_icon);
                ll_device_type_item.setBackgroundResource(R.color.device_type_item_default_color);
            }
            if (clickPosition == position){
                tv_device_type_item_name.setTextColor(context.getResources().getColor(R.color.device_type_item_text_color_h));
            } else {
                tv_device_type_item_name.setTextColor(context.getResources().getColor(R.color.device_type_item_text_color_n));
            }
            tv_device_type_item_name.setText(data.get(position).getProductTypeName());
            ll_device_type_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClickListener.click(v,position);
                }
            });
        }
    }

    public interface OnItemClickListener{
        void click(View view, int position);
    }

}
