package com.lifesense.weidong.lzbinddivicelibs.widget.shadow;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import com.lifesense.utils.ui.ViewUtil;

/**
 * <code>
 * if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
 * view.setLayerType(View.LAYER_TYPE_SOFTWARE, drawable.getPaint());
 * }
 * </code>
 * <p/>
 * Author: wangjie
 * Email: tiantian.china.2@gmail.com
 * Date: 5/2/15.
 */
public class ShadowViewDrawable extends Drawable {
	private Paint paint;

	private RectF bounds = new RectF();

	private int width;
	private int height;

	private ShadowProperty shadowProperty;
	private int shadowOffset;

	private RectF drawRect;

	private float rx;
	private float ry;
	private int mColor;
	public ShadowViewDrawable(ShadowProperty shadowProperty, int color, float rx, float ry) {
		this.shadowProperty = shadowProperty;
		shadowOffset = this.shadowProperty.getShadowOffset();

		this.rx = rx;
		this.ry = ry;
		mColor = color;
		paint = new Paint();
		paint.setAntiAlias(true);
		/**
		 * 解决旋转时的锯齿问题
		 */
		paint.setFilterBitmap(true);
		paint.setDither(true);
		paint.setStyle(Paint.Style.FILL);
		paint.setColor(mColor);
		/**
		 * 设置阴影
		 */
		paint.setShadowLayer(shadowProperty.getShadowRadius(), shadowProperty.getShadowDx(),
				shadowProperty.getShadowDy(), shadowProperty.getShadowColor());

		drawRect = new RectF();
	}

	@Override
	protected void onBoundsChange(Rect bounds) {
		super.onBoundsChange(bounds);
		if (bounds.right - bounds.left > 0 && bounds.bottom - bounds.top > 0) {
			this.bounds.left = bounds.left;
			this.bounds.right = bounds.right;
			this.bounds.top = bounds.top;
			this.bounds.bottom = bounds.bottom;
			width = (int) (this.bounds.right - this.bounds.left);
			height = (int) (this.bounds.bottom - this.bounds.top);
//			int left = (shadowProperty.getSide()&ShadowProperty.LEFT) == ShadowProperty.LEFT ? shadowOffset : 0;
			int left = ViewUtil.dip2px(15);
			int top = (shadowProperty.getSide()&ShadowProperty.TOP) == ShadowProperty.TOP ?shadowOffset : 0;
//			int right = (shadowProperty.getSide()&ShadowProperty.RIGHT) == ShadowProperty.RIGHT ? width - shadowOffset : width;
			int right = width - ViewUtil.dip2px(15);
			int bottom = (shadowProperty.getSide()&ShadowProperty.BOTTOM) == ShadowProperty.BOTTOM ? height - shadowOffset : height;
			drawRect = new RectF(left, top, right,
						bottom);

			invalidateSelf();

		}
	}

	@Override
	public void draw(Canvas canvas) {
		paint.setStyle(Paint.Style.FILL);
		paint.setColor(mColor);
		canvas.drawRoundRect(drawRect, rx, ry, paint);
		if (shadowProperty.getBorderColor() != 0) {
			paint.setStyle(Paint.Style.STROKE);
			paint.setColor(shadowProperty.getBorderColor());
			canvas.drawRoundRect(drawRect, rx, ry, paint);
		}

	}

	public ShadowViewDrawable setColor(int color) {
		paint.setColor(color);
		return this;
	}

	@Override
	public void setAlpha(int alpha) {

	}

	@Override
	public void setColorFilter(ColorFilter cf) {

	}

	@Override
	public int getOpacity() {
		return 0;
	}
}
