package com.lifesense.weidong.lzbinddivicelibs.widget.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;

/**
 * Created by wrh on 16/3/2.
 */
public class CustomDialogFragment extends DialogFragment implements View.OnClickListener {

    public static final int TYPE_ONE_BUTTON = 1;
    public static final int TYPE_TWO_BUTTON = 2;

    private static final String KEY_TYPE = "type";
    private static final String KEY_CONTENT = "content";
    private static final String KEY_CONFIRMTEXT = "confirmText";
    private static final String KEY_CANCELTEXT = "cancelText";

    private int type;
    private String mContent;
    private String mConfirmText;
    private String mCancelText;

    private TextView tv_context;
    private TextView tv_confirm;
    private TextView tv_cancel;

    private OnConfirmListener mConfirmListener;
    private OnCancelListener mCancelListener;

    public static CustomDialogFragment newOneButtonDialog(String content, String confirmText) {
        CustomDialogFragment commomDialogFragment = new CustomDialogFragment();
        Bundle args = new Bundle();
        args.putInt(KEY_TYPE, TYPE_ONE_BUTTON);
        args.putString(KEY_CONTENT, content);
        args.putString(KEY_CONFIRMTEXT, confirmText);
        commomDialogFragment.setArguments(args);
        return commomDialogFragment;
    }

    public static CustomDialogFragment newTwoButtonDialog(String content, String confirmText, String cancelText) {
        CustomDialogFragment commomDialogFragment = new CustomDialogFragment();
        Bundle args = new Bundle();
        args.putInt(KEY_TYPE, TYPE_TWO_BUTTON);
        args.putString(KEY_CONTENT, content);
        args.putString(KEY_CONFIRMTEXT, confirmText);
        args.putString(KEY_CANCELTEXT, cancelText);
        commomDialogFragment.setArguments(args);
        return commomDialogFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        type = getArguments().getInt(KEY_TYPE);
        mContent = getArguments().getString(KEY_CONTENT);
        mConfirmText = getArguments().getString(KEY_CONFIRMTEXT);
        if (type == TYPE_TWO_BUTTON) {
            mCancelText = getArguments().getString(KEY_CANCELTEXT);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getActivity(), R.style.MyDialogStyleWithWhite);
        View view;
        if (type == TYPE_TWO_BUTTON) {
            view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_wifi_setting, null);
            tv_context = view.findViewById(R.id.tv_content);
            tv_confirm = view.findViewById(R.id.tv_confirm);
            tv_cancel = view.findViewById(R.id.tv_cancel);
            tv_confirm.setText(mConfirmText == null ? "" : mConfirmText);
            tv_confirm.setOnClickListener(this);
            tv_cancel.setText(mCancelText == null ? "" : mCancelText);
            tv_cancel.setOnClickListener(this);
            tv_context.setText(mContent == null ? "" : mContent);

        } else {
            view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_one_button, null);
            tv_context = view.findViewById(R.id.tv_content);
            tv_confirm = view.findViewById(R.id.tv_confirm);
            tv_confirm.setText(mConfirmText == null ? "" : mConfirmText);
            tv_confirm.setOnClickListener(this);
            tv_context.setText(mContent == null ? "" : mContent);
        }
//        dialog.getWindow().getAttributes().windowAnimations = R.style.dialogWindowAnim;
        dialog.setContentView(view);
        return dialog;
    }

    public void setOnConfirmListener(OnConfirmListener onListener) {
        this.mConfirmListener = onListener;
    }

    public void setOnCancelListener(OnCancelListener mCancelListener) {
        this.mCancelListener = mCancelListener;
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.tv_confirm) {
            if (mConfirmListener != null) {
                mConfirmListener.onConfirm(CustomDialogFragment.this);
            }
        } else if (i == R.id.tv_cancel) {
            if (mCancelListener != null) {
                mCancelListener.onCancel(CustomDialogFragment.this);
            }
        }
        dismiss();
    }

    public interface OnConfirmListener {
        void onConfirm(DialogFragment fragment);
    }

    public interface OnCancelListener {
        void onCancel(DialogFragment fragment);
    }
}
