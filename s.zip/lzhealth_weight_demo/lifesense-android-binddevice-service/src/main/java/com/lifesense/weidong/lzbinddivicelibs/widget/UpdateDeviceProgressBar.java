/*
 * 文件名:  CircleProgressView.java
 * 版权:   广州动心信息科技有限公司
 * 创建人:  liguoliang
 * 创建时间:2017-05-11
 */

package com.lifesense.weidong.lzbinddivicelibs.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import com.lifesense.utils.UIUtil;


/**
 * @author liguoliang
 * @date 2017/5/11
 */

public class UpdateDeviceProgressBar extends View {
	private int mMaxProgress = 100;
	private int mProgress = 0;
	private int mCircleLineStrokeWidth = 15;
	private int mLineStrokeWidth = 3;

	private RectF mRectF;
	private RectF mRectFOut;
	private RectF mRectFInner;
	private Paint mPaint;
	private Paint mCirclePaint;
	private Context mContext;

	public UpdateDeviceProgressBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	private void init(Context context) {
		mContext = context;
		mRectF = new RectF();
		mRectFOut = new RectF();
		mPaint = new Paint();
		mCircleLineStrokeWidth = UIUtil.dipToPx(getContext(),5);
		mLineStrokeWidth = UIUtil.dipToPx(getContext(),1);

		// 设置画笔相关属性
		mPaint.setAntiAlias(true);
		mPaint.setStrokeWidth(mCircleLineStrokeWidth);
		mPaint.setStrokeCap(Paint.Cap.ROUND);
		mCirclePaint = new Paint();
		mCirclePaint.setAntiAlias(true);
		mCirclePaint.setStrokeWidth(mLineStrokeWidth);
		mCirclePaint.setStyle(Paint.Style.STROKE);
		mCirclePaint.setColor(0x33ffffff);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		int width = this.getWidth();
		int height = this.getHeight();
		if (width != height) {
			int min = Math.min(width, height);
			width = min;
			height = min;
		}
		// 设置画笔相关属性         
		mPaint.setColor(0x22ffffff);
		canvas.drawColor(Color.TRANSPARENT);


		mRectFOut.left = mLineStrokeWidth / 2; // 左上角x
		mRectFOut.top = mLineStrokeWidth / 2; // 左上角y
		mRectFOut.right = width - mLineStrokeWidth / 2;
		mRectFOut.bottom = height - mLineStrokeWidth / 2; // 右下角y
		canvas.drawArc(mRectFOut, 0, 360, false, mCirclePaint);

		// 位置
		mRectF.left = mRectFOut.left+2*mCircleLineStrokeWidth; // 左上角x
		mRectF.top = mRectFOut.top+2*mCircleLineStrokeWidth; // 左上角y
		mRectF.right = mRectFOut.right-2*mCircleLineStrokeWidth;
		// 左下角x
		mRectF.bottom = mRectFOut.bottom-2*mCircleLineStrokeWidth; // 右下角y
		// 绘制圆圈，进度条背景
		mPaint.setStyle(Paint.Style.STROKE);
		canvas.drawArc(mRectF, 0, 360, false, mPaint);

		mRectFOut.left = mRectF.left+2*mCircleLineStrokeWidth ; // 左上角x
		mRectFOut.top = mRectF.top+2*mCircleLineStrokeWidth; // 左上角y
		mRectFOut.right = mRectF.right - 2*mCircleLineStrokeWidth ;
		mRectFOut.bottom = mRectF.bottom - 2*mCircleLineStrokeWidth; // 右下角y
		canvas.drawArc(mRectFOut, 0, 360, false, mCirclePaint);

		mPaint.setStyle(Paint.Style.FILL);
		canvas.drawCircle(width/2,height/2,mRectFOut.width()/2,mPaint);


		mPaint.setColor(Color.WHITE);
		mPaint.setStyle(Paint.Style.STROKE);
		canvas.drawArc(mRectF, 270, ((float) mProgress / mMaxProgress) * 360, false, mPaint);
	}

	public void setProgress(int progress) {
		this.mProgress = progress;
		this.invalidate();
	}
}
