package com.lifesense.weidong.lzbinddivicelibs.common;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.utils.PreferencesUtils;

public class UiDeviceBindType {
    //历史绑定
    public static final int history = 1;
    //二维码绑定
    public static final int qrcode = 2;
    //sn绑定
    public static final int sn = 3;
    //搜索绑定
    public static final int search = 4;
    //二维码和sn绑定
    public static final int qrcode_sn = 5;

    private static final String KEY = "UiDeviceBindType";

    public static void setCurrentUiDeviceBindType(int uiDeviceBindType) {
        PreferencesUtils.putInt(ApplicationHolder.getmApplication(), KEY, uiDeviceBindType);
    }

    public static int getCurrentUiDeviceBindType() {
        return PreferencesUtils.getInt(ApplicationHolder.getmApplication(), KEY);
    }
}
