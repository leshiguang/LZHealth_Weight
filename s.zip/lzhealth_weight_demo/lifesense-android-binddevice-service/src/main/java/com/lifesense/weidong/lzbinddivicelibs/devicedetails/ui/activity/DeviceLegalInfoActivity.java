package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;


import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter.CellGroupRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.LegalInfoModel;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.widget.AlertDialogFragment;


/**
 * Create by qwerty
 * Create on 2020/6/9
 * 法律信息
 **/
public class DeviceLegalInfoActivity extends BaseActivity implements BaseRvAdapter.OnItemClickListener {
    private RecyclerView rvLawInfoList;
    private CellGroupRvAdapter cellGroupRvAdapter;
    public static Intent makeIntent(Context context) {
        return new Intent(context, DeviceLegalInfoActivity.class);
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_legal_info;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        setTitle(getString(R.string.legal_info));
        rvLawInfoList = findViewById(R.id.rv_law_info_list);
        cellGroupRvAdapter = new CellGroupRvAdapter();
        cellGroupRvAdapter.bindListView(rvLawInfoList);
        cellGroupRvAdapter.setData(LegalInfoModel.createLawInfoCells(this));
        cellGroupRvAdapter.setOnItemClickListener(this);

        findViewById(R.id.bt_cancel_auth).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialogFragment.Builder()
                        .setTitle(getString(R.string.tips))
                        .setMsg(getString(R.string.remove_auth_msg))
                        .build()
                        .show(getSupportFragmentManager());
            }
        });
    }

    @Override
    protected void initData(Bundle savedInstanceState) {

    }


    @Override
    public void onItemClick(int position, long itemId) {
        LegalInfoModel legalInfoModel = LegalInfoModel.valueOf(cellGroupRvAdapter.getItem(position).getId());
        switch (legalInfoModel) {
            case DATA_ACCESS:
                break;
            case PRIVACY:
                break;
        }
    }

    @Override
    public boolean showNav() {
        return true;
    }
}
