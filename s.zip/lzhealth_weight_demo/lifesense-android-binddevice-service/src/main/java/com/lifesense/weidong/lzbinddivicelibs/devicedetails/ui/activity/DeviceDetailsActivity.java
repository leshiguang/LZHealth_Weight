package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.OnSettingCallBack;
import com.lifesense.ble.bean.constant.DeviceConnectState;
import com.lifesense.ble.bean.constant.HeartRateSwitch;
import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnCheckUpgradeCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnResultCallback;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter.CellGroupRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.bean.Cell;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.DeviceDetailModel;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.DeviceModel;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.Unit;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.widget.AlertDialogFragment;
import com.lifesense.weidong.lzbinddivicelibs.deviceota.ui.activity.DeviceUpgradeActivity;

import java.util.List;

/**
 * Create by qwerty
 * Create on 2020/6/9
 * 设备详情
 **/
public class DeviceDetailsActivity extends BaseActivity implements DeviceModel.OnLoadDeviceDetailsInfoCallback,
        OnCheckUpgradeCallback, BaseRvAdapter.OnItemClickListener, CellGroupRvAdapter.OnSwitchChangedListener {
    private static final String DEVICE_ID_EXTRA = "device_id_extra";
    private RecyclerView rvDeviceInfo;
    private CellGroupRvAdapter cellGroupRvAdapter;
    private Device device;
    private DeviceModel deviceModel = new DeviceModel();


    private static final int UNIT_SETTING_REQ = 1001;

    public static Intent makeIntent(Context context, String deviceId) {
        return new Intent(context, DeviceDetailsActivity.class).putExtra(DEVICE_ID_EXTRA, deviceId);
    }

    @Override
    protected int getContentView() {
        return R.layout.ativity_device_details;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        setTitle(R.string.device_details);
        rvDeviceInfo = findViewById(R.id.rv_device_info);
        rvDeviceInfo.setLayoutManager(new LinearLayoutManager(this));
        cellGroupRvAdapter = new CellGroupRvAdapter();
        cellGroupRvAdapter.setOnItemClickListener(this);
        cellGroupRvAdapter.setOnSwitchChangedListener(this);
        rvDeviceInfo.setAdapter(cellGroupRvAdapter);
        findViewById(R.id.bt_cancel_bind).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCancelBindDialog();
            }
        });
    }

    @Override
    protected void initData(Bundle savedInstanceState) {
        String deviceId = getIntent().getStringExtra(DEVICE_ID_EXTRA);
        if(TextUtils.isEmpty(deviceId)) {
            List<Device> deviceList = LZDeviceService.getInstance().getBondedDevices();
            if (deviceList != null) {
                for (Device device : deviceList) {
                    if (DeviceConnectState.CONNECTED_SUCCESS == LsBleManager.getInstance().checkDeviceConnectState(device.getMac())) {
                        this.device = device;
                    }
                }
            }
        } else {
            this.device = RepositoryRegistry.deviceRepository().get(deviceId);
        }
        if(this.device == null) {
            ToastUtil.showSingletonToast(getString(R.string.setting_fail_msg));
            finish();
            return;
        }
        loadDeviceDetailsInfo();
    }


    public void loadDeviceDetailsInfo() {
        //加载详情列表
        deviceModel.loadDeviceDetailsInfo(this, device, this);
    }

    @Override
    public void onLoadDeviceDetailsInfoSuccess(List<Cell> cellList) {
        cellGroupRvAdapter.setData(cellList);
    }

    @Override
    public void onCheckUpgradeSuccess(FirmwareInfo firmwareInfo) {
        startActivity(DeviceUpgradeActivity.makeIntent(this, device.getId(), firmwareInfo));
    }

    @Override
    public void onCheckUpgradeFail(int i, String s) {
        ToastUtil.showSingletonToast(getString(R.string.latest_version_msg));
    }

    @Override
    public void onItemClick(int position, long itemId) {
        Cell cell = cellGroupRvAdapter.getItem(position);
        if (cell != null) {
            DeviceDetailModel deviceDetailModel = DeviceDetailModel.valueOf(cell.getId());
            switch (deviceDetailModel) {
                case UNIT_SETTING:
                    startActivityForResult(DeviceUnitSettingActivity.makeIntent(this, device.getId()), UNIT_SETTING_REQ);
                    break;
                case FIRMWARE_UPGRADE:
                    deviceModel.checkFirmwareUpgrade(device.getId(), this);
                    break;
                case USER_MANUAL:
                    startActivity(DeviceUserManualActivity.makeIntent(this));
                    break;
                case LEGAL_INFO:
                    startActivity(DeviceLegalInfoActivity.makeIntent(this));
                    break;
            }
        }
    }

    @Override
    public void onSwitchChanged(final CompoundButton buttonView, final boolean checked, final int position) {
        final Cell cell = cellGroupRvAdapter.getItem(position);
        final DeviceDetailModel deviceDetailModel = DeviceDetailModel.valueOf(cell.getId());
        switch (deviceDetailModel) {
            case HEART_RATE_SWITCH:
                LZDeviceService.getInstance().setHeartRateSwitch(device.getId(), checked ? HeartRateSwitch.OPEN : HeartRateSwitch.CLOSE, new OnSettingCallBack() {
                    @Override
                    public void onSuccess(String macAddress) {
                        super.onSuccess(macAddress);
                        if (checked) {
                            ToastUtil.showSingletonToast(getString(R.string.open_heart_rate_msg));
                        } else {
                            ToastUtil.showSingletonToast(getString(R.string.close_heart_rate_msg));
                        }
                    }

                    @Override
                    public void onFailure(int errorCode) {
                        super.onFailure(errorCode);
                        ToastUtil.showSingletonToast(getString(R.string.setting_fail_msg));
                    }
                });
                break;
        }
    }

    private void showCancelBindDialog() {
        new AlertDialogFragment.Builder().
                setMsg(String.format(getString(R.string.hint_device_delete_format), device.getName()))
                .setPositiveClickListener(getString(R.string.stop), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cancelBind();
                    }
                }).build().show(getSupportFragmentManager());
    }

    private void cancelBind() {
        LZDeviceService.getInstance().unBindDevice(device.getId(), new OnResultCallback() {
            @Override
            public void onSuccess() {
                finish();
            }

            @Override
            public void onFailed(int i, String s) {

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case UNIT_SETTING_REQ:
                if (resultCode == AppCompatActivity.RESULT_OK) {
                    int command = data.getIntExtra(DeviceUnitSettingActivity.CHOICE_UNIT_RES, UnitType.UNIT_KG.getCommand());
                    Cell cell = DeviceDetailModel.UNIT_SETTING.createDeviceDetailsCell(this, Unit.getUnitByUnitTypeCommand(command).getUnitName(this));
                    List<Cell> cellList = cellGroupRvAdapter.getItems();
                    if (cellList != null) {
                        int poi = cellList.indexOf(cell);
                        cellGroupRvAdapter.replaceItem(poi, cell);
                    }
                }
                break;
        }
    }
}