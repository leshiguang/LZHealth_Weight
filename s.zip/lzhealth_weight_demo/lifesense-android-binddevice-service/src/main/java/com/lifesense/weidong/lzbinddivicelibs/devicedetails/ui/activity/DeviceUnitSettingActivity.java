package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.lifesense.ble.OnSettingCallBack;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter.UnitChoiceRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.Unit;


/**
 * Create by qwerty
 * Create on 2020/6/9
 * 单位设置
 **/
public class DeviceUnitSettingActivity extends BaseActivity implements UnitChoiceRvAdapter.OnChoiceUnitListener {
    private static final String DEVICE_ID_EXTRA = "device_id_extra";
    private RecyclerView rvUnitChoice;
    private UnitChoiceRvAdapter unitChoiceRvAdapter;
    private String deviceId;
    public static final String CHOICE_UNIT_RES = "choice_unit_res";

    public static Intent makeIntent(Context context, String deviceId) {
        return new Intent(context, DeviceUnitSettingActivity.class).putExtra(DEVICE_ID_EXTRA,deviceId);
    }
    @Override
    protected int getContentView() {
        return R.layout.activity_unit_setting;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        setTitle(getString(R.string.unit));
        rvUnitChoice = findViewById(R.id.rv_unit_choice);
        unitChoiceRvAdapter = new UnitChoiceRvAdapter();
        unitChoiceRvAdapter.bindView(rvUnitChoice);
        unitChoiceRvAdapter.setOnChoiceUnitListener(this);

    }

    @Override
    protected void initData(Bundle savedInstanceState) {
        deviceId = getIntent().getStringExtra(DEVICE_ID_EXTRA);
        int command = LZDeviceService.getInstance().getUnit(deviceId);
        unitChoiceRvAdapter.setChoiceUnit(Unit.getUnitByUnitTypeCommand(command));

    }

    @Override
    public void onChoiceUnit(final Unit unit) {
        Log.d(getClass().getSimpleName(),"onChoiceUnit");
        showLoading();
        LZDeviceService.getInstance().setUnit(deviceId, unit.getUnitType(), new OnSettingCallBack() {
            @Override
            public void onSuccess(String macAddress) {
                super.onSuccess(macAddress);
                dismissLoading();
                Intent intent = new Intent();
                intent.putExtra(CHOICE_UNIT_RES,unit.getUnitType().getCommand());
                setResult(Activity.RESULT_OK,intent);
            }

            @Override
            public void onFailure(int errorCode) {
                super.onFailure(errorCode);
                dismissLoading();
                ToastUtil.showSingletonToast(getString(R.string.setting_fail_msg));
            }
        });
    }

    @Override
    protected boolean showNav() {
        return true;
    }


}
