package com.lifesense.weidong.lzbinddivicelibs.widget.dialog;

import android.app.Dialog;
import android.os.Bundle;

import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.weidong.lzbinddivicelibs.R;

/**
 * Created by Administrator on 2014/11/29.
 */
public class DialogUpgradeFail extends DialogFragment implements View.OnClickListener {
    private String TAG = this.getClass().getSimpleName();
    //    private String nContent;
    private OnConfirmListener mConfirmListener;
    private static String EXTRA_SUB_TITLE = "SUBTITLE_EXTRA";
    private static String EXTRA_LEFT_TEXT = "SUBTITLE_EXTRA_LEFT";
    private static String EXTRA_TITLE_TEXT = "TITLE_EXTRA";
    private static String EXTRA_Right_TEXT = "SUBTITLE_EXTRA_Right";


    private String mSubTitle = null;


    public static DialogUpgradeFail newInstance() {
        return new DialogUpgradeFail();
    }

    public static DialogUpgradeFail newInstance(String showContent, String left_text) {
//        DialogUpgradeFail recordReportDialog = new DialogUpgradeFail();
//        Bundle bundle = new Bundle();
//        bundle.putString(EXTRA_SUB_TITLE, showContent);
//        bundle.putString(EXTRA_LEFT_TEXT, left_text);
//        recordReportDialog.setArguments(bundle);

        return newInstance(showContent, left_text, "", "");
    }

    public static DialogUpgradeFail newInstance(String showContent, String left_text, String title, String right) {
        DialogUpgradeFail recordReportDialog = new DialogUpgradeFail();
        Bundle bundle = new Bundle();
        bundle.putString(EXTRA_SUB_TITLE, showContent);
        bundle.putString(EXTRA_LEFT_TEXT, left_text);
        bundle.putString(EXTRA_TITLE_TEXT, title);
        bundle.putString(EXTRA_Right_TEXT, right);

        recordReportDialog.setArguments(bundle);
        return recordReportDialog;
    }

    public static DialogUpgradeFail newInstance(String showContent) {
//        DialogUpgradeFail recordReportDialog = new DialogUpgradeFail();
//        Bundle bundle = new Bundle();
//        bundle.putString(EXTRA_SUB_TITLE, showContent);
//
//        bundle.putString(EXTRA_LEFT_TEXT, "");
//
//        recordReportDialog.setArguments(bundle);
        return newInstance(showContent, "");
//        return recordReportDialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return createDialog();
    }

    private Dialog createDialog() {
        Dialog dialog = new Dialog(getActivity(), R.style.MyDialogStyleWithWhite);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_hint_ota_fail, null);
        dialog.getWindow().getAttributes().windowAnimations = R.style.dialogWindowAnim;

        Bundle bundle = getArguments();
        if (bundle != null) {
            mSubTitle = bundle.getString(EXTRA_SUB_TITLE);
            leftText = bundle.getString(EXTRA_LEFT_TEXT);
            title = bundle.getString(EXTRA_TITLE_TEXT);
            rightText = bundle.getString(EXTRA_Right_TEXT);
        }
        initial(view);
        dialog.setContentView(view);
        return dialog;
    }

    private String leftText;
    private String title;
    private String rightText;

    public void setShowContent(String content) {
        if (dhof_subTitle_tv != null) {
            if (content == null) {
                dhof_subTitle_tv.setText(ApplicationHolder.getmApplication().getString(R.string.device_ota_fail_connect_us));
            } else {
                dhof_subTitle_tv.setText(content);
            }
        }
    }

    private TextView dhof_subTitle_tv, dhof_title_tv;
    private TextView mSrfCancelTv, mSrfConfirmTv;


    private void initial(View view) {
        dhof_title_tv = view.findViewById(R.id.dhof_title_tv);
        mSrfCancelTv = view.findViewById(R.id.dhof_cancel_tv);
        mSrfCancelTv.setOnClickListener(this);
        if (!TextUtils.isEmpty(leftText)) {
            mSrfCancelTv.setText(leftText);
        }
        if (!TextUtils.isEmpty(title)) {
            dhof_title_tv.setText(title);
        }
        mSrfConfirmTv = view.findViewById(R.id.dhof_confirm_tv);
        mSrfConfirmTv.setOnClickListener(this);
        if (!TextUtils.isEmpty(rightText)) {
            mSrfConfirmTv.setText(rightText);
        }
        dhof_subTitle_tv = view.findViewById(R.id.dhof_subTitle_tv);
        if (!TextUtils.isEmpty(mSubTitle)) {
            dhof_subTitle_tv.setText(mSubTitle);
        }
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.dhof_cancel_tv) {
            if (mConfirmListener != null) {
                mConfirmListener.onCancel();
            }
            this.dismiss();
        } else if (v.getId() == R.id.dhof_confirm_tv) {
            if (mConfirmListener != null) {
                mConfirmListener.onConfirm();
            }
            this.dismiss();

        }
    }

    public void setOnConfirmListener(OnConfirmListener onListener) {
        this.mConfirmListener = onListener;
    }

    public interface OnConfirmListener {
        void onConfirm();

        void onCancel();
    }

}
