package com.lifesense.weidong.lzbinddivicelibs.logic.device;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.constant.DeviceConnectState;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;


/**
 * Author:  winds
 * Email:   heardown@163.com
 * Date:    2019/9/18.
 * Desc:
 */
public class DeviceStateWrapper implements Cloneable, Comparable {
    private Device device;
    private int batteryState;   //电池状态
    private int battery; //电池电量信息
    private boolean isConnecting; //当前是否正在连接中

    public DeviceStateWrapper() {

    }

    public DeviceStateWrapper(Device device, DeviceConnectState state) {
        this.device = device;
        this.state = state;
    }

    public String getDeviceId() {
        if (device != null) {
            return device.getId();
        }
        return null;
    }

    private DeviceConnectState state;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public int getBatteryState() {
        return batteryState;
    }

    public void setBatteryState(int batteryState) {
        this.batteryState = batteryState;
    }

    public DeviceConnectState getState() {
        return state;
    }

    public void setState(DeviceConnectState state) {
        this.state = state;
    }

    public boolean isCheck() {
        return device != null && device.isActive();
    }

    public boolean isConnected() {
        return state != null && state == DeviceConnectState.CONNECTED_SUCCESS;
    }

    public boolean checkDeviceConnectState() {
        if (device != null) {
            this.state = LsBleManager.getInstance()
                    .checkDeviceConnectState(device.getMac());
        }
        return isConnected();
    }

    public boolean isWeight() {
        return device != null && device.isWeight();
    }

//    public boolean isPedometer() {
//        return device != null && device.isPedometer();
//    }
//
//    public boolean isWatch() {
//        if (isPedometer() && device.getModel() != null) {
//            return DeviceTools.getSaleType(device.getModel(), null) == SaleType.LSWatch;
//        }
//        return false;
//    }

//    public boolean isNB() {
//        return device != null && device.getCommunicationType() == Device.COMM_NB_IOT;
//    }
//
//    /**
//     * 是否为血压计
//     *
//     * @return
//     */
//    public boolean isManometer() {
//        return device != null && device.getProductTypeCode().equals(Device.PRODUCT_BLOOD_PRESSURE);
//    }
//
//    /**
//     * 是否为睡眠枕
//     *
//     * @return
//     */
//    public boolean isSleepPillow() {
//        return device != null && device.getProductTypeCode().equals(Device.PRODUCT_SLEEPACE);
//    }
//
//    /**
//     * 是否为Ali pay card
//     *
//     * @return
//     */
//    public boolean isAliPayCard() {
//        return device != null && device.getProductTypeCode().equals(Device.PRODUCT_ALI_PAY);
//    }
//
//    /**
//     * 是否为活跃设备
//     *
//     * @return
//     */
//    public boolean isActivePedometer() {
//        return device != null && device.isPedometer() && device.isActive();
//    }

    public boolean isActive() {
        return device != null && device.isActive();
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public boolean isConnecting() {
        return isConnecting;
    }

    public void setConnecting(boolean isConnecting) {
        this.isConnecting = isConnecting;
    }

    public DeviceStateWrapper clone() throws CloneNotSupportedException {
        return (DeviceStateWrapper) super.clone();
    }

    @Override
    public int compareTo(Object o) {
        DeviceStateWrapper wrapper = (DeviceStateWrapper) o;
        if (getDevice() == null) {
            return 1;
        }

        if (wrapper.getDevice() == null) {
            return -1;
        }

        int i = getSortNum(this) - getSortNum(wrapper);

        if (i == 0) {
            /*//是同种设备
            if (getDevice().isBluetooth() && isConnected()) { //是蓝牙设备 且已连接排在前面
                return -1;
            }*/
            /*if (isPedometer() && isActive()) { //是手环 且是活跃设备排在前面  产品要求同种设备只根据绑定时间排序
                return -1;
            }*/
            if (getDevice().getBindTime() != null && wrapper.getDevice().getBindTime() != null) {
                return wrapper.getDevice().getBindTime().compareTo(getDevice().getBindTime());
            }

            return 0;
        } else if (i > 0) {
            return 1;
        } else {
            return -1;
        }

    }

    public int getSortNum(DeviceStateWrapper wrapper) {
//        if (wrapper.isPedometer()) {
//            if (wrapper.isWatch()) {
//                return 1;
//            }
//            return 0;
//        }
        if (wrapper.isWeight()) {
            return 2;
        }
//
//        if (wrapper.isManometer()) {
//            return 3;
//        }
//
//        if (wrapper.isAliPayCard()) {
//            return 4;
//        }
        return Integer.MAX_VALUE;
    }
}

