package com.lifesense.weidong.lzbinddivicelibs.deviceconfig.ui;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.lifesense.ble.tools.PLogUtil;

import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.product.DisplayBindType;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.component.devicemanager.device.product.DisplayProductCategory;
import com.lifesense.component.devicemanager.device.product.DisplayProductType;
import com.lifesense.component.devicemanager.device.product.GetProductListRespond;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter.DeviceListItemAdapter;
import com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter.DeviceTypeMenuAdapter;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity.DeviceConnectSearchActivity;
import com.lifesense.weidong.lzbinddivicelibs.util.DialogUtil;
import com.lifesense.weidong.lzbinddivicelibs.util.ToastUtil;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.ArrayList;
import java.util.List;

public class DeviceConnectMenuActivity extends OlderBaseActivity {

    private static final int BIND_DEVICE = 2; //绑定历史设备
    private static final int BIND_HISTORY = 4;

    private final static int REQUESTCODE_BINDING_CHOOSE = 10000;
    private final static int REQUESTCODE_CONNECT_SEARCH = 10001;

    private RecyclerView rv_device_type;
    private RecyclerView rv_device_item;
    private DeviceTypeMenuAdapter deviceTypeMenuAdapter;
    private DeviceListItemAdapter deviceListItemAdapter;
    private GridLayoutManager gridLayoutManager;

    private List<DisplayProductCategory> datas = new ArrayList<>();
    private List<DisplayProduct> deviceItem = new ArrayList<>();

    public static Intent makeIntent(Context context){
        Intent intent = new Intent(context, DeviceConnectMenuActivity.class);
        return intent;
    }

    @Override
    protected void initHeader() {
        setHeader_Title(getString(R.string.device_select_device));
        setHeader_LeftImage(R.mipmap.nav_icn_back);
        setHeader_LeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeviceConnectMenuActivity.this.finish();
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCenterView(R.layout.activity_device_type_list);
        initView();
        initData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK){
            setResult(RESULT_OK);
            finish();
        }
    }

    private void initView() {
        rv_device_type = findViewById(R.id.rv_device_type);
        rv_device_type.setOverScrollMode(View.OVER_SCROLL_NEVER);
        rv_device_item = findViewById(R.id.rv_device_item);
        rv_device_item.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initData(){
        DialogUtil.getInstance().showProcessDialog(this);
        deviceTypeMenuAdapter = new DeviceTypeMenuAdapter(this,datas);
        deviceTypeMenuAdapter.setOnItemClickListener(new DeviceTypeMenuAdapter.OnItemClickListener() {
            @Override
            public void click(View view, int position) {
                if (datas == null || datas.size() <= position
                        || datas.get(position) == null || datas.get(position).getDisplayProducts() == null
                        || datas.get(position).getDisplayProducts().size() <= 0) {
                    return;
                }
                if (deviceItem.contains(datas.get(position).getDisplayProducts().get(0))) {
                    return;
                } else {
                    deviceItem.clear();
                    deviceItem.addAll(datas.get(position).getDisplayProducts());
                    deviceListItemAdapter.notifyDataSetChanged();
                }
                deviceTypeMenuAdapter.setClickPosition(position);
            }
        });
        rv_device_type.setLayoutManager(new LinearLayoutManager(this));
        rv_device_type.setAdapter(deviceTypeMenuAdapter);

        deviceListItemAdapter = new DeviceListItemAdapter(this,deviceItem);
        deviceListItemAdapter.setOnItemClickListener(new DeviceListItemAdapter.OnItemClickListener() {
            @Override
            public void click(View view, int position) {
//            ToastUtil.showCenterShowToast(String.valueOf(position));
                DeviceConnectMenuActivity.this.skipToSearchDevice(position);
            }
        });
        gridLayoutManager = new GridLayoutManager(this,2);
        rv_device_item.setLayoutManager(gridLayoutManager);
        rv_device_item.setAdapter(deviceListItemAdapter);
        LZDeviceService.getInstance().getProduct(new IRequestCallBack<GetProductListRespond>() {
            @Override
            public void onRequestSuccess(GetProductListRespond respond) {
                DialogUtil.getInstance().dismissProcessDialog();
                if (respond == null || respond.getData() == null || respond.getData() .size() <= 0){
                    return;
                }
                datas.clear();
                datas.addAll(respond.getData());
                if(datas.get(0) != null && datas.get(0).getDisplayProducts() != null && datas.get(0).getDisplayProducts().size() > 0) {
                    deviceItem.clear();
                    deviceItem.addAll(datas.get(0).getDisplayProducts());
                    deviceTypeMenuAdapter.notifyDataSetChanged();
                    deviceListItemAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onRequestError(int i, String s, GetProductListRespond respond) {
                DialogUtil.getInstance().dismissProcessDialog();
                ToastUtil.showCenterShowToast(mContext,s);
                showNetworkErrorView();
            }
        });
    }

    @Override
    protected void onNetworkErrorReload(View view) {
        dismissNetworkErrorView();
        initData();
    }

    /**
     * 根据绑定类型 跳转到对应搜索页面
     * @param position
     */
    private void skipToSearchDevice(int position) {
        if(deviceItem == null || position >= deviceItem.size()) { //存在IndexOutOfBoundsException https://bugly.qq.com/v2/crash-reporting/crashes/356cb341aa/98365?pid=1
            return;
        }
        DisplayProduct displayProduct = deviceItem.get(position);
        DisplayBindType bindType = displayProduct.getDisplayBindType();
        DisplayProductType productType = displayProduct.getDisplayProductType();
        switch (bindType){
            case bluetooth:
                PLogUtil.e("DeviceTypeListActivity,displayProduct:" + displayProduct);
                startActivityForResult(
                        DeviceConnectSearchActivity.makeIntentWithDisplayProduct(
                                this, displayProduct),
                        REQUESTCODE_CONNECT_SEARCH);
                break;
        }
    }
}
