package com.lifesense.weidong.lzbinddivicelibs.util;

import android.content.Context;
import android.support.annotation.NonNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Created by Sanjay on 2014/10/29 0029.
 * 这个是用来缓存一个对象到本地的一个简单工具
 * 一个对象类只能存一个，多了会被替换
 */
public class CommonObjectCache {

//    public static <T extends Serializable> void saveObject(@NonNull Context context, T CacheObject) {
//        FileOutputStream fos = null;
//        ObjectOutputStream oos = null;
//        try {
//            //移除就得对象
//            removeRecordMsg(context, CacheObject);
//            fos = context.openFileOutput(CacheObject.getClass().getSimpleName(), Context.MODE_PRIVATE);
//            oos = new ObjectOutputStream(fos);
//            oos.writeObject(CacheObject);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            StreamUtil.close(null, fos);
//            StreamUtil.close(null, oos);
//        }
//    }

    public static <T extends Serializable> void saveObject(@NonNull Context context, String key, Object object) {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            removeCacheObj(context, key);
            fos = context.openFileOutput(key, Context.MODE_PRIVATE);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            StreamUtil.close(null, fos);
            StreamUtil.close(null, oos);
        }
    }

    public static <T extends Serializable> void saveObject(String path, String key, Object object) {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            removeCacheObj(path, key);
            File file = new File(path + "/" + key);
            if (!file.exists()) {
                file.createNewFile();
            }
            fos = new FileOutputStream(file);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            StreamUtil.close(null, fos);
            StreamUtil.close(null, oos);
        }
    }

    public static <T> T getCacheObj(String path, String key) {

        T cacheObject = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            File file = new File(path + "/" + key);
            fis = new FileInputStream(file);// context.openFileInput(key);
            ois = new ObjectInputStream(fis);
            cacheObject = (T) ois.readObject();
            ois.close();
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cacheObject;
    }

    public static <T extends Serializable> boolean removeCacheObj(@NonNull Context context, String key) {
        File file = new File(context.getFilesDir(), key);
        return file.delete();
    }

    public static <T extends Serializable> boolean removeCacheObj(String path, String key) {
        File file = new File(path, key);
        return file.delete();
    }

    public static <T> T getCacheObj(@NonNull Context context, String key) {

        T cacheObject = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            fis = context.openFileInput(key);
            ois = new ObjectInputStream(fis);
            cacheObject = (T) ois.readObject();
            ois.close();
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cacheObject;
    }


//    public static <T> T getLastMsg(@NonNull Context context, String classSimpleName) {
//
//        T cacheObject = null;
//        FileInputStream fis = null;
//        ObjectInputStream ois = null;
//
//        try {
//            fis = context.openFileInput(classSimpleName);
//            ois = new ObjectInputStream(fis);
//            cacheObject = (T) ois.readObject();
//            ois.close();
//            fis.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cacheObject;
//    }

//    public static <T extends Serializable> boolean removeRecordMsg(@NonNull Context context, T cacheObject) {
//        File file = new File(context.getFilesDir(), cacheObject.getClass().getSimpleName());
//        return file.delete();
//    }

}
