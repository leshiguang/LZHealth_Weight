package com.lifesense.weidong.lzbinddivicelibs.logic.device.manage;


import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;

/**
 * Created by Sinyi.liu on 16/4/18.
 * Copyright by gz.lifesense.com
 */
public interface DeviceStatusChangeObserver {
     void onDeviceStatusChange(DeviceStatus deviceStatus);
}
