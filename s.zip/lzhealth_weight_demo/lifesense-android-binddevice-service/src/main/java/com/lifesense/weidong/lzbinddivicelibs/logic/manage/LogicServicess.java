package com.lifesense.weidong.lzbinddivicelibs.logic.manage;

import com.lifesense.utils.LSLog;
//import com.lifesense.weidong.lzbinddivicelibs.logic.device.manage.SportDeviceManagee;

import java.util.HashMap;
import java.util.Map;

public class LogicServicess {

    private static final String TAG = "LogicServicess";
    Map<String, Object> logicManagerMap = new HashMap<String, Object>();

    /**
     * 根据实体类来获得logicManager
     *
     * @param logicManagerClass
     * @return
     */
    @SuppressWarnings("unchecked")
    public <T extends Object> T findBylogicManagerClass(Class<T> logicManagerClass) {
        T logicManager = null;
        String className = getlogicManagerClassName(logicManagerClass);
        if (logicManagerMap.containsKey(className)) {
            logicManager = (T) logicManagerMap.get(className);
        }
        if (logicManager == null) {
            //			LSLog.d(TAG, String.format("findByLogicManagerClass %s", logicManagerClass.getName()));
            try {
                logicManager = logicManagerClass.newInstance();
            } catch (IllegalAccessException e) {
                LSLog.e(TAG, e.getMessage());
            } catch (InstantiationException e) {
                LSLog.e(TAG, e.getMessage());
            }
            if (logicManager != null) {
                logicManagerMap.put(className, logicManager);
                //				LSLog.d(TAG, String.format("findByLogicManagerClass result: %s", logicManager.getClass().getName()));
            } else {
                LSLog.e(TAG, String.format("fail to find logic manager %s", className));
            }
        }

        return logicManager;
    }

    /**
     * 获得实体类的类名
     *
     * @param logicManagerClass
     * @return
     */
    protected <T> String getlogicManagerClassName(Class<T> logicManagerClass) {
        //用class name, 避免冲突
        return logicManagerClass.getName();
    }

    private static LogicServicess gInstance;

    public static LogicServicess shareInstance() {
        if (gInstance == null) {
            synchronized (LogicServicess.class) {
                gInstance = new LogicServicess();
            }
        }
        return gInstance;
    }
}
