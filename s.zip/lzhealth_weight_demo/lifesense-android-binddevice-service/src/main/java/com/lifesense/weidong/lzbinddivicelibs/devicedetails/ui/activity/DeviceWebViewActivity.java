package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.lifesense.jumpaction.action.ActivityAction;
import com.lifesense.jumpaction.utils.IntentUtils;
import com.lifesense.weidong.lswebview.activity.WebViewActivity;
import com.lifesense.weidong.lzbinddivicelibs.util.DeviceConstants;
import com.lifesense.weidong.lzbinddivicelibs.util.DeviceUtils;

/**
 * lifesensexu
 * 17/5/4
 * gz.lifesense.weidong.ui.activity.mine
 */
public class DeviceWebViewActivity extends WebViewActivity {
    private String mDeviceId;
    public static final String EXTRA_DEVICE_ID = "deviceId";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_URL = "url";

    public static ActivityAction makeActivityAction(Context context, String title, String url, String deviceId) {
        return new ActivityAction(DeviceWebViewActivity.class, context).putString(EXTRA_TITLE, title).putString(EXTRA_URL, url).putString(EXTRA_DEVICE_ID, deviceId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDatas();
    }

    private void initDatas() {
        mDeviceId = IntentUtils.getStringData(EXTRA_DEVICE_ID, getIntent(), null);
        setHeaderLeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goNext();
            }
        });
    }

    @Override
    public void onBackPressed() {
        goNext();
    }

    private void goNext() {
        if (mDeviceId != null) {
//            Intent intent = new Intent(DeviceWebViewActivity.this, DeviceMelodyActivity.class);
//            intent.putExtra(DeviceConstants.DEVICE_ID, mDeviceId);
            startActivity(DeviceUtils.getDeviceInfoIntent(this,mDeviceId));
            finish();
        } else {
            finish();
        }
    }
}
