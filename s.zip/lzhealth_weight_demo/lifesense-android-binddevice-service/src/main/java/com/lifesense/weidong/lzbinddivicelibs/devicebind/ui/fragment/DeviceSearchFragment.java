package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lifesense.component.devicemanager.application.interfaces.callback.SearchResultCallback;
import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity.DeviceConnectSearchActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;
import com.lifesense.weidong.lzbinddivicelibs.widget.RippleBackground;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 搜索设备
 */
@SuppressLint("ValidFragment")
public class DeviceSearchFragment extends BaseFragment {

    private RippleBackground mRippleBackground;
    private CountDownTimer mCountDownTimer;
    private int mSecond = 0;
    private List<LSEDeviceInfoApp> mDeviceList;
    private final static int MAX_DEVICE_LIST_SIZE = 3;  //设备列表最大个数
    private long lastFindTime;
    private static final int LONGEST_SEARCH_SECOND = 30;

    private DisplayProduct displayProduct;

    public static DeviceSearchFragment newInstance(DisplayProduct displayProduct) {
        DeviceSearchFragment fragment = new DeviceSearchFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("displayProduct", displayProduct);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        this.displayProduct = bundle.getParcelable("displayProduct");
        View view = inflater.inflate(R.layout.fragment_device_search, null);
        return view;
    }

    @Override
    protected void initData() {
        mRippleBackground = getActivity().findViewById(R.id.content);
//        getActivity().findViewById(R.id.tvOtherBind).setOnClickListener(this);
        ((OlderBaseActivity) getActivity()).setHeader_Title("");

        mCountDownTimer = new CountDownTimer(Long.MAX_VALUE, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (mSecond >= LONGEST_SEARCH_SECOND && mDeviceList.size() == 0) {
                    stopSearchDevice();
                    ((DeviceConnectSearchActivity) getActivity()).show(mDeviceList);
                }

                if (lastFindTime != 0 && System.currentTimeMillis() - lastFindTime > 3 * 1000 && mDeviceList.size() > 0) {
                    stopSearchDevice();
                    if (mDeviceList.size() == 1) {
                        mDeviceList.get(0).setCheck(true);
                        ((DeviceConnectSearchActivity) getActivity()).show(mDeviceList);
                    } else {
                        Collections.sort(mDeviceList);
                        mDeviceList.get(0).setCheck(true);
                        ((DeviceConnectSearchActivity) getActivity()).show(mDeviceList);
                    }
                }
                mSecond += 1;
            }

            @Override
            public void onFinish() {

            }
        };
    }

    @Override
    public void onShowChanged(boolean isShow) {
        if (isShow) {
            startSearchDevice();
        } else {
            stopSearchDevice();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvOtherBind) {

        }
    }

    private void startSearchDevice() {
        mDeviceList = new ArrayList<>();
        mRippleBackground.startRippleAnimation();
        mCountDownTimer.start();
        mSecond = 0;
        LZDeviceService.getInstance().searchDevice(displayProduct, new SearchResultCallback() {
            @Override
            public void onSearchResult(LSEDeviceInfo lseDeviceInfo, int i) {
                if (lseDeviceInfo == null || mDeviceList.size() > MAX_DEVICE_LIST_SIZE) {
                    return;
                }

                LSEDeviceInfoApp info = new LSEDeviceInfoApp();
                info.setMacAddress(lseDeviceInfo.getMacAddress());

                lastFindTime = System.currentTimeMillis();
                info.setDeviceName(lseDeviceInfo.getDeviceName());
                info.setRssi(i);
                info.setLSEDeviceInfo(lseDeviceInfo);
                if (canBeInsertIntoDeviceList(info)) {
                    mDeviceList.add(info);
                }
            }
        });
    }

    private void stopSearchDevice() {
        mCountDownTimer.cancel();
        LZDeviceService.getInstance().stopSearch();
        mRippleBackground.stopRippleAnimation();
    }

    private boolean canBeInsertIntoDeviceList(LSEDeviceInfoApp info) {
        boolean ret = true;
        //判断是不是已经加入了list
        for (int i = 0; i < mDeviceList.size(); i++) {
            if (mDeviceList.get(i).getMacAddress().equalsIgnoreCase(info.getMacAddress())) {
                ret = false;
                break;
            }
        }
        return ret;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        stopSearchDevice();
    }
}
