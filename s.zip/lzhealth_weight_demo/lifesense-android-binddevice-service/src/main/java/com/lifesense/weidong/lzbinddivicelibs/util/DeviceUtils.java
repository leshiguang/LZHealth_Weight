package com.lifesense.weidong.lzbinddivicelibs.util;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;


import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.lifesense.commonlogic.config.ProtocolConfig;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lswebview.activity.WebViewActivity;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity.DeviceDetailsActivity;
//import com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity.DeviceMelodyActivity;

import java.util.Hashtable;

public class DeviceUtils {
    public static String getFormateDeviceSn(@NonNull String deviceSn) {
        StringBuilder builder = new StringBuilder(deviceSn.length());
        for (int i = 0; i < deviceSn.length(); i++) {
            if (i % 4 == 0 && i != 0) {
                builder.append(" ");
            }
            builder.append(deviceSn.charAt(i));
        }

        return builder.toString();
    }

    //设备详情分发
    public static Intent getDeviceInfoIntent(Context context, Device device) {
        return DeviceDetailsActivity.makeIntent(context,device.getId());
    }

    //设备详情分发
    public static Intent getDeviceInfoIntent(Context context, String deviceId) {
        return DeviceDetailsActivity.makeIntent(context,deviceId);
    }

    /**
     * 根据型号获取对应的icon
     *
     * @param device device
     * @return img index
     */
    @DrawableRes
    public static int getDeviceIcon(Device device) {
        return R.mipmap.icon_melody;
    }

    //获取设备操作指南的url
    public static String getDeviceOperationGuideUrl(Device device){
        String url = "";
        if (!TextUtils.isEmpty(device.getOperationGuide())){
            url = device.getOperationGuide();
        } else {
            String host = ProtocolConfig.getStaticDomain();
            String modelNum = device.getModel();
            String softwareVersion = device.getSoftwareVersion();
            String hardWareVersion = device.getHardwareVersion();
//            url = String.format(WebViewActivity.OPERATION_URL, host, modelNum, softwareVersion, "2", hardWareVersion);
        }
        return url;
    }

    /**
     * 生成一个二维码图像
     *
     * @param url       传入的字符串，通常是一个URL
     * @param QR_WIDTH  宽度（像素值px）
     * @param QR_HEIGHT 高度（像素值px）
     * @return
     */
    public static final Bitmap create2DCoderBitmap(String url, int QR_WIDTH, int QR_HEIGHT) {
        try {
            // 判断URL合法性
            if (url == null || "".equals(url) || url.length() < 1) {
                return null;
            }
            Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
            hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
            // 图像数据转换，使用了矩阵转换
            BitMatrix bitMatrix = new QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT, hints);
            int[] pixels = new int[QR_WIDTH * QR_HEIGHT];
            // 下面这里按照二维码的算法，逐个生成二维码的图片，
            // 两个for循环是图片横列扫描的结果
            for (int y = 0; y < QR_HEIGHT; y++) {
                for (int x = 0; x < QR_WIDTH; x++) {
                    if (bitMatrix.get(x, y)) {
                        pixels[y * QR_WIDTH + x] = 0xff000000;
                    } else {
                        pixels[y * QR_WIDTH + x] = 0xffffffff;
                    }
                }
            }
            // 生成二维码图片的格式，使用ARGB_8888
            Bitmap bitmap = Bitmap.createBitmap(QR_WIDTH, QR_HEIGHT, Bitmap.Config.ARGB_8888);
            bitmap.setPixels(pixels, 0, QR_WIDTH, 0, 0, QR_WIDTH, QR_HEIGHT);
            return bitmap;
        } catch (WriterException e) {
            return null;
        }
    }

//    /**
//     * @param saleType
//     * @return OTA是否支持中断升级操作
//     * @author liuxinyi
//     * @date 2016-09-30
//     */
//    public static boolean isSupportInterruptUpgrade(SaleType saleType) {
//        return DeviceManager.isSupportInterruptUpgrade(saleType);
//    }
}
