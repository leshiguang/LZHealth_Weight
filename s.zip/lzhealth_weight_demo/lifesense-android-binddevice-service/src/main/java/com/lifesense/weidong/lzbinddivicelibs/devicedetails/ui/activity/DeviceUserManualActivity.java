package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseActivity;


/**
 * Create by qwerty
 * Create on 2020/6/9
 **/
public class DeviceUserManualActivity extends BaseActivity {
    public static Intent makeIntent(Context context) {
        return new Intent(context, DeviceUserManualActivity.class);
    }

    @Override
    protected boolean showNav() {
        return true;
    }


    @Override
    protected int getContentView() {
        return R.layout.fragment_help;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        setTitle(getString(R.string.user_manual));
    }

    @Override
    protected void initData(Bundle savedInstanceState) {

    }
}
