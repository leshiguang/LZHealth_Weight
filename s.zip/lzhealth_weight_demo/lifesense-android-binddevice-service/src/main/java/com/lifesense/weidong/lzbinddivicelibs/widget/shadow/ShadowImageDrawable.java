/*
 * 文件名:  ShadowImageDrawable.java
 * 版权:   广州动心信息科技有限公司
 * 创建人:  liguoliang
 * 创建时间:2016-10-09
 */

package com.lifesense.weidong.lzbinddivicelibs.widget.shadow;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

/**
 * @author liguoliang
 * @date 16/10/9
 */
public class ShadowImageDrawable extends Drawable {

    private Drawable mSrc;

    private Paint mPaint;

    private ShadowProperty mShadowProperty;

    private boolean mIsShowShadow = false;
    public ShadowImageDrawable(Drawable src, ShadowProperty shadowProperty) {
        mSrc = src;
        mPaint = new Paint();
        mShadowProperty = shadowProperty;
    }

    public boolean isShowShadow() {
        return mIsShowShadow;
    }

    public void setShowShadow(boolean showShadow) {
        mIsShowShadow = showShadow;
    }

    @Override
    public void draw(Canvas canvas) {
        if (mSrc == null) {
            return;
        }
        if (mIsShowShadow) {
            if (mSrc instanceof BitmapDrawable) {
                Bitmap bmp = ((BitmapDrawable) mSrc).getBitmap();
                if (bmp == null) {
                    return;
                }
                if (mShadowProperty == null) {
                    mSrc.draw(canvas);
                } else {
                    Bitmap shadowBmp = imgshadow(bmp, mSrc.getIntrinsicWidth() , mSrc.getIntrinsicHeight(), mShadowProperty.getShadowColor(), Math.round(mShadowProperty.getShadowRadius()), mShadowProperty.getShadowDx(), mShadowProperty.getShadowDy());
                    if (shadowBmp == null) {
                        mSrc.draw(canvas);
                    } else {
                        canvas.drawBitmap(shadowBmp, 0, 0, mPaint);
                    }
                }
            } else {
                mSrc.draw(canvas);
            }
        } else {
            drawSrc(canvas);
        }

       
    }

    private void drawSrc(Canvas canvas) {
        if (mSrc instanceof BitmapDrawable) {
            Bitmap bmp = ((BitmapDrawable) mSrc).getBitmap();
            final Matrix scaleToFit = new Matrix();
            final RectF src = new RectF(0, 0, bmp.getWidth(), bmp.getHeight());
            final RectF dst = new RectF(0, 0, bmp.getWidth() - mShadowProperty.getShadowDx(), bmp.getHeight() - mShadowProperty.getShadowDy());
            scaleToFit.setRectToRect(src, dst, Matrix.ScaleToFit.CENTER);
            int saveCount = canvas.save();
            canvas.translate(mShadowProperty.getShadowDx()/2, mShadowProperty.getShadowDy() /2);
            canvas.drawBitmap(bmp, scaleToFit, null);
            canvas.restoreToCount(saveCount);
        }
    }

    public Bitmap imgshadow(final Bitmap bm, final int dstHeight, final int dstWidth, int color, int size, float dx, float dy) {
        try {
            final Bitmap mask = Bitmap.createBitmap(dstWidth, dstHeight, Bitmap.Config.ALPHA_8);

            final Matrix scaleToFit = new Matrix();
            final RectF src = new RectF(0, 0, bm.getWidth(), bm.getHeight());
            final RectF dst = new RectF(0, 0, dstWidth - dx, dstHeight - dy);
            scaleToFit.setRectToRect(src, dst, Matrix.ScaleToFit.CENTER);

            final Matrix dropShadow = new Matrix(scaleToFit);
            dropShadow.postTranslate(dx, dy);

            final Canvas maskCanvas = new Canvas(mask);
            final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            maskCanvas.drawBitmap(bm, scaleToFit, paint);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
            maskCanvas.drawBitmap(bm, dropShadow, paint);

            final BlurMaskFilter filter = new BlurMaskFilter(size, BlurMaskFilter.Blur.NORMAL);
            paint.reset();
            paint.setAntiAlias(true);
            paint.setColor(color);
            paint.setMaskFilter(filter);
            paint.setFilterBitmap(true);

            final Bitmap ret = Bitmap.createBitmap(dstWidth, dstHeight, Bitmap.Config.ARGB_8888);
            final Canvas retCanvas = new Canvas(ret);
            retCanvas.drawBitmap(mask, 0, 0, paint);
            int saveCount = retCanvas.save();
            retCanvas.translate(dx/2, dy /2);
            retCanvas.drawBitmap(bm, scaleToFit, null);
            retCanvas.restoreToCount(saveCount);
            mask.recycle();
            return ret;
        } catch (Throwable e) {

        }

        return null;
    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return 0;
    }

    @Override
    public int getIntrinsicWidth() {
        if (mSrc == null) {
            return 0;
        }
        return mSrc.getIntrinsicWidth();
    }

    @Override
    public int getIntrinsicHeight() {
        if (mSrc == null) {
            return 0;
        }
        return mSrc.getIntrinsicHeight();
    }
}
