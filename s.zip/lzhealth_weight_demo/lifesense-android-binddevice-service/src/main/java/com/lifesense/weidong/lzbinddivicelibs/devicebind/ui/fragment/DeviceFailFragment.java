package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.UiDeviceBindType;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity.DeviceConnectSearchActivity;

import static android.support.v7.app.AppCompatActivity.RESULT_FIRST_USER;

/**
 * 设备绑定失败展示
 */
@SuppressLint("ValidFragment")
public class DeviceFailFragment extends BaseFragment {

    private TextView tvBottom;
    private ImageView ivDeviceIcon;
    private String imgUrl;
    private LSEDeviceInfoApp lseDeviceInfoApp;
    private Device device;

    public static DeviceFailFragment newInstance(String imgUrl, LSEDeviceInfoApp lseDeviceInfoApp) {
        DeviceFailFragment fragment = new DeviceFailFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("lseDeviceInfoApp", lseDeviceInfoApp);
        bundle.putString("imgUrl", imgUrl);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static DeviceFailFragment newInstance(String imgUrl, Device device) {
        DeviceFailFragment fragment = new DeviceFailFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("device", device);
        bundle.putString("imgUrl", imgUrl);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        this.imgUrl = bundle.getString("imgUrl");
        this.lseDeviceInfoApp = bundle.getParcelable("lseDeviceInfoApp");
        this.device = bundle.getParcelable("device");
        return inflater.inflate(R.layout.fragment_device_fail, null);
    }

    @Override
    protected void initData() {
        ivDeviceIcon = getActivity().findViewById(R.id.ivDeviceIcon);
        tvBottom = getActivity().findViewById(R.id.tvBottom);
        tvBottom.setOnClickListener(this);
        ImageUtil.displayImage(imgUrl, ivDeviceIcon);
        ((OlderBaseActivity) getActivity()).setHeader_Title(getString(R.string.device_search_connect_title));
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvBottom) {
            FragmentActivity activity = getActivity();
            switch (UiDeviceBindType.getCurrentUiDeviceBindType()) {
                case UiDeviceBindType.history:
                case UiDeviceBindType.qrcode:
                    activity.finish();
                    break;
                case UiDeviceBindType.qrcode_sn:
                    getActivity().setResult(RESULT_FIRST_USER);
                    activity.finish();
                    break;
                case UiDeviceBindType.search:
                    ((DeviceConnectSearchActivity) activity).startSearchDevice();
                    break;
            }
        }
    }
}
