package com.lifesense.weidong.lzbinddivicelibs.devicedetails.model;

import android.content.Context;
import android.support.annotation.StringRes;


import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.weidong.lzbinddivicelibs.R;


/**
 * Create by qwerty
 * Create on 2020/6/10
 **/
public enum Unit {
    UNIT_KG(R.string.unit_kg, UnitType.UNIT_KG),
    UNIT_LB(R.string.unit_lb, UnitType.UNIT_LB);
    private int unitNameRes;
    private UnitType unitType;

    Unit(@StringRes int unitNameRes , UnitType unitType) {
        this.unitNameRes = unitNameRes;
        this.unitType = unitType;
    }

    public String getUnitName(Context context) {
        return context.getString(unitNameRes);
    }

    public UnitType getUnitType() {
        return unitType;
    }

    public static Unit getUnitByUnitTypeCommand(int command) {
        for (Unit unit : values()) {
            if(unit.unitType.getCommand() == command) {
                return unit;
            }
        }
        return null;
    }
}
