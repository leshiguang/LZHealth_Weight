package com.lifesense.weidong.lzbinddivicelibs.devicedetails.model;

import android.content.Context;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.bean.Cell;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by qwerty
 * Create on 2020/6/10
 **/
public enum LegalInfoModel {
    DATA_ACCESS(R.string.data_access),
    PRIVACY(R.string.privacy);
    private int itemNameRes;

    LegalInfoModel(int itemNameRes) {
        this.itemNameRes = itemNameRes;
    }

    public static List<Cell> createLawInfoCells(Context context) {
        List<Cell> cells = new ArrayList<>();
        for (LegalInfoModel legalInfoModel : values()) {
            Cell cell = new Cell();
            cell.setId(legalInfoModel.name());
            cell.setShowArrow(true);
            cell.setShowSwitch(false);
            cell.setShowTag(false);
            cell.setShowValue(false);
            cell.setTitle(context.getString(legalInfoModel.itemNameRes));
            cells.add(cell);
        }
        return cells;
    }

}
