package com.lifesense.weidong.lzbinddivicelibs.util;

import android.text.TextUtils;

/**
 * Created by lee on 16-7-15.
 */
public class MIUIUtils {

    private static final String KEY_MIUI_VERSION_NAME = "ro.miui.ui.version.name";

    public static boolean isMIUI() {
        return !TextUtils.isEmpty(getMIUIVersion());
    }

    public static String getMIUIVersion() {
        return SysUtils.getSystemProperty(KEY_MIUI_VERSION_NAME);
    }

    /**
     * 是否为MIUI6或者之后的系统
     * @return
     */
    public static boolean isOverMIUI6() {
        String version = getMIUIVersion();
        return !TextUtils.isEmpty(version) && Integer.parseInt(version.substring(1)) > 5;
    }
}
