package com.lifesense.weidong.lzbinddivicelibs.deviceota.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lifesense.component.devicemanager.application.interfaces.listener.UpgradeStateListener;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.util.CommonObjectCache;
import com.lifesense.weidong.lzbinddivicelibs.util.FileUtils;
import com.lifesense.weidong.lzbinddivicelibs.util.UIUtil;
import com.lifesense.weidong.lzbinddivicelibs.widget.UpdateDeviceProgressBar;
import com.lifesense.weidong.lzbinddivicelibs.widget.dialog.DialogUpgradeFail;
import com.lifesense.weidong.lzbinddivicelibs.widget.dialog.ShowHintDialog;
import com.lifesense.weidong.lzsimplenetlibs.file.DownloadRequest;
import com.lifesense.weidong.lzsimplenetlibs.file.DownloadResponse;
import com.lifesense.weidong.lzsimplenetlibs.file.IDownloadRequestCallback;

import java.io.File;

public class StartUpdateActivity extends OlderBaseActivity {

	private static final String EXTRA_FIRM = "extra_firm";
	private static final String EXTRA_REINSTALL = "extra_reinstall";
	private static final String EXTRA_DATA_DEVICE = "extra_device";
	private TextView mAuTitleTv;
	private TextView mProgressTv;
	private TextView mAuSubtitleTv;
	private TextView mWathcHintTv;
	private UpdateDeviceProgressBar progressView;
	private ViewStub mAuSuccessStub;
	private FirmwareInfo mFirmWareInfo;
	private Device mDevice;

	private Button cancelBtn;
	private View successView;
	private TextView au_ota_hint1_tv;
	private LinearLayout au_title_layout;
	private View content_layout;

	public static Intent makeIntent(Context context, Device device, FirmwareInfo firmwareInfo) {

		return new Intent(context, StartUpdateActivity.class).putExtra(EXTRA_DATA_DEVICE, device).putExtra(EXTRA_FIRM, (Parcelable) firmwareInfo);
	}

	public static Intent makeReInstallIntent(Context context, Device device, boolean isReInstall) {

		return new Intent(context, StartUpdateActivity.class).putExtra(EXTRA_REINSTALL, isReInstall).putExtra(EXTRA_DATA_DEVICE, device);
	}

	private void assignViews() {
		content_layout = findViewById(R.id.content_layout);
		mAuTitleTv = findViewById(R.id.au_title_tv);
		au_title_layout = findViewById(R.id.au_title_layout);
		mAuSubtitleTv = findViewById(R.id.au_subtitle_tv);
//		mAuLoadingIv = (ImageView) findViewById(R.id.au_loading_iv);
		progressView = findViewById(R.id.progressView);
		mAuSuccessStub = findViewById(R.id.au_success_stub);
		cancelBtn = findViewById(R.id.au_cancel_btn);
		mProgressTv = findViewById(R.id.au_progress_tv);
	}

	@Override
	protected void initHeader() {
		setHeaderBackground(R.color.main_blue);
		layout_header.setVisibility(View.GONE);

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setCenterView(R.layout.activity_update);
		initView();
	}

	public void initView() {
		isReportFail=false;
		assignViews();
		showLoadingAnim();
		mDevice = getIntent().getParcelableExtra(EXTRA_DATA_DEVICE);
//		download(mFirmWareInfo);
		mFirmWareInfo = getIntent().getParcelableExtra(EXTRA_FIRM);
		startInstallFirmware(mFirmWareInfo.getName());
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			//
			if (content_layout != null) {
				ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) content_layout.getLayoutParams();
				content_layout.setPadding(0, UIUtil.getStatusBarHeight(mContext), 0, 0);
				content_layout.setLayoutParams(layoutParams);
			}
		}
	}

	private void download(FirmwareInfo mFirmWareInfo) {
		if (mFirmWareInfo == null) {//碰到过 mFirmWareInfo为空，从缓存读取也没错，
			mFirmWareInfo = CommonObjectCache.getCacheObj(this, mDevice.getId());
		}

		File file = new File(FileUtils.getFirmWarePath(mFirmWareInfo.getName()));
		if (file.exists()) {//已经有下载文件
			file.delete();
		}
		Log.e(TAG, " targetFilepath=" + FileUtils.getFilePath(this,mFirmWareInfo.getName()));
		DownloadRequest downloadRequest = new DownloadRequest(FileUtils.getFilePath(this,mFirmWareInfo.getName()),mFirmWareInfo.getFileUrl());
		downloadRequest.execute(downloadFileManagerDelegate);
	}

	public void showLoadingAnim() {
		Animation operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate_self_anim);
		LinearInterpolator lin = new LinearInterpolator();
		operatingAnim.setInterpolator(lin);
	}

	IDownloadRequestCallback downloadFileManagerDelegate = new IDownloadRequestCallback() {

		@Override
		public void onDownloading(int i) {
			mProgressTv.setText(i + "%");
			progressView.setProgress(i);
		}

		@Override
		public void onRequestSuccess(DownloadResponse downloadResponse) {
			Log.e(TAG, "onDownloadSuccess() called with: " + "response = [" + downloadResponse.getFilePath() + "]");
			startInstallFirmware(downloadResponse.getFilePath());
		}

		@Override
		public void onRequestError(int i, String s, DownloadResponse downloadResponse) {
			showFailDownloadMsg();
			Log.e(TAG, "onDownloadFailed() called with: " + "errMsg = [" + s + "], errCode = [" + i + "]");
		}

	};
	private final int DOWNLOAD_FAIL = -10;

	private boolean deleteFirmwareFile() {
		File file = new File(FileUtils.getFirmWarePath(mFirmWareInfo.getName()));
		return file.delete();
	}
	private void startInstallFirmware(String path) {
		//如果是OTA失败，重新安装，需要设置为5%。
		//下载完成文件也是5%，所以直接在这里手动设置一个
		mProgressTv.setText("5%");
		progressView.setProgress(5);

		Log.e(TAG, "startInstallFirmware() called with: " + "path = [" + path + "]");
        LZDeviceService.getInstance().upgradeDeviceFirmware(mDevice.getId(), path, new UpgradeStateListener() {
            @Override
            public void onStart() {
                //保持屏幕常亮
            }

            @Override
            public void onProgress(int i) {
                //把0-100映射成5-100；
                final int newProgress = (int) ((0.95 * i) + 5);
                Log.e(TAG, "onProgress: " + i + "finalProgress =" + newProgress);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mProgressTv.setText(newProgress + "%");
                        progressView.setProgress(newProgress);

                    }
                });
                if (newProgress == 100) {
                    cancelBtn.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onFinish(boolean b, int i, String s) {
                //关闭屏幕常亮
				if(b) {
					showSuccessView();
				} else  {
					showUpgradeFailView(null);
				}

            }
        });
	}

	boolean isReportFail = false;


	private void showFailDownloadMsg() {

		//        setResult(RESULT_CANCELED, ShowDeviceUpdateInfoActivity.makeDownloadFailIntent());
		//        finish();
		showUpgradeFailView(getResources().getString(R.string.hint_download_package_fail));
	}

	private void showUpgradeFailView(String msg) {

		DialogUpgradeFail tagDialogUpgradeFail = (DialogUpgradeFail) getSupportFragmentManager().findFragmentByTag("DialogUpgradeFail");
		DialogUpgradeFail dialogUpgradeFail;

		if (msg == null) {
			msg = getString(R.string.device_ota_fail);
		}
		if (tagDialogUpgradeFail == null) {

			if (msg == null) {
				dialogUpgradeFail = DialogUpgradeFail.newInstance();
			} else {
				dialogUpgradeFail = DialogUpgradeFail.newInstance(msg);
			}
		} else {
			dialogUpgradeFail = tagDialogUpgradeFail;
			dialogUpgradeFail.setShowContent(msg);
		}

		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		try {
			transaction.add(dialogUpgradeFail, "DialogUpgradeFail");
			transaction.commitAllowingStateLoss();

		} catch (Exception e) {
			e.printStackTrace();
		}

		transaction.show(dialogUpgradeFail);

		final String finalMsg = msg;
		dialogUpgradeFail.setOnConfirmListener(new DialogUpgradeFail.OnConfirmListener() {
			@Override
			public void onConfirm() {
				isReportFail=false;
				startInstallFirmware(mFirmWareInfo.getName());
			}

			@Override
			public void onCancel() {
				setResult(RESULT_OK);
				LZDeviceService.getInstance().interruptUpgradeDeviceFirmware(mDevice.getId());
				finish();
			}
		});

	}

	private void showSuccessView() {
		if (content_layout != null) {
			content_layout.setVisibility(View.GONE);
		}

		if (successView == null) {
			successView = mAuSuccessStub.inflate();
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			//
			if (successView != null) {
				ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) successView.getLayoutParams();
				successView.setPadding(0, UIUtil.getStatusBarHeight(mContext), 0, 0);
				successView.setLayoutParams(layoutParams);
			}
		}
		successView.setVisibility(View.VISIBLE);
		View upgrade_success_layout = successView.findViewById(R.id.upgrade_success_layout);
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.upgrade_success_anim);
		upgrade_success_layout.startAnimation(animation);
		View finishBtn = successView.findViewById(R.id.vus_finish_btn);
		finishBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				setResult(RESULT_OK);
				finish();
			}
		});
	}


	public void onCancelClick(View view) {

		ShowHintDialog dialog = ShowHintDialog.newInstance(getString(R.string.hint_quit_update_device));
		dialog.setOnConfirmListener(new ShowHintDialog.OnConfirmListener() {
			@Override
			public void onConfirm() {
				LZDeviceService.getInstance().interruptUpgradeDeviceFirmware(mDevice.getId());
				finish();
			}
		});
		dialog.show(getSupportFragmentManager(), "");

	}

	@Override
	public void onBackPressed() {
		ShowHintDialog dialog = ShowHintDialog.newInstance(getString(R.string.hint_quit_update_device));
		dialog.setOnConfirmListener(new ShowHintDialog.OnConfirmListener() {
			@Override
			public void onConfirm() {
				LZDeviceService.getInstance().interruptUpgradeDeviceFirmware(mDevice.getId());
				finish();
			}
		});
		dialog.show(getSupportFragmentManager(), "");
	}
}
