package com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseRvAdapter;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.bean.Cell;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Create by qwerty
 * Create on 2020/6/8
 **/
public class CellGroupRvAdapter extends BaseRvAdapter<Cell> {
    private OnSwitchChangedListener onSwitchChangedListener;

    @Override
    protected RecyclerView.ViewHolder createHolderView(ViewGroup parent, int viewType) {
        return new CellViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cell, parent, false));
    }

    @Override
    protected void bindHolderView(final RecyclerView.ViewHolder holder, Cell cell, int position) {
        if (holder instanceof CellViewHolder) {
            CellViewHolder cellViewHolder = (CellViewHolder) holder;
            cellViewHolder.setTitle(cell.getTitle());
            cellViewHolder.setOnCheckChangedListener(null);
            cellViewHolder.setSwitch(cell.isOpenSwitch());
            cellViewHolder.setValue(cell.getValue());
            cellViewHolder.showArrow(cell.isShowArrow());
            cellViewHolder.showSwitch(cell.isShowSwitch());
            cellViewHolder.showValue(cell.isShowValue());
            cellViewHolder.setTagText(cell.getTag());
            cellViewHolder.showTagText(cell.isShowTag());
            cellViewHolder.setOnCheckChangedListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (onSwitchChangedListener != null) {
                        onSwitchChangedListener.onSwitchChanged(buttonView, isChecked, holder.getLayoutPosition());
                    }
                }
            });
        }
    }

    public void setOnSwitchChangedListener(OnSwitchChangedListener onSwitchChangedListener) {
        this.onSwitchChangedListener = onSwitchChangedListener;
    }

    public static class CellViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivCellArrow;

        private TextView tvCellTitle;

        private TextView tvCellValue;

        private SwitchCompat svCellSwitch;

        private TextView tvCellTag;

        public CellViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCellArrow = itemView.findViewById(R.id.iv_cell_arrow);
            tvCellTitle = itemView.findViewById(R.id.tv_cell_title);
            tvCellValue = itemView.findViewById(R.id.tv_cell_value);
            svCellSwitch = itemView.findViewById(R.id.sc_cell_switch);
            tvCellTag = itemView.findViewById(R.id.tv_cell_tag);
        }


        public void showArrow(boolean show) {
            ivCellArrow.setVisibility(show ? VISIBLE : GONE);
        }

        public void setTitle(String title) {
            tvCellTitle.setText(title);
        }

        public void setValue(String value) {
            tvCellValue.setText(value);
        }

        public void showValue(boolean show) {
            tvCellValue.setVisibility(show ? VISIBLE : GONE);
        }

        public void setSwitch(boolean open) {
            svCellSwitch.setChecked(open);
        }

        public void showSwitch(boolean show) {
            svCellSwitch.setVisibility(show ? VISIBLE : GONE);
        }

        public void setOnCheckChangedListener(CompoundButton.OnCheckedChangeListener onCheckChangedListener) {
            svCellSwitch.setOnCheckedChangeListener(onCheckChangedListener);
        }

        public void showTagText(boolean show) {
            tvCellTag.setVisibility(show ? VISIBLE : GONE);
        }

        public void setTagText(String tag) {
            tvCellTag.setText(tag);
        }
    }

    public interface OnSwitchChangedListener {
        void onSwitchChanged(CompoundButton buttonView, boolean checked, int position);
    }
}
