//package com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity;
//
//import android.Manifest;
//import android.app.Activity;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.net.Uri;
//import android.os.Bundle;
//import android.text.TextUtils;
//import android.util.Log;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.lifesense.ble.LsBleManager;
//import com.lifesense.ble.bean.constant.DeviceConnectState;
//import com.lifesense.component.devicemanager.application.interfaces.callback.OnResultCallback;
//import com.lifesense.component.devicemanager.application.service.LZDeviceService;
//import com.lifesense.component.devicemanager.constant.SaleType;
//import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
//import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
//import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
//import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
//import com.lifesense.jumpaction.utils.IntentUtils;
//import com.lifesense.logger.Logger;
//import com.lifesense.utils.PreferencesUtils;
//import com.lifesense.weidong.lswebview.activity.WebViewActivity;
//import com.lifesense.weidong.lswebview.util.ImageUtil;
//import com.lifesense.weidong.lswebview.util.ToastUtil;
//import com.lifesense.weidong.lzbinddivicelibs.R;
//import com.lifesense.weidong.lzbinddivicelibs.deviceota.ui.activity.StartUpdateActivity;
//import com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter.DeviceMelodyAdapter;
//import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
//import com.lifesense.weidong.lzbinddivicelibs.deviceconfig.ui.DeviceStatusListActivity;
//import com.lifesense.weidong.lzbinddivicelibs.logic.device.manage.SyncDeviceObserver;
//import com.lifesense.weidong.lzbinddivicelibs.util.DeviceConstants;
//import com.lifesense.weidong.lzbinddivicelibs.util.DeviceUtils;
//import com.lifesense.weidong.lzbinddivicelibs.util.DialogUtil;
//import com.lifesense.weidong.lzbinddivicelibs.util.PermissionUtils;
//import com.lifesense.weidong.lzbinddivicelibs.util.PickUtils;
//import com.lifesense.weidong.lzbinddivicelibs.util.StringUtils;
//import com.lifesense.weidong.lzbinddivicelibs.util.UIUtil;
//import com.lifesense.weidong.lzbinddivicelibs.widget.DeviceListView;
//import com.lifesense.weidong.lzbinddivicelibs.widget.dialog.ShowHintDialog;
//import java.util.ArrayList;
//import java.util.List;
///**
// * 体重称详情
// * Created by luoxf on 2016/1/19.
// */
//public class DeviceMelodyActivity extends OlderBaseActivity implements View.OnClickListener, SyncDeviceObserver {
//    public static final int MELODY_USER = 1;
//    public static final int MELODY_WIFI = 2;
//    private ImageView firstRight;
//    private ImageView deviceIV;
//    private TextView deviceName;
//    private TextView deviceVersion;
//    private DeviceListView deviceObviousListView;
//    private DeviceMelodyAdapter deviceMelodyAdapter;
//    private List<DeviceMelodyAdapter.MelodyObvious> melodyObviousData;
//    private DeviceMelodyAdapter.MelodyObvious user, wifi, unit;
//    private TextView tvTitle;
//    private TextView deviceWork;
//    private String deviceId; //设备ID
//    private Device device; //设备
//    private List<DeviceUser> deviceUsers; //绑定列表
//    private SaleType saleType; //产品型号
//    private static final int GO_TO_SET_WIFI = 1000;
//    private TextView deviceSn;
//    //private boolean mIsNeedSetWifi;
//    private TextView tvDeviceID;
//    private RelativeLayout deviceQrcodeLayout;
//    private View debugA6;
//    private TextView deviceConnect;
//    private View deviceUpgrade;
//    private TextView deviceUpgradeNew;
//    private TextView adm_deviceVersion_tv;
//    private View ivUpdateNext;
//    private String userId;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setCenterView(R.layout.activity_device_melody);
////        LogicServicess.shareInstance().getDeviceManager().syncDeviceinfo();
//        userId = PreferencesUtils.getString(this, "userId", "0");
//        initView();
//        initData();
////        LogicServicess.shareInstance().getDeviceManager().registerSyncObserver(this);
//    }
//
//    private void initUpgrade() {
//
//        deviceUpgrade.setVisibility(View.VISIBLE);
//    }
//
//    private void refreshUpdateLayout(FirmwareInfo firmwareInfo) {
//        boolean canUpdate = false;
//        if (firmwareInfo != null && device != null && deviceUpgradeNew != null) {//&& firmwareInfo.getId().equalsIgnoreCase(mDevice.getId()) 该 ID 压根不是和deviceid
//            int result = firmwareInfo.getSoftwareVersion().compareToIgnoreCase(device.getSoftwareVersion());
//            //有更新的版本
//            canUpdate = result > 0;
//        }
//        if (canUpdate) {
//            deviceUpgradeNew.setVisibility(View.VISIBLE);
//            adm_deviceVersion_tv.setVisibility(View.GONE);
//            ivUpdateNext.setVisibility(View.VISIBLE);
//        } else {
//            if (deviceUpgradeNew != null) {
//                deviceUpgradeNew.setVisibility(View.INVISIBLE);
//                adm_deviceVersion_tv.setVisibility(View.VISIBLE);
//                ivUpdateNext.setVisibility(View.INVISIBLE);
//            }
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        if (mReceiver != null) {
//            unregisterReceiver(mReceiver);
//        }
////        LogicServicess.shareInstance().getDeviceManager().unregisterSyncObserver(this);
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        device = RepositoryRegistry.deviceRepository().get(deviceId);
//        String versionInfo = getString(R.string.device_hardware) + device.getHardwareVersion() + " " + getString(R.string.device_software)
//                + device.getSoftwareVersion();
//        deviceVersion.setText(versionInfo);
//        updateDeviceStatus();
//    }
//
//    private void initView() {
//        deviceUpgrade = findViewById(R.id.deviceUpgrade);
//        deviceUpgrade.setOnClickListener(this);
//        deviceUpgradeNew = findViewById(R.id.deviceUpgradeNew);
//        adm_deviceVersion_tv = findViewById(R.id.adm_deviceVersion_tv);
//        ivUpdateNext = findViewById(R.id.iv_update_next);
//        deviceConnect = findViewById(R.id.deviceConnect);
//        findViewById(R.id.layout_second).setVisibility(View.GONE);
//        findViewById(R.id.layout_left).setOnClickListener(this);
//        findViewById(R.id.layout_first).setOnClickListener(this);
//        findViewById(R.id.deviceDelete).setOnClickListener(this);
//        debugA6 = findViewById(R.id.debugA6);
//        deviceQrcodeLayout = findViewById(R.id.deviceQrcodeLayout);
//        deviceQrcodeLayout.setOnClickListener(this);
//        deviceIV = findViewById(R.id.deviceIV);
//        deviceName = findViewById(R.id.deviceName);
//        firstRight = findViewById(R.id.first_right);
//        firstRight.setImageResource(R.mipmap.device_add);
//        findViewById(R.id.deviceWork).setOnClickListener(this);
//        findViewById(R.id.deviceQrcode).setOnClickListener(this);
//        deviceObviousListView = findViewById(R.id.deviceObviousListView);
//        deviceVersion = findViewById(R.id.deviceVersion);
//        deviceSn = findViewById(R.id.adm_deviceSn_tv);
//
//
//        tvTitle = findViewById(R.id.tv_title);
//        deviceWork = findViewById(R.id.deviceWork);
//    }
//
//    private void initData() {
//        deviceId = IntentUtils.getStringData(DeviceConstants.DEVICE_ID, getIntent(), "");
//        device = RepositoryRegistry.deviceRepository().get(deviceId);
//        if (device == null) {
//            return;
//        }
//        initA6();
//        initUpgrade();
//        deviceSn.setText(DeviceUtils.getFormateDeviceSn(device.getSn()));
//        //修改标题
//        String getName = device.getName();
//        if (getName != null) {
//            tvTitle.setText(getName);
//            deviceWork.setText(getName + " " + getString(R.string.device_work));
//            deviceName.setText(getName);
//            setHeader_Title(getName);
//        }
//        deviceUsers = RepositoryRegistry.deviceUserRepository().queryByDeviceId(deviceId);
//
//        deviceMelodyAdapter = new DeviceMelodyAdapter(getSupportFragmentManager(), this);
//        deviceMelodyAdapter.setDevice(device);
//        melodyObviousData = new ArrayList<>();
//        String picUrl = StringUtils.getPicStringUrl(getDefaultImgUrl(device.getImgUrl()), UIUtil.dip2px(this, 40), UIUtil.dip2px(this, 40));
//        ImageUtil.disableImage(picUrl, deviceIV, DeviceUtils.getDeviceIcon(device));
//
//        user = new DeviceMelodyAdapter.MelodyObvious(DeviceMelodyAdapter.MelodyObvious.DEVICE_USER);
//        setDeviceUser();
//        melodyObviousData.add(user);
//        Log.i(TAG, "initData: " + device);
//        saleType = device.getSaleType();
//        Log.i(TAG, "initData: " + saleType);
//        if (canSetUnit(device.getModel())) {
//            unit = new DeviceMelodyAdapter.MelodyObvious(DeviceMelodyAdapter.MelodyObvious.DEVICE_UNIT);
//            unit.setUnit(LZDeviceService.getInstance().getUnit(deviceId));
//            melodyObviousData.add(unit);
//        }
//        deviceMelodyAdapter.setDatas(melodyObviousData);
//        deviceObviousListView.setAdapter(deviceMelodyAdapter);
//        deviceObviousListView.setEnabled(false);
//        deviceMelodyAdapter.notifyDataSetChanged();
//        UIUtil.setListViewHeightBasedOnChildren(deviceObviousListView);
//
//        if (saleType == SaleType.InterConnection) {
//            if (!TextUtils.isEmpty(device.getName())) {
//                deviceName.setText(device.getName());
//            } else {
//                deviceName.setText(R.string.lifesence_device);
//            }
//            findViewById(R.id.viewDividerUser).setVisibility(View.VISIBLE);
//            findViewById(R.id.llWarpper).setVisibility(View.VISIBLE);
//            findViewById(R.id.deviceQrcodeLayout).setVisibility(View.GONE);
//
//            findViewById(R.id.llConnectDeviceInfoItems).setVisibility(View.VISIBLE);
//            tvDeviceID = findViewById(R.id.tvDeviceID);
//            tvDeviceID.setText(DeviceUtils.getFormateDeviceSn(device.getSn()));
//            findViewById(R.id.rlMerchant).setOnClickListener(this);
//            findViewById(R.id.rlMerchant).setVisibility(View.GONE);
//        } else if (device.getSaleType() == SaleType.S5Mini || device.getSaleType() == SaleType.S9Fit || device.getSaleType() == SaleType.S12Fit) {
//            deviceQrcodeLayout.setVisibility(View.GONE);
//            findViewById(R.id.llConnectDeviceInfoItems).setVisibility(View.VISIBLE);
//            findViewById(R.id.rlMerchant).setVisibility(View.GONE);
//            tvDeviceID = findViewById(R.id.tvDeviceID);
//            tvDeviceID.setText(DeviceUtils.getFormateDeviceSn(device.getSn()));
//        } else {
//            findViewById(R.id.llConnectDeviceInfoItems).setVisibility(View.GONE);
//            findViewById(R.id.llWarpper).setVisibility(View.VISIBLE);
//
//        }
//        debugA6.setVisibility(View.GONE);
//
//    }
//
//    public static boolean canSetUnit(String model) {
////        ls 110 ls210f ls210f1
//        return !TextUtils.isEmpty(model) && (model.equals("LS110-F") || model.contains("LS210") || model.contains("LS213-B"));
//    }
//
//
//    /**
//     * 获取无阴影的设备图片
//     */
//    public String getDefaultImgUrl(String imgUrl) {
//        String shadowImgUrl = imgUrl;
//        if (shadowImgUrl != null && shadowImgUrl.lastIndexOf(",") != -1) {
//            shadowImgUrl = shadowImgUrl.substring(0, shadowImgUrl.lastIndexOf(","));
//        }
//        return shadowImgUrl;
//    }
//
//    private void initA6() {
//        //不做连接状态
//        boolean isA6 = isA6WeightScale(device);
//
//
//        if (isA6) {
//            updateDeviceStatus();
//            registerReceivers();
//        }
//    }
//
//    public boolean isA6WeightScale(Device device) {
//        if (device != null) {
//            if (device.getCommunicationType() == Device.COMM_BLE && device.isWeight()) {
//                return device.getSaleType() == SaleType.S5Mini ||
//                        device.getSaleType() == SaleType.InterConnection
//                        || device.getSaleType() == SaleType.S9Fit
//                        || device.getSaleType() == SaleType.S12Fit;
//            }
//        }
//        return false;
//    }
//
//    BroadcastReceiver mReceiver;
//
//    /**
//     * 注册广播监听
//     */
//    private void registerReceivers() {
//        IntentFilter filter = new IntentFilter();
//        filter.addAction(DeviceConstants.DEVICE_CONNECT_STATE_CHANGE);
//        mReceiver = new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                String action = intent.getAction();
//                if (TextUtils.isEmpty(action)) {
//                    return;
//                }
//                updateDeviceStatus();
//            }
//
//        };
//        registerReceiver(mReceiver, filter);
//    }
//
//    private void updateDeviceStatus() {
//
//        DeviceConnectState deviceConnectState = LsBleManager.getInstance().checkDeviceConnectState(device.getMac());
//        initUpgrade();
//        if (deviceConnectState == DeviceConnectState.CONNECTED_SUCCESS) {
//            deviceConnect.setText(getString(R.string.device_connect_success));
//        } else {
//            if (!LsBleManager.getInstance().isOpenBluetooth()) {
//                deviceConnect.setText(getString(R.string.device_connect_fail));
//            } else {
//                deviceConnect.setText(getString(R.string.hint_connect_state_try_connecting));
//            }
//        }
//    }
//
//    /**
//     * 设置用户列表
//     */
//    private void setDeviceUser() {
//        if (null == deviceUsers || deviceUsers.size() == 0) {
//            user.setObviousStr(String.format(getString(R.string.device_user_num), 0));
//        } else {
//            user.setObviousStr(String.format(getString(R.string.device_user_num), deviceUsers.size()));
//        }
//    }
//
//    @Override
//    protected void initHeader() {
//
//    }
//
//    private void netUnbindDevice() {
//        LZDeviceService.getInstance().unBindDevice(deviceId, new OnResultCallback() {
//            @Override
//            public void onSuccess() {
//                DialogUtil.getInstance().dismissProcessDialog();
//                ToastUtil.showShortToast(DeviceMelodyActivity.this, getString(R.string.device_unbind_success));
//                finish();
//            }
//
//            @Override
//            public void onFailed(int errorCode, String msg) {
//                DialogUtil.getInstance().dismissProcessDialog();
//                ToastUtil.showShortToast(DeviceMelodyActivity.this, msg);
//                finish();
//            }
//        });
//    }
//
//    private Runnable unBindRunnable = new Runnable() {
//        @Override
//        public void run() {
//            netUnbindDevice();
//        }
//    };
//
//    private void unBindDevice() {
//        DialogUtil.getInstance().showProcessDialog(DeviceMelodyActivity.this, getString(R.string.device_unbinging), true);
//        netUnbindDevice();
//    }
//
//    @Override
//    public void onClick(View v) {
//        int i = v.getId();//固件升级
//        if (i == R.id.deviceUpgrade) {
//            onCheckUpdate();
//            //设备升级入口点击埋点上报
//            //                DeviceTest.upgradeDeviceTest(deviceId);
//        } else if (i == R.id.layout_left) {
//            finish();
//        } else if (i == R.id.layout_first) {
////            startActivity(new Intent(this, DeviceScanActivity.class));
//        } else if (i == R.id.deviceDelete) {//“删除设备”按钮点击埋点上报
//            if (device == null) {
//                return;
//            }
//            String hintDelete = String.format(getString(R.string.hint_device_delete_format), device.getName());
//            ShowHintDialog hintDialog = ShowHintDialog.newInstance(hintDelete);
//            hintDialog.setOnConfirmListener(new ShowHintDialog.OnConfirmListener() {
//                @Override
//                public void onConfirm() {
//
//                    unBindDevice();
//                }
//            });
//            if (isDestroyed() || isFinishing()) {
//                return;
//            }
//            try {
//                hintDialog.show(getSupportFragmentManager(), "");
//            } catch (Exception e) {
//
//            }
//            //操作指南
//        } else if (i == R.id.deviceWork) {
//            if (device == null) {
//                return;
//            }
//            String title = device.getName() + " " + getString(R.string.device_work);
//            String url = DeviceUtils.getDeviceOperationGuideUrl(device);
//            startActivity(WebViewActivity.makeIntent(mContext, title, url));
//            //操作指南入口点击埋点上报
//            //二维码
//        } else if (i == R.id.deviceQrcodeLayout) {
////            Intent intent = new Intent(this, DeviceQrcodeActivity.class);
//            intent.putExtra(DeviceConstants.DEVICE_ID, deviceId);
//            intent.putExtra("DEVICE_TYPE", "BALANCE");
//
//            startActivity(intent);
//        } else if (i == R.id.rlMerchant) {
////            Intent intent;
////            if (device == null) {
////                return;
////            }
////            intent = new Intent(DeviceVenderInfoActivity.makeIntent(mContext));
////            intent.putExtra("manufactureId", device.getVenderId());
////            startActivity(intent);
//        }
//    }
//
//    private FirmwareInfo currentFirmwareInfo;
//
//    private void onCheckUpdate() {
//        //是否有读写
//        if (!PermissionUtils.checkPermission(mContext, Manifest.permission.READ_EXTERNAL_STORAGE)) {
//            Logger.json(DeviceStatusListActivity.TAG, "缺少读写权限");
//            PermissionUtils.requestPermission(mContext, Manifest.permission.READ_EXTERNAL_STORAGE, 10001);
//            return;
//        }
//        onBtnUiStyle();
//    }
//
//
//    public void onBtnUiStyle() {
////		startActivity(new Intent(DebugActivity.this, UICommonActivity.class));
//        ToastUtil.showCenterToast("请要升级的选择固件文件");
//        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//        intent.setType("*/*");//无类型限制
//        intent.addCategory(Intent.CATEGORY_OPENABLE);
//        startActivityForResult(intent, 2);
//
//    }
//
//    long lastToastTime;
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        switch (requestCode) {
//            case MELODY_USER:
//                deviceUsers = RepositoryRegistry.deviceUserRepository().queryByDeviceId(deviceId);
//                setDeviceUser();
//                break;
//            case 2:
//                if(resultCode == Activity.RESULT_OK) {
//                    Uri uri = data.getData();
//                    String path = null;
//                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
//                        path = PickUtils.getPath(this, uri);
//                    }
//                    ToastUtil.showCenterToast("选择的文件是:" + path);
//                    if (device == null) {
//                        ToastUtil.showCenterToast("未绑定设备");
//                        return;
//                    }
//                    FirmwareInfo info = new FirmwareInfo();
//                    info.setName(path);
//                    startActivity(StartUpdateActivity.makeIntent(this, device, info));
//                }
//                break;
//
//        }
//        deviceMelodyAdapter.notifyDataSetChanged();
//    }
//
//
//    @Override
//    public void syncDeviceSucceed() {
//        List<Device> dataList = RepositoryRegistry.deviceRepository().queryByUser(Long.parseLong(userId));
//        boolean isHave = false;
//        if (null != dataList && dataList.size() > 0) {
//            for (Device device : dataList) {
//                if (device.getId().equals(deviceId)) {
//                    isHave = true;
//                    break;
//                }
//            }
//        }
//        if (!isHave) {
//            finish();
//        }
//    }
//
//
//
//
//
//}
