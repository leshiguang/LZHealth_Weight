package com.lifesense.weidong.lzbinddivicelibs.util;

import com.lifesense.foundation.ApplicationHolder;

/**
 * Created by luoxf on 2016/1/27.
 */
public class DeviceConstants {
    public static final String DEVICE = "DEVICE";
    public static final String DEVICE_ID = "deviceId";
    public static final String DEVICE_TYPE = "deviceType";
    public static final String DEVICE_ALARM_LIST = "DEVICE_ALARM_LIST";
    public static final String DEVICE_ALARM_SELECTION = "DEVICE_ALARM_SELECTION";
    public static final String DEVICE_CONNECT_STATE_CHANGE = "DEVICE_CONNECT_STATE_CHANGE"+ ApplicationHolder.getApplicationId();
    public static final String DEVICE_MAC = "DEVICE_MAC";
    public static final String DEVICE_CONNECT_STATE = "DEVICE_CONNECT_STATE";
    public static final String DEVICE_FIRST_SET_WIFI = "DEVICE_BIND";
}
