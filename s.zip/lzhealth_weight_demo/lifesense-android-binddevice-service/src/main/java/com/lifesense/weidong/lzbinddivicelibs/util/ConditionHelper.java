//package com.lifesense.weidong.lzbinddivicelibs.util;
//
//import com.lifesense.ble.bean.constant.DeviceConnectState;
//import com.lifesense.component.devicemanager.manager.DeviceManager;
//import com.lifesense.weidong.lzbinddivicelibs.R;
//
///**
// * Created by Sanjay on 2016/5/14.
// */
//public class ConditionHelper {
//
//
//    public static ConditionState checkEvir(String deviceId) {
//
//
//        ConditionState conditionState = new ConditionState();
//
//
//        DeviceConnectState deviceConnectState = DeviceManager.getInstance().checkDeviceConnectState(deviceId);
//
//        if (!DeviceManager.getInstance().isBleEnable()) {
//            conditionState.setState(ConditionState.STATE_BLE_OFF);
//        } else if (!NetUtil.isNetworkAvailable()) {
//            conditionState.setState(ConditionState.STATE_NET_OFF);
//        } else if (deviceConnectState != DeviceConnectState.CONNECTED_SUCCESS) {
//            conditionState.setState(ConditionState.STATE_DEVICE_CONNECT_OFF);
//        }
//        return conditionState;
//    }
//
//    public static class ConditionState {
//
//
//        public  static final int STATE_NET_OFF = 0;
//        public  static final int STATE_BLE_OFF = 1;
//        public  static final int STATE_DEVICE_CONNECT_OFF = 2;
//        public  static final int STATE_SUCCESS = 3;
//
//        private int state = STATE_SUCCESS;
//
//        public int getState() {
//            return state;
//        }
//
//        public void setState(int state) {
//            this.state = state;
//        }
//
//
//        public int getReasonString(){
//
//            switch (state){
//                case STATE_NET_OFF:
//                    return R.string.hint_net_off;
//                case STATE_DEVICE_CONNECT_OFF:
//                    return R.string.hint_ble_connect_off;
//            }
//            return -1;
//        }
//    }
//}
