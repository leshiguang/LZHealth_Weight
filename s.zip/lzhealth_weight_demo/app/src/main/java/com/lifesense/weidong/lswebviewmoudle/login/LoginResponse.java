package com.lifesense.weidong.lswebviewmoudle.login;

import android.text.TextUtils;

import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

public class LoginResponse extends JsonResponse {
    private LoginEntity loginEntity = null;
    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
        if (jsonData == null) {
            return;
        }
        if (!TextUtils.isEmpty(jsonData.optString("userId"))) {
            loginEntity = new LoginEntity();
            loginEntity.setAccessToken(jsonData.optString("accessToken"));
            loginEntity.setUserId(jsonData.optString("userId"));
            loginEntity.setNeedInfo(jsonData.optBoolean("needInfo"));
        }
    }

    public LoginEntity getLoginEntity() {
        return loginEntity;
    }
}
