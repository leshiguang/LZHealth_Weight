package com.lifesense.weidong.lswebviewmoudle.login;

import com.lifesense.weidong.lswebviewmoudle.http.BaseBean;

import java.io.Serializable;

public class LoginEntity extends BaseBean {
    private String userId;
    private String accessToken;
    private boolean needInfo;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public boolean isNeedInfo() {
        return needInfo;
    }

    public void setNeedInfo(boolean needInfo) {
        this.needInfo = needInfo;
    }

    @Override
    public String toString() {
        return "LoginEntity{" +
                "userId='" + userId + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", needInfo=" + needInfo +
                '}';
    }
}
