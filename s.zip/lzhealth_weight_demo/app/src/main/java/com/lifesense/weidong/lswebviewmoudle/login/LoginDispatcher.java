package com.lifesense.weidong.lswebviewmoudle.login;

import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;


public class LoginDispatcher {
    private static LoginDispatcher dispatcher;
    private LoginDispatcher(){}
    public static LoginDispatcher getInstance() {
        if (dispatcher == null) {
            synchronized (LoginDispatcher.class) {
                if (dispatcher == null) {
                    dispatcher = new LoginDispatcher();
                }
            }
        }
        return dispatcher;
    }

    public void login(int tenantId, int subscriptionId, String associatedId,  IRequestCallBack<LoginResponse> callBack) {
        LoginRequest request = new LoginRequest();
        request.addIntValue("tenantId",tenantId);
        request.addIntValue("subscriptionId",subscriptionId);
        request.addStringValue("associatedId",associatedId);
        request.execute(callBack);
    }
}
