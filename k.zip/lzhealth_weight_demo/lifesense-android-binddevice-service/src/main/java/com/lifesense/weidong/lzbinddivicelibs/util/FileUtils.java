package com.lifesense.weidong.lzbinddivicelibs.util;

import android.content.Context;

import com.lifesense.commonlogic.util.FileUtilCommon;
import com.lifesense.foundation.ApplicationHolder;

import java.io.File;

import static com.lifesense.commonlogic.util.FileUtilCommon.getLogPath;

public class FileUtils {

    public static String getFilePath(Context context, String fileName) {
        return getFilePath(context) + fileName;
    }
    public static String getFilePath(Context context) {
        String filePath = null;
        try {
            filePath = context.getExternalFilesDir(null).toString();
        } catch (Exception e) {
            File file = context.getFilesDir();
            if(file != null) {
                filePath = file.toString();
            }
        }
        return filePath;
    }

    public static String getFirmWarePath(String fileName) {
        String path = "/data/data/"
                + ApplicationHolder.getmApplication().getPackageName()
                + "/files/" + fileName;
        return path;
    }

    public static String getBleLogFilePath() {
        String path = getLogPath() + "/BleLog";
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }
        return path;
    }
}
