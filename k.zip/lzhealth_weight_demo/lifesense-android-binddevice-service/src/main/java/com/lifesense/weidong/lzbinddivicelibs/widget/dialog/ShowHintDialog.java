package com.lifesense.weidong.lzbinddivicelibs.widget.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;

/**
 * Created by Administrator on 2014/11/29.
 */
final public class ShowHintDialog extends DialogFragment implements View.OnClickListener {
    private String TAG = this.getClass().getSimpleName();
    private static final String EXTRA_TYPE = "extra_type";
    private static final String LEFT_TEXT = "LEFT_TEXT";
    private static final String RIGHT_TEXT = "RIGHT_TEXT";
    private String nContent;
    private String nleftStr, nRightStr;
    private OnConfirmListener mConfirmListener;
    private OnCancelListener mCancelListener;


    private TextView mSrfTitleTv;
    private TextView mSrfCancelTv;
    private TextView mSrfConfirmTv;




    public static ShowHintDialog newInstance(String hintContent) {
        ShowHintDialog recordReportDialog = new ShowHintDialog();
        Bundle args = new Bundle();
        args.putString(EXTRA_TYPE, hintContent);
        recordReportDialog.setArguments(args);
        return recordReportDialog;
    }

    public static ShowHintDialog newInstance(String hintContent, String leftStr, String rightStr) {
        ShowHintDialog recordReportDialog = new ShowHintDialog();
        Bundle args = new Bundle();
        args.putString(EXTRA_TYPE, hintContent);
        args.putString(LEFT_TEXT, leftStr);
        args.putString(RIGHT_TEXT, rightStr);
        recordReportDialog.setArguments(args);
        return recordReportDialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        nContent = getArguments().getString(EXTRA_TYPE);
        nleftStr = getArguments().getString(LEFT_TEXT);
        nRightStr= getArguments().getString(RIGHT_TEXT);

    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return createDialog();
    }

    private Dialog createDialog() {
        Dialog dialog = new Dialog(getActivity(), R.style.MyDialogStyleWithWhite);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_hint_frag, null);
        dialog.getWindow().getAttributes().windowAnimations = R.style.dialogWindowAnim;
        initial(view);
        dialog.setContentView(view);
        return dialog;
    }

    private void initial(View view) {
        mSrfTitleTv = view.findViewById(R.id.dhf_content_tv);
        mSrfTitleTv.setText(nContent);
        mSrfCancelTv = view.findViewById(R.id.dhf_cancel_tv);
        if(!TextUtils.isEmpty(nleftStr)){
            mSrfCancelTv.setText(nleftStr);
        }
        mSrfCancelTv.setOnClickListener(this);
        mSrfConfirmTv = view.findViewById(R.id.dhf_confirm_tv);
        if(!TextUtils.isEmpty(nRightStr)){
            mSrfConfirmTv.setText(nRightStr);
        }
        mSrfConfirmTv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.dhf_cancel_tv) {
            dismiss();
            if (mCancelListener != null) {
                mCancelListener.onCancel();
            }
        } else if (v.getId() == R.id.dhf_confirm_tv) {
            if (mConfirmListener != null) {
                mConfirmListener.onConfirm();
            }
            this.dismiss();
        }
    }

    public void setOnConfirmListener(OnConfirmListener onListener) {
        this.mConfirmListener = onListener;
    }

    public void setOnCancelListener(OnCancelListener mCancelListener) {
        this.mCancelListener = mCancelListener;
    }

    public interface OnConfirmListener {
        void onConfirm();
    }

    public interface OnCancelListener {
        void onCancel();
    }


}
