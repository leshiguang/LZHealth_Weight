package com.lifesense.weidong.lzbinddivicelibs.logic.device.manage;

/**
 * Created by Sinyi.liu on 16/2/29.
 * Copyright by gz.lifesense.com
 */
public interface SyncDeviceObserver {
    void syncDeviceSucceed();
}
