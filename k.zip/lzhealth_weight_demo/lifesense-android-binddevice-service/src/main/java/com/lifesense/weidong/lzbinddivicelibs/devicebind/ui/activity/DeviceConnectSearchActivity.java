package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.constant.PairedResultsCode;

import com.lifesense.component.devicemanager.application.interfaces.callback.BindResultCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnResultCallback;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
import com.lifesense.utils.PreferencesUtils;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;
import com.lifesense.weidong.lzbinddivicelibs.common.UiDeviceBindType;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.BaseFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceBluetoothDisableFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceFailFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceMultiFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DevicePairingFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceSearchFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceSingleFragment;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment.DeviceSuccessFragment;
import com.lifesense.weidong.lzbinddivicelibs.util.DialogUtil;
import com.lifesense.weidong.lzbinddivicelibs.util.SystemUtil;
import com.lifesense.weidong.lzbinddivicelibs.util.dialog.DialogConfig;

import java.util.List;

public class DeviceConnectSearchActivity extends OlderBaseActivity {
    private static final String KEY_DISPLAY_PRODUCT = "KEY_DISPLAY_PRODUCT";

    private Context mContext;
    private LSEDeviceInfoApp mCurDeviceInfoApp;
    private boolean isEnableBlueTooth;
    private BroadcastReceiver mReceiver;
    private DisplayProduct displayProduct;
    private BaseFragment currentFragment;
    private String userId;

    public DeviceConnectSearchActivity() {
    }

    @Override
    protected void initHeader() {
        setHelpBtnVisibility(false);
    }

    public static Intent makeIntentWithDisplayProduct(Context context, DisplayProduct displayProduct) {
        Intent intent = new Intent(context, DeviceConnectSearchActivity.class);
        intent.putExtra(KEY_DISPLAY_PRODUCT, displayProduct);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCenterView(R.layout.activity_device_connect_search);
        displayProduct = getIntent().getParcelableExtra(KEY_DISPLAY_PRODUCT);
        mContext = this;
        userId = PreferencesUtils.getString(this,"userId","0");
        initView();
        initData();
    }



    @Override
    protected void onResume() {
        super.onResume();

        UiDeviceBindType.setCurrentUiDeviceBindType(UiDeviceBindType.search);

        if (!SystemUtil.isProviderEnabledGps(mContext)) {
            showGpsDialog();
            return;
        }

        if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
            showEnableBlueToothDialog();
            return;
        }
    }

    private void initView() {
        setHeader_LeftImage(R.mipmap.icn_close);
    }

    private void initData() {
        registerReceivers();
        startSearchDevice();
    }

    private void registerReceivers() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (TextUtils.isEmpty(action)) {
                    return;
                }

                if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                    int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
                    switch (state) {
                        case BluetoothAdapter.STATE_ON:
                            if (currentFragment != null && currentFragment instanceof DeviceBluetoothDisableFragment) {
                                startSearchDevice();
                            }
                            break;
                        case BluetoothAdapter.STATE_TURNING_ON:
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            break;
                        case BluetoothAdapter.STATE_OFF:
                            isEnableBlueTooth = false;
                            if (currentFragment != null && currentFragment instanceof DeviceSearchFragment) {
                                setBlueToothUnEnable();
                                showEnableBlueToothDialog();
                            }
                            break;
                    }
                }
            }
        };
        try {
            registerReceiver(mReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startSearchDevice() {
        isEnableBlueTooth = LsBleManager.getInstance().isOpenBluetooth();
        if (!isEnableBlueTooth) {
            setBlueToothUnEnable();
            return;
        }

        currentFragment = DeviceSearchFragment.newInstance(displayProduct);
        replace(currentFragment);
    }

    private void setBlueToothUnEnable() {
        currentFragment = new DeviceBluetoothDisableFragment();
        replace(currentFragment);
    }

    private void showEnableBlueToothDialog() {
        String content = getStringById(R.string.device_open_bluetooth_to_lifesense);
        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogUtil.getInstance().dismissProcessDialog();
                 BluetoothAdapter.getDefaultAdapter().enable();
            }
        };
        DialogUtil.getInstance().showTitleTwoBtnDialog(new DialogConfig.Builder(this)
                .setContent(content)
                .setConfirmBtn(getString(R.string.device_heart_maintain_mode))
                .setCancelBtn(getString(R.string.common_cancel))
                .setConfirmClickListener(onClickListener)
                .build());
    }

    private void showGpsDialog() {
        DialogUtil.getInstance().showTitleTwoBtnDialog(new DialogConfig.Builder(mContext)
                .setTitle(getStringById(R.string.permissions_location_title))
                .setContent(getStringById(R.string.permissions_location_open))
                .setCancelBtn(getStringById(R.string.common_cancel))
                .setConfirmBtn(getStringById(R.string.permissions_setting))
                .setConfirmClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DialogUtil.getInstance().dismissDialog();
                        SystemUtil.openLocationOpenActivity(mContext);
                    }
                }).build());
    }

    private void setHelpBtnVisibility(boolean visibility) {
        if (visibility) {
            setHeader_RightTextColor(getResources().getColor(R.color.normal_text_color));
            setHeader_RightText(R.string.device_help);
            setHeader_RightClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        } else {
            setHeader_RightTextVisibility(View.GONE);
        }

    }

    private void findSingleDevice(LSEDeviceInfoApp deviceInfoApp) {
        currentFragment = DeviceSingleFragment.newInstance(displayProduct, deviceInfoApp);
        replace(currentFragment);
    }

    private void findMultiDevice(List<LSEDeviceInfoApp> deviceInfoAppList) {
        setHeader_Title(getStringById(R.string.device_find_multi));
        currentFragment = DeviceMultiFragment.newInstance(deviceInfoAppList);
        replace(currentFragment);
    }

    private void nofindDevice() {
        //2019/10/28 产品要求搜索不到设备也是显示绑定失败
        currentFragment = DeviceFailFragment.newInstance(displayProduct.getImageUrl(), mCurDeviceInfoApp);
        replace(currentFragment);
    }

    public void bindDevice(final LSEDeviceInfoApp mCurDeviceInfoApp) {
        if (mCurDeviceInfoApp == null) {
            showBindFail();
            return;
        }
        this.mCurDeviceInfoApp = mCurDeviceInfoApp;
        LZDeviceService.getInstance().stopSearch();
        final LSEDeviceInfo lseDeviceInfo = mCurDeviceInfoApp.getLSEDeviceInfo();
        LZDeviceService.getInstance().bindDeviceBySearchResult(lseDeviceInfo, new BindResultCallback() {
            @Override
            public void onSuccess(Device device, List<DeviceUser> list) {
                setBindSuccess(mCurDeviceInfoApp, device);
            }

            @Override
            public void onFailed(int i, String s) {
                if (i != PairedResultsCode.PAIR_FAILED_RANDOM_CHECK) {
                    //错误码大于200为服务器报错
                    if (i > 200){
                        ToastUtil.showCenterToast(s);
                    }
                    showBindFail();
                }
                if (i == PairedResultsCode.PAIR_FAILED_SYSTEM_FAIL) {
                    unbindDevice(lseDeviceInfo);
                }
            }
        });
        setBinding(mCurDeviceInfoApp);
    }

    private void unbindDevice(LSEDeviceInfo lseDeviceInfo) {

        LZDeviceService.getInstance().unBindDevice(lseDeviceInfo.getDeviceId(), new OnResultCallback() {
            @Override
            public void onSuccess() {
//                LogicServicess.shareInstance().getDeviceManager().notifySyncObserver();
            }

            @Override
            public void onFailed(int i, String s) {

            }
        });

    }

    public void setBinding(LSEDeviceInfoApp mCurDeviceInfoApp) {
        setHeader_Title(getStringById(R.string.device_mid_binding));

        currentFragment = DevicePairingFragment.newInstance(
                displayProduct.getImageUrl(), mCurDeviceInfoApp.getDeviceName());
        replace(currentFragment);
    }

    private void setBindSuccess(LSEDeviceInfoApp mCurDeviceInfoApp, Device device) {
        currentFragment = DeviceSuccessFragment.newInstance(displayProduct.getImageUrl(), mCurDeviceInfoApp, device);
        replace(currentFragment);
    }

    private void showBindFail() {
        currentFragment = DeviceFailFragment.newInstance(displayProduct.getImageUrl(), mCurDeviceInfoApp);
        replace(currentFragment);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mReceiver != null) {
            try {
                unregisterReceiver(mReceiver);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        LZDeviceService.getInstance().stopSearch();
        if (mCurDeviceInfoApp != null && mCurDeviceInfoApp.getLSEDeviceInfo() != null) {
            LZDeviceService.getInstance().interruptBindDevice(mCurDeviceInfoApp.getLSEDeviceInfo());
        }
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }
    }

    /**
     * 取消已经连接的的设备
     */
    public void cancelBind() {
        LZDeviceService.getInstance().stopSearch();
        if (mCurDeviceInfoApp != null && mCurDeviceInfoApp.getLSEDeviceInfo() != null) {
            LZDeviceService.getInstance().interruptBindDevice(mCurDeviceInfoApp.getLSEDeviceInfo());
        }
    }

    private void replace(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fl_content, fragment);
        transaction.commitAllowingStateLoss();
    }

    public void show(List<LSEDeviceInfoApp> deviceInfoAppList) {
        int size = deviceInfoAppList.size();
        switch (size) {
            case 0:
                nofindDevice();
                break;
            case 1:
                findSingleDevice(deviceInfoAppList.get(0));
                break;
            default:
                findMultiDevice(deviceInfoAppList);
                break;
        }
    }
}
