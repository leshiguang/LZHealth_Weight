package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.StringRes;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.lifesense.commonlogic.config.DefaultConfig;
import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.utils.LSLog;
import com.lifesense.weidong.lzbinddivicelibs.util.StatusBarUtils;
import com.lifesense.weidong.lzbinddivicelibs.util.ToastUtil;

/**
 * Created by wrh on 16/1/4.
 */
public abstract class BaseFragment extends Fragment implements OnClickListener {

    public String TAG = this.getClass().getName();
    private boolean isRun = false;
    public Intent intent;
    protected Activity mContext;
    public void Log(String msg) {
        LSLog.e(TAG, msg);// 打e 比较醒目，也好过滤
    }

    protected boolean isHookInit=true;

    /**
     * @param text
     */
    public void debugTips(String text) {
        if (DefaultConfig.isDebug()) {
            ToastUtil.showSingletonToast(getActivity(),text);
        }
    }
    public boolean isSupportChangeStatusBarColor(){
        return StatusBarUtils.isSupportChangeStatusBarColor();
    }

    @NonNull
    public String getStringById(@StringRes int resId) {
        if (ApplicationHolder.getmApplication() == null) {
            return "";
        }
        return getActivity().getString(resId);
    }

    public int getColorById(@ColorRes int resId) {
        return getActivity().getResources().getColor(resId);
    }

    public int getDimensionPixelSizeById(int resId) {
        return getActivity().getResources().getDimensionPixelSize(resId);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(isHookInit) {
            findView(view);
            initData();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        mContext=getActivity();
        return setCenterView(inflater, container, savedInstanceState);
    }

    protected abstract View setCenterView(LayoutInflater inflater,
                                          ViewGroup container, Bundle savedInstanceState);

    /**
     * 判断改fragment 是否初始化
     *
     * @return
     */
    public boolean isInit() {
        return getActivity() != null && getView() != null;
    }

    protected  void findView(View view){}

    /**
     * 初始化数据，在这里
     */
    protected abstract void initData();

    /**
     * 当需要接受返回键时，复写该函数
     *
     * @return
     */
    public boolean back() {
        return false;
    }

    /**
     * 判断fragment 是否在跟用户交互
     *
     * @return
     */
    public boolean isRun() {
        return isRun;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        isRun = true;
        onShowChanged(true);
    }

    /**
     * 因为屏蔽了back键，所以记录了返回状态后，重新打开APP 要做刷新动作
     */
    public void onRestart() {

    }

    @Override
    public void onPause() {
        super.onPause();
        isRun = false;
        onShowChanged(false);
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mContext=null;
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        isRun = !hidden;
        onShowChanged(!hidden);
    }

    public void onShowChanged(boolean isShow) {
        // onResume只会在activity切换时调用
        // onHiddenChanged只会在页面切换时调用
        // 这两个接口都不完善,所以添加这个方法来处理页面切换监听
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public boolean isDestroyed() {
        return getActivity() == null || getActivity().isDestroyed() || getActivity().isFinishing();
    }
}
