package com.lifesense.weidong.lzbinddivicelibs.util;


import java.io.Closeable;

/**
 * Created by Administrator on 2014/10/14.
 */
public class StreamUtil {
    public static void close(Closeable in) {
        try {
            if (in != null) {
                in.close();
            }
        } catch (Exception e) {
        }


    }
    public static void close(Closeable in, Closeable out) {
        try {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        } catch (Exception e) {
        }


    }

}
