//package com.lifesense.weidong.lzbinddivicelibs.logic.device.manage;
//
//import android.bluetooth.BluetoothAdapter;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.util.Log;
//
//import com.lifesense.ble.OnConnectExceptionListener;
//import com.lifesense.ble.bean.BPMeasureInfo;
//import com.lifesense.ble.bean.BloodPressureData;
//import com.lifesense.ble.bean.ExcepetionRecord;
//import com.lifesense.ble.bean.PedometerEcgData;
//import com.lifesense.ble.bean.PedometerEcgStatus;
//import com.lifesense.ble.bean.PedometerEcgSummaryData;
//import com.lifesense.ble.bean.PedometerPpgData;
//import com.lifesense.ble.bean.constant.ConnectionStableStatus;
//import com.lifesense.ble.bean.constant.DeviceConnectState;
//import com.lifesense.businesslogic.base.logicmanager.BaseAppLogicManager;
//import com.lifesense.component.devicemanager.bean.datareceive.AerobicData;
//import com.lifesense.component.devicemanager.bean.datareceive.BadmintonData;
//import com.lifesense.component.devicemanager.bean.datareceive.BasketballData;
//import com.lifesense.component.devicemanager.bean.datareceive.BodyBuildingData;
//import com.lifesense.component.devicemanager.bean.datareceive.CyclingData;
//import com.lifesense.component.devicemanager.bean.datareceive.FootballData;
//import com.lifesense.component.devicemanager.bean.datareceive.GamingData;
//import com.lifesense.component.devicemanager.bean.datareceive.HRSectionStatisticData;
//import com.lifesense.component.devicemanager.bean.datareceive.HealthWalkingData;
//import com.lifesense.component.devicemanager.bean.datareceive.HeartRateData;
//import com.lifesense.component.devicemanager.bean.datareceive.HistoryDataNotify;
//import com.lifesense.component.devicemanager.bean.datareceive.IndoorRunningData;
//import com.lifesense.component.devicemanager.bean.datareceive.PingPongData;
//import com.lifesense.component.devicemanager.bean.datareceive.RunningCalorieData;
//import com.lifesense.component.devicemanager.bean.datareceive.RunningData;
//import com.lifesense.component.devicemanager.bean.datareceive.SleepingData;
//import com.lifesense.component.devicemanager.bean.datareceive.SportHeartRateData;
//import com.lifesense.component.devicemanager.bean.datareceive.SportsData;
//import com.lifesense.component.devicemanager.bean.datareceive.SwimmingData;
//import com.lifesense.component.devicemanager.bean.datareceive.TrackMode;
//import com.lifesense.component.devicemanager.bean.datareceive.VolleyballData;
//import com.lifesense.component.devicemanager.bean.datareceive.WalkingData;
//import com.lifesense.component.devicemanager.bean.datareceive.WeightData;
//import com.lifesense.component.devicemanager.bean.datareceive.YogaData;
//import com.lifesense.component.devicemanager.constant.UnitType;
//import com.lifesense.component.devicemanager.database.entity.Device;
//import com.lifesense.component.devicemanager.database.entity.DeviceStatus;
//import com.lifesense.component.devicemanager.interfaces.OnBatteryCallback;
//import com.lifesense.component.devicemanager.interfaces.OnDataReceiveListener;
//import com.lifesense.component.devicemanager.interfaces.OnDeviceConnectStateListener;
//import com.lifesense.component.devicemanager.interfaces.OnSettingListener;
//import com.lifesense.component.devicemanager.interfaces.SyncDeviceDataCallback;
//import com.lifesense.component.devicemanager.manager.DeviceManager;
//import com.lifesense.foundation.ApplicationHolder;
//import com.lifesense.utils.LSLog;
//import com.lifesense.utils.PreferencesUtils;
//import com.lifesense.weidong.lzbinddivicelibs.R;
//import com.lifesense.weidong.lzbinddivicelibs.logic.manage.LogicServicess;
//import com.lifesense.weidong.lzbinddivicelibs.util.DeviceConstants;
//import com.lifesense.weidong.lzbinddivicelibs.util.PropertyPresistanceUtil;
//import com.lifesense.weidong.lzbinddivicelibs.util.ToastUtil;
//import com.lifesense.weidong.lzbinddivicelibs.util.UnitUtil;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * 对接 设备服务组件，中间层管理类
// */
//public class SportDeviceManagee extends BaseAppLogicManager
//        implements
//        OnDataReceiveListener,
//        OnDeviceConnectStateListener {
//    private Context mContext;
//    /**
//     * 全局注册一个蓝牙打开关闭监听器
//     */
//    private BluetoothReceiveBroadCast mBluetoothReceiveBroadCast;
//    private static final String BLUETOOTH_STATE_CHANGED_OBSERVER = "bluetooth_state_changed_observer";
//    public static int M5_NEW_VERSION37 = 200;
//
//    public void init(Context context) {
//        this.mContext = context;
//        DeviceManager.getInstance().monitorDeviceConnectionStatus(this);
//        DeviceManager.getInstance().registerDataReceiver(this);
//        // 蓝牙开闭状态接收器
//        mBluetoothReceiveBroadCast = new BluetoothReceiveBroadCast();
//        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
//        try{
//            mContext.registerReceiver(mBluetoothReceiveBroadCast, filter);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        DeviceManager.getInstance()
//                .registerBleConnectExceptionListener(mOnConnectExceptionListener);
//    }
//
//    private OnConnectExceptionListener mOnConnectExceptionListener = new OnConnectExceptionListener() {
//        @Override
//        public void onConnectionStableStatusChange(ConnectionStableStatus connectionStableStatus) {
//            super.onConnectionStableStatusChange(connectionStableStatus);
//            if (connectionStableStatus == ConnectionStableStatus.CONNECTION_UNSTABLE_2) {
//                //连接故障,需要提示用户重启蓝牙
//                long time = PropertyPresistanceUtil.getPropertyLong("enableBluetoothTime", 0);
//                if (System.currentTimeMillis() - time > 1000 * 60 * 60 * 6) {
//                    DeviceManager.getInstance().disableBluetooth();
//                    DeviceManager.getInstance().enableBluetooth();
//                    PropertyPresistanceUtil.setPropertyLong("enableBluetoothTime", System.currentTimeMillis());
//                }
//            }
//
//        }
//
//        @Override
//        public void onExceptionRecordNotify(ExcepetionRecord excepetionRecord) {
//            super.onExceptionRecordNotify(excepetionRecord);
//            if (excepetionRecord != null) {
//                LSLog.e("sinyi ", excepetionRecord.formatString());
//                //				LifesenseApplication.writeLogToDeviceManager(excepetionRecord.formatString());
//                Map<String, Object> hashData = new HashMap<>();
//                hashData.put("errorCategoryCode", excepetionRecord.getErrorCategoryCode());
//                hashData.put("errorCode", excepetionRecord.getErrorCode());
//                hashData.put("firmwareVersion",
//                        excepetionRecord.getFirmwareVersion() == null
//                                ? ""
//                                : excepetionRecord.getFirmwareVersion());
//                hashData.put("modelNumber",
//                        excepetionRecord.getModelNumber() == null
//                                ? ""
//                                : excepetionRecord.getModelNumber());
//
////				LogicServicess.shareInstance().getEventReportManager()
////						.addCommonEventReport(UmengEvent.BLUETOOTH_ERROR, hashData);
//
//            }
//        }
//    };
//
//    public class BluetoothReceiveBroadCast extends BroadcastReceiver {
//
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            if (intent.getAction().equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
//                int blueState = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
//                notifyBluetoothStateChanged(blueState);
//                //				switch (blueState) {
//                //					case BluetoothAdapter.STATE_ON :
//                //
//                //						break;
//                //					case BluetoothAdapter.STATE_OFF :
//                //
//                //						break;
//                //				}
//
//            }
//        }
//    }
//
//    public void addBluetoothStateChangedObserver(
//            BluetoothStateChangedObserver bluetoothStateChangedObserver) {
//        addObserver(BLUETOOTH_STATE_CHANGED_OBSERVER, bluetoothStateChangedObserver);
//    }
//
//    public void removeBluetoothStateChangedObserver(
//            BluetoothStateChangedObserver bluetoothStateChangedObserver) {
//        removeObserver(BLUETOOTH_STATE_CHANGED_OBSERVER, bluetoothStateChangedObserver);
//    }
//
//    private void notifyBluetoothStateChanged(final int blueState) {
//        mLogicManagerHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                List<Object> observers = getObservers(BLUETOOTH_STATE_CHANGED_OBSERVER);
//                for (Object ob : observers) {
//                    if (ob != null && ob instanceof BluetoothStateChangedObserver) {
//                        BluetoothStateChangedObserver bluetoothStateChangedObserver = (BluetoothStateChangedObserver) ob;
//                        bluetoothStateChangedObserver.onBlueStateChanged(blueState);
//                    }
//                }
//            }
//        });
//    }
//
//    private Device mDevice;
//
//    public Device getDevice(String deviceId) {
//        if (mDevice != null && mDevice.getId().equals(deviceId)) {
//            return mDevice;
//        }
//        mDevice = DeviceManager.getInstance().getDevice(deviceId);
//        return mDevice;
//    }
//
//    public void cleanCache() {
//        mDevice = null;
//    }
//
//    public void cleanDeviceCache(Device device) {
//        PropertyPresistanceUtil.setPropertyString(device.getId() + "lengthUnit", "-1");
//        PropertyPresistanceUtil.setPropertyString(device.getId() + "lengthUnitTs", "0");
//    }
//
//    public void logout() {
//        DeviceManager.getInstance().registerDataReceiver(null);
//    }
//
//    private static final String device_newdata_observer = "device_newdata_observer";
//    private static final String device_status_change = "device_newdata_observer";
//    private boolean isSyncing = false;//同步锁，防止重复调用
//
//    public void syncDeviceinfo() {
//        if (isSyncing) {
//            return;
//        }
//        isSyncing = true;
//
//        DeviceManager.getInstance().syncFromServer(new SyncDeviceDataCallback() {
//            @Override
//            public void onSuccess() {
//                isSyncing = false;
//                notifySyncObserver();
//            }
//
//            @Override
//            public void onFailed(int i, String s) {
//                isSyncing = false;
//            }
//        });
//    }
//
//    public void setDeviceUserInfo() {
////        User mUser = UserManager.getInstance().getLoginUser();
////        if (mUser != null) {  //出现过LoginUser 为空的问题
////            //保存配置信息
////            if (mUser.getWeight() == 0) {
////                if (mUser.getSex() == 1) {
////                    mUser.setWeight(65);
////                    //女是50，男是65
////                } else {
////                    mUser.setWeight(50);
////                }
////            }
////            DeviceUserInfo deviceUserInfo = new DeviceUserInfo(mUser.getSex(), mUser.getId(), (int) mUser.getHeight(), mUser.getAge(),
////                    (int) mUser.getWeight(), (int) PropertyPresistanceUtil.getTargetStep(LifesenseApplication.getCurrentUserId()));
////            deviceUserInfo.setWaistline((float) mUser.getWaist());
////            WeightRecord weightRecord = WeightAdapterUtils.getFirstWeightRecord();
////            if (weightRecord != null) {
////                deviceUserInfo.setWeight(weightRecord.getWeight());
////            }
////            DeviceManager.getInstance().setUserInfo(deviceUserInfo);
////        }
//    }
//
//    public String getWeightUnitStringByUnitType(Device device) {
//        int unitType = DeviceManager.getInstance().getWeightUnit(device.getId());// == 1 ? true : false;
//        String unit = kg;
//        if (unitType == UnitType.KG) {
//            return unit;
//        }
//        if (unitType == UnitType.JIN) {
//            //这个不用语言化,因为体重秤上面就直接显示斤的汉字
//            return jin;// UnitUtil.WeightUnit.JIN.getUnit();
//        }
//        if (unitType == UnitType.GJ) {
//            return gong_jin;//这个不用语言化,因为体重秤上面就直接显示公斤的汉字
//        }
//        if (unitType == UnitType.POUND) {
//            return lb;
//        }
//        if (unitType == UnitType.ST) {
//            return st;
//        }
//        return unit;
//    }
//
//    public static String kg = "kg";
//    public static String lb = "lb";
//    public static String st = "st";
//    public static String jin = "斤";// LifesenseApplication.getApp().getResources().getString(R.string.unit_jin);
//    public static String gong_jin = "公斤";// LifesenseApplication.getApp().getResources().getString(R.string.unit_gong_jin);
//
//    public ArrayList<String> getWeightUnitList(Device device) {
//        ArrayList<String> strings = new ArrayList<>();
//        if (DeviceManager.getInstance().isA6WeightScale(device)) {
//            strings.add(kg);
//            strings.add(lb);
//            strings.add(st);
//            strings.add(jin);
//            strings.add(gong_jin);
//        } else {
//            strings.add(kg);
//            strings.add(jin);//LifesenseApplication.getApp().getResources().getString(R.string.unit_jin));
//        }
//        return strings;
//    }
//
//    public void registerSyncObserver(SyncDeviceObserver syncDeviceObserver) {
//        addObserver(device_newdata_observer, syncDeviceObserver);
//    }
//
//    public void unregisterSyncObserver(SyncDeviceObserver syncDeviceObserver) {
//        removeObserver(device_newdata_observer, syncDeviceObserver);
//    }
//
//    public void registerDeviceStatusChange(DeviceStatusChangeObserver deviceStatusChangeObserver) {
//        addObserver(device_status_change, deviceStatusChangeObserver);
//
//    }
//
//    public void unregisterDeviceStatusChange(
//            DeviceStatusChangeObserver deviceStatusChangeObserver) {
//        removeObserver(device_status_change, deviceStatusChangeObserver);
//    }
//
//    public void notifyDeviceStatusChange(final DeviceStatus deviceStatus) {
//        mLogicManagerHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                List<Object> observers = getObservers(device_status_change);
//                for (Object ob : observers) {
//                    if (ob != null && ob instanceof DeviceStatusChangeObserver) {
//                        DeviceStatusChangeObserver syncDeviceObserver = (DeviceStatusChangeObserver) ob;
//                        syncDeviceObserver.onDeviceStatusChange(deviceStatus);
//                    }
//                }
//            }
//        });
//
//    }
//
//    public void setWeightUnit(UnitUtil.WeightUnit weightUnit) {
//
//        List<Device> devices = DeviceManager.getInstance().getDevices(Long.parseLong(PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId","0")));
//        if (devices == null) {
//            return;
//        }
//        for (int i = 0; i < devices.size(); i++) {
//            Device device = devices.get(i);
//            if (!device.canSetUnit()) {
//                return;
//            }
//            int type = UnitType.KG;
//            switch (weightUnit) {
//                case ST:
//                    type = UnitType.ST;
//                    break;
//                case LB:
//                    type = UnitType.POUND;
//                    break;
//                case KG:
//                    type = UnitType.KG;
//                    break;
//                case JIN:
//                    type = UnitType.JIN;
//                    break;
//            }
//
//            DeviceManager.getInstance().setWeightUnit(device.getId(), type, new OnSettingListener() {
//                @Override
//                public void onSuccess() {
//                    ToastUtil.showCenterShowToast(mContext,mContext.getString(R.string.device_unit_change));
//
//                }
//
//                @Override
//                public void onFailed(int errorCode, String msg) {
//                }
//            });
//        }
//
//
//    }
//
////    public void setDeviceLengthUnit(boolean isAuth, final LengthUnit deviceLengthUnit) {
////        final Device device = DeviceManager.getInstance().getPedometer(LifesenseApplication.getCurrentUserId());
////        if (device == null) {
////            return;
////        }
////        if (isAuth) {
////            long lastTs = 0;
////            int lastUnit = -1;
////            try {
////                lastTs = Long.parseLong(PropertyPresistanceUtil.getPropertyString(device.getId() + "lengthUnitTs", "0"));
////                lastUnit = Integer.parseInt(PropertyPresistanceUtil.getPropertyString(device.getId() + "lengthUnit", "-1"));
////            } catch (NumberFormatException e) {
////            }
////            if (lastUnit == deviceLengthUnit.getCommand()) {
////                //23小时内,不重复发
////                if (System.currentTimeMillis() - lastTs < 23 * 60 * 60 * 1000) {
////                    return;
////                }
////            }
////        }
////        LsBleManager.getInstance().updateDeviceDistanceUnit(device.getMacConvert(), deviceLengthUnit, new com.lifesense.ble.OnSettingListener() {
////            @Override
////            public void onSuccess(String macAddress) {
////                super.onSuccess(macAddress);
////                PropertyPresistanceUtil.setPropertyString(device.getId() + "lengthUnit", String.valueOf(deviceLengthUnit.getCommand()));
////                PropertyPresistanceUtil.setPropertyString(device.getId() + "lengthUnitTs", String.valueOf(System.currentTimeMillis()));
////
////            }
////
////            @Override
////            public void onFailure(int errorCode) {
////                super.onFailure(errorCode);
////            }
////        });
////    }
//
//    public void notifySyncObserver() {
//
//        mLogicManagerHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                List<Object> observers = getObservers(device_newdata_observer);
//                for (Object ob : observers) {
//                    if (ob != null && ob instanceof SyncDeviceObserver) {
//                        SyncDeviceObserver syncDeviceObserver = (SyncDeviceObserver) ob;
//                        syncDeviceObserver.syncDeviceSucceed();
//                    }
//                }
//            }
//        });
//
//    }
//
////    /**
////     * 返回是否处理该笔推送
////     *
////     * @param jsonData
////     * @param isWebsocket
////     * @return
////     */
////    public boolean receivePushUnbind(JSONObject jsonData, boolean isWebsocket) {
////        String deviceId = null;
//////        if (LifesenseApplication.isForeground()) {
//////            String content = JsonUtil.getString(jsonData, "content");
//////            if (LifesenseApplication.getApp().getLastActivity() != null)
//////                DialogUtil.getInstance()
//////                        .showUnbindDialog(LifesenseApplication.getApp().getLastActivity(), content);
//////        }
////
////        if (isWebsocket) {
////            String title = JsonUtil.getString(jsonData, "title");
////            String content = JsonUtil.getString(jsonData, "content");
////            LogicServicess.shareInstance().getPushManager().notificationSystem(2, title, content,
////                    PushManager.unbind);
////            try {
////                JSONObject data1 = jsonData.getJSONObject("data1");
////                deviceId = data1.getString("deviceId");
////            } catch (JSONException e) {
////                e.printStackTrace();
////            }
////        } else {//jpush
////            deviceId = JsonUtil.getString(jsonData, "recordId");
////        }
////        if (!TextUtils.isEmpty(deviceId)) {
////            //            DeviceManager.getInstance().deleteDeviceUser(deviceId, LifesenseApplication.getCurrentUserId());
////            List<DeviceUser> deviceUsers = DeviceManager.getInstance().getDeviceUsers(deviceId);
////            boolean isHas = false;
////            long userId = Long.parseLong(PreferencesUtils.getString(mContext,"userId","0"));
////            for (DeviceUser du : deviceUsers) {
////                if (du.getUserId() == userId) {
////                    isHas = true;
////                    break;
////                }
////            }
////            //            if (isHas && isWebsocket) {//如果有这个设备才在通知栏产生
////            //                DeviceManager.getInstance().deleteDeviceUser(deviceId, LifesenseApplication.getCurrentUserId());
////            //            }
////            notifySyncObserver();
////            return isHas;
////
////        } else {
////            //            syncDeviceinfo();
////        }
////
////        return false;
////
////    }
//
//    @Override
//    public void onDeviceConnectStateChange(String mac, DeviceConnectState state) {
//        if (state != DeviceConnectState.CONNECTING) {
//            //后面发现，只要判断蓝牙打开就算是连接中状态，所以不需要组件的这个回调，而且这个回调有点频繁，怕UI吃不消
//            //监听蓝牙开关使用 addBluetoothStateChangedObserver函数，可以考虑在蓝牙打开时，调用一下这个状态
//            Intent intent = new Intent();
//            intent.setAction(DeviceConstants.DEVICE_CONNECT_STATE_CHANGE);
//            intent.putExtra(DeviceConstants.DEVICE_MAC, mac);
//            intent.putExtra(DeviceConstants.DEVICE_CONNECT_STATE, state);
//            try {
//                mContext.sendBroadcast(intent);
//            } catch (Exception e) {
//            }
//
//            DeviceManager.getInstance()
//                    .writeLog("onDeviceConnectStateChange:: deviceStatus=" + state);
////            LogicServicess.shareInstance().getEcgManager().receiveDeviceState(mac, state);
//        }
//        if (state == DeviceConnectState.CONNECTED_SUCCESS) {
//
//        }
//
//
//    }
//
//
//    /**
//     * 收到蓝牙秤体重数据
//     *
//     * @param data
//     */
//    @Override
//    public void onReceiveWeightData(final WeightData data) {
//        Log.e("onReceiveWeightData", data.toString());
////        LogicServicess.shareInstance().getWeightManager().receiveBleWeight(data);
//
//    }
//
//    @Override
//    public void onReceiveRunningData(RunningData data) {
//
//    }
//
//    @Override
//    public void onReceiveIndoorRunningData(IndoorRunningData data) {
//
//    }
//
//    @Override
//    public void onReceiveHealthWalking(HealthWalkingData data) {
//
//    }
//
//    @Override
//    public void onReceiveSwimmingData(SwimmingData data) {
//
//    }
//
//    @Override
//    public void onReceiveWalkingData(WalkingData data) {
//
//    }
//
//    @Override
//    public void onReceiveWalkingDataFromMobile(WalkingData data) {
//
//    }
//
//    @Override
//    public void onReceiveHeartRateData(HeartRateData data) {
//
//    }
//
//    @Override
//    public void onReceiveSportHeartRateData(SportHeartRateData data) {
//
//    }
//
//    @Override
//    public void onReceiveRealTimeHeartRateData(String macAddress, HeartRateData data) {
//
//    }
//
//    @Override
//    public void onReceiveSleepingData(SleepingData data) {
//
//    }
//
//    @Override
//    public void onReceiveSleepingResultData(SleepingData.SleepResult data) {
//
//    }
//
//    private long tempCheckVoltageTime;
//    private int mState = OnBatteryCallback.STATE_NON;
//    private int mBattery = OnBatteryCallback.BATTERY_DEFAULT;
//    private String mDeviceId;
//
//    /**
//     * 读取缓存，先展示在界面上，避免电量不显示
//     *
//     * @param deviceId
//     * @return
//     */
//    public int[] getCacheVoltageStatus(String deviceId) {
//        if (deviceId.equals(mDeviceId)) {
//            int[] ints = new int[2];
//            ints[0] = mState;
//            ints[1] = mBattery;
//            return ints;
//        }
//        return null;
//
//    }
//
//    public void checkDeviceVoltageStatus(String deviceId,
//                                         final OnBatteryCallback onBatteryCallback) {
//
//        if (mDeviceId != null && mDeviceId.equalsIgnoreCase(deviceId)
//                && System.currentTimeMillis() - tempCheckVoltageTime < 8000 && mState != -1) {
//            //同一个设备，3s内重复读取，则拦截，使用上次缓存的
//            onBatteryCallback.onReadBattery(mState, mBattery);
//            return;
//        }
//        if (mDeviceId != null && !mDeviceId.equalsIgnoreCase(deviceId)) {
//            //清除不同设备电量缓存
//            mState = OnBatteryCallback.STATE_NON;
//            mBattery = OnBatteryCallback.BATTERY_DEFAULT;
//        }
//        mDeviceId = deviceId;
//        tempCheckVoltageTime = System.currentTimeMillis();
//        DeviceManager.getInstance().checkDeviceVoltageStatus(deviceId, new OnBatteryCallback() {
//            @Override
//            public void onReadBattery(int state, int battery) {
//                mState = state;
//                mBattery = battery;
//                if (onBatteryCallback != null) {
//                    onBatteryCallback.onReadBattery(state, battery);
//                }
//            }
//        });
//    }
//
//    @Override
//    public void onDeviceStatusChange(DeviceStatus deviceStatus) {
//        notifyDeviceStatusChange(deviceStatus);
//    }
//
//    @Override
//    public void onReceiveRunningCaloriesData(RunningCalorieData runningCalorieData) {
//
//    }
//
//    @Override
//    public void onReceiveHRSectionStatisticData(HRSectionStatisticData hrSectionStatisticData) {
//
//    }
//
//    @Override
//    public void onReceiveTrackMode(TrackMode trackMode) {
//
//    }
//
//    @Override
//    public void onReceiveAerobicStartGps(int aerobicType) {
//
//    }
//
//    @Override
//    public void onReceiveAerobicStartGpsFail() {
//
//    }
//
//    @Override
//    public void onReceiveAerobicStartRun(int aerobicType) {
//
//    }
//
//    @Override
//    public void onReceiveAerobicEnd() {
//
//    }
//
//    @Override
//    public void onReceiveAerobicData(AerobicData aerobicData) {
//
//    }
//
//    @Override
//    public void onReceiveHistoryDataNotify(HistoryDataNotify historyDataNotify) {
//
//    }
//
//    @Override
//    public void onReceiveCyclingData(CyclingData cyclingData) {
//
//    }
//
//    @Override
//    public void onReceiveBodyBuildingData(BodyBuildingData bodyBuildingData) {
//
//    }
//
//    @Override
//    public void onReceiveBasketballData(BasketballData basketballData) {
//
//    }
//
//    @Override
//    public void onReceiveFootballData(FootballData footballData) {
//
//    }
//
//    @Override
//    public void onReceiveBadmintonData(BadmintonData badmintonData) {
//
//    }
//
//    @Override
//    public void onReceiveVolleyballData(VolleyballData volleyballData) {
//
//    }
//
//    @Override
//    public void onReceivePingPongData(PingPongData pingPongData) {
//
//    }
//
//    @Override
//    public void onReceiveYogaData(YogaData yogaData) {
//
//    }
//
//    @Override
//    public void onReceiveGamingData(GamingData gamingData) {
//
//    }
//
//    @Override
//    public void onReceiveWatchGps(Object gpsData) {
//
//    }
//
//    @Override
//    public void onReceiveWatchEcg(PedometerEcgData data) {
//
//    }
//
//    @Override
//    public void onReceiveWatchRealtimeEcg(PedometerEcgData data) {
//
//    }
//
//    @Override
//    public void onReceiveWatchEcgRealtimeStatus(PedometerEcgStatus data) {
//
//    }
//
//    @Override
//    public void onReceiveWatchSummaryEcg(PedometerEcgSummaryData data) {
//
//    }
//
//    @Override
//    public void onReceiveSportsData(SportsData sportsData) {
//
//    }
//
//    @Override
//    public void onReceiveBloodPressureData(BloodPressureData bpData) {
//
//    }
//
//    @Override
//    public void onReceiveWatchPpgData(PedometerPpgData pedometerPpgData) {
//
//    }
//
//    @Override
//    public void onReceiveBloodPressureData(BPMeasureInfo bpData) {
//
//    }
//}
