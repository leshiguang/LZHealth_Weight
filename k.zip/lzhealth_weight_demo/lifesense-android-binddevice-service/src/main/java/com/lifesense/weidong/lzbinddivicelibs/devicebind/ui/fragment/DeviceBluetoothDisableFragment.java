package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;

/**
 * 蓝牙关闭
 */
public class DeviceBluetoothDisableFragment extends BaseFragment {

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_device_bluetooth_disable,null);
    }

    @Override
    protected void initData() {
        ((OlderBaseActivity)getActivity()).setHeader_Title("");
    }

    @Override
    public void onClick(View v) {

    }
}
