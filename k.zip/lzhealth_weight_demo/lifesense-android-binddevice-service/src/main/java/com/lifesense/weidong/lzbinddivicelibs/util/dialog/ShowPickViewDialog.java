//package com.lifesense.weidong.lzbinddivicelibs.util.dialog;
//
//import android.app.Dialog;
//import android.os.Bundle;
//import androidx.annotation.IntDef;
//import androidx.fragment.app.DialogFragment;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewTreeObserver;
//import android.widget.TextView;
//import com.lifesense.weidong.lzbinddivicelibs.R;
//import java.lang.annotation.Retention;
//import java.lang.annotation.RetentionPolicy;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//
///**
// * Created by Administrator on 2014/11/29.
// */
//public class ShowPickViewDialog extends DialogFragment implements View.OnClickListener {
//    private String TAG = this.getClass().getSimpleName();
//    private static final String EXTRA_TYPE = "extra_type";
//    private static final String EXTRA2_TYPE = "extra2_type";
//    private static final String EXTRA3_TYPE = "extra3_type";
//    private static final String EXTRA_UNIT_TYPE = "extra_unit_type";
//
//    /**
//     * { @hide }
//     */
//    @IntDef(flag = true,
//            value = {
//                    TYPE_COMMON,
//                    TYPE_YEAR,
//                    TYPE_WEIGHT,
//                    TYPE_HEIGHT,
//                    TYPE_WAIST,
//                    TYPE_GENDER,
//                    TYPE_WRIST_MODE,
//                    TYPE_DATE,
//                    TYPE_UNIT,
//                    TYPE_UNIT_INTERNATION,
//                    TYPE_SWIM_POOL_LENGTH,
//                    TYPE_SLEEP_TIME,
//                    TYPE_HEART_INTERVAL,
//                    TYPE_MAX_HEART,
//                    TYPE_HEART_WARNING,
//
//                    TYPE_SEX,
//
//            })
//    @Retention(RetentionPolicy.SOURCE)
//    public @interface DialogType {
//    }
//    public static final int TYPE_COMMON = -1;
//
//    public static final int TYPE_YEAR = 1;
//    public static final int TYPE_WEIGHT = 2;
//    public static final int TYPE_HEIGHT = 3;
//    public static final int TYPE_WAIST = 4;
//    public static final int TYPE_GENDER = 5;
//
//    public static final int TYPE_DATE = 6;
//    public static final int TYPE_UNIT = 7;
//
//    public static final int TYPE_SWIM_POOL_LENGTH = 8;
//    public static final int TYPE_SLEEP_TIME = 9;
//    public static final int TYPE_HEART_INTERVAL = 10;
//    public static final int TYPE_MAX_HEART = 11;
//    public static final int TYPE_HEART_WARNING = 12;
//    public static final int TYPE_WEIGHT_ST = 13; //体重,英石
//    public static final int TYPE_HEIGHT_YC = 14; //身高,英尺
//    public static final int TYPE_UNIT_INTERNATION = 15;
//    public static final int TYPE_WRIST_MODE = 16;
//    public static final int TYPE_NEW_SLEEP_TIME = 17;
//
//    public static final int TYPE_SEX= 18;
//
//    private RecycleWheelView pvData;
//
//    TextWheelAdapter<String> dataAdapter;
//    TextWheelAdapter<String> monthAdapter;
//    private TextView tvTitle;
//    private OnConfirmListener mConfirmListener;
//    private int mType;
//    private String selectedData = null;
//
//    public static ShowPickViewDialog newInstance(@DialogType int type, ArrayList<String> strings) {
//        ShowPickViewDialog recordReportDialog = new ShowPickViewDialog();
//        Bundle args = new Bundle();
//        args.putSerializable(EXTRA_TYPE, type);
//        args.putStringArrayList(EXTRA3_TYPE,strings);
//        recordReportDialog.setArguments(args);
//        return recordReportDialog;
//    }
//
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        mType = (int) getArguments().getSerializable(EXTRA_TYPE);
//    }
//
//    @Override
//    public Dialog onCreateDialog(Bundle savedInstanceState) {
//        return createDialog();
//    }
//
//    private Dialog createDialog() {
//        Dialog dialog = new Dialog(getActivity(), R.style.wheel_style);
//        View view = LayoutInflater.from(getActivity()).inflate(R.layout.show_wheel_frag, null);
//        dialog.getWindow().getAttributes().windowAnimations = R.style.dialogWindowAnim;
//        initial(view);
//        dialog.setContentView(view);
//        return dialog;
//    }
//
//    TextWheelAdapter2 weightAdapter;
//
//
//
//    private void initial(View view) {
//        tvTitle = view.findViewById(R.id.sw_title_tv);
//        pvData = view.findViewById(R.id.sw_data_wv);
//
//        pvData.setOnSelectListener(new RecycleWheelView.OnSelectItemListener() {
//            @Override
//            public void onSelectChanged(int position) {
//                if(dataAdapter != null) { //此处dataAdapter存在为空的情况
//                    dataAdapter.setSelectedIndex(position);
//                }
//            }
//        });
//
//        pvData.setLableTextColor(getResources().getColor(R.color.main_blue));
//        pvData.setVisibleItem(3);
//
//        view.findViewById(R.id.sw_cancel_tv).setOnClickListener(this);
//        view.findViewById(R.id.sw_ok_tv).setOnClickListener(this);
//        setData();
//    }
//
//    private void setData() {
//        switch (mType) {
//            case TYPE_UNIT_INTERNATION:
//                setUnitDataInternation();
//                break;
//            default:
//                break;
//        }
//    }
//
//
//    private void setUnitDataInternation() {
//        tvTitle.setText(getResources().getString(R.string.device_unit));
//        dataAdapter = new TextWheelAdapter<>(getContext());
//        dataAdapter.setTextColor(getResources().getColor(R.color.text_weak_color));
//        final List<String> dataList = getArguments().getStringArrayList(EXTRA3_TYPE);
//        pvData.setLabel("");
//        dataAdapter.setData(dataList);
//        pvData.setAdapter(dataAdapter);
//
//        pvData.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
//            @Override
//            public void onGlobalLayout() {
//
//                if (selectedData == null) {
//                    pvData.setSelectedItem(dataList.indexOf(0));
//                } else {
//                    pvData.setSelectedItem(dataList.indexOf(selectedData));
//                }
//                pvData.getViewTreeObserver().removeOnGlobalLayoutListener(this);
//            }
//        });
//    }
//
//    public void setSelectedData(String selectedData) {
//        this.selectedData = selectedData;
//    }
//
//    @Override
//    public void onClick(View v) {
//        if (v.getId() == R.id.sw_cancel_tv) {
//            dismiss();
//            return;
//        }
//
//        if (v.getId() == R.id.sw_cancel_tv) {
//            dismiss();
//        } else if (v.getId() == R.id.sw_ok_tv) {
//            if (mConfirmListener != null) {
//                mConfirmListener.onConfirm(dataAdapter.getValue(pvData.getSelectPosition()));
//            }
//            this.dismiss();
//        }
//
//    }
//
//    public void setOnConfirmListener(OnConfirmListener onListener) {
//        this.mConfirmListener = onListener;
//    }
//
//    public interface OnConfirmListener {
//        void onConfirm(String data);
//
//    }
//    //最大最小心率
//    public interface OnHeartConfirmListener {
//        void onConfirm(String min, String max);
//
//    }
//
//
//    public interface OnYearConfirmListener {
//        void onConfirm(int year, int month, int day);
//    }
//
//    public interface OnDateConfirmListener {
//        void onConfirm(String year, String month, String day);
//        void onConfirm(Date date, String month, String day);
//    }
//
//    public interface OnUnitConfirmListener {
//        void onConfirm(int one, int two, int three);
//    }
//
//    public class DateStringBean{
//        private Date date;
//        private String dateString;
//
//        public DateStringBean(Date date, String dateString) {
//            this.date = date;
//            this.dateString = dateString;
//        }
//
//        public Date getDate() {
//            return date;
//        }
//
//        public void setDate(Date date) {
//            this.date = date;
//        }
//
//        public String getDateString() {
//            return dateString;
//        }
//
//        public void setDateString(String dateString) {
//            this.dateString = dateString;
//        }
//
//        @Override
//        public String toString() {
//            return dateString;
//        }
//    }
//
//
//    public static void main(String[] args) {
//
//    }
//
//
//}
