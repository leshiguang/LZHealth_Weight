package com.lifesense.weidong.lzbinddivicelibs.devicedetails.model;

import android.content.Context;
import android.text.TextUtils;

import com.lifesense.component.devicemanager.application.interfaces.callback.OnCheckUpgradeCallback;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.device.dto.device.FirmwareInfo;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.bean.Cell;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by qwerty
 * Create on 2020/6/8
 **/
public class DeviceModel {

    public DeviceModel() {
    }

    public void loadDeviceDetailsInfo(final Context context, final Device device, final OnLoadDeviceDetailsInfoCallback onLoadDeviceDetailsInfoCallback) {
        final List<Cell> cellList = new ArrayList<>();
        if(device != null) {
            cellList.add(DeviceDetailModel.DEVICE_NAME.createDeviceDetailsCell(context, device.getName()));
            cellList.add(DeviceDetailModel.HEART_RATE_SWITCH.createDeviceDetailsCell(context,LZDeviceService.getInstance().getHeartRateSwitch(device.getId()) == 1));
            cellList.add(DeviceDetailModel.UNIT_SETTING.createDeviceDetailsCell(context,Unit.getUnitByUnitTypeCommand(LZDeviceService.getInstance().getUnit(device.getId())).getUnitName(context)));
            cellList.add(DeviceDetailModel.MAC_ADDRESS.createDeviceDetailsCell(context,device.getMacConvert()));
            cellList.add(DeviceDetailModel.FIRMWARE_UPGRADE.createDeviceDetailsCell(context,device.getHardwareVersion()));
        } else {
            cellList.add(DeviceDetailModel.DEVICE_NAME.createDeviceDetailsCell(context,""));
            cellList.add(DeviceDetailModel.HEART_RATE_SWITCH.createDeviceDetailsCell(context,false));
            cellList.add(DeviceDetailModel.UNIT_SETTING.createDeviceDetailsCell(context,""));
            cellList.add(DeviceDetailModel.MAC_ADDRESS.createDeviceDetailsCell(context,""));
            cellList.add(DeviceDetailModel.FIRMWARE_UPGRADE.createDeviceDetailsCell(context,""));
        }
        cellList.add(DeviceDetailModel.USER_MANUAL.createDeviceDetailsCell(context,""));
        cellList.add(DeviceDetailModel.LEGAL_INFO.createDeviceDetailsCell(context,""));
        if (onLoadDeviceDetailsInfoCallback != null) {
            onLoadDeviceDetailsInfoCallback.onLoadDeviceDetailsInfoSuccess(cellList);
        }
        if(device != null) {
            //检查更新
            checkFirmwareUpgrade(device.getId(), new OnCheckUpgradeCallback() {
                @Override
                public void onCheckUpgradeSuccess(FirmwareInfo firmwareInfo) {
                    Cell newVersionCell = DeviceDetailModel.FIRMWARE_UPGRADE.createDeviceDetailsCell(context,null, context.getString(R.string.new_version_available_msg));
                    int index = cellList.indexOf(newVersionCell);
                    cellList.set(index, newVersionCell);
                    if (onLoadDeviceDetailsInfoCallback != null) {
                        onLoadDeviceDetailsInfoCallback.onLoadDeviceDetailsInfoSuccess(cellList);
                    }
                }

                @Override
                public void onCheckUpgradeFail(int i, String s) {

                }
            });
        }
    }

    public void checkFirmwareUpgrade(String deviceId, OnCheckUpgradeCallback callback) {
        if (!TextUtils.isEmpty(deviceId)) {
            LZDeviceService.getInstance().checkDeviceFirmwareUpgrade(deviceId, callback);
        }
    }

    public interface OnLoadDeviceDetailsInfoCallback {
        void onLoadDeviceDetailsInfoSuccess(List<Cell> cellList);
    }
}
