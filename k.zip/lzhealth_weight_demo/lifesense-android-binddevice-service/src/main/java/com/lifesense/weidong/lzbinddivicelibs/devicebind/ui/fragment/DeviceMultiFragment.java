package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.lifesense.utils.ui.ViewUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity.DeviceConnectSearchActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.adapter.FindDeviceResultAdapter;
import com.lifesense.weidong.lzbinddivicelibs.widget.shadow.ShadowProperty;
import com.lifesense.weidong.lzbinddivicelibs.widget.shadow.ShadowViewHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 多设备展示
 */
@SuppressLint("ValidFragment")
public class DeviceMultiFragment extends BaseFragment {

    private List<LSEDeviceInfoApp> mDeviceList;
    private FindDeviceResultAdapter adapter;
    private ListView listview1;

    public static DeviceMultiFragment newInstance(List<LSEDeviceInfoApp> mDeviceList) {
        DeviceMultiFragment fragment = new DeviceMultiFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("mDeviceList", changeNearest(mDeviceList));
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        this.mDeviceList = bundle.getParcelableArrayList("mDeviceList");
        return inflater.inflate(R.layout.fragment_device_multi, null);
    }

    @Override
    protected void initData() {
        listview1 = getActivity().findViewById(R.id.listview1);
        getActivity().findViewById(R.id.tvBottom).setOnClickListener(this);
        TextView other = getActivity().findViewById(R.id.tvOtherBind);
        other.setOnClickListener(this);
        ((DeviceConnectSearchActivity) getActivity()).setHeader_Title(getString(R.string.device_search_connect_title));

        SpannableString spannableString = new SpannableString(other.getText());
        int start = 0;
        int end = start + other.getText().length();
        spannableString.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View view) {
//                startActivityForResult(
//                        new Intent(getActivity(), DeviceBindingChooseActivity.class), 2);
            }
        }, start, end, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new UnderlineSpan() {
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setColor(getResources().getColor(R.color.color_6593E5));//设置颜色
                ds.setUnderlineText(true);//去掉下划线
            }
        }, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        other.setText(spannableString);
        other.setMovementMethod(LinkMovementMethod.getInstance());

        adapter = new FindDeviceResultAdapter(getActivity(), mDeviceList);
        listview1.setAdapter(adapter);

        float ry = ViewUtil.dip2px(getActivity(), 12);
        ShadowViewHelper.bindShadowHelper(
                new ShadowProperty().setShadowColor(0x0F000000)
                        .setShadowDx(ViewUtil.dip2px(getActivity(), 0f))
                        .setShadowDy(ViewUtil.dip2px(getActivity(), 0.5f))
                        .setShadowRadius(ViewUtil.dip2px(getActivity(), 6f))
                        .setSide(ShadowProperty.BOTTOM),
                listview1, Color.WHITE, ry, ry);
    }

    @Override
    public void onClick(View v) {
        int i1 = v.getId();
        if (i1 == R.id.tvBottom) {
            LSEDeviceInfoApp mCurDeviceInfoApp = null;
            for (int i = 0; i < mDeviceList.size(); i++) {
                LSEDeviceInfoApp item = mDeviceList.get(i);
                if (item.isCheck()) {
                    mCurDeviceInfoApp = item;
                    break;
                }
            }
            ((DeviceConnectSearchActivity) getActivity()).bindDevice(mCurDeviceInfoApp);
        } else if (i1 == R.id.tvOtherBind) {
//            startActivityForResult(
//                    new Intent(getActivity(), DeviceBindingChooseActivity.class), 2);
        }
    }

    private static ArrayList<LSEDeviceInfoApp> changeNearest(List<LSEDeviceInfoApp> mDeviceList) {
        ArrayList<LSEDeviceInfoApp> lseDeviceInfoApps = new ArrayList<>(mDeviceList);
        Collections.sort(lseDeviceInfoApps, new Comparator<LSEDeviceInfoApp>() {
            @Override
            public int compare(LSEDeviceInfoApp o1, LSEDeviceInfoApp o2) {
                return Math.abs(o1.getRssi()) > Math.abs(o2.getRssi()) ? 1 : -1;
            }
        });

        LSEDeviceInfoApp deviceInfoApp;
        for (int i = 0; i < lseDeviceInfoApps.size(); i++) {
            deviceInfoApp = lseDeviceInfoApps.get(i);
            if (i == 0) {
                deviceInfoApp.setCheck(true);
            } else {
                deviceInfoApp.setCheck(false);
            }
        }

        return lseDeviceInfoApps;
    }
}
