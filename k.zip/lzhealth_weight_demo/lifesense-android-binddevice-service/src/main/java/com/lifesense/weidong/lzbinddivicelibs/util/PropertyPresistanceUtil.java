package com.lifesense.weidong.lzbinddivicelibs.util;
import com.lifesense.commonlogic.config.PropertyPersistanceManager;
import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.utils.PreferencesUtils;
import com.lifesense.utils.StringUtil;

/**
 * @author rolandxu
 */
public class PropertyPresistanceUtil {
    // private static final String TAG = "PropertyPersistanceUtil";
    //用户ID
    protected static final String PROPERTY_USER_ID = "userId";
    protected static final String PROPERTY_CLIENT_ID = "ls_client_id";
    protected static final String PROPERTY_ACCOUNT_ID = "AccountId";
    protected static final String PROPERTY_UNION_ID = "unionId";
    protected static final String PROPERTY_ACCOUNT_TICKET = "Ticket";
    protected static final String PROPERTY_MEMBER_ID = "MemberUUID";

    protected static final String PROPERTY_ACCOUNT_TYPE = "account_type";
    protected static final String PROPERTY_LANGUAGE = "language";
    protected static final String PROPERTY_LAUNCHED_STRING = "launched_string";
    protected static final String PROPERTY_SEARCH_SWIPED = "swiped";

    protected static final String PROPERTY_VERSION_CODE = "version_code";

    protected static final String PROPERTY_IS_LOCATION_MOCKUP = "is_location_mockup";
    protected static final String PROPERTY_MOCKUP_LOCATION_LAT = "mockup_geo_lat";

    protected static final String PROPERTY_KEY_PROTOCOL_NAME = "protocol_name";
    protected static final String PROPERTY_KEY_PROTOCOL_HOST = "protocol_host";
    protected static final String PROPERTY_KEY_PROTOCOL_WEB_DOMAIN = "url_domain";

    protected static final String PROPERTY_MOCKUP_LOCATION_LON = "mockup_geo_lon";

    protected static final String PROPERTY_LOCATION_CITY = "location_city";
    protected static final String PROPERTY_CONTENT_CITY = "content_city";

    protected static final String PROPERTY_NEED_SHOW_RATING = "need_show_rating";

    protected static final String PROPERTY_USER_OPENED_RATING = "opened_show_rating";

    protected static final String PROPERTY_IS_FINISH_INSTALL_GUIDANCE = "is_finish_guidance";
//	protected static final String SYNC_WEIGHT_HISTORY_DATA_TS = "sync_history_weight_data_ts";
//	protected static final String SYNC_WEIGHT_NEW_DATA_TS = "sync_new_weight_data_ts";
//	protected static final String SYNC_WEIGHT_FIRSTTS_DATA_TS = "sync_first_weight_data_ts";

    protected static final String SYNC_COLLECTION_POINT = "sync_collectino_point";

    //	protected static final String WEIGHT_IS_MORE = "weight_is_more";
//	protected static final String TARGET_WEIGHT = "TARGET_WEIGHT";
    protected static final String TARGET_STEP = "TARGET_STEP";
    protected static final String TARGET_DISTANCE = "target_distance";
    protected static final String TARGET_CALORIES = "target_calories";
    protected static final String TARGET_TYPE = "target_type";

    protected static final String PROPERTY_TARGET_STEP_SUCCEED = "PROPERTY_TARGET_STEP_SUCCEED";
    protected static final String STEP_SOURCE = "step_source";
    protected static final String IS_SHOWED_SPORT_TIPPAGE = "is_showed_sport_tippage";
    public static final String isDeletePic_2_3 = "isDeletePic_2_3";
    public static final String isDeletePic_2_5 = "isDeletePic_2_5";

    protected static final String AUTOSTARTMANAGER_ENABLE = "autostartmanager_enable";
    protected static final String AUTOSTARTMANAGER_PACKAGENAME = "autostartmanager_packagename";
    protected static final String AUTOSTARTMANAGER_ACTIVITYNAME = "autostartmanager_activityname";
    protected static final String IS_FIRST_START = "is_first_start";
    protected static final String IS_SHOW_CHALLENGE_RED_DOT = "is_show_challenge_red_dot";
    protected static final String IS_NEED_UPDATE_CHALLENGE_NEW_MARK = "is_need_update_challenge_new_mark";
    protected static final String HAS_NEW_CHALLENGE = "has_new_challenge";
    protected static final String IS_SHOWED_OPENGPS_DIALOG = "is_showed_opengps_dialog";
    protected static final String TRACK_PREV_PLAYSOUND_KM = "track_prev_playsound_km";
    protected static final String IS_START_CORESERVICE = "is_start_coreservice";

    protected static final String TOTAL_RUN_DISTANCE = "total_run_distance";
    protected static final String TOTAL_WALK_DISTANCE = "total_walk_distance";
    protected static final String TOTAL_RIDING_DISTANCE = "total_riding_distance";
    protected static final String TOTAL_SWIM_DISTANCE = "total_swim_distance";
    protected static final String TOTAL_BOYDYBUILDING_MIN = "total_boydybuilding_min";
    protected static final String TOTAL_BASKETBALL_MIN = "total_basketball_min";
    protected static final String TOTAL_FOOTBALL_MIN = "total_football_min";
    protected static final String TOTAL_BADMINTON_MIN = "total_badminton_min";
    protected static final String TOTAL_VOLLEYBALL_MIN = "total_volleyball_min";
    protected static final String TOTAL_PING_PONG_MIN = "total_ping_pong_min";
    protected static final String TOTAL_YOGA_MIN = "total_yoga_min";
    protected static final String TOTAL_GAMING_MIN = "total_gaming_min";
    protected static final String TOTAL_INDOOR_RUN = "total_indoor_run";
    protected static final String TOTAL_ELLIPTICAL= "total_elliptical";
    protected static final String TOTAL_AEROBIC= "total_aerobic";
    protected static final String TOTAL_FITNESS_DANCE= "total_fitness_dance";
    protected static final String TOTAL_TAIJI= "total_taiji";
    protected static final String TOTAL_SPORTS= "total_sports_";
    protected static final String TOTAL_SPORTS_DISTANCE= "total_sports_distance";





    protected static final String OPEN_MID_SETTING = "open_mid_setting";
    protected static final String CUSTOM_HEART_RATE = "custom_heart_rate";
    protected static final String SWIM_SINGLE_DISTANCE = "swim_single_distance";
    protected static final String ACTIVE_PEDOMETER_ID = "active_pedometer_id";

    private static final String GUIDE_LAST_GRADE_NO = "guide_last_grade_no";
    private static final String GUIDE_LAST_GRADE_DATE = "guide_last_grade_date";
    private static final String GUIDE_LAST_GRADE_ENCOURAGE_TIP = "guide_last_grade_encourage_tip";

    private static final String GUIDE_GRADE = "guide_grade";
    //锻炼首页引导
    private static final String GUIDE_SPORTS_ITEM_MAIN = "guide_sport_item_main";

    //运动首页引导
    private static final String GUIDE_SPORTS_RECORD_MAIN = "guide_sport_record_main";

    //运动tab引导
    private static final String GUIDE_SPORTS_TAB_MAIN = "guide_sport_tab_main";
    //睡眠截图分享引导
    private static final String GUIDE_SLEEP_SHARE= "guide_sleep_share";
    //第一次睡眠分>=80引导分享弹窗
    private static final String LEAD_SLEEP_SHARE= "guide_sleep_share";

    //豆腐块引导
    private static final String GUIDE_DATA_BLOCKS = "guide_data_blocks_";

    public static final int CHOOSE_PEDOMETER = 1;
    public static final int CHOOSE_PHONE = 0;
    /**
     * 是否第一次进入心率主页面
     */
    protected static final String PROPERTY_IS_FIRST_ENTRY_HEART = "is_first_entry_heart";

    public static boolean setIsFirstEntryHeart(boolean isFirstEntryHeart) {
        return setPropertyString(PROPERTY_IS_FIRST_ENTRY_HEART, isFirstEntryHeart ? "true" : "false");
    }

    public static boolean getIsFirstEntryHeart() {
        String isFinishString = getPropertyString(PROPERTY_IS_FIRST_ENTRY_HEART, "true");
        return !StringUtil.isEmptyOrNull(isFinishString) && isFinishString.equals("true");
    }

    /**
     * 2.8后是否第一次接收晨脉数据
     */
    protected static final String IS_FIRST_RECEIVE_MORNING_PULSE = "is_first_receive_morning_pulse";

    public static boolean setIsFirstReceiveMorningPulse(boolean isFirstReceiveMorningPulse) {
        return setPropertyString(IS_FIRST_RECEIVE_MORNING_PULSE, isFirstReceiveMorningPulse ? "true" : "false");
    }

    public static boolean getIsFirstReceiveMorningPulse() {
        String isFinishString = getPropertyString(IS_FIRST_RECEIVE_MORNING_PULSE, "true");
        return !StringUtil.isEmptyOrNull(isFinishString) && isFinishString.equals("true");
    }

    /**
     * 是否第一次接收过心率数据
     */
    protected static final String PROPERTY_IS_FIRST_RECEIVE_HEART = "is_first_receive_heart";

    public static boolean setIsFirstReceiveHeart(boolean hasReceveHeart) {
        return setPropertyString(PROPERTY_IS_FIRST_RECEIVE_HEART, hasReceveHeart ? "true" : "false");
    }

    public static boolean getIsFirstReceiveHeart() {
        String isFinishString = getPropertyString(PROPERTY_IS_FIRST_RECEIVE_HEART, "false");
        return !StringUtil.isEmptyOrNull(isFinishString) && isFinishString.equals("true");
    }

    /**
     * 是否已经展示过静息心率引导
     */
    protected static final String PROPERTY_IS_SHOW_SILENT_HEART = "is_show_silent_heart";

    public static boolean setHasShowSilentHeart(boolean hasShowSilentHeart) {
        return setPropertyString(PROPERTY_IS_SHOW_SILENT_HEART, hasShowSilentHeart ? "true" : "false");
    }

    public static boolean getHasShaowSilentHeart() {
        String isFinishString = getPropertyString(PROPERTY_IS_SHOW_SILENT_HEART, "false");
        return !StringUtil.isEmptyOrNull(isFinishString) && isFinishString.equals("true");
    }

    /**
     * 常规心率ts
     */
    protected static final String PROPERTY_SYNC_HEART_FIRST_TS = "sync_heart_first_ts";
    protected static final String PROPERTY_SYNC_HEART_HISTORY_TS = "sync_heart_history_ts";
    protected static final String PROPERTY_SYNC_HEART_NEW_DATA_TS = "sync_heart_new_data_ts";
    /**
     * 晨脉
     */
    protected static final String PROPERTY_SYNC_SILENT_HEART_DAY_NEW_DATA_TS = "sync_silent_heart_day_new_data_ts";
    protected static final String PROPERTY_SYNC_SILENT_HEART_DAY_HISTORY_TS = "sync_silent_heart_day_history_ts";
    protected static final String PROPERTY_SYNC_SILENT_HEART_DAY_FIRST_TS = "sync_silent_heart_day_first_ts";
    protected static final String PROPERTY_SYNC_SILENT_HEART_DAY_ORI_FIRST_TS = "sync_silent_heart_day_ori_first_ts";


    protected static final String PROPERTY_SYNC_SILENT_HEART_WEEK_NEW_DATA_TS = "sync_silent_heart_week_new_data_ts";
    protected static final String PROPERTY_SYNC_SILENT_HEART_WEEK_HISTORY_TS = "sync_silent_heart_week_history_ts";
    protected static final String PROPERTY_SYNC_SILENT_HEART_WEEK_FIRST_TS = "sync_silent_heart_week_first_ts";


    protected static final String PROPERTY_SYNC_USER_GROWTH_TREE_FIRST_TS = "sync_user_growth_tree_first_ts";
    protected static final String PROPERTY_SYNC_USER_GROWTH_TREE_HISTORY_TS = "sync_user_growth_tree_history_ts";
    protected static final String PROPERTY_SYNC_USER_GROWTH_TREE_NEW_DATA_TS = "sync_user_growth_tree_new_data_ts";



    /**
     * 运动心率ts
     */
    protected static final String PROPERTY_SYNC_SPORT_HEART_FIRST_TS = "sync_sport_heart_first_ts";
    protected static final String PROPERTY_SYNC_SPORT_HEART_HISTORY_TS = "sync_sport_heart_history_ts";
    protected static final String PROPERTY_SYNC_SPORT_HEART_NEW_DATA_TS = "sync_sport_heart_new_data_ts";

    /**
     * 步数ts
     *
     * @param firstTs
     */
//	protected static final String PROPERTY_SYNC_PEDOMETER_FIRST_TS = "sync_pedometer_first_ts";
//	protected static final String PROPERTY_SYNC_PEDOMETER_TS = "sync_pedometer_ts";
//	protected static final String PROPERTY_SYNC_STEP_History_DAY_TS = "sync_step_History_day_ts";

    // 3.1版本启用等系步数后要重新设置一下数据
    protected static final String PROPERTY_SYNC_PEDOMETER_FIRST_TS = "sync_pedometer_first_ts_31";
    protected static final String PROPERTY_SYNC_PEDOMETER_TS = "sync_pedometer_ts_31";
    protected static final String PROPERTY_SYNC_STEP_History_DAY_TS = "sync_step_History_day_ts_31";
    private static final String PROPERTY_SYNC_PEDOMETER_NEW_TS = "PROPERTY_SYNC_PEDOMETER_NEW_TS_31";


    /**
     * 跑步数据ts
     *
     * @param firstTs
     */
    protected static final String PROPERTY_SYNC_RUNDATA_FIRST_TS = "sync_rundata_first_ts";
    protected static final String PROPERTY_SYNC_NEW_RUNDATA_TS = "sync_new_rundata_ts";
    protected static final String PROPERTY_SYNC_HISTORY_RUNDATA_TS = "sync_History_rundata_ts";


    /**
     * 保存当前帐户memberid
     *
     * @param value
     * @return
     */
    public static boolean saveMemberId(String value) {
        return setPropertyString(PROPERTY_MEMBER_ID, value);
    }

    /**
     * 当前帐户memberid
     *
     * @param defaultValue
     * @return
     */
    public static String getMemberId(String defaultValue) {
        return getPropertyString(PROPERTY_MEMBER_ID, defaultValue);
    }

    /**
     * 保存当前帐户accountid
     *
     * @param value
     * @return
     */
    public static boolean saveAccountId(String value) {
        return setPropertyString(PROPERTY_ACCOUNT_ID, value);
    }

    public static boolean saveUnionId(String unionId) {
        return setPropertyString(PROPERTY_UNION_ID, unionId);
    }

    public static String getUnionId(String defaultValue) {
        return getPropertyString(PROPERTY_UNION_ID, defaultValue);
    }

    /**
     * 当前帐户ticket
     *
     * @param defaultValue
     * @return
     */
    public static String getAccountTicket(String defaultValue) {
        return getPropertyString(PROPERTY_ACCOUNT_TICKET, defaultValue);
    }

    public static boolean getDeviceUpdateNotShow(String deviceId, String version) {
        boolean ret = false;

        if (getPropertyString("getDeviceUpdateIsShow" + version + deviceId + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), "false")
                .equalsIgnoreCase("true")) {
            ret = true;
        }
        return ret;
    }

    public static void saveDeviceUpdateNotShow(String deviceId, String version) {
        setPropertyString("getDeviceUpdateIsShow" + version + deviceId + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), "true");
    }

    public static void saveAppVersionIgnore(String version) {
        setPropertyString("app_ignore_version", version);
    }

    public static String getAppVersionIgnore() {
        return getPropertyString("app_ignore_version", "");
    }

    /**
     * 保存当前帐户ticket
     *
     * @param value
     * @return
     */
    public static boolean saveAccountTicket(String value) {
        return setPropertyString(PROPERTY_ACCOUNT_TICKET, value);
    }

    /**
     * 保存当前帐户session
     *
     * @param value
     * @return
     */
    public static boolean saveAccountType(String value) {
        return setPropertyString(PROPERTY_ACCOUNT_TYPE, value);
    }

    /**
     * 当前帐户session
     *
     * @param defaultValue
     * @return
     */
    public static String getAccountType(String defaultValue) {
        return getPropertyString(PROPERTY_ACCOUNT_TYPE, defaultValue);
    }

    /**
     * 获取保存的语言
     *
     * @param defaultValue
     * @return
     */
    public static String getLanguage(String defaultValue) {
        return getPropertyString(PROPERTY_LANGUAGE, defaultValue);
    }

    /**
     * 保存语言
     *
     * @param value
     * @return
     */
    public static boolean saveLanguage(String value) {
        return setPropertyString(PROPERTY_LANGUAGE, value);
    }

    /**
     * 保存登录应用标记
     *
     * @return
     */
    public static boolean saveLaunched() {
        return setPropertyString(PROPERTY_LAUNCHED_STRING, "Launched");
    }


    public static boolean isShowOpenedRatingGuide() {
        String value = getPropertyString(PROPERTY_USER_OPENED_RATING, null);
        return !StringUtil.isEmptyOrNull(value) && value.equals("true");
    }


    public static String getPropertyString(String key, String defaultValue) {
        return PropertyPersistanceManager.getInstance().getString(key, defaultValue);
    }

    /**
     * 跟用户绑定
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public static long getPropertyLong(String key, long defaultValue) {
        //把存储的key 跟当前的userId 进行绑定，确保切换用户后每个ts都是新的
        return PropertyPersistanceManager.getInstance().getLong(key + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), defaultValue);
    }
    /**
     * 跟用户绑定
     *
     * @param key
     * @param value
     * @return
     */
    public static boolean setPropertyLong(String key, long value) {
        //把存储的key 跟当前的userId 进行绑定，确保切换用户后每个ts都是新的
        return PropertyPersistanceManager.getInstance().setLong(key + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), value);
    }

    public static boolean setPropertyString(String key, String value) {
        return PropertyPersistanceManager.getInstance().setString(key, value);
    }
}
