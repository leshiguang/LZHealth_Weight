package com.lifesense.weidong.lzbinddivicelibs.event;

/**
 * Create by qwerty
 * Create on 2020/6/17
 **/
public interface EventAction {
    String UPDATE_DEVICE_DETAILS_LIST_ACTION = "update_device_details_list_action";
}
