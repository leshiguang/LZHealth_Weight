package com.lifesense.weidong.lzbinddivicelibs.util;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


/**
 * Create by qwerty
 * Create on 2020/6/8
 **/
public class Task {
    private static volatile Executor executor;

    private Task() {
    }

    public static void execute(Runnable action) {
        getBgTaskExecutor().execute(action);
    }

    private static Executor getBgTaskExecutor() {
        if (executor == null) {
            synchronized(Task.class) {
                if (executor == null) {
                   executor = Executors.newCachedThreadPool();
                }
            }
        }
        return executor;
    }
}
