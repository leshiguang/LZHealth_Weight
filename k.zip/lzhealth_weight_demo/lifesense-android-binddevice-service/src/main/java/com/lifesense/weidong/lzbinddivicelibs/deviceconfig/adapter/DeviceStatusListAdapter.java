package com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter;

import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lifesense.ble.LsBleManager;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.logic.device.DeviceStateWrapper;

import java.util.Collections;

/**
 * Author:  winds
 * Email:   heardown@163.com
 * Date:    2019/9/12.
 * Desc:    手表和NB设备的判断 暂时根据设备型号判断   如若新接入需要主动补全判断的逻辑
 */
public class DeviceStatusListAdapter extends BaseQuickAdapter<DeviceStateWrapper, BaseViewHolder> {

    private DeviceStateWrapper connectingStateWrapper; //当前正在连接中的item

    public DeviceStatusListAdapter() {
        super(R.layout.item_device_status_list, null);
    }

    /**
     * 设置连接中状态
     *
     * @param wrapper
     */
    public void setConnectingStateWrapper(DeviceStateWrapper wrapper) {
        this.connectingStateWrapper = wrapper;
        notifyAdapterDataSetChanged();
    }

    /**
     * 连接成功 取消连接状态
     */
    public void setConnectingSuccess() {
        setConnectingStateWrapper(null);
    }

    /**
     * 设置当前设备已完成
     */
    public void setPedometerConnected() {
        setConnectingSuccess();
//        if(connectingStateWrapper != null && connectingStateWrapper.isPedometer()) {
//            setConnectingSuccess();
//        }
    }

    /**
     * 连接失败 取消连接状态
     */
    public void setConnectingFailed() {
        setConnectingStateWrapper(null);
    }

    public void notifyAdapterDataSetChanged() {
        Collections.sort(getData());
        notifyDataSetChanged();
    }


    @Override
    protected void convert(BaseViewHolder helper, DeviceStateWrapper item) {
        helper.setGone(R.id.tv_retry_connect, false);   //重连view
        helper.setGone(R.id.tv_device_battery, false);  //电池电量描述
        helper.setGone(R.id.iv_device_battery, false);  //电池电量图片
        helper.setGone(R.id.layout_connecting, false); //连接中view

        helper.setText(R.id.tv_name, item.getDevice().getName()); //设备名称
        ImageUtil.disableImage(getDefaultImgUrl(item.getDevice().getImgUrl()), (ImageView) helper.getView(R.id.iv_device), R.mipmap.ic_place_holder); //设备图片

        if (item.isWeight()) { //秤
            convertWeight(helper, item);
        } else {
            convertDevice(helper, item);
        }

        if (connectingStateWrapper != null && (connectingStateWrapper == item || connectingStateWrapper.getDevice() == item.getDevice() || connectingStateWrapper.getDeviceId() == item.getDeviceId())) {
            //当前设备是正在连接的设备
            if (item.getDevice().isBluetooth() && LsBleManager.getInstance().isOpenBluetooth()) {
                if (!item.isConnected()) {
                    helper.setGone(R.id.tv_retry_connect, false);   //重连view
                    helper.setGone(R.id.tv_device_battery, false);  //电池电量描述
                    helper.setGone(R.id.iv_device_battery, false);  //电池电量图片
                    helper.setGone(R.id.layout_connecting, true); //连接中view
                }
            }
        }

//        helper.addOnClickListener(R.id.tv_retry_connect);
    }

    /**
     * 获取无阴影的设备图片
     */
    public String getDefaultImgUrl(String imgUrl) {
        String shadowImgUrl = imgUrl;
        if (shadowImgUrl != null && shadowImgUrl.lastIndexOf(",") != -1) {
            shadowImgUrl = shadowImgUrl.substring(0, shadowImgUrl.lastIndexOf(","));
        }
        return shadowImgUrl;
    }
    /**
     * 展示体重秤/体脂秤
     *
     * @param helper
     * @param item
     */
    private void convertWeight(BaseViewHolder helper, DeviceStateWrapper item) {
        if (item.getDevice().isBluetooth()) { //支持蓝牙
            if (LsBleManager.getInstance().isOpenBluetooth()) { //蓝牙已打开
                if (item.isConnected()) { //设备已连接
                    helper.setText(R.id.tv_connect_status, R.string.s_bluetooth_connected); //连接状态文字
                    helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_bluetooth_connected); //连接状态图片
                } else {
                    //设备未连接
                    helper.setGone(R.id.tv_retry_connect, true); //重连文字显示状况
                    helper.setText(R.id.tv_retry_connect, R.string.s_retry_connected); //重连文字
                    helper.setText(R.id.tv_connect_status, R.string.s_bluetooth_disconnect);  //连接状态文字
                    helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_bluetooth_disconnect); //连接状态图片
                }
            } else {
                //蓝牙未打开或无权限
                helper.setGone(R.id.tv_retry_connect, true);
                helper.setText(R.id.tv_retry_connect, R.string.s_retry_connected); //重连文字
                helper.setText(R.id.tv_connect_status, R.string.s_bluetooth_disconnect);  //连接状态文字
                helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_bluetooth_disconnect); //蓝牙未打开或者无权限图片
            }
        } else {//其他
            convertDevice(helper, item);
        }
    }

    private void convertDevice(BaseViewHolder helper, DeviceStateWrapper item) {
//        if (item.getDevice().isGprs()) {
//            convertGPRSDevice(helper, item);
//        } else if (item.getDevice().isWifi()) {
//            convertWifiDevice(helper, item);
//        } else if (item.isNB()) {
//            convertNBDevice(helper, item);
//        } else {
            convertUnknownDevice(helper, item);
//        }
    }

    private void convertGPRSDevice(BaseViewHolder helper, DeviceStateWrapper item) {
        helper.setText(R.id.tv_connect_status, mContext.getString(R.string.s_type_gprs));  //连接状态文字
        helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_gprs_state_connected); //连接状态图片
    }

    private void convertWifiDevice(BaseViewHolder helper, DeviceStateWrapper item) {
        helper.setText(R.id.tv_connect_status, mContext.getString(R.string.s_type_wifi));  //连接状态文字
        helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_wifi_state_connected); //连接状态图片
    }

    private void convertNBDevice(BaseViewHolder helper, DeviceStateWrapper item) {
        helper.setText(R.id.tv_connect_status, mContext.getString(R.string.s_type_nb));  //连接状态文字
        helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_gprs_state_connected); //连接状态图片
    }

    private void convertUnknownDevice(BaseViewHolder helper, DeviceStateWrapper item) {
        helper.setText(R.id.tv_connect_status, mContext.getString(R.string.already_bind_device));  //连接状态文字
        helper.setImageResource(R.id.iv_connect_status, R.mipmap.ic_cloud_state_connected); //连接状态图片
    }
}
