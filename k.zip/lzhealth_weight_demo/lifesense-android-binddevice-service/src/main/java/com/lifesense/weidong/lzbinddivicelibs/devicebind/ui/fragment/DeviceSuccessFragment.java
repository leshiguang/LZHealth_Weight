package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.jumpaction.LSActionPerformerManager;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity.DeviceWebViewActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.ui.activity.DeviceDetailsActivity;
import com.lifesense.weidong.lzbinddivicelibs.util.DeviceUtils;

import static com.lifesense.weidong.lzbinddivicelibs.util.DeviceUtils.getDeviceInfoIntent;

/**
 * 设备绑定成功展示
 */
@SuppressLint("ValidFragment")
public class DeviceSuccessFragment extends BaseFragment {
    private ImageView ivDeviceIcon;
    private TextView tvInvite;
    private String imgUrl;
    private LSEDeviceInfoApp lseDeviceInfoApp;
    private Device device;

    public static DeviceSuccessFragment newInstance(String imgUrl, LSEDeviceInfoApp lseDeviceInfoApp, Device device) {
        DeviceSuccessFragment fragment = new DeviceSuccessFragment();
        Bundle bundle = new Bundle();
        bundle.putString("imgUrl", imgUrl);
        bundle.putParcelable("lseDeviceInfoApp", lseDeviceInfoApp);
        bundle.putParcelable("device", device);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static DeviceSuccessFragment newInstance(String imgUrl, Device device) {
        DeviceSuccessFragment fragment = new DeviceSuccessFragment();
        Bundle bundle = new Bundle();
        bundle.putString("imgUrl", imgUrl);
        bundle.putParcelable("device", device);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        if(bundle != null) {
            this.imgUrl = bundle.getString("imgUrl");
            this.lseDeviceInfoApp = bundle.getParcelable("lseDeviceInfoApp");
            this.device = bundle.getParcelable("device");
        }
        return inflater.inflate(R.layout.fragment_device_success, null);
    }

    @Override
    protected void initData() {
        ivDeviceIcon = getActivity().findViewById(R.id.ivDeviceIcon);
        tvInvite = getActivity().findViewById(R.id.tv_invite);
        TextView tvHowToUse = getActivity().findViewById(R.id.tvHowToUse);
        tvInvite.setOnClickListener(this);
        TextView tvBottom = getActivity().findViewById(R.id.tvBottom);
        tvBottom.setOnClickListener(this);
        tvHowToUse.setOnClickListener(this);
        ((OlderBaseActivity) getActivity()).setHeader_Title(getString(R.string.device_search_connect_title));

        if (device == null){
            getActivity().finish(); //不处理会导致点击事件存在问题
            return;
        }

        //转向操作指南
        tvHowToUse.setText(getString(R.string.how_to_use_device));
        tvBottom.setText(R.string.device_success);

        ImageUtil.displayImage(imgUrl, ivDeviceIcon);

        ToastUtil.showCenterToast(getStringById(R.string.bind_successful));

    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.tvBottom) {
//            LogicServicess.shareInstance().getDeviceManager().notifySyncObserver();

            Intent intent = getDeviceInfoIntent(getActivity(), device);
            getActivity().startActivityForResult(DeviceDetailsActivity.makeIntent(getContext(),device.getId()), Activity.RESULT_OK);
            getActivity().setResult(Activity.RESULT_OK);
            getActivity().finish();
        } else if (i == R.id.tvHowToUse) {
            if (device == null) {
                return;
            }
            String deviceId = device.getId();
            String url = DeviceUtils.getDeviceOperationGuideUrl(device);
            LSActionPerformerManager.getInstance().sendAction(DeviceWebViewActivity.makeActivityAction(mContext, getString(R.string.device_work), url, deviceId));
        }
    }
}
