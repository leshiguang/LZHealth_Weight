package com.lifesense.weidong.lzbinddivicelibs.devicebind.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.BaseAdapter;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;

import java.util.List;

public class FindDeviceResultAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater mInflater;
    private List<LSEDeviceInfoApp> list;

    public FindDeviceResultAdapter(Context context, List<LSEDeviceInfoApp> data) {
        super(context);
        list = data;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.listview_find_device_result_item, parent, false);
            holder = new ViewHolder();
            holder.textView = convertView.findViewById(R.id.textView);
            holder.checkBox = convertView.findViewById(R.id.checkbox);
            holder.tvTip = convertView.findViewById(R.id.tvTip);
            holder.viewBottomLine = convertView.findViewById(R.id.viewBottomLine);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectItem(position);
            }
        });

        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectItem(position);
            }
        });
//        if("qa".equals(BuildConfig.FLAVOR) || "dev".equals(BuildConfig.FLAVOR)){
//            holder.textView.setText(list.get(position).getDeviceName()+" ("+list.get(position).getMacAddress()+")");
//        }else{
            holder.textView.setText(list.get(position).getDeviceName());
//        }
        holder.checkBox.setSelected(list.get(position).isCheck());
        //@@：需求3196，去掉离我最近
        if (position == 0) {
            holder.tvTip.setVisibility(View.VISIBLE);
        } else {
            holder.tvTip.setVisibility(View.INVISIBLE);
        }

        if (position == list.size() - 1) {
            holder.viewBottomLine.setVisibility(View.INVISIBLE);
        } else {
            holder.viewBottomLine.setVisibility(View.VISIBLE);
        }
        return convertView;
    }

    private void selectItem(int position) {

        for (int i = 0; i < list.size(); i++) {
            list.get(i).setCheck(false);
        }
        list.get(position).setCheck(!list.get(position).isCheck());
        notifyDataSetChanged();
    }

    class ViewHolder {
        ImageView checkBox;
        TextView tvTip;
        TextView textView;
        View viewBottomLine;

    }
}
