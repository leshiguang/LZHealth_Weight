//package com.lifesense.weidong.lzbinddivicelibs.activity;
//
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Parcelable;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.ListView;
//import android.widget.TextView;
//
//import com.lifesense.ble.bean.constant.DeviceUpgradeStatus;
//import com.lifesense.component.devicemanager.bean.FirmwareInfo;
//import com.lifesense.component.devicemanager.database.entity.Device;
//import com.lifesense.component.devicemanager.manager.DeviceManager;
//import com.lifesense.weidong.lswebview.util.ToastUtil;
//import com.lifesense.weidong.lzbinddivicelibs.R;
//import com.lifesense.weidong.lzbinddivicelibs.deviceota.adapter.UpdateInfoAdapter;
//import com.lifesense.weidong.lzbinddivicelibs.activity.base.BaseActivity;
//import com.lifesense.weidong.lzbinddivicelibs.util.ConditionHelper;
//import com.lifesense.weidong.lzbinddivicelibs.util.DeviceUtils;
//import com.lifesense.weidong.lzbinddivicelibs.widget.dialog.DialogOpenBle;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
//
//public class ShowDeviceUpdateInfoActivity extends BaseActivity {
//
//
//    private static final String EXTAR_DEVICE = "extra_device";
//    private static final String EXTRA_DATA = "RESULT_DATA";
//    public static final int REQ_UPGRADE_CODE = 123;
//    private static String extra_data_info = "EXTRA_DATA";
//    private ImageView mAduUpgradeIv;
//    private TextView mAduVersionTv;
//    private TextView mAduUpgradeTitleTv;
//    private ListView mAduContentLv;
//    private View mAduUpgradeBtn;
//    private FirmwareInfo mFirmwareInfo;
//    private Device mDevice;
//
//    public static Intent makeIntent(Context mContext, FirmwareInfo firmwareInfo, Device device) {
//        return new Intent(mContext, ShowDeviceUpdateInfoActivity.class).putExtra(extra_data_info, (Parcelable) firmwareInfo).putExtra(EXTAR_DEVICE, device);
//    }
//
//    public static Intent makeDownloadFailIntent() {
//        return new Intent().putExtra(EXTRA_DATA, false);
//    }
//
//    @Override
//    protected void initHeader() {
//        setHeaderBackground(R.color.ota_blue);
//        setHeader_LeftImage(R.drawable.btn_back);
//        setHeader_Title(getString(R.string.title_device_update));
//        setTitleLineVisibility(View.GONE);
//        setHeader_Title_Color(getResources().getColor(R.color.white));
//    }
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setCenterView(R.layout.activity_device_update);
//        initView();
//    }
//
//
//    public void initView() {
//        mAduUpgradeIv = findViewById(R.id.adu_upgrade_iv);
//        mAduVersionTv = findViewById(R.id.adu_version_tv);
//        mAduUpgradeTitleTv = findViewById(R.id.adu_upgrade_title_tv);
//        mAduContentLv = findViewById(R.id.adu_content_lv);
//        mAduUpgradeBtn =  findViewById(R.id.adu_upgrade_btn);
//        mAduUpgradeBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onUpgradeClick(v);
//            }
//        });
//
//        mFirmwareInfo = getIntent().getParcelableExtra(extra_data_info);
//        mDevice = getIntent().getParcelableExtra(EXTAR_DEVICE);
//
//
//        if (mFirmwareInfo == null) {
//            finish();
//            return;
////            mFirmwareInfo = new FirmwareInfo();
////            mFirmwareInfo.setModel("Mambo");
////            mFirmwareInfo.setSoftwareVersion("2.1");
////            mFirmwareInfo.setName("LS405_B6_A081.hex");
////            mFirmwareInfo.setDescribe("这个是测试内容1;这个是测试内容2;这个是测试内容3;这个是测试内容4;这个是测试内容5;这个是测试内容6");
////            mFirmwareInfo.setFileUrl("http://7xl9zd.com1.z0.glb.clouddn.com/LS405_B6_20160201_1147.jpg");
////            adcUpdateTitle.setText(String.format("发现%s 更新", mFirmwareInfo.getModel()));
//        }
//        mAduVersionTv.setText(mDevice.getName() + "\n" + mFirmwareInfo.getSoftwareVersion());
//
//        String[] updateInfoArr = mFirmwareInfo.getDescribe().split("；");
//        UpdateInfoAdapter adapter = new UpdateInfoAdapter(this);
//        mAduContentLv.setAdapter(adapter);
//        List<String> data = new ArrayList<>();
//        if (updateInfoArr.length > 0) {
//            Collections.addAll(data, updateInfoArr);
//            adapter.changeList(data);
//        }
//    }
//
//    public void onUpgradeClick(View view) {
//
//        ConditionHelper.ConditionState state = ConditionHelper.checkEvir(mDevice.getId());
//        if (state.getState() != ConditionHelper.ConditionState.STATE_SUCCESS) {
//
//            if (state.getState() == ConditionHelper.ConditionState.STATE_BLE_OFF) {
//                DialogOpenBle dialogOpenBle = DialogOpenBle.newInstance();
//                dialogOpenBle.show(getSupportFragmentManager(), "");
//                return;
//            }
//
//            if (DeviceUtils.isSupportInterruptUpgrade(mDevice.getSaleType())) {
//                ToastUtil.showShortToast(mContext,mContext.getResources().getString(state.getReasonString()));
//                if (mDevice.isAlipayCard()) {
//                    if (state.getState() == ConditionHelper.ConditionState.STATE_BLE_OFF
//                            || state.getState() == ConditionHelper.ConditionState.STATE_DEVICE_CONNECT_OFF
//                            ) {
//                        setResult(RESULT_FIRST_USER);
//                        finish();
//                    }
//                }
//                return;
//            }
//
//            if (state.getState() == ConditionHelper.ConditionState.STATE_DEVICE_CONNECT_OFF) {
//                //非ota失败导致无法连接的手环，没连接上的不给过
//                boolean isSucceed = DeviceManager.getInstance().getDeviceOTAStatus(mDevice.getId()) != DeviceUpgradeStatus.UPGRADE_FAILURE;
//                if (isSucceed || DeviceUtils.isSupportInterruptUpgrade(mDevice.getSaleType())) {//如果是 watch必须保持连接才能升级
//                    ToastUtil.showShortToast(mContext,mContext.getResources().getString(state.getReasonString()));
//
//                    return;
//                }
//            }
//        }
//        startActivityForResult(StartUpdateActivity.makeIntent(this, mDevice, mFirmwareInfo), REQ_UPGRADE_CODE);
//
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == REQ_UPGRADE_CODE) {
//            if (resultCode == RESULT_OK) {
//                setResult(REQ_UPGRADE_CODE);
//                finish();
//            } else if (RESULT_CANCELED == resultCode) {
//                ToastUtil.showNew();
//            } else if (resultCode == RESULT_FIRST_USER) {
//                setResult(RESULT_FIRST_USER);
//                finish();
//            }
//        }
//    }
//}
