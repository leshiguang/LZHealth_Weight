package com.lifesense.weidong.lzbinddivicelibs.util;

import android.text.TextUtils;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.foundation.config.SharedPreferencesConfig;
import com.lifesense.utils.PreferencesUtils;
import com.lifesense.utils.StringUtil;

import java.text.DecimalFormat;
import java.util.Locale;

import static com.lifesense.weidong.lzbinddivicelibs.util.UnitUtil.WeightUnit.JIN;
import static com.lifesense.weidong.lzbinddivicelibs.util.UnitUtil.WeightUnit.KG;
import static com.lifesense.weidong.lzbinddivicelibs.util.UnitUtil.WeightUnit.LB;
import static com.lifesense.weidong.lzbinddivicelibs.util.UnitUtil.WeightUnit.ST;

/**
 * Created by jiale.chen on 17/6/26.
 */
public class UnitUtil {
    public static final int MAX_WEIGHT_LB = 330;
    public static final int MIN_WEIGHT_KG = 1;

    public static LengthUnit getLengthUnit() {
        int code = SharedPreferencesConfig.getInstance().getInt(SP_UNIT_NAME, KEY_LENGTH_UNIT + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId",""), 0);
       try{
           if (TextUtils.isEmpty(PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId",""))) {
               code = 0;
           }
           if (code == 0) {

//               String name = CountryUtils.getCountryAreaShortName();
//               if ("US".equalsIgnoreCase(name)) {
                   code = LengthUnit.IMPERIAL.getCode();
//               }
           }
       }catch (Exception e){

       }

        return LengthUnit.getInstance(code);
    }


    public enum Unit {
        //公制
        INTERNATION("internation"),
        //英制
        IMPERIAL("imperial");

        private String unit;

        Unit(String unit) {
            this.unit = unit;
        }

        public String getUnit() {
            return unit;
        }

        public static Unit getInstance(String unit) {
            if (INTERNATION.getUnit().equals(unit)) {
                return INTERNATION;
            } else if (IMPERIAL.getUnit().equals(unit)) {
                return IMPERIAL;
            } else {
                return INTERNATION;
            }
        }
    }

    public enum WeightUnit {
        KG(" kg ", 1), LB(" lb ", 3), ST(" st ", 4), JIN(" jin ", 2);

        private String unit;
        private int code;

        WeightUnit(String unit, int code) {
            this.unit = unit;
            this.code = code;
        }

        public int getCode() {
            return code;
        }

        public String getUnit() {

//            if (LifesenseApplication.isZh()) {
//                if (this == WeightUnit.LB) {
//                    return LifesenseApplication.getApp().getString(R.string.lb);
//                }
//                if (this == WeightUnit.JIN) {
//                    return LifesenseApplication.getApp().getString(R.string.jin);
//                }
//                if (this == WeightUnit.ST) {
//                    return LifesenseApplication.getApp().getString(R.string.lb);
//                }
//                if (this == WeightUnit.KG) {
//                    return LanguageUtil.getSpace() +
//                            LifesenseApplication.getApp().getString(R.string.kg)
//                            + LanguageUtil.getSpace();
//                }
//            } else {
                if (this == ST) {
                    return LB.unit;
                }
//            }

            return unit;
        }

        public static WeightUnit getInstance(String unit) {
            if (KG.getUnit().trim().equals(unit.trim())) {
                return KG;
            } else if (LB.getUnit().trim().equals(unit.trim())) {
                return LB;
            } else if (JIN.getUnit().trim().equals(unit.trim())) {
                return JIN;
            } else if (ST.getUnit().trim().equals(unit.trim())) {
                return ST;
            } else {
                return KG;
            }
        }

        public static WeightUnit getInstance(int type) {
            if (KG.getCode() == type) {
                return KG;
            } else if (LB.getCode() == type) {
                return LB;
            } else if (JIN.getCode() == type) {
                return JIN;
            } else if (ST.getCode() == type) {
                return ST;
            } else {
                return KG;
            }
        }
    }

    public static final int LENGTH_TYPE_CM = 0;
    public static final int LENGTH_TYPE_KM = 1;

    public enum LengthUnit {
        INTERNATION(1), IMPERIAL(2);

        private int code;

        LengthUnit(int code) {
            this.code = code;
        }

        /**
         * @param type 0 用在体围  英寸/厘米  in/cm
         *             1 用在运动锻炼   英里/公里 mile/km
         * @return
         */
        public String getUnit(int type) {
            StringBuilder stringBuilder = new StringBuilder();
//            switch (type) {
//                case LENGTH_TYPE_CM:
//                    if (this == LengthUnit.INTERNATION) {
//                        stringBuilder.append(LanguageUtil.getSpace());
//                        stringBuilder.append(LifesenseApplication.getApp().getResources().getString(R.string.unit_cm));
//                        stringBuilder.append(LanguageUtil.getSpace());
//                    } else {
//                        stringBuilder.append(LanguageUtil.getSpace());
//                        stringBuilder.append(LifesenseApplication.getApp().getResources().getString(R.string.unit_in));
//                        stringBuilder.append(LanguageUtil.getSpace());
//                    }
//                    break;
//                case LENGTH_TYPE_KM:
//                    if (this == LengthUnit.INTERNATION) {
//                        stringBuilder.append(LanguageUtil.getSpace());
//                        stringBuilder.append(LifesenseApplication.getApp().getResources().getString(R.string.unit_km));
//                        stringBuilder.append(LanguageUtil.getSpace());
//                    } else {
//                        stringBuilder.append(LanguageUtil.getSpace());
//                        stringBuilder.append(LifesenseApplication.getApp().getResources().getString(R.string.unit_mile));
//                        stringBuilder.append(LanguageUtil.getSpace());
//                    }
//                    break;
//            }
            return stringBuilder.toString();
        }

        public int getCode() {
            return code;
        }

        public static LengthUnit getInstance(int code) {
            if (INTERNATION.code == code) {
                return INTERNATION;
            } else if (IMPERIAL.code == code) {
                return IMPERIAL;
            } else {
                return INTERNATION;
            }
        }
    }


    /**
     * lb -> kg
     *
     * @param pound
     * @return
     */
    public static double poundToKg(double pound) {
        double poundToKg = 0.45359237;
        double kg = pound * poundToKg;
        if (kg < MIN_WEIGHT_KG) {
            kg = MIN_WEIGHT_KG;
        }
        return Double.parseDouble(com.lifesense.utils.StringUtil.doubleFormatStringWithDecimalOptional(2, kg));
    }

    /**
     * lb -> st
     *
     * @param pound
     * @return
     */
    public static double[] poundToSt(double pound) {
        double[] doubles = new double[2];
        int st = (int) (pound / 14);
        doubles[0] = st;
        double po = pound % 14;// - (14f * (float)st);
        doubles[1] = po;
        return doubles;
        // 14.9  0.149   1.9   019

//        return Double.parseDouble(com.lifesense.utils.StringUtil.doubleFormatStringWithDecimalOptional(2, kg));
    }

    /**
     * st->pound
     *
     * @param st 比如10.10  那么就是10st 10lb= 10*14+10;
     * @return
     */
    public static double stToPound(double st) {
        String valueStr = String.valueOf(st);
        String[] strings = valueStr.split(".");
        double pou = 0;
        if (strings.length == 0) {
            return st;
        }
        if (strings.length == 2) {
            pou = Double.parseDouble(strings[0]) * 14 + Double.parseDouble(strings[1]) * 100;
        } else {
            String pound = strings[0];
            pou = Double.parseDouble(pound) * 14;
        }
        return pou;
    }

    public static double kgToPound(double kg, String deviceId) {
        if (deviceId == null || deviceId.equals("")) {
            return kgToPound(kg);
        } else {
            //分度0.2
            double kgToPound = 1.1023;
            double pound = kg * kgToPound;
            if (pound > MAX_WEIGHT_LB) {
                pound = MAX_WEIGHT_LB;
            }
            String kgStr = StringUtil.doubleFormatString(1,pound);
            return Double.parseDouble(kgStr) * 2;
        }
    }

    /**
     * kg -> lb
     * 分度：0.1
     *
     * @param kg
     * @return
     */
    public static double kgToPound(double kg) {
        double kgToPound = 2.2046;//2.2046  秤上面是这个系数
        double pound = kg * kgToPound;
        if (pound > MAX_WEIGHT_LB) {
            pound = MAX_WEIGHT_LB;
        }
        return Double.parseDouble(com.lifesense.utils.StringUtil.doubleFormatStringWithDecimalOptional(1, pound));
    }

    /**
     * ft -> cm
     *
     * @param ft
     * @return
     */
    public static double ftToCm(double ft) {
        double ftToCm = 30.48;
        double ftData = ft * ftToCm;
        String ftStr = StringUtil.doubleFormatString(1,ftData);
        return Double.parseDouble(ftStr);
    }


    /**
     * cm -> ft
     *
     * @param cm
     * @return
     */
    public static double cmToFt(double cm) {
        double cmToFt = 0.0328084;
        double cmData = cm * cmToFt;
        String ftStr = StringUtil.doubleFormatString(1,cmData);
        return Double.parseDouble(ftStr);
    }

    /**
     * cm -> in
     *
     * @param cm
     * @return
     */
    public static double cmToIn(double cm) {
        double cmToIn = 0.3937008;
        double cmData = cm * cmToIn;
        String inStr = StringUtil.doubleFormatString(1,cmData);
        return Double.parseDouble(inStr);
    }

    public static int[] cmToFt2(double cm) {
        double in = cmToIn(cm);
        int[] ints = new int[3];
        ints[0] = (int) (in / 12);

        double yuIn = in-(ints[0]*12);
        ints[1] = (int) yuIn;
        String s = StringUtil.doubleFormatString(1, yuIn);
        if (s.contains(".")) {
            String d = s.substring(s.indexOf(".") + 1);
            ints[2] = Integer.parseInt(d);
        }
        return ints;
    }

    public static double ftToIn(double ft) {
        double ftToIn = 12;
        double ftData = ft * ftToIn;
        String inStr = StringUtil.doubleFormatString(1,ftData);
        return Double.parseDouble(inStr);
    }

    public static double inToFt(double in) {
        double inToFt = 0.0833333;
        double inData = in * inToFt;
        String ftStr = StringUtil.doubleFormatString(1,inData);
        return Double.parseDouble(ftStr);
    }

    public static double kmTomi(double km) {
        double kmToMi = 0.6213712;
        double miData = km * kmToMi;
        String ftStr = StringUtil.doubleFormatString(2,miData);
        return Double.parseDouble(ftStr);
    }

    public static double miToKm(double mi) {
        double miToKm = 1.609344;
        double kmData = mi * miToKm;
        String ftStr = StringUtil.doubleFormatString(2,kmData);
        return Double.parseDouble(ftStr);
    }

    /**
     * in -> cm
     *
     * @param in
     * @return
     */
    public static double inToCm(double in) {
        double inToCm = 2.54;
        double inData = in * inToCm;
        String cmStr = StringUtil.doubleFormatString(1,inData);
        return Double.parseDouble(cmStr);
    }

    public static WeightUnit getWeightUnit() {
        int code = SharedPreferencesConfig.getInstance().getInt(SP_UNIT_NAME, KEY_WEIGHT_UNIT + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), 0);
        if(PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId","0").equals("0")){
            code=0;
        }
        if (code == 0) {
//            String name = CountryUtils.getCountryAreaShortName();
//            if ("US".equalsIgnoreCase(name)) {
                code = LB.getCode();
//            }
        }
        return WeightUnit.getInstance(code);
    }

    public static double lengthValuewTransform(LengthUnit oldUnit, LengthUnit unit, int type, double value) {
        if (type == LENGTH_TYPE_CM) {
            if (oldUnit == LengthUnit.INTERNATION && unit == LengthUnit.IMPERIAL) {
                return cmToIn(value);
            }
            if (oldUnit == LengthUnit.IMPERIAL && unit == LengthUnit.INTERNATION) {
                return inToCm(value);
            }
        } else {
            if (oldUnit == LengthUnit.INTERNATION && unit == LengthUnit.IMPERIAL) {
                return kmTomi(value);
            }
            if (oldUnit == LengthUnit.IMPERIAL && unit == LengthUnit.INTERNATION) {
                return miToKm(value);
            }
        }
        return value;
    }



    public static int[] kgToSt(double value) {
        int[] ints = new int[3];
        double pound = kgToPound(value);
        double[] doubles = poundToSt(pound);
        ints[0] = (int) doubles[0];
        double stPou = doubles[1];
        ints[1] = (int) stPou;
        String s = StringUtil.doubleFormatString(1, stPou);
        if (s.contains(".")) {
            String d = s.substring(s.indexOf(".") + 1);
            ints[2] = Integer.parseInt(d);
        }

        return ints;
    }

    /**
     * 默认带单位的
     *
     * @param type
     * @param value
     * @return
     */
    public static String getLengthUnitInfo(int type, double value) {
        return getLengthUnitInfo(LengthUnit.INTERNATION, type, value, true);
    }

    public static String getLengthUnitInfo(int type, double value, boolean isUnit) {
        return getLengthUnitInfo(LengthUnit.INTERNATION, type, value, isUnit);
    }

    public static String getLengthUnitInfo(LengthUnit oldUnit, int type, double value, boolean isUnit) {
        LengthUnit currentUnit = getLengthUnit();// WeightUnit.valueOf(SharedPreferencesConfig.getInstance().getString(LSConstant.KEY_WEIGHT_UNIT + LifesenseApplication.getCurrentUserId(), KG.getUnit()));
        StringBuilder info = new StringBuilder();
        double ds = lengthValuewTransform(oldUnit, currentUnit, type, value);
        info.append(StringUtil.numberFormatStringWithDecimalOptional(2, ds));
        if (isUnit) {
            info.append(currentUnit.getUnit(type));
        }

        return info.toString();
    }

    /**
     * V4.0 个人信息 获取 带单位 整数 体重
     * */
    public static String getWeightStr(double mUserWeight) {
        WeightUnit currentUnit = getWeightUnit();
        if (ST == currentUnit) {//  st 转为 lb
            currentUnit = LB;
        }
        StringBuilder info = new StringBuilder();
        double ds = weightValueTransform(mUserWeight, KG, currentUnit);
//        info.append(NumberUtils.halfUpInt(ds));
        info.append(ds);
        info.append(currentUnit.getUnit());
        return info.toString();
    }

    public static String getWeightUnitInfo(double value) {
        return getWeightUnitInfo(KG, value, 1, true);
    }

    public static String getWeightUnitInfo(double value, boolean isUnit) {
        return getWeightUnitInfo(KG, value, 1, isUnit);
    }


    /**
     * 输入KG单位
     *
     * @param kg
     * @return 转换成当前用户单位
     */
    public static double getWeightByUnit(double kg) {
        WeightUnit currentUnit = getWeightUnit();// WeightUnit.valueOf(SharedPreferencesConfig.getInstance().getString(LSConstant.KEY_WEIGHT_UNIT + LifesenseApplication.getCurrentUserId(), KG.getUnit()));
        if (currentUnit == LB) {
            return kgToPound(kg);
        } else if (currentUnit == JIN) {
            return kg * 2f;
        } else if (currentUnit == ST) {
            return kgToPound(kg);
        }

        return kg;
    }
    public static double getDistanceByUnit(double km) {
        LengthUnit currentUnit = getLengthUnit();// WeightUnit.valueOf(SharedPreferencesConfig.getInstance().getString(LSConstant.KEY_WEIGHT_UNIT + LifesenseApplication.getCurrentUserId(), KG.getUnit()));
        if(currentUnit== LengthUnit.IMPERIAL){
            return kmTomi(km);
        }

        return km;
    }
    public static double getCurrentUnit2KgUnit(double value) {
        WeightUnit currentUnit = getWeightUnit();// WeightUnit.valueOf(SharedPreferencesConfig.getInstance().getString(LSConstant.KEY_WEIGHT_UNIT + LifesenseApplication.getCurrentUserId(), KG.getUnit()));
        if (currentUnit == LB) {
            return poundToKg(value);
        } else if (currentUnit == JIN) {
            return value / 2f;
        } else if (currentUnit == ST) {
            return poundToKg(value);
        }
        return value;
    }

    public static String getWeightUnitInfo(WeightUnit oldUnit, double value, int num,
                                           boolean isUnit) {
        WeightUnit currentUnit = getWeightUnit();// WeightUnit.valueOf(SharedPreferencesConfig.getInstance().getString(LSConstant.KEY_WEIGHT_UNIT + LifesenseApplication.getCurrentUserId(), KG.getUnit()));
        StringBuilder info = new StringBuilder();
        double ds = weightValueTransform(value, oldUnit, currentUnit);
        info.append(StringUtil.doubleFormatString(1, ds));
        if (isUnit) {
            if (getWeightUnit() == ST) {
                currentUnit = LB;
            }
            info.append(currentUnit.getUnit());
        }
        return info.toString();
    }

    /**
     * 重量数值的单位转换，不止包括体重，只要涉及到重量的单位
     *
     * @param value
     * @param originUnit
     * @param currentUnit
     * @return
     */
    private static double weightValueTransform(double value, WeightUnit originUnit, WeightUnit
            currentUnit) {
        double cast;
        if (KG == originUnit && LB == currentUnit) {
            cast = kgToPound(value);
            return cast;
        } else if (KG == originUnit && currentUnit == JIN) {
            cast = value * 2f;
        } else if (KG == originUnit && ST == currentUnit) {
            cast = kgToPound(value);
        } else if (JIN == originUnit && KG == currentUnit) {
            cast = value / 2f;
        } else if (LB == originUnit && KG == currentUnit) {
            cast = poundToKg(value);
        } else if (ST == originUnit && KG == currentUnit) {
            double pou = stToPound(value);
            cast = poundToKg(pou);
        } else {
            cast = value;
        }
        return cast;
    }


    public static Unit getUnit() {
        return Unit.INTERNATION;
    }



    public static String decimalFormatWeight(double weight, WeightUnit weightUnit) {
        return StringUtil.doubleFormatString( 1,weight);
    }

    public static String decimalFormat(double number) {
        return DecimalFormat.getNumberInstance(Locale.ENGLISH).format(number);
    }

    public static final String SP_UNIT_NAME = "lifesense_unit";
    public static final String KEY_WEIGHT_UNIT = "key_weight_unit";
    public static final String KEY_LENGTH_UNIT = "key_length_unit";

    public static void setWeightUnit(int code) {
        SharedPreferencesConfig.getInstance().setInt(SP_UNIT_NAME, KEY_WEIGHT_UNIT + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userID"), code);
    }

    public static void setLengthUnit(int code) {


        SharedPreferencesConfig.getInstance().setInt(SP_UNIT_NAME, KEY_LENGTH_UNIT + PreferencesUtils.getString(ApplicationHolder.getmApplication(),"userId"), code);
    }
}
