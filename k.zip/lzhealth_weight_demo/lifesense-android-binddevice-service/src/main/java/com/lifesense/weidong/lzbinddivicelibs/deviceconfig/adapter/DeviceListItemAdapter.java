package com.lifesense.weidong.lzbinddivicelibs.deviceconfig.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.utils.ImageUtil;
import com.lifesense.utils.ui.ViewUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.widget.shadow.ShadowProperty;
import com.lifesense.weidong.lzbinddivicelibs.widget.shadow.ShadowViewHelper;

import java.util.List;

public class DeviceListItemAdapter extends RecyclerView.Adapter<DeviceListItemAdapter.MenuViewHolder> {

    private Context context;
    private List<DisplayProduct> data;//数据

    private OnItemClickListener onItemClickListener;

    public DeviceListItemAdapter(Context context, List<DisplayProduct> data){
        this.context = context;
        this.data = data;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setData(List<DisplayProduct> data) {
        this.data = data;
    }

    private int getLayoutId(int itemViewType){
        return itemViewType == 0 ? R.layout.device_list_item_type : R.layout.device_list_item;
    }


    @Override
    public MenuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(getLayoutId(getItemViewType(viewType)),parent,false);
        return new MenuViewHolder(view,viewType);
    }

    @Override
    public void onBindViewHolder(MenuViewHolder holder, int position) {
        holder.initView(position);
    }

    @Override
    public int getItemViewType(int position) {
        return data.get(position) == null ? 0 : 1;
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout ll_device_list_item;
        private ImageView iv_device_list_item_icon;
        private TextView tv_device_list_item_name;
        private int viewType;
        public MenuViewHolder(View itemView , int viewType) {
            super(itemView);
            this.viewType = viewType;
            if (viewType == 0){

            }else {
                ll_device_list_item = itemView.findViewById(R.id.ll_device_list_item);
                iv_device_list_item_icon = itemView.findViewById(R.id.iv_device_list_item_icon);
                tv_device_list_item_name = itemView.findViewById(R.id.tv_device_list_item_name);

                float ry = ViewUtil.dip2px(context, 12);
                ShadowViewHelper.bindShadowHelper(
                        new ShadowProperty().setShadowColor(0x0F000000)
                                .setShadowDx(ViewUtil.dip2px(context, 0f))
                                .setShadowDy(ViewUtil.dip2px(context, 0.5f))
                                .setShadowRadius(ViewUtil.dip2px(context, 6f))
                                .setSide(ShadowProperty.BOTTOM),
                        ll_device_list_item, Color.WHITE, ry, ry);
            }
        }

        public void initView(final int position){
            if (viewType == 0){

            }else {
                iv_device_list_item_icon.setImageDrawable(null);
                ImageUtil.displayImage(data.get(position).getImageUrl(),iv_device_list_item_icon);
                tv_device_list_item_name.setText(data.get(position).getName());
                ll_device_list_item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onItemClickListener.click(v, position);
                    }
                });
            }
        }
    }

    public interface OnItemClickListener{
        void click(View view, int position);
    }

}
