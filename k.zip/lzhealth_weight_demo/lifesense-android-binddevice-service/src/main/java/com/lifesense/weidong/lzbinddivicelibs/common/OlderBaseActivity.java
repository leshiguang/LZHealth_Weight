package com.lifesense.weidong.lzbinddivicelibs.common;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.util.DialogUtil;
import com.lifesense.weidong.lzbinddivicelibs.util.QMUIStatusBarHelper;
import com.lifesense.weidong.lzbinddivicelibs.util.StatusBarUtils;
import com.lifesense.weidong.lzbinddivicelibs.util.ToastUtil;
import com.lifesense.weidong.lzbinddivicelibs.util.UIUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wrh on 16/1/4.
 */
public abstract class OlderBaseActivity extends AppCompatActivity {

    protected String TAG = this.getClass().getName();
    protected LinearLayout Layout_center;
    protected RelativeLayout Layout_all;
    //2016年08月12日11:50:17  因为怕会影响其他界面，所以在Layout_center外面包裹这层view。用于做网络错误通用界面
    protected View layout_header;
    protected RelativeLayout layout_left;
    protected LinearLayout layout_right;
    protected LinearLayout layoutRightText;
    protected RelativeLayout layout_more;
    protected RelativeLayout layout_statistics;
    protected TextView tv_title;
    protected TextView tv_left;
    protected TextView tv_right;
    protected ImageView iv_left;
    protected ImageView iv_right;
    protected ImageView iv_more;

    protected View layout_empty;
    protected TextView tv_empty_content, tvSubContent;
    protected ImageView tv_empty_img;
    protected Context mContext = this;
    protected Intent intent;
    protected boolean destroyFlag = false;

    protected int mType;

    private List<String> mTypeList;
    private View mHeader_line;
    protected View mTvTitleBar;

    public int getType() {
        return mType;
    }

    public void setType(int type) {
        mType = type;
    }

    public List<String> getTypeList() {
        return mTypeList;
    }

    public void setList(String type) {

    }

    public void setTypeList(List<String> typeList) {
        mTypeList = typeList;
    }

    public static final String TYPE_PRESCRIPTION_STR = "prescription";
    public static final int TYPE_PRESCRIPTION = 1;
    public static final int TYPE_WAKE_ALARM = 2;

    /**
     * 加载头部，调用setHeader_xxxx方法来设置相关控件属性
     */
    protected abstract void initHeader();

    /**
     * 是否需要沉浸通知栏效果
     */
    protected boolean mNeedTranslucentStatus = true;
    protected boolean isNeedBaseCommon = true;
    protected boolean mIsDark = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isNeedBaseCommon) {
            requestWindowFeature(Window.FEATURE_NO_TITLE);//无标题
            setContentView(R.layout.common_base_new);
            initHeaderView();
            translucentStatus();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
    }

    public void setTitleBarStateColor(int color) {
        if (mTvTitleBar != null) {
            mTvTitleBar.setBackgroundColor(getResources().getColor(color));
        }
    }

    public void setTitleBarStateDrawable(int resId) {
        if (mTvTitleBar != null) {
            mTvTitleBar.setBackgroundResource(resId);
        }
    }

    protected void translucentStatus() {
        QMUIStatusBarHelper.translucent(this);
        if (!mNeedTranslucentStatus) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //增加沉浸通知栏效果
            //透明状态栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            //透明导航栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            if (layout_header != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (mTvTitleBar != null) {
                        mTvTitleBar.setVisibility(View.GONE);
                    }
                    ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) layout_header.getLayoutParams();

                    layoutParams.height += UIUtil.getStatusBarHeight(this);
                    //                padding 标题栏高度
                    layout_header.setPadding(0, UIUtil.getStatusBarHeight(this), 0, 0);
                    layout_header.setLayoutParams(layoutParams);
                } else {
                    if (mTvTitleBar != null) {
                        mTvTitleBar.setVisibility(View.VISIBLE);
                        ViewGroup.LayoutParams layoutParamsBar = mTvTitleBar.getLayoutParams();
                        layoutParamsBar.height = UIUtil.getStatusBarHeight(this);
                        mTvTitleBar.setLayoutParams(layoutParamsBar);
                    }
                }
            }
        } else {
            if (mTvTitleBar != null) {
                mTvTitleBar.setVisibility(View.GONE);
            }
        }
    }

    public boolean isNeedTranslucentStatus() {
        return mNeedTranslucentStatus;
    }

    public void setNeedTranslucentStatus(boolean needTranslucentStatus) {
        mNeedTranslucentStatus = needTranslucentStatus;
    }

    /**
     * 设置标题高度
     *
     * @param dip dp单位
     */
    public void setHeaderHeight(final int dip) {
        //UI设计师说，标题栏高度不能随便改动
        //        if (layout_header != null) {
        //            layout_header.post(new Runnable() {
        //                @Override
        //                public void run() {
        //                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) layout_header.getLayoutParams();
        //
        //                    layoutParams.height = UiUtils.getStatusBarHeight(mContext) + ViewUtil.dip2px(mContext, dip);
        ////                padding 标题栏高度
        //                    layout_header.setPadding(0, UiUtils.getStatusBarHeight(mContext), 0, 0);
        //                    layout_header.setLayoutParams(layoutParams);
        //                }
        //            });
        //
        //        }
    }

   protected boolean isClearflag_translucent_status = true;

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);

        if (layoutResID != R.layout.common_base_new && isClearflag_translucent_status) { //清理沉浸通知栏效果
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }

    }

    //    @Override
    //    public void setContentView(int layoutResID) {
    //        super.setContentView(layoutResID);
    //    }
    private void Log(String text) {
        Log.e(TAG, text);
    }

    public void baseInitHeaderView() {
        initHeaderView();
    }

    public void setCenterViewFillScreen(boolean isFill) {
        if (Layout_all != null) {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) Layout_all.getLayoutParams();
            if (isFill) {
                layoutParams.removeRule(RelativeLayout.BELOW);
            } else {
                layoutParams.addRule(RelativeLayout.BELOW, R.id.header_line);
            }
        }
    }


    private void initHeaderView() {
        boolean result = true;
        Layout_all = findViewById(R.id.layout_all);
        Layout_center = findViewById(R.id.layout_center);
        layout_header = findViewById(R.id.layout_header);
        mTvTitleBar = findViewById(R.id.tvTitleBar);

        if (layout_header != null) {

            tv_title = findViewById(R.id.tv_title);
            tv_left = findViewById(R.id.tv_left);
            tv_right = findViewById(R.id.tv_right);
            layout_left = findViewById(R.id.layout_left);
            layout_right = findViewById(R.id.layout_right);
            iv_left = findViewById(R.id.iv_left);
            iv_right = findViewById(R.id.iv_right);
            layout_more = findViewById(R.id.layout_more);
            layout_statistics = findViewById(R.id.layout_statistics);
            iv_more = findViewById(R.id.iv_more);
            mHeader_line = findViewById(R.id.header_line);
            layout_left.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }
    }

    /**
     * 设置中间的显示内容
     *
     * @param layout
     */
    public void setCenterView(int layout) {
        Layout_center.removeAllViews();
        LayoutInflater inflater = getLayoutInflater();
        mAddView = inflater.inflate(layout, null);
        Layout_center.addView(mAddView, new ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT));

        initHeaderView();
        initHeader();
        Log.d("xyc", "onCreate: mIsDark=" + mIsDark);
        if (mIsDark) {
            StatusBarUtils.setStatusBarDarkIcon(this, true);
        } else {
            StatusBarUtils.setStatusBarDarkIcon(this, false);
        }
    }

    private View mAddView;

    public View getAddView() {
        return mAddView;
    }

    public LinearLayout getCenterView() {
        return Layout_center;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    public boolean activityIsRun = false;

    @Override
    protected void onResume() {
        activityIsRun = true;
        super.onResume();
        Log("onResume");
    }

    @Override
    protected void onPause() {
        activityIsRun = false;
        super.onPause();
        Log("onPause");

    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        destroyFlag = true;
    }

    protected void setStatusBarDarkIcon(boolean isDark) {
        mIsDark = isDark;
    }

    protected void setTitleLineVisibility(int visibility) {
        if (mHeader_line == null) {
            return;
        }
        mHeader_line.setVisibility(visibility);
    }

    protected void setHeader_Title(int resid) {
        if (resid > 0) {
            if (tv_title != null) {
                tv_title.setText(resid);
            }
        }
    }

    public void setHeader_Title(String text) {
        if (tv_title != null) {
            tv_title.setText(text);
        }
    }

    protected void setHeader_Title_Color(int color) {
        if (tv_title != null) {
            tv_title.setTextColor(color);
        }
    }

    protected void setHeader_LeftImage(int resid) {
        if (iv_left != null) {
            iv_left.setVisibility(View.VISIBLE);
            if (resid > 0) {
                iv_left.setImageResource(resid);
                layout_left.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //                        finish();
                        try {
                            onBackPressed();
                            //可能子类使用了Fragment 会导致
                            // Caused by: java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
                        } catch (Exception e) {
                            finish();
                        }

                    }
                });
            } else {
                iv_left.setImageBitmap(null);
            }
        }
    }

    protected void hideHeader_leftImage() {
        if (iv_left != null) {
            iv_left.setVisibility(View.GONE);
        }
    }

    protected void setHeader_LeftText(String text) {
        if (tv_left != null) {
            tv_left.setVisibility(View.VISIBLE);
            tv_left.setText(text);
        }
    }

    protected void setHeader_LeftClickListener(View.OnClickListener listener) {
        if (layout_left != null) {
            layout_left.setOnClickListener(listener);
        }
    }

    protected void setHeader_RightImage(int resid) {
        if (iv_right != null) {
            if (resid > 0) {
                iv_right.setVisibility(View.VISIBLE);
                iv_right.setImageResource(resid);
            } else {
                iv_right.setVisibility(View.GONE);

            }
        }
    }

    protected void setHeader_RightImage(Drawable d) {
        if (iv_right != null) {
            if (d != null) {
                iv_right.setVisibility(View.VISIBLE);
                iv_right.setImageDrawable(d);
            } else {
                iv_right.setVisibility(View.GONE);

            }
        }
    }

    protected void setHeader_RightText(int resid) {
        if (tv_right != null) {
            tv_right.setVisibility(View.VISIBLE);
            if (resid > 0) {
                tv_right.setText(resid);
            }
        }
    }

    protected void setHeader_LeftTextColor(@ColorInt int color) {
        if (tv_left != null) {
            tv_left.setTextColor(color);
        }
    }

    protected void setHeader_RightText(String text) {
        if (tv_right != null) {
            tv_right.setVisibility(View.VISIBLE);
            if (text != null) {
                tv_right.setText(text);
            }
        }
    }

    protected void setHeader_RightTextVisibility(int visibility) {
        if (tv_right != null) {
            tv_right.setVisibility(visibility);
        }

    }

    protected void setHeader_RightClickListener(View.OnClickListener listener) {
        if (layout_right != null) {
            layout_right.setOnClickListener(listener);
        }
    }

    protected void setHeader_RightTextColor(@ColorInt int color) {
        if (tv_right != null) {
            tv_right.setTextColor(color);
        }
    }

    protected void setHeader_RightTextBold() {
        if (tv_right != null) {
            TextPaint tp = tv_right.getPaint();
            tp.setFakeBoldText(true);
        }
    }

    protected void setHeader_LeftTextSize(int spSize) {
        if (tv_left != null) {
            tv_left.setTextSize(TypedValue.COMPLEX_UNIT_SP, spSize);
        }
    }

    protected void setHeader_RightTextSize(int spSize) {
        if (tv_right != null) {
            tv_right.setTextSize(TypedValue.COMPLEX_UNIT_SP, spSize);
        }
    }


    protected void setHeaderVisibility(int visibility) {
        if (layout_header != null) {

            layout_header.setVisibility(visibility);
        }
    }

    protected void setHeaderBackground(int colorId) {
        if (layout_header != null) {
            layout_header.setBackgroundColor(getResources().getColor(colorId));
        }
    }

    protected void setHeaderBackgroundDrawable(int resId) {
        if (layout_header != null) {
            layout_header.setBackgroundResource(resId);
        }
    }

    /**
     * eg:#FFFAFA
     *
     * @param colorStr
     */
    protected void setHeaderBackground(String colorStr) {
        if (layout_header != null) {
            layout_header.setBackgroundColor(Color.parseColor(colorStr));
        }
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

    }
    public void startActivityupdown(Intent intent) {
        super.startActivity(intent);
        updownTranAnimation();
    }

    public void updownTranAnimation(){
        overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_bottom);
    }

    public void finishupdownTranAnimation(){
        overridePendingTransition(R.anim.slide_in_nochange, R.anim.slide_in_bottom);
    }
    public void noAnimation(){
        overridePendingTransition(0,0);
    }

    public void finishNoAnimation(){
        super.finish();
    }

    public void startActivityNoTransition(Intent intent) {
        super.startActivity(intent);
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode, Bundle options) {
        super.startActivityForResult(intent, requestCode, options);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public String getStringById(int resId) {
        return mContext.getString(resId);
    }

    public int getColorById(@ColorRes int resId) {
        return mContext.getResources().getColor(resId);
    }

    private View layout_network_disconnect;
    private View mErrorTopLayout;

    public void showNetworkErrorView() {
        showNetworkErrorView(false);
    }

    public void showNetworkErrorView(boolean needTitleLayout) {
        if (Layout_all == null) {
            return;
        }
        if (layout_network_disconnect == null) {
            layout_network_disconnect = LayoutInflater.from(mContext).inflate(R.layout.common_error_page, null);
            layout_network_disconnect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 添加点击事件,防止消息透传
                }
            });
            Layout_all.addView(layout_network_disconnect,
                    new ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT));
            mErrorTopLayout = layout_network_disconnect.findViewById(R.id.error_top_layout);
            UIUtil.setViewTranslucentStatus(this, mErrorTopLayout);
            layout_network_disconnect.findViewById(R.id.iv_error_back).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            layout_network_disconnect.findViewById(R.id.tv_reload).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onNetworkErrorReload(v);
                }
            });
        } else {
            layout_network_disconnect.setVisibility(View.VISIBLE);
        }
        Layout_center.setVisibility(View.INVISIBLE);

        if (needTitleLayout) {
            mErrorTopLayout.setVisibility(View.VISIBLE);
        } else {
            mErrorTopLayout.setVisibility(View.GONE);
        }
    }

    protected void onNetworkErrorReload(View view) {

    }

    public void dismissNetworkErrorView() {
        if (layout_network_disconnect != null) {
            UIUtil.removeFromParent(layout_network_disconnect);
            layout_network_disconnect = null;
        }
        Layout_center.setVisibility(View.VISIBLE);
    }

    public void showEmptyView(String content) {
        if (layout_empty == null) {
            layout_empty = LayoutInflater.from(mContext).inflate(R.layout.common_empty_page, null);
            layout_empty.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 添加点击事件,防止消息透传
                }
            });
        }

        UIUtil.removeFromParent(layout_empty);
        Layout_all.addView(layout_empty, new ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT));
        if (tv_empty_content == null) {
            tv_empty_content = layout_empty.findViewById(R.id.content_text);
        }
        tv_empty_content.setText(content);

    }

    public void showEmptyView(String content, int resId) {
        if (layout_empty == null) {
            layout_empty = LayoutInflater.from(mContext).inflate(R.layout.common_empty_page, null);
            layout_empty.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 添加点击事件,防止消息透传
                }
            });
        }

        UIUtil.removeFromParent(layout_empty);
        Layout_all.addView(layout_empty, new ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT));
        if (tv_empty_content == null) {
            tv_empty_content = layout_empty.findViewById(R.id.content_text);
        }
        if (tv_empty_img == null) {
            tv_empty_img = layout_empty.findViewById(R.id.icon_image);
        }
        if (resId != 0) {
            tv_empty_img.setImageResource(resId);
        }
        tv_empty_content.setText(content);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // QQ分享回调需要加入该接口,统一在基类处理
        Log.i("ABEN", "MainShareActivity onActivityResult requestCode = " + requestCode + " resultCode = " + resultCode + " data = " + data);
//        if (requestCode == 10103) {
//            Tencent.onActivityResultData(requestCode, resultCode, data, this);
//        } else if (requestCode == 11101) {
//            QQUtil.getInstance().onActivityResult(requestCode, resultCode, data);
//        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void dismissEmptyView() {
        if (layout_empty != null) {
            UIUtil.removeFromParent(layout_empty);
            layout_empty = null;
            tv_empty_content = null;
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        if (newConfig.fontScale != 1)//非默认值
        {
            getResources();
        }
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public Resources getResources() {
        Resources res = super.getResources();
        try {
            if (res.getConfiguration().fontScale != 1) {//非默认值
                Configuration newConfig = new Configuration();
                newConfig.setToDefaults();//设置默认
                res.updateConfiguration(newConfig, res.getDisplayMetrics());
            }
        } catch (Exception e) {

        }

        return res;
    }
// 设置字体大小不随系统改变而改变。
//    作者：马伟奇
//    链接：http://www.jianshu.com/p/33d499170e25
//    來源：简书
//    著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。

    /**
     * 判断底部navigator是否已经显示
     *
     * @return
     * @paramwindowManager
     */

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static boolean hasSoftKeys(android.support.v7.app.AppCompatActivity activity) {

//        Display d=windowManager.getDefaultDisplay();
//
//        DisplayMetrics realDisplayMetrics=new DisplayMetrics();
//
//        d.getRealMetrics(realDisplayMetrics);
//
//        int realHeight=realDisplayMetrics.heightPixels;
//
//        int realWidth=realDisplayMetrics.widthPixels;
//
//        DisplayMetrics displayMetrics=new DisplayMetrics();
//
//        d.getMetrics(displayMetrics);
//
//        int displayHeight=displayMetrics.heightPixels;
//
//        int displayWidth=displayMetrics.widthPixels;

        return isNavigationBarShow(activity);
    }

    public static boolean isNavigationBarShow(AppCompatActivity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Display display = activity.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            Point realSize = new Point();
            display.getSize(size);
            display.getRealSize(realSize);
            return realSize.y != size.y;
        } else {
            boolean menu = ViewConfiguration.get(activity).hasPermanentMenuKey();
            boolean back = KeyCharacterMap.deviceHasKey(KeyEvent.KEYCODE_BACK);
            return !menu && !back;
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static int getBarHeight(WindowManager windowManager) {

        Display d = windowManager.getDefaultDisplay();

        DisplayMetrics realDisplayMetrics = new DisplayMetrics();

        d.getRealMetrics(realDisplayMetrics);

        int realHeight = realDisplayMetrics.heightPixels;

        int realWidth = realDisplayMetrics.widthPixels;

        DisplayMetrics displayMetrics = new DisplayMetrics();

        d.getMetrics(displayMetrics);

        int displayHeight = displayMetrics.heightPixels;

        int displayWidth = displayMetrics.widthPixels;

        return realHeight - displayHeight;
    }

    //显示引导
    protected void showGuide(View view) {
        FrameLayout frameLayout = findViewById(R.id.ui_guide);
        frameLayout.setVisibility(View.VISIBLE);
        frameLayout.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    protected void hideGuide() {
        FrameLayout frameLayout = findViewById(R.id.ui_guide);
        frameLayout.setVisibility(View.GONE);
        frameLayout.removeAllViews();
    }

    /**
     * 判断是否有某项权限
     *
     * @param string_permission 权限
     * @param request_code      请求码
     * @return
     */
    public boolean checkReadPermission(String string_permission, int request_code) {
        boolean flag = false;
        if (ContextCompat.checkSelfPermission(this, string_permission) == PackageManager.PERMISSION_GRANTED) {//已有权限
            flag = true;
        } else {//申请权限
            ActivityCompat.requestPermissions(this, new String[]{string_permission}, request_code);
        }
        return flag;
    }

    /**
     * 判断是否有某项权限
     *
     * @param string_permission 权限
     * @param request_code      请求码
     * @return
     */
    public boolean checkReadPermission(int request_code, String... string_permission) {
        List<String> lackPermissionList = new ArrayList<>();
        for (String permission:string_permission) {
            if (!(ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)){
                lackPermissionList.add(permission);
            }
        }
        if (lackPermissionList.size()>0){
            ActivityCompat.requestPermissions(this, lackPermissionList.toArray(new String[]{}), request_code);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_CODE) {
            boolean isReject = false;
            if (permissions != null && permissions.length > 0 && grantResults != null && grantResults.length > 0) {
                isReject = permissions.length != 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED;
            }
            if (isReject) {
                DialogUtil.getInstance().showPermissionDialog(getStringById(R.string.permissions_camera_content), mContext, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DialogUtil.getInstance().dismissDialog();
                    }
                });
            } else {
                startCamera(mCameraFile, mCameraCode);
            }

        }
    }

//    public void startCrop(Uri source, Uri outputUri) {
//        Crop.of(source, outputUri).withMaxSize(800, 800)
//                .asSquare().start(this);
//
//    }

    public static final int CALL_CODE = 20001;
    public static final int CAMERA_CODE = 20002;
    public static final int SMS_CODE = 20003;
    public static final int READ_CONTACTS_CODE = 20004;
    public static final int CALL_PHONE_CODE = 20005;
    public static final int ACCESS_FINE_LOCATION_CODE = 20006;
    public static final int REQUEST_INSTALL_PACKAGES_CODE = 20007;
    public static final int READ_EXTERNAL_STORAGE_CODE = 20008;
    public static final int READ_CALL_LOG_CODE = 20009;

    private void startCamera(File mTmpFile, int requestCamera) {
        Uri uri = null;
        if (mTmpFile != null) {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.M) {
                uri = Uri.fromFile(mTmpFile);
            } else {
                /**
                 * 7.0 调用系统相机拍照不再允许使用Uri方式，应该替换为FileProvider
                 * 并且这样可以解决MIUI系统上拍照返回size为0的情况
                 */
                uri = FileProvider.getUriForFile(mContext, getFileProviderName(mContext), mTmpFile);
            }
        }
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            if (uri != null) {
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            }
            startActivityForResult(cameraIntent, requestCamera);
        } else {
            ToastUtil.showSingletonToast(mContext,getStringById(R.string.msg_no_camera));
        }

    }

    private File mCameraFile;
    private int mCameraCode;

    public void cameraApply(File file, int code) {
        mCameraFile = file;
        mCameraCode = code;
        if (checkReadPermission(Manifest.permission.CAMERA, CAMERA_CODE)) {
            startCamera(file, code);
        }
    }

    //    public interface  OnPermissionApply{
//        void onApplySucceed();
//    }
    public static String getFileProviderName(Context context) {
        return context.getPackageName() + ".fileprovider";
    }

    /**
     * 请使用IntentUtils 获取数据
     *
     * @return
     */
    @Override
    @Deprecated
    public Intent getIntent() {
        return super.getIntent();
    }

//    public Object getIntentStringData(String key, String def) {
//        return IntentUtils.getStringData(key, getIntent(), def);
//    }
}
