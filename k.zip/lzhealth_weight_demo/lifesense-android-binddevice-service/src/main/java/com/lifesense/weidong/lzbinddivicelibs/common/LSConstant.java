package com.lifesense.weidong.lzbinddivicelibs.common;

public class LSConstant {
    //版本更新相关
    public static  String VERSIONCODE="VERSION_CODE";
    public static String LAST_VERSION_CODE = "lastVersionCode";
    public static String OLD_DB_VERSION = "oldDbVersion";
    public static final String IS_FROM_SCALE_BIND = "isFromBind";
    public static final String KEY_DEVICE_OTA_FILE_PATH = "device_ota_file_path";
}
