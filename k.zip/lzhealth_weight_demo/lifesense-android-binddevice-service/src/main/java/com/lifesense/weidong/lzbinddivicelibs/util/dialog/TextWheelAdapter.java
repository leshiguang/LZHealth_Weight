package com.lifesense.weidong.lzbinddivicelibs.util.dialog;

import android.content.Context;

import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lifesense.ble.tools.PLogUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;

import java.util.List;


/**
 * 数据需要完成toString方法
 */
public class TextWheelAdapter<T> extends RecyclerView.Adapter<TextWheelAdapter.tvViewHolder> {
    private static final String TAG = TextWheelAdapter.class.getSimpleName();
    List<T> mTextList;
    //字体颜色
    int mTextColor;
    //字体padding
    int mTextPadding;
    //字体大小
    float mTextSize;
    //上下文
    Context mContext;
    private int selectedIndex;
    boolean isSetGravity = false;
    int mGravity= Gravity.CENTER;

    public TextWheelAdapter(Context context) {
        mContext = context;

        mTextSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 16, mContext.getResources().getDisplayMetrics());

        mTextPadding = dp2px(mContext, 5);

    }

    public void setTextSize(int unit, float size) {
        mTextSize = TypedValue.applyDimension(
                unit, size, mContext.getResources().getDisplayMetrics());
    }

    public void setTextPadding(int padding) {
        mTextPadding = padding;
    }

    public void setTextColor(int color) {
        mTextColor = color;
    }

    public void setData(List<T> dataList) {
        mTextList = dataList;
//        notifyDataSetChanged();
    }

    public void setDataWithOutNotify(List<T> dataList) {
        mTextList = dataList;

    }

//    public void addData(List<T> dataList) {
//        mTextList.addAll(dataList);
//        notifyDataSetChanged();
//    }
    public void setIsGravity(boolean isGravity)
    {
        this.isSetGravity=isGravity;
    }
    public void setTextGravity(int gravity)
    {
        this.mGravity=gravity;
    }

    @Override
    public tvViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem_date, parent,false);
        return new tvViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TextWheelAdapter.tvViewHolder holder, int position) {
        if (position == selectedIndex && selectedLeftString != null) {
            holder.bindData(selectedLeftString + mTextList.get(position).toString(),position);
        } else {
            holder.bindData(mTextList.get(position).toString(),position);
        }
    }

    @Override
    public int getItemCount() {
        return mTextList == null ? 0 : mTextList.size();
    }



    class tvViewHolder extends RecyclerView.ViewHolder {
        TextView contentTv;

        private int originalTextColor;

        public tvViewHolder(View view) {
            super(view);
            contentTv = view.findViewById(R.id.content_textview);

            originalTextColor = contentTv.getCurrentTextColor();
        }

        public void bindData(String data, int position) {

//            Log.e("bindData", " data =" + data + " index=" + getAdapterPosition());

            if (mTextSize != 0 && this.contentTv.getTextSize() != mTextSize) {
                this.contentTv.setTextSize(TypedValue.COMPLEX_UNIT_PX, mTextSize);
            }
            if (mTextColor != 0 && this.contentTv.getCurrentTextColor() != mTextColor) {
                this.contentTv.setTextColor(mTextColor);
            }
            if (this.contentTv.getPaddingTop() != mTextPadding) {
                this.contentTv.setPadding(0, mTextPadding, 0, mTextPadding);
            }
            if (position == selectedIndex) {
                PLogUtil.i(TAG, " pos=" + getAdapterPosition() + "data=" + data+"  selectedIndex="+selectedIndex);
                if (selectedLeftString != null) {
                    contentTv.setText(selectedLeftString + mTextList.get(selectedIndex));
                }
                contentTv.setTextColor(mContext.getResources().getColor(R.color.main_blue));
                this.contentTv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
            } else {
                //originalTextColor
                contentTv.setTextColor(originalTextColor);
            }
            if(isSetGravity)
            {
                this.contentTv.setGravity(mGravity);
            }

            this.contentTv.setText(data);
        }
    }

    public static int dp2px(Context context, float dp) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);
    }

    public void setSelectedIndex(int index) {

        if (mTextList != null && mTextList.size() < index) {
            index = mTextList.size() - 1;
        } else if (mTextList != null && index < 0) {
            index = 0;
        }
        this.selectedIndex = index;
        notifyDataSetChanged();
    }

    public String selectedLeftString;

    public T getValue(int index) {
        if (mTextList == null) {
            return null;
        }
        if (index < 0 || index >= mTextList.size()) {
            return null;
        }
        return mTextList.get(index);
    }


    public T getCurSelectedValue() {
        return mTextList.get(selectedIndex);
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }
}
