package com.lifesense.weidong.lzbinddivicelibs.widget.dialog;

import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;


/**
 * Created by Administrator on 2014/11/29.
 */
public class DialogOpenBle extends DialogFragment implements View.OnClickListener {
    private String TAG = this.getClass().getSimpleName();


    public static DialogOpenBle newInstance() {
        DialogOpenBle recordReportDialog = new DialogOpenBle();
        return recordReportDialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return createDialog();
    }

    private Dialog createDialog() {
        Dialog dialog = new Dialog(getActivity(), R.style.MyDialogStyleWithWhite);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_hint_open_ble, null);
        dialog.getWindow().getAttributes().windowAnimations = R.style.dialogWindowAnim;
        initial(view);
        dialog.setContentView(view);
        return dialog;
    }

    private void initial(View view) {


        TextView mSrfCancelTv = view.findViewById(R.id.dhob_set_btn);
        mSrfCancelTv.setOnClickListener(this);

        TextView mSrfConfirmTv = view.findViewById(R.id.dhob_confirm_btn);
        mSrfConfirmTv.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.dhob_confirm_btn) {
            BluetoothAdapter.getDefaultAdapter().enable();
            this.dismiss();
        } else if (v.getId() == R.id.dhob_set_btn) {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            this.dismiss();
        }

    }
}
