package com.lifesense.weidong.lzbinddivicelibs.util;

import android.os.Environment;

import java.io.File;

public class PhoneUtils {
    /***
     * 获取手机相册目录
     * @return
     */
    public static String getCameraPath() {
        String dcimPath = Environment.getExternalStorageDirectory().getPath() + "/DCIM";
        String cameraPath = dcimPath + "/Camera/";
        File file = new File(cameraPath);
        if (file.exists() && file.isDirectory()) {
            return cameraPath;
        }
        return  dcimPath;
    }
}
