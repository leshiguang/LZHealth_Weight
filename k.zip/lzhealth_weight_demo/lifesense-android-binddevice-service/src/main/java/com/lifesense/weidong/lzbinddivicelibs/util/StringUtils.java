package com.lifesense.weidong.lzbinddivicelibs.util;

import static com.lifesense.utils.StringUtil.isEmptyOrNull;

public class StringUtils {
    /**
     * 获取网络压缩图片后面一段url的拼接串
     *
     * @param width
     * @param height
     * @return
     */
    public static String getPicStringUrl(String netUrl, int width, int height) {
        //
        if (isEmptyOrNull(netUrl) || netUrl.equals("(null)") || netUrl.equals("null")) {
            return netUrl;
        }
        String url = "?imageView2/1/w/%1$d/h/%2$d/q/100";
        url = String.format(url, width, height);
        return netUrl + url;
    }
}
