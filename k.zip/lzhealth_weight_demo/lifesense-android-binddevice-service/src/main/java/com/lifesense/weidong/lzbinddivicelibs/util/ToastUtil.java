package com.lifesense.weidong.lzbinddivicelibs.util;

import android.content.Context;

import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.weidong.lzbinddivicelibs.R;

/**
 * Created by Administrator on 2014/11/3.
 */
public class ToastUtil {

    public static void showShortToast(Context context, @StringRes int rsId) {
        if (context != null) {
            showCustomCenterShowToast(context,context.getString(rsId));
        }
    }

    public static void showShortToast(Context context, String content) {
        if (context != null) {
            showCustomCenterShowToast(context, content);
        }
    }

    public static void showLongToast(Context context, @StringRes int rsId) {
        if (context != null) {
            Toast.makeText(context.getApplicationContext(), rsId, Toast.LENGTH_LONG).show();
        }
    }

    public static void showLongToast(Context context, String content) {
        if (context != null) {
            showCustomCenterShowToast(context,content);
        }
    }

    private static final String ToastUtil = "ToastUtil";

    private static long lastToastTime;

    public static void showCenterShowToast(Context mContext, @StringRes int resId) {
        showCustomCenterShowToast(mContext, mContext.getString(resId));
    }

    public static void showCenterShowToast(Context mContext, String str) {
        showCustomCenterShowToast(mContext, str);
    }
    public static void showCustomCenterShowToast(Context mContext, String info) {
        if (info == null || mContext == null) {
            return;
        }
        Toast toast = new Toast(mContext.getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0, 0);
        View view = LayoutInflater.from(mContext.getApplicationContext()).inflate(R.layout.toast_group_tips, null);
        TextView textView = view.findViewById(R.id.td_content_tv);
//        if(info.length()>8){
//            ViewGroup.LayoutParams layoutParams=   textView.getLayoutParams();
//            layoutParams.height= ViewUtil.dip2px(69);//如果2行，则高度是69
//            textView.setLayoutParams(layoutParams);
//        }
        textView.setText(info);
        toast.setView(view);
        toast.show();
    }

    static Toast toast;

    /**
     * 展示单例Toast
     *
     * @param context
     * @param message
     */
    public static void showSingletonToast(Context context, String message) {
        if (context == null || message == null) {
            return;
        }
        if (toast == null) {
            toast = new Toast(context.getApplicationContext());
        }
        toast.setGravity(Gravity.CENTER, 0, 0);
        View view = LayoutInflater.from(context.getApplicationContext()).inflate(R.layout.toast_group_tips, null);
        ((TextView) view.findViewById(R.id.td_content_tv)).setText(message);
        toast.setView(view);
        toast.show();
    }

    public static void showFailToast(Context context, String msg) {
        if (System.currentTimeMillis() - lastToastTime > 2000) {
            showCenterImgToast(context, R.mipmap.device_ota_ic_fail, msg);
            lastToastTime = System.currentTimeMillis();
        }
    }

    public static void showCenterImgToast(Context mContext, @DrawableRes int imgId, String message) {
        if (mContext == null) {
            return;
        }

        Toast toast_ota_common = new Toast(ApplicationHolder.getmApplication());
        View view = LayoutInflater.from(mContext.getApplicationContext()).inflate(R.layout.toast_device_ota_common, null);
        TextView msg_view = view.findViewById(R.id.td_content_tv);
        msg_view.setText(message);
        ImageView td_hintImg_iv = view.findViewById(R.id.td_hintImg_iv);
        td_hintImg_iv.setImageResource(imgId);
        toast_ota_common.setView(view);
        toast_ota_common.setGravity(Gravity.CENTER, 0, 0);
        toast_ota_common.show();

    }
}
