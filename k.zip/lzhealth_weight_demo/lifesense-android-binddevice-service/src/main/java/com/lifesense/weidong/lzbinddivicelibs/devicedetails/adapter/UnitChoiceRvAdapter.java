package com.lifesense.weidong.lzbinddivicelibs.devicedetails.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicedetails.model.Unit;

import java.util.Arrays;
import java.util.List;

/**
 * Create by qwerty
 * Create on 2020/6/10
 **/
public class UnitChoiceRvAdapter extends RecyclerView.Adapter<UnitChoiceRvAdapter.UnitChoiceViewHolder> {
    private List<Unit> unitList;
    private Unit choiceUnit = null;
    private OnChoiceUnitListener onChoiceUnitListener;
    private LinearLayoutManager layoutManager;
    public UnitChoiceRvAdapter() {
        this.unitList = Arrays.asList(Unit.values());
    }

    @NonNull
    @Override
    public UnitChoiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new UnitChoiceViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_unit_setting, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final UnitChoiceViewHolder holder, int position) {
        final Unit unit = unitList.get(position);
        holder.setUnitName(unit.getUnitName(holder.itemView.getContext()));
        holder.setChecked(unit == choiceUnit);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onChoiceUnitListener != null) {
                    onChoiceUnitListener.onChoiceUnit(unit);
                }
                choiceUnit = unit;
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return unitList == null ? 0 : unitList.size();
    }

    public void setOnChoiceUnitListener(OnChoiceUnitListener onChoiceUnitListener) {
        this.onChoiceUnitListener = onChoiceUnitListener;
    }


    public void bindView(RecyclerView recyclerView) {
        recyclerView.setAdapter(this);
        layoutManager = new LinearLayoutManager(recyclerView.getContext());
        recyclerView.setLayoutManager(layoutManager);
    }

    static class UnitChoiceViewHolder extends RecyclerView.ViewHolder {
        private TextView tvUnitName;
        private View choiceIcon;

        public UnitChoiceViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tvUnitName = itemView.findViewById(R.id.tv_unit_name);
            choiceIcon = itemView.findViewById(R.id.rb_unit_choice);
        }

        public void setUnitName(String unitName) {
            this.tvUnitName.setText(unitName);
        }

        public void setChecked(boolean checked) {
            choiceIcon.setBackgroundResource(checked ? R.drawable.checkbox_on : R.drawable.checkbox_off);
        }
    }

    public interface OnChoiceUnitListener {
        void onChoiceUnit(Unit unit);
    }

    public void setChoiceUnit(Unit choiceUnit) {
        this.choiceUnit = choiceUnit;
        notifyDataSetChanged();
    }
}
