package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;

/**
 * 设备绑定中展示
 */
@SuppressLint("ValidFragment")
public class DevicePairingFragment extends BaseFragment {
    private ImageView ivDeviceIcon;
    private TextView tvDeviceBind;

    private String imgUrl;
    private String deviceName;

    public static DevicePairingFragment newInstance(String imgUrl, String deviceName) {
        DevicePairingFragment fragment = new DevicePairingFragment();
        Bundle bundle = new Bundle();
        bundle.putString("imgUrl", imgUrl);
        bundle.putString("deviceName", deviceName);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        this.imgUrl = bundle.getString("imgUrl");
        this.deviceName = bundle.getString("deviceName");
        return inflater.inflate(R.layout.fragment_device_pairing,null);
    }

    @Override
    protected void initData() {
        ivDeviceIcon = getActivity().findViewById(R.id.ivDeviceIcon);
        tvDeviceBind = getActivity().findViewById(R.id.tvDeviceBind);

        tvDeviceBind.setText(deviceName);
        ImageUtil.displayImage(imgUrl, ivDeviceIcon);
        ((OlderBaseActivity)getActivity()).setHeader_Title(getString(R.string.device_search_connect_title));

    }

    @Override
    public void onClick(View v) {

    }
}
