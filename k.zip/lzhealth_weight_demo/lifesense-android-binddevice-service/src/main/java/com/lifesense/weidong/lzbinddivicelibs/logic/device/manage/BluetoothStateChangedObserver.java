package com.lifesense.weidong.lzbinddivicelibs.logic.device.manage;

/**
 * @author Sinyi.liu
 * @date 2017/8/3 14:55
 * @describe:
 */
public interface BluetoothStateChangedObserver {
    /**
     * @see android.bluetooth.BluetoothAdapter
     * @param blueState BluetoothAdapter.STATE_ON /BluetoothAdapter.STATE_OFF
     */
    void onBlueStateChanged(int blueState);
}
