package com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.utils.ImageUtil;
import com.lifesense.weidong.lzbinddivicelibs.R;
import com.lifesense.weidong.lzbinddivicelibs.devicebind.ui.activity.DeviceConnectSearchActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.OlderBaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.common.LSEDeviceInfoApp;

/**
 * 单设备展示
 */
@SuppressLint("ValidFragment")
public class DeviceSingleFragment extends BaseFragment {
    private ImageView ivDeviceIcon;
    private TextView tvDeviceBind;
    private TextView tvBottom;

    private DisplayProduct displayProduct;
    private LSEDeviceInfoApp lseDeviceInfoApp;

    public static DeviceSingleFragment newInstance(DisplayProduct displayProduct, LSEDeviceInfoApp lseDeviceInfoApp) {
        DeviceSingleFragment fragment = new DeviceSingleFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("displayProduct", displayProduct);
        bundle.putParcelable("lseDeviceInfoApp", lseDeviceInfoApp);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected View setCenterView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        this.displayProduct = bundle.getParcelable("displayProduct");
        this.lseDeviceInfoApp = bundle.getParcelable("lseDeviceInfoApp");
        return inflater.inflate(R.layout.fragment_device_single, null);
    }

    @Override
    protected void initData() {
        ivDeviceIcon = getActivity().findViewById(R.id.ivDeviceIcon);
        tvDeviceBind = getActivity().findViewById(R.id.tvDeviceBind);
        tvBottom = getActivity().findViewById(R.id.tvBottom);
        tvBottom.setOnClickListener(this);
        ((OlderBaseActivity) getActivity()).setHeader_Title(getString(R.string.device_search_connect_title));

        tvDeviceBind.setText(lseDeviceInfoApp.getDeviceName());
        String imgUrl = displayProduct.getImageUrl();
        ImageUtil.displayImage(imgUrl, ivDeviceIcon);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvBottom) {
            ((DeviceConnectSearchActivity) getActivity()).bindDevice(lseDeviceInfoApp);
        }
    }
}
