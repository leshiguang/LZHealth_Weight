package com.lifesense.weidong.lswebview.webview.setting;

import android.annotation.TargetApi;
import android.os.Build;

import com.lifesense.weidong.lswebview.webview.WebSettings;
import com.lifesense.weidong.lswebview.webview.engine.BaseWebViewEngine;


/**
 * Created by liuxinyi on 2017/4/13.
 */

public class SysWebViewSetting extends WebSettings<android.webkit.WebSettings> {
    public SysWebViewSetting(BaseWebViewEngine baseWebViewEngine, android.webkit.WebSettings webSettings) {
        super(baseWebViewEngine, webSettings);
    }

    @Override
    public void setSupportZoom(boolean support) {
        mSettings.setSupportZoom(support);
    }

    @Override
    public boolean supportZoom() {
        return mSettings.supportZoom();
    }

    @Override
    public void setMediaPlaybackRequiresUserGesture(boolean require) {
        mSettings.setMediaPlaybackRequiresUserGesture(require);
    }

    @Override
    public boolean getMediaPlaybackRequiresUserGesture() {
        return mSettings.getMediaPlaybackRequiresUserGesture();
    }

    @Override
    public void setBuiltInZoomControls(boolean enabled) {
        mSettings.setBuiltInZoomControls(enabled);
    }

    @Override
    public boolean getBuiltInZoomControls() {
        return mSettings.getBuiltInZoomControls();
    }

    @Override
    public void setDisplayZoomControls(boolean enabled) {
        mSettings.setDisplayZoomControls(enabled);
    }

    @Override
    public boolean getDisplayZoomControls() {
        return mSettings.getDisplayZoomControls();
    }

    @Override
    public void setAllowFileAccess(boolean allow) {
        mSettings.setAllowFileAccess(allow);
    }

    @Override
    public boolean getAllowFileAccess() {
        return  mSettings.getAllowFileAccess();
    }

    @Override
    public void setAllowContentAccess(boolean allow) {
        mSettings.setAllowFileAccess(allow);
    }

    @Override
    public boolean getAllowContentAccess() {
        return mSettings.getAllowContentAccess();
    }

    @Override
    public void setLoadWithOverviewMode(boolean overview) {
        mSettings. setLoadWithOverviewMode(overview);
    }

    @Override
    public boolean getLoadWithOverviewMode() {
        return  mSettings.getLoadWithOverviewMode();
    }

    @Override
    public void setEnableSmoothTransition(boolean enable) {
        mSettings.setEnableSmoothTransition(enable);
    }

    @Override
    public boolean enableSmoothTransition() {
        return  mSettings.enableSmoothTransition();
    }

    @Override
    public void setSaveFormData(boolean save) {
        mSettings. setSaveFormData(save);
    }

    @Override
    public boolean getSaveFormData() {
        return  mSettings.getSaveFormData();
    }

    @Override
    public void setSavePassword(boolean save) {
        mSettings.setSavePassword(save);
    }

    @Override
    public boolean getSavePassword() {
        return  mSettings.getSavePassword();
    }

    @Override
    public void setTextZoom(int textZoom) {
        mSettings.setTextZoom(textZoom);
    }

    @Override
    public int getTextZoom() {
        return  mSettings.getTextZoom();
    }

    @Override
    public void setDefaultZoom(WebSettings.ZoomDensity zoom) {
        mSettings.setDefaultZoom(zoom);
    }

    @Override
    public ZoomDensity getDefaultZoom() {
        return  mSettings.getDefaultZoom();
    }

    @Override
    public void setLightTouchEnabled(boolean enabled) {
        mSettings.setLightTouchEnabled(enabled);
    }

    @Override
    public boolean getLightTouchEnabled() {
        return  mSettings.getLightTouchEnabled();
    }

    @Override
    public void setUseWideViewPort(boolean use) {
        mSettings.setUseWideViewPort(use);
    }

    @Override
    public boolean getUseWideViewPort() {
        return mSettings. getUseWideViewPort();
    }

    @Override
    public void setSupportMultipleWindows(boolean support) {
        mSettings.setSupportMultipleWindows(support);
    }

    @Override
    public boolean supportMultipleWindows() {
        return  mSettings.supportMultipleWindows();
    }

    @Override
    public void setLayoutAlgorithm(LayoutAlgorithm l) {
        mSettings.setLayoutAlgorithm(l);
    }

    @Override
    public LayoutAlgorithm getLayoutAlgorithm() {
        return mSettings. getLayoutAlgorithm();
    }

    @Override
    public void setStandardFontFamily(String font) {
        mSettings.setStandardFontFamily(font);
    }

    @Override
    public String getStandardFontFamily() {
        return  mSettings.getStandardFontFamily();
    }

    @Override
    public void setFixedFontFamily(String font) {
        mSettings.setFixedFontFamily(font);
    }

    @Override
    public String getFixedFontFamily() {
        return  mSettings.getFixedFontFamily();
    }

    @Override
    public void setSansSerifFontFamily(String font) {
        mSettings.setSansSerifFontFamily(font);
    }

    @Override
    public String getSansSerifFontFamily() {
        return  mSettings.getSansSerifFontFamily();
    }

    @Override
    public void setSerifFontFamily(String font) {
        mSettings. setSerifFontFamily(font);
    }

    @Override
    public String getSerifFontFamily() {
        return  mSettings.getSerifFontFamily();
    }

    @Override
    public void setCursiveFontFamily(String font) {
        mSettings.setCursiveFontFamily(font);
    }

    @Override
    public String getCursiveFontFamily() {
        return  mSettings.getCursiveFontFamily();
    }

    @Override
    public void setFantasyFontFamily(String font) {
        mSettings. setFantasyFontFamily(font);
    }

    @Override
    public String getFantasyFontFamily() {
        return  mSettings.getFantasyFontFamily();
    }

    @Override
    public void setMinimumFontSize(int size) {
        mSettings.setMinimumFontSize(size);
    }

    @Override
    public int getMinimumFontSize() {
        return  mSettings.getMinimumFontSize();
    }

    @Override
    public void setMinimumLogicalFontSize(int size) {
        mSettings. setMinimumLogicalFontSize(size);
    }

    @Override
    public int getMinimumLogicalFontSize() {
        return  mSettings.getMinimumLogicalFontSize();
    }

    @Override
    public void setDefaultFontSize(int size) {
        mSettings. setDefaultFontSize(size);
    }

    @Override
    public int getDefaultFontSize() {
        return  mSettings.getDefaultFontSize();
    }

    @Override
    public void setDefaultFixedFontSize(int size) {
        mSettings.setDefaultFixedFontSize(size);
    }

    @Override
    public int getDefaultFixedFontSize() {
        return mSettings. getDefaultFixedFontSize();
    }

    @Override
    public void setLoadsImagesAutomatically(boolean flag) {
        mSettings. setLoadsImagesAutomatically(flag);
    }

    @Override
    public boolean getLoadsImagesAutomatically() {
        return  mSettings.getLoadsImagesAutomatically();
    }

    @Override
    public void setBlockNetworkImage(boolean flag) {
        mSettings.  setBlockNetworkImage(flag);
    }

    @Override
    public boolean getBlockNetworkImage() {
        return mSettings. getBlockNetworkImage();
    }

    @Override
    public void setBlockNetworkLoads(boolean flag) {
        mSettings. setBlockNetworkLoads(flag);
    }

    @Override
    public boolean getBlockNetworkLoads() {
        return  mSettings.getBlockNetworkLoads();
    }

    @Override
    public void setJavaScriptEnabled(boolean flag) {
        mSettings.setJavaScriptEnabled(flag);
    }

    @Override
    public void setAllowUniversalAccessFromFileURLs(boolean flag) {
        mSettings. setAllowUniversalAccessFromFileURLs(flag);
    }

    @Override
    public void setAllowFileAccessFromFileURLs(boolean flag) {
        mSettings. setAllowFileAccessFromFileURLs(flag);
    }

    @Override
    public void setPluginState(PluginState state) {
        mSettings.  setPluginState(state);
    }

    @Override
    public void setDatabasePath(String databasePath) {
        mSettings.  setDatabasePath(databasePath);
    }

    @Override
    public void setGeolocationDatabasePath(String databasePath) {
        mSettings. setGeolocationDatabasePath(databasePath);
    }

    @Override
    public void setAppCacheEnabled(boolean flag) {
        mSettings. setAppCacheEnabled(flag);
    }

    @Override
    public void setAppCachePath(String appCachePath) {
        mSettings. setAppCachePath(appCachePath);
    }

    @Override
    public void setAppCacheMaxSize(long appCacheMaxSize) {
        mSettings. setAppCacheMaxSize(appCacheMaxSize);
    }

    @Override
    public void setDatabaseEnabled(boolean flag) {
        mSettings.  setDatabaseEnabled(flag);
    }

    @Override
    public void setDomStorageEnabled(boolean flag) {
        mSettings. setDomStorageEnabled(flag);
    }

    @Override
    public boolean getDomStorageEnabled() {
        return mSettings. getDomStorageEnabled();
    }

    @Override
    public String getDatabasePath() {
        return  mSettings.getDatabasePath();
    }

    @Override
    public boolean getDatabaseEnabled() {
        return  mSettings.getDatabaseEnabled();
    }

    @Override
    public void setGeolocationEnabled(boolean flag) {
        mSettings.setGeolocationEnabled(flag);
    }

    @Override
    public boolean getJavaScriptEnabled() {
        return  mSettings.getJavaScriptEnabled();
    }

    @Override
    public boolean getAllowUniversalAccessFromFileURLs() {
        return  mSettings.getAllowUniversalAccessFromFileURLs();
    }

    @Override
    public boolean getAllowFileAccessFromFileURLs() {
        return  mSettings.getAllowFileAccessFromFileURLs();
    }

    @Override
    public PluginState getPluginState() {
        return  mSettings.getPluginState();
    }

    @Override
    public void setJavaScriptCanOpenWindowsAutomatically(boolean flag) {
        mSettings.setJavaScriptCanOpenWindowsAutomatically(flag);
    }

    @Override
    public boolean getJavaScriptCanOpenWindowsAutomatically() {
        return  mSettings.getJavaScriptCanOpenWindowsAutomatically();
    }

    @Override
    public void setDefaultTextEncodingName(String encoding) {
        mSettings. setDefaultTextEncodingName(encoding);
    }

    @Override
    public String getDefaultTextEncodingName() {
        return mSettings. getDefaultTextEncodingName();
    }

    @Override
    public void setUserAgentString(String ua) {
        mSettings. setUserAgentString(ua);
    }

    @Override
    public String getUserAgentString() {
        return  mSettings.getUserAgentString();
    }

    @Override
    public void setNeedInitialFocus(boolean flag) {
        mSettings.  setNeedInitialFocus(flag);
    }

    @Override
    public void setRenderPriority(RenderPriority priority) {
        mSettings. setRenderPriority(priority);
    }

    @Override
    public void setCacheMode(int mode) {
        mSettings. setCacheMode(mode);
    }

    @Override
    public int getCacheMode() {
        return  mSettings.getCacheMode();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setMixedContentMode(int mode) {
        mSettings.  setMixedContentMode(mode);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public int getMixedContentMode() {
        return mSettings. getMixedContentMode();
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void setOffscreenPreRaster(boolean enabled) {
        mSettings. setOffscreenPreRaster(enabled);

    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public boolean getOffscreenPreRaster() {
        return  mSettings.getOffscreenPreRaster();
    }

    public void setSafeBrowsingEnabled(boolean enabled) {

    }

    public boolean getSafeBrowsingEnabled() {
        return false;
    }

    public void setDisabledActionModeMenuItems(int menuItems) {

    }

    public int getDisabledActionModeMenuItems() {
        return 0;
    }
}
