package com.lifesense.weidong.lswebview.webview;

import java.util.List;
import java.util.Map;

/**
 * Created by liuxinyi on 2017/4/13.
 */

public interface ILSWebViewInterface {
    void loadUrl(String url);

    void loadUrl(String url, Map<String, String> additionalHttpHeaders);

    void setCookie(String url, List<String> cookieList);

    boolean canGoBack();

    void goBack();

    void onResume();

    void resumeTimers();

    void onPause();

    void destroy();

    void reload();

    void pauseTimers();

    void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl);
}
