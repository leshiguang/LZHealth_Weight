package com.lifesense.weidong.lswebview.logic.webview.handler.entity;


import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsTitle extends JsEntity {
    String title = "";
    String subTitle = "";
    String titleLeftImage;  //标题左侧图片
    String titleRightImage; //标题右侧图片

    public String getTitle() {
        return title;
    }

    public JsTitle setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public JsTitle setSubTitle(String subTitle) {
        this.subTitle = subTitle;
        return this;
    }

    public JsTitle setTitleLeftImage(String titleLeftImage) {
        this.titleLeftImage = titleLeftImage;
        return this;
    }

    public JsTitle setTitleRightImage(String titleRightImage) {
        this.titleRightImage = titleRightImage;
        return this;
    }

    public String getTitleLeftImage() {
        return titleLeftImage;
    }

    public String getTitleRightImage() {
        return titleRightImage;
    }

    @Override
    public boolean isInvalid() {
        return title == null && subTitle == null;
    }

}
