package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import android.text.TextUtils;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsButton extends JsEntity {

    String title;
    String imageUrl;
    String buttonId;
    String callbackHandlerName;

    public String getTitle() {
        return title;
    }

    public JsButton setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public JsButton setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
        return this;
    }

    public String getButtonId() {
        return buttonId;
    }

    public JsButton setButtonId(String buttonId) {
        this.buttonId = buttonId;
        return this;
    }

    public String getCallbackHandlerName() {
        return callbackHandlerName;
    }

    public JsButton setCallbackHandlerName(String callbackHandlerName) {
        this.callbackHandlerName = callbackHandlerName;
        return this;
    }

    @Override
    public boolean isInvalid() {
        return TextUtils.isEmpty(callbackHandlerName);
    }
}
