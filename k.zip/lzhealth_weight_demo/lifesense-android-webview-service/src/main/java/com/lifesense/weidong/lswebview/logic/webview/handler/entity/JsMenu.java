package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class JsMenu extends JsEntity {
    String menuId;
    List<MenuItem> menuItems;
    int trailingPadding;
    String callbackHandlerName;

    public String getMenuId() {
        return menuId;
    }

    public JsMenu setMenuId(String menuId) {
        this.menuId = menuId;
        return this;
    }

    public List<MenuItem> getMenuItems() {
        return menuItems;
    }

    public JsMenu setMenuItems(List<MenuItem> menuItems) {
        this.menuItems = menuItems;
        return this;
    }

    public int getTrailingPadding() {
        return trailingPadding;
    }

    public JsMenu setTrailingPadding(int trailingPadding) {
        this.trailingPadding = trailingPadding;
        return this;
    }

    public String getCallbackHandlerName() {
        return callbackHandlerName;
    }

    public JsMenu setCallbackHandlerName(String callbackHandlerName) {
        this.callbackHandlerName = callbackHandlerName;
        return this;
    }

    @Override
    public boolean isInvalid() {
        return false;
    }
}