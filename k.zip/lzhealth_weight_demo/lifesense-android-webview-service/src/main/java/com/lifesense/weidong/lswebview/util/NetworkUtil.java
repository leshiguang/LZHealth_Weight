package com.lifesense.weidong.lswebview.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.lifesense.foundation.ApplicationHolder;

/**
 * Created by Sinyi.liu on 16/1/25.
 * Copyright by gz.lifesense.com
 */
public class NetworkUtil {

    /**
     * 检查网络是否已连接
     *
     * @return
     */
    public static boolean checkNetworkConnection() {
        final ConnectivityManager connMgr = (ConnectivityManager) ApplicationHolder.getmApplication().getSystemService(Context.CONNECTIVITY_SERVICE);

//        final android.net.NetworkInfo wifi = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
//        final android.net.NetworkInfo mobile = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

        NetworkInfo mNetworkInfo = connMgr.getActiveNetworkInfo();
        if (mNetworkInfo == null) {

        } else {
            return mNetworkInfo.isAvailable();

        }
        return false;

    }

    public static boolean isNetworkAvailable() {

        ConnectivityManager mConnectivityManager = (ConnectivityManager) ApplicationHolder.getmApplication()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (mNetworkInfo != null) {
            return mNetworkInfo.isAvailable();
        }
        return false;
    }

    /**
     * make true current connect service is wifi
     *
     * @return
     */
    public static boolean isWifi() {
        ConnectivityManager connectivityManager = (ConnectivityManager) ApplicationHolder.getmApplication()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetInfo != null
                && activeNetInfo.getType() == ConnectivityManager.TYPE_WIFI;
    }

    public static boolean isNetworkAvailable(Context context) {

        ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (mNetworkInfo != null) {
            return mNetworkInfo.isAvailable();
        }
        return false;
    }
}
