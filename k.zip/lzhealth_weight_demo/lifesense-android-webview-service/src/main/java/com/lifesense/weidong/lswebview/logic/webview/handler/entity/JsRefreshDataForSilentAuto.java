package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * Create by qwerty
 * Create on 2019-09-02
 **/
public class JsRefreshDataForSilentAuto extends JsEntity {
    int refreshType;

    public int getRefreshType() {
        return refreshType;
    }

    public void setRefreshType(int refreshType) {
        this.refreshType = refreshType;
    }

    @Override
    public boolean isInvalid() {
        return false;
    }
}
