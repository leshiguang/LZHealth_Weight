package com.lifesense.weidong.lswebview.webview.toolbar;

import android.content.Context;
import android.graphics.Color;

import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.lifesense.weidong.lswebview.R;
import com.lifesense.weidong.lswebview.util.StatusBarUtils;

/**
 * @author Sinyi.liu
 * @date 2017/6/12
 */

public class WebViewToolbar extends LinearLayout implements View.OnClickListener {
	public WebViewToolbar(Context context) {
		super(context);
		init();
	}

	public WebViewToolbar(Context context, @Nullable AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public WebViewToolbar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();
	}
	private MenuView leftMenuView, rightMenuView, right2MenuView;
	private TextView titleTv, subTitleTv;
	private int startColor;
	private View header_line;
	private View tvTitleBar;
	private ImageView ivCenterLeft, ivCenterRight;
	private void init() {
		startColor = ContextCompat.getColor(getContext(), R.color.white);
		LayoutInflater.from(getContext()).inflate(R.layout.web_view_toolbar, this);
		tvTitleBar = findViewById(R.id.tvTitleBar);
		leftMenuView = findViewById(R.id.layout_left);
		rightMenuView = findViewById(R.id.layout_right);
		right2MenuView = findViewById(R.id.layout_right2);
		titleTv = findViewById(R.id.tv_title);
		subTitleTv = findViewById(R.id.tv_subtitle);
		header_line = findViewById(R.id.header_line);
		ivCenterLeft = findViewById(R.id.iv_center_left);
		ivCenterRight = findViewById(R.id.iv_center_right);
		leftMenuView.setOnClickListener(this);
		rightMenuView.setOnClickListener(this);
		right2MenuView.setOnClickListener(this);
		setDefaultConfig();

	}
	public void setStatusBarHeight(int height) {
		if (tvTitleBar != null) {
			if (StatusBarUtils.isSupportChangeStatusBarColor()) {
				this.setPadding(0, height, 0, 0);
				tvTitleBar.setVisibility(GONE);
			} else {
				tvTitleBar.setVisibility(View.VISIBLE);
				ViewGroup.LayoutParams layoutParamsBar = tvTitleBar.getLayoutParams();
				layoutParamsBar.height = height;
				tvTitleBar.setLayoutParams(layoutParamsBar);
				this.setPadding(0, 0, 0, 0);
			}
		}

	}

	/**
	 * 默认白色, 1:白色，2:黑色
	 * @param type
	 */
	public void setNavigationBarTintColorType(int type) {
		if (type == 2) {
			titleTv.setTextColor(
					ContextCompat.getColor(getContext(), R.color.com_title_text_left_color));
		} else {
			titleTv.setTextColor(Color.WHITE);
		}
	}
	public void setDefaultConfig() {
		setLeftImageView(R.mipmap.ic_close_black);
		leftMenuView.setText("");
		rightMenuView.setText("");
		right2MenuView.setText("");
		subTitleTv.setText("");
		rightMenuView.setImageResId(0);
		right2MenuView.setImageResId(0);
		setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
		setStyle(true);
		header_line.setVisibility(VISIBLE);
	}

	public void setBarLineHidden(boolean hidden) {
		header_line.setVisibility(hidden ? GONE : VISIBLE);
	}

	public int getBackgroundColor() {
		return startColor;
	}

	@Override
	public void setBackgroundColor(@ColorInt int color) {
		super.setBackgroundColor(color);
		startColor = color;
		if (color == Color.TRANSPARENT) {
			tvTitleBar.setBackgroundColor(Color.TRANSPARENT);

		}
	}

	public void setTitleBarColor(@ColorInt int color) {
		this.tvTitleBar.setBackgroundColor(color);
		tvTitleBar.setVisibility(VISIBLE);
	}

	//	public static final int STYLE_DARK_BULE=1;
//	public static final int STYLE_DARK_WHITE=2;
//
//	public void setStyle(int style){
//
//	}
	@Deprecated
	public void setStyle(boolean isDark) {
		if (isDark) {
			int darkColor = ContextCompat.getColor(getContext(), R.color.normal_text_color);
			int blueColor = ContextCompat.getColor(getContext(), R.color.main_blue);
			titleTv.setTextColor(darkColor);
			subTitleTv.setTextColor(darkColor);
			leftMenuView.setTextColor(blueColor);
			right2MenuView.setTextColor(blueColor);
			rightMenuView.setTextColor(blueColor);
			setLeftImageView(R.mipmap.ic_close_black);

		} else {
			setLeftImageView(R.mipmap.ic_close_white);

			titleTv.setTextColor(Color.WHITE);
			subTitleTv.setTextColor(Color.WHITE);
			leftMenuView.setTextColor(Color.WHITE);
			right2MenuView.setTextColor(Color.WHITE);
			rightMenuView.setTextColor(Color.WHITE);
		}
	}
	public void setRight2TextView(String text) {
		right2MenuView.setText(text);
	}
	public void setRight2ImageView(String url) {
		right2MenuView.setImageUrl(url);
	}
	public void setRight2ImageView(@DrawableRes int resId) {
		right2MenuView.setImageResId(resId);
	}
	public void setRightTextView(String text) {
		rightMenuView.setText(text);
	}
	public void setRightNull() {
		rightMenuView.setNull();
	}
	public void setRight2Null() {
		right2MenuView.setNull();
	}
	public void setRightTextViewVisibility(int visibility) {
		rightMenuView.setTextVisibility(visibility);
	}
	public void setRightImageView(@DrawableRes int resId) {

		rightMenuView.setImageResId(resId);
	}
	public void setRightImageView(String url) {
		rightMenuView.setImageUrl(url);
	}
	public void setLeftTextView(String text) {
		leftMenuView.setText(text);

	}

	public void setLeftImageView(String url) {
		leftMenuView.setImageUrl(url);
	}
	public void setLeftImageView(int resId) {
		leftMenuView.setImageResId(resId);
	}

	public void setTitleTv(String text) {
		if (text == null) {
			text = "";
		}
		titleTv.setText(text);

	}
	public void setSubTitleTv(String text) {
		if (text == null) {
			text = "";
		}
		if (TextUtils.isEmpty(text)) {
			subTitleTv.setVisibility(View.GONE);
		} else {
			subTitleTv.setVisibility(View.VISIBLE);
		}
		subTitleTv.setText(text);
	}
	//	private OnMenuClickListener mListener;
	//	public void setOnMenuClickListener(OnMenuClickListener listener) {
	//		mListener = listener;
	//	}
	private OnClickListener leftListener, rightListener, right2Listener;

	public OnClickListener getLeftListener() {
		return leftListener;
	}

	public WebViewToolbar setLeftListener(OnClickListener leftListener) {
		this.leftListener = leftListener;
		return this;
	}

	public OnClickListener getRightListener() {
		return rightListener;
	}

	public WebViewToolbar setRightListener(OnClickListener rightListener) {
		this.rightListener = rightListener;
		return this;
	}

	public OnClickListener getRight2Listener() {
		return right2Listener;
	}

	public WebViewToolbar setRight2Listener(OnClickListener right2Listener) {
		this.right2Listener = right2Listener;
		return this;
	}

	@Override
	public void onClick(View v) {
		int i = v.getId();
		if (i == R.id.layout_left) {
			if (leftListener != null) {
				leftListener.onClick(v);
			}
		} else if (i == R.id.layout_right2) {
			if (right2Listener != null) {
				right2Listener.onClick(v);
			}
		} else if (i == R.id.layout_right) {
			if (rightListener != null) {
				rightListener.onClick(v);
			}
		}
	}

	public MenuView getLeftMenuView() {
		return leftMenuView;
	}

	public MenuView getRightMenuView() {
		return rightMenuView;
	}

	public MenuView getRight2MenuView() {
		return right2MenuView;
	}

	public TextView getTitleTv() {
		return titleTv;
	}

	public TextView getSubTitleTv() {
		return subTitleTv;
	}

	public interface OnMenuClickListener {
		void onClickLeft();
		void onClickRight();

		/**
		 * 右边副按钮
		 */
		void onClickRight2();

	}

	public WebViewToolbar setTitleLeftImage(String url){
		setImageUrl(ivCenterLeft, url);
		return this;
	}

	public WebViewToolbar setTitleRightImage(String url){
		setImageUrl(ivCenterRight, url);
		return this;
	}

	/**
	 * 设置标题左侧点击事件
	 * @param titleClickListener
	 * @return
	 */
	public WebViewToolbar setTitleLeftImageClickListener(OnClickListener titleClickListener) {
		if(ivCenterLeft != null){
			ivCenterLeft.setOnClickListener(titleClickListener);
		}
		return this;
	}

	/**
	 * 设置标题右侧图片点击事件
	 * @param titleClickListener
	 * @return
	 */
	public WebViewToolbar setTitleRightImageClickListener(OnClickListener titleClickListener) {
		if(ivCenterRight != null){
			ivCenterRight.setOnClickListener(titleClickListener);
		}
		return this;
	}

	/**
	 * 设置标题栏点击事件
	 * @param titleClickListener
	 * @return
	 */
	public WebViewToolbar setTitleClickListener(OnClickListener titleClickListener) {
		if(titleTv != null){
			titleTv.setOnClickListener(titleClickListener);
		}
		return this;
	}

	/**
	 * 设置
	 * @param view
	 * @param url
	 */
	public void setImageUrl(ImageView view, String url) {
		if(view == null) {
			return;
		}
		if (TextUtils.isEmpty(url)) {
			view.setImageDrawable(null);
			view.setVisibility(View.GONE);
			return;
		}
		view.setVisibility(View.VISIBLE);
		url = url.replace("https","http");
//		ImageUtil.displayImage(url, view);
	}
}
