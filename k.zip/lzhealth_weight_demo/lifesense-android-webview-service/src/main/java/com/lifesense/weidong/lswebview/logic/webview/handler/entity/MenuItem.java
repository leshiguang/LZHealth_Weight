package com.lifesense.weidong.lswebview.logic.webview.handler.entity;

import com.lifesense.weidong.lswebview.logic.webview.base.JsEntity;

/**
 * @author Sinyi.liu
 * @date 2017/6/13
 */

public class MenuItem extends JsEntity {
    String imageUrl;
    String title;

    public String getTitle() {
        return title;
    }

    public MenuItem setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public MenuItem setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
        return this;
    }

    @Override
    public boolean isInvalid() {
        return false;
    }
}
