package com.lifesense.weidong.lswebview.logic.webview.handler;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import com.lifesense.weidong.lswebview.logic.webview.base.BaseLSBridgeJs;
import com.lifesense.weidong.lswebview.logic.webview.delegate.BaseJsDelegate;
import com.lifesense.weidong.lswebview.logic.webview.jsbridge.CallBackFunction;
import com.lifesense.weidong.lswebview.webview.LSWebView;

/**
 * @author Sinyi.liu
 * @date 2017/6/23
 */

public class ThirdWebsiteJsHandler extends BaseLSBridgeJs {
	private final String OPEN_THIRD_WEBSITE = "openThirdWebsite";
	public ThirdWebsiteJsHandler(LSWebView lsWebView, BaseJsDelegate delegate) {
		super(lsWebView, delegate);
	}

	@Override
	public void handler(String handlerName, String data, CallBackFunction function) {
		if (OPEN_THIRD_WEBSITE.equals(handlerName)) {
			if (TextUtils.isEmpty(data)) {
                callBackParseError(function,data);
				return;
			}
			//打开系统下载器
			Uri uri = Uri.parse(data);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			mLSWebView.getContext().startActivity(intent);
            callBackSucceed(function);
		}
	}

	@Override
	public void registerHandler(LSWebView lsWebView) {
		lsWebView.registerHandler(OPEN_THIRD_WEBSITE, this);
	}
}
