package com.lifesense.weidong.lswebview.util;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.lifesense.weidong.lswebview.R;

/**
 * 这里对接UI样式，使用新的对话框弹出，跟之前旧的区分开来
 *
 * @author Sinyi.liu
 * @date 2017/9/26 10:20
 * @describe:
 */
public class DialogUtilImp {

	private static volatile DialogUtilImp singleton = null;

	private DialogUtilImp() {
	}

	public static DialogUtilImp getInstance() {
		if (singleton == null) {
			synchronized (DialogUtilImp.class) {
				if (singleton == null) {
					singleton = new DialogUtilImp();
				}
			}
		}
		return singleton;
	}

	public CustomDialog showNoTitleOneBtnDialog(DialogConfig dialogConfig) {
		return showNoTitleOneDialog(dialogConfig);
	}
	private CustomDialog showNoTitleOneDialog(DialogConfig dialogConfig) {
		CustomDialog dialog = CustomDialog.createStandardDialog(dialogConfig.getContext(),
				R.layout.dialog_common_no_title_onebtn);
		TextView tv_content = dialog.findViewById(R.id.tvContent);
		TextView tv_confirm = dialog.findViewById(R.id.tvConfirm);
		tv_content.setText(dialogConfig.getContent());
		tv_content.setGravity(dialogConfig.getGravity());
		if (!TextUtils.isEmpty(dialogConfig.getConfirmBtn())) {
			tv_confirm.setText(dialogConfig.getConfirmBtn());
		}
		tv_confirm.setOnClickListener(getClickListener(dialogConfig.getConfirmClickListener()));
		dialog.setCancelable(dialogConfig.isCancelable());
		return dialog;
	}

	public CustomDialog showNoTitleTwoBtnDialog(DialogConfig dialogConfig) {
		return showNoTitleDialog(dialogConfig);
	}

	private CustomDialog showNoTitleDialog(DialogConfig dialogConfig) {

		CustomDialog dialog = CustomDialog.createStandardDialog(dialogConfig.getContext(),
				R.layout.dialog_common_no_title);
		TextView tv_content = dialog.findViewById(R.id.tvContent);
		TextView tv_confirm = dialog.findViewById(R.id.tvConfirm);
		tv_content.setText(dialogConfig.getContent());
		if (!TextUtils.isEmpty(dialogConfig.getConfirmBtn())) {
			tv_confirm.setText(dialogConfig.getConfirmBtn());
		}
		tv_confirm.setOnClickListener(getClickListener(dialogConfig.getConfirmClickListener()));
		TextView tvCancel = dialog.findViewById(R.id.tvCancel);
		View lineDivide = dialog.findViewById(R.id.lineDivide);
		tvCancel.setVisibility(View.VISIBLE);
		lineDivide.setVisibility(View.VISIBLE);
		if (!TextUtils.isEmpty(dialogConfig.getCancelBtn())) {
			tvCancel.setText(dialogConfig.getCancelBtn());
		}
		tvCancel.setOnClickListener(getClickListener(dialogConfig.getCancelClickListener()));

		dialog.setCancelable(dialogConfig.isCancelable());
		return dialog;
	}


	public View.OnClickListener getClickListener(View.OnClickListener onClickListener) {
		if (onClickListener == null) {
			onClickListener = defaultOnClickListener;
		}
		return onClickListener;
	}

	public View.OnClickListener defaultOnClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			DialogUtil.getInstance().dismissDialog();
		}
	};

}
