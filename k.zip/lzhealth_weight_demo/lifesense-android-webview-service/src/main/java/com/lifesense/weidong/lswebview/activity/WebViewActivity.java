package com.lifesense.weidong.lswebview.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.utils.LanguageUtil;
import com.lifesense.weidong.lswebview.R;
import com.lifesense.weidong.lswebview.base.BaseWebViewActivity;
import com.lifesense.weidong.lswebview.logic.webview.LSWebViewManager;
import com.lifesense.weidong.lswebview.logic.webview.delegate.IShareJavaScriptInterDelegate;
import com.lifesense.weidong.lswebview.logic.webview.handler.WeightJavaScript;
import com.lifesense.weidong.lswebview.logic.webview.js.CheckPermissionJavaScript;
import com.lifesense.weidong.lswebview.logic.webview.js.ShareJavaScriptLocalObj;
import com.lifesense.weidong.lswebview.logic.webview.js.SkipViewJavaScript;
import com.lifesense.weidong.lswebview.util.IntentUtils;
import java.util.Set;

public class WebViewActivity extends BaseWebViewActivity implements IShareJavaScriptInterDelegate {

	private static final String TAG = WebViewActivity.class.getSimpleName();
	public static final String EXTRA_TITLE = "title";
	public static final String EXTRA_URL = "url";
	public static final String EXTRA_CONTENT = "content";
    public static final String EXTRA_BAR = "bar";

    public static Boolean noTitleBar = false;


    private String loadUrl;

    public static Intent makeIntent(Context context, String title, String url) {
		return new Intent(context, WebViewActivity.class).putExtra(EXTRA_TITLE, title)
				.putExtra(EXTRA_URL, url);
	}

	public static Intent makeIntent(Context context, String title, String url, String extra) {
		return new Intent(context, WebViewActivity.class).putExtra(EXTRA_TITLE, title)
				.putExtra(EXTRA_URL, url).putExtra(EXTRA_CONTENT, extra);
	}
	public static Intent makeIntent(Context context, String url, Boolean notitlebar) {
		return new Intent(context, WebViewActivity.class)
				.putExtra(EXTRA_URL, url)
				.putExtra(EXTRA_BAR,  notitlebar);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		getWindow().setFormat(PixelFormat.TRANSLUCENT);
		super.onCreate(savedInstanceState);
		initData();
	}

	private CheckPermissionJavaScript checkPermissionJavaScript;
	private SkipViewJavaScript skipViewJavaScript;
	private WeightJavaScript weightJavaScript;
	private ShareJavaScriptLocalObj mShareJavaScriptLocalObj;

	private boolean isShowShareImage = false;

	public void initData() {
		isUseWebTitle = false;
		loadUrl = IntentUtils.getStringData(EXTRA_URL, getIntent(), "");
		noTitleBar = IntentUtils.getBoolean(EXTRA_BAR,getIntent(),false);
		if (noTitleBar){
			mWebViewToolbar.setVisibility(View.GONE);
			ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) contentLayout.getLayoutParams();
			layoutParams.topMargin = 0;
			contentLayout.setLayoutParams(layoutParams);
		}

		String title = IntentUtils.getStringData(EXTRA_TITLE, getIntent(), "");

        if (TextUtils.isEmpty(loadUrl)) {
			finish();
			return;
		}

		if(!TextUtils.isEmpty(title)){
			this.title =title;
			isUseWebTitle=false;
			setHeaderTitle(this.title);
		}
		isUseWebTitle = false;
		resolveRequestParam();
		//我们在
		if (mRequestParam != 0) {
			// 这里是传过来就有参数，补充userId和accessToken
			StringBuffer buffer = new StringBuffer();
			buffer.append("&userId=").append(LSWebViewManager.getInstance().getUserId());
			if (!TextUtils.isEmpty(LSWebViewManager.getInstance().getAccessToken())) {
				buffer.append("&accessToken=").append(LSWebViewManager.getInstance().getAccessToken());
			}

			buffer.append("&versionName=").append(ApplicationHolder.getAppVersionName());
			buffer.append("&lang=").append(LanguageUtil.getLocale().getLanguage());
			loadUrl = loadUrl + buffer.toString();
		} else {
			StringBuffer buffer = new StringBuffer();
			if (loadUrl.contains("?")) {
				buffer.append("&userId=").append(LSWebViewManager.getInstance().getUserId());
			} else {
				buffer.append("?userId=").append(LSWebViewManager.getInstance().getUserId());
			}
			if (!TextUtils.isEmpty(LSWebViewManager.getInstance().getAccessToken())) {
				buffer.append("&accessToken=").append(LSWebViewManager.getInstance().getAccessToken());
			}
			buffer.append("&versionName=").append(ApplicationHolder.getAppVersionName());
			buffer.append("&lang=").append(LanguageUtil.getLocale().getLanguage());
			loadUrl = loadUrl + buffer.toString();
		}
		checkPermissionJavaScript = new CheckPermissionJavaScript(mContext,mWebView);
		addJavascriptInterface(checkPermissionJavaScript);
		skipViewJavaScript = new SkipViewJavaScript(mContext,mWebView);
		addJavascriptInterface(skipViewJavaScript);
		weightJavaScript = new WeightJavaScript(mWebView,null);
		mShareJavaScriptLocalObj = new ShareJavaScriptLocalObj(mContext, mWebView);
		mShareJavaScriptLocalObj.setDelegate(this);
		addJavascriptInterface(mShareJavaScriptLocalObj);
		loadUrl(loadUrl);
	}

	@Override
	public void onPageStarted(String url, Bitmap favicon) {
		super.onPageStarted(url, favicon);
	}

	private static final String KEY_REQUEST_PARAM = "requestParam";

	private int mRequestParam = 0;

	/**
	 * 解析showShare字段
	 */
	private void resolveRequestParam() {
		try { //保护下url格式不规范
			Uri uri = Uri.parse(loadUrl);
			Set<String> paramsName = uri.getQueryParameterNames();
			for (String paramName:paramsName) {
				if (KEY_REQUEST_PARAM.equals(paramName)) {
					String value = uri.getQueryParameter(paramName);
					try {
						mRequestParam = Integer.parseInt(value);
					} catch (Exception e) {
						Log.e(TAG,"resolveRequestParam error");
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void onRightClick() {
		if (isShowShareImage) {
			mShareJavaScriptLocalObj.showShareDialog(this);
		} else {
			super.onRightClick();
		}
	}

	@Override
	public void onSetShareType(int shareType) {
		resolveShareText(shareType);
	}

	@Override
	public boolean handlerNavigationBarConfig(boolean autoResetToDefaultConfigWhenOpenLink) {
		boolean retVal = super.handlerNavigationBarConfig(autoResetToDefaultConfigWhenOpenLink);
		if (autoResetToDefaultConfigWhenOpenLink){
			if (noTitleBar){
				mWebViewToolbar.setVisibility(View.GONE);
				ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) contentLayout.getLayoutParams();
				layoutParams.topMargin = 0;
				contentLayout.setLayoutParams(layoutParams);
			}
		}
		return retVal;
	}

	@Override
	public void onRefresh() {
		super.onRefresh();
	}

	/**
	 * 根据showShare判断是否显示分享按钮
	 */
	private void resolveShareText(int shareType) {
		if (shareType != 0) {
			isShowShareImage = true;
			setHeaderRightImage(R.mipmap.ic_share);
		} else {
			isShowShareImage = false;
			setHeaderRightImage(0);
		}
	}

	@Override
	public void finishPressed() {
		super.finishPressed();
	}


}
