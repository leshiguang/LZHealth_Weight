package com.lifesense.weidong.lswebview.webview.engine;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.lifesense.foundation.ApplicationHolder;
import com.lifesense.weidong.lswebview.webview.LSWebViewClient;
import com.lifesense.weidong.lswebview.webview.WebSettings;
import com.lifesense.weidong.lswebview.webview.setting.SysWebViewSetting;


import java.net.HttpCookie;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxinyi on 2017/4/13.
 */

public class SystemWebViewEngine extends BaseWebViewEngine<WebView> {
	private SysWebViewSetting mSysWebViewSetting;

	public SystemWebViewEngine(WebView webView, LSWebViewClient lsWebViewClient) {
		super(webView, lsWebViewClient);
		mSysWebViewSetting = new SysWebViewSetting(this, webView.getSettings());
	}

	@Override
	public WebSettings getWebViewSettings() {
		return mSysWebViewSetting;
	}

	@Override
	public int getScrollY() {
		return mWebView.getScrollY();
	}

	@Override
	public void init() {
		mWebView.setWebViewClient(mWebViewClient);
		mWebView.setWebChromeClient(mWebChromeClient);
		mWebView.setDownloadListener(mDownloadListener);
		android.webkit.WebSettings webSettings = mWebView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setBuiltInZoomControls(false);
		super.init();

	}

	@Override
	public void syncCookieToWebView(String url, List<HttpCookie> httpCookieList) {
		super.syncCookieToWebView(url, httpCookieList);
		if(httpCookieList == null) {
			return;
		}
		Context context = ApplicationHolder.getmApplication();
		if(context == null) {
			return;
		}
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
			CookieSyncManager.createInstance(context);
		}

		android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);
		for(int i = 0; i < httpCookieList.size(); i++) {
			HttpCookie httpCookie = httpCookieList.get(i);
			if(httpCookie == null) {
				continue;
			}
			cookieManager.setCookie(url,httpCookie.toString());
		}
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
			CookieSyncManager.getInstance().sync();
		} else {
			cookieManager.flush();
		}
	}

	@SuppressLint("JavascriptInterface")
	@Override
	public void addJavascriptInterface(Object object, String name) {
		mWebView.addJavascriptInterface(object, name);
	}

	@Override
	public void loadUrl(String url) {
		mWebView.loadUrl(url);
	}

	@Override
	public void loadUrl(String url, Map<String, String> additionalHttpHeaders) {
		mWebView.loadUrl(url, additionalHttpHeaders);
	}

	@Override
	public void setCookie(String url, List<String> cookie) {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
			CookieSyncManager.createInstance(mWebView.getContext());
		}
		final CookieManager cm = CookieManager.getInstance();
		cm.setAcceptCookie(true);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			CookieManager.getInstance().setAcceptThirdPartyCookies(mWebView,true);
		}
		for (String value : cookie) {
			cm.setCookie(url, value);
		}
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
			CookieSyncManager.getInstance().sync();
		} else {
			CookieManager.getInstance().flush();
		}
	}

	@Override
	public boolean canGoBack() {
		return mWebView.canGoBack();
	}

	@Override
	public void goBack() {
		mWebView.goBack();
	}

	@Override
	public void onResume() {
		mWebView.onResume();
	}

	@Override
	public void resumeTimers() {
		mWebView.resumeTimers();
	}

	@Override
	public void onPause() {
		mWebView.onPause();
	}

	@Override
	public void destroy() {
		mWebView.destroy();
	}

	@Override
	public void reload() {
		mWebView.reload();
	}

	@Override
	public void pauseTimers() {
		mWebView.pauseTimers();
	}

	@Override
	public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding,
                                    String historyUrl) {
		mWebView.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, historyUrl);
	}

	private WebViewClient mWebViewClient = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			if (TextUtils.isEmpty(url)) {
				return mLSWebViewClient.shouldOverrideUrlLoading(url);
			}
			return mLSWebViewClient.shouldOverrideUrlLoading(url);

//			boolean bridgeRet = mJSBridgeEngine.shouldOverrideUrlLoading(url);
//			if (bridgeRet) {
//				return true;
//			} else {
//			}
		}

		@Override
		public WebResourceResponse shouldInterceptRequest(WebView view,
                                                          WebResourceRequest request) {
			//			WebResourceResponse webResourceResponse =new WebResourceResponse();
			return super.shouldInterceptRequest(view, request);
		}

		@Override
		public void onLoadResource(WebView view, String url) {
			super.onLoadResource(view, url);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			mLSWebViewClient.onPageStarted(url, favicon);
			getWebViewSettings().setBlockNetworkImage(true);

		}


		@Override
		public void onPageCommitVisible(WebView view, String url) {
			super.onPageCommitVisible(view, url);
		}

		@Override
		public void onPageFinished(WebView view, String url) {
			mJSBridgeEngine.onPageFinished(url);
			mLSWebViewClient.onPageFinished(url);
			getWebViewSettings().setBlockNetworkImage(false);
			if (!getWebViewSettings().getLoadsImagesAutomatically()) {
				//设置wenView加载图片资源
				getWebViewSettings().setBlockNetworkImage(false);
				getWebViewSettings().setLoadsImagesAutomatically(true);
			}

		}

		@Override
		public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
			super.onReceivedHttpError(view, request, errorResponse);
//			mLSWebViewClient.onReceivedError(0,"","");
		}


		@Override
		public void onReceivedError(WebView view, int errorCode, String description,
                                    String failingUrl) {
			super.onReceivedError(view, errorCode, description, failingUrl);
			mLSWebViewClient.onReceivedError(errorCode, description, failingUrl);
		}




	};

	private WebChromeClient mWebChromeClient = new WebChromeClient() {
		@Override
		public void onShowCustomView(View view, CustomViewCallback callback) {
			super.onShowCustomView(view, callback);
			mLSWebViewClient.onShowCustomView(view,callback);
		}
		@Override
		public void onProgressChanged(WebView webView, int i) {
			super.onProgressChanged(webView, i);
		}
		@Override
		public void onHideCustomView() {
			super.onHideCustomView();
			mLSWebViewClient.onHideCustomView();
		}

		@Override
		public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
			return mLSWebViewClient.onShowFileChooser(filePathCallback, fileChooserParams);
		}

		@Override
		public void onReceivedTitle(WebView view, String title) {
			super.onReceivedTitle(view, title);
			if (title == null) {
				return;
			}
			mLSWebViewClient.onReceivedTitle(title);
		}

		@Override
		public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
			if (consoleMessage == null) {
				return true;
			}
			return mLSWebViewClient.onConsoleMessage(consoleMessage.message());
		}

		@Override
		public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
//			result.cancel();    //一定要cancel，否则会出现各种奇怪问题
//			result.confirm();
//			try {
//				showJsAlert(message, new View.OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						result.confirm();
//						DialogUtil.getInstance().dismissProcessDialog();
//					}
//				});
//			} catch (Exception e) {
//			}
			return false;

		}

		@Override
		public boolean onJsConfirm(WebView view, String url, String message,
                                   final JsResult result) {
			result.cancel();    //一定要cancel，否则会出现各种奇怪问题
//			try {
//				showJsConfirm(message, new View.OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						result.confirm();
//						DialogUtil.getInstance().dismissProcessDialog();
//					}
//				}, new View.OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						result.cancel();
//						DialogUtil.getInstance().dismissProcessDialog();
//					}
//				});
//			} catch (Exception e) {
//			}

			return false;

		}
	};



	private DownloadListener mDownloadListener = new DownloadListener() {
		@Override
		public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                    String mimetype, long contentLength) {
			onListenerDownloadStart(getWebView().getContext(), url);
		}
	};
}
