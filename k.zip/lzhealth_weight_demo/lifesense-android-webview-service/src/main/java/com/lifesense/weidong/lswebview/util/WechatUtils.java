package com.lifesense.weidong.lswebview.util;

import android.content.Context;
import android.util.Xml;

import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by lee on 2016/1/17.
 */
public class WechatUtils {

    public static final String WX_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token";
    private static String WX_APP_ID = "";
    private static String WX_APP_SECRET = "";
    private static String WX_OPEN_USERNAME = "";
    private static String WX_OPEN_EXTMSG = "";

    public static String getWxAppId(Context context) {
        if (WX_APP_ID == null || "".equals(WX_APP_ID)) {
            readWxCfg(context);
        }
        return WX_APP_ID;
    }


    public static String getWxAppSecret(Context context) {
        if (WX_APP_SECRET == null || "".equals(WX_APP_SECRET)) {
            readWxCfg(context);
        }
        return WX_APP_SECRET;
    }

    public static String getWxOpenUsername(Context context) {
        if (WX_OPEN_USERNAME == null || "".equals(WX_OPEN_USERNAME)) {
            readWxCfg(context);
        }
        return WX_OPEN_USERNAME;
    }


    public static String getWxOpenExtmsg(Context context) {
        if (WX_OPEN_EXTMSG == null || "".equals(WX_OPEN_EXTMSG)) {
            readWxCfg(context);
        }
        return WX_OPEN_EXTMSG;
    }

    private static IWXAPI sWxApi;

    public static IWXAPI regToWx(Context context) {
        if (sWxApi == null) {
            // 通过WXAPIFactory工厂获取IWXAPI实例
            synchronized (WechatUtils.class) {
                if (sWxApi == null) {
                    String appId = getWxAppId(context);
                    sWxApi = WXAPIFactory.createWXAPI(context, appId, true);
                    // 将应用的appId注册到微信
                    sWxApi.registerApp(appId);
                }
            }
        }

        return sWxApi;
    }

//    public static void getWXAccessToken(Context context, String code, String grant_type, NetRequestResult request) {
//        UserNetManager.get(WX_ACCESS_TOKEN_URL + "?appid=" + getWxAppId(context)
//                + "&secret=" + getWxAppSecret(context) + "&code=" + code + "&grant_type=" + grant_type, request);
//    }

    private static void readWxCfg(Context context) {
        try {
            XmlPullParser parser = Xml.newPullParser();
            InputStream is = context.getApplicationContext().getAssets().open("WeChatCfg.xml");
            parser.setInput(is, "UTF-8");

            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals("Wechat")) {
                            for (int i = 0; i < parser.getAttributeCount(); i++) {
                                String name = parser.getAttributeName(i);
                                if (name.equals("AppId")) {
                                    WX_APP_ID = parser.getAttributeValue(i);
                                } else if (name.equals("AppSecret")) {
                                    WX_APP_SECRET = parser.getAttributeValue(i);
                                } else if (name.equals("OpenUserName")) {
                                    WX_OPEN_USERNAME = parser.getAttributeValue(i);
                                } else if (name.equals("OpenExtMsg")) {
                                    WX_OPEN_EXTMSG = parser.getAttributeValue(i);
                                }
                            }
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        break;
                }
                eventType = parser.next();
            }
        } catch (IOException | XmlPullParserException e) {
            e.printStackTrace();
        }

    }
}
