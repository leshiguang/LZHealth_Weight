package com.lifesense.weidong.lswebviewmoudle.login;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

public class LoginRequest extends BaseRequest {
    public LoginRequest(){
        super();
        setRequestMethod(HTTP_POST);
        addIntValue("tenantId",1);
        addIntValue("subscriptionId",6);
        addIntValue("associatedId",1);
    }

    @Override
    public String getUrlWithoutProtocol() {
        return "/sessions_service/associatedBusiness/login";
    }

    @Override
    public String getResponseClassName() {
        return LoginResponse.class.getName();
    }
}
