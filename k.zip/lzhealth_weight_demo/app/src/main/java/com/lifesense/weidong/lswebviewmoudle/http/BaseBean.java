package com.lifesense.weidong.lswebviewmoudle.http;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.json.JSONException;

import java.io.Serializable;
import java.util.List;

/**
 * Author:  winds
 * Email:   heardown@163.com
 * Date:    2019/5/23.
 * Desc:
 */
public class BaseBean implements Serializable {

    public Object rawData;

    /**
     * 根据对象类型解析数据 如果对象类型是数组 子类需实现elementType和setDataList方法
     *
     * @param jsonString Json字符串
     * @param dataClass  对象类型
     * @param <T>        对象泛型
     * @return
     * @throws JSONException
     */
    public static <T extends BaseBean> T parseData(String jsonString, Class<T> dataClass) {
        if (TextUtils.isEmpty(jsonString) || dataClass == null) {
            return null;
        }
        T bean = null;
        try {
            if (jsonString.startsWith("[")) {
                bean = dataClass.newInstance();
                List<?> dataSet = JSON.parseArray(jsonString, bean.elementType());
                bean.setDataList(dataSet);
            } else {
                bean = JSON.parseObject(jsonString, dataClass);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Log.i("parseData", "数据解析失败! Exception: " + ex.getMessage());
        }
        return bean;
    }

    /**
     * 如果返回数据是集合，数据解析方法会调用次方法获取元素的类型
     *
     * @return
     */
    public Class<?> elementType() {
        return null;
    }


    /**
     * 数据解析成功后会调用此方法设置数据
     *
     * @param list
     */
    public void setDataList(List<?> list) {

    }

    public JSONObject parseObject(String json) {
        if (json != null) {
            try {
                return JSON.parseObject(json);
            } catch (Exception e) {
            }
        }
        return null;
    }
}
