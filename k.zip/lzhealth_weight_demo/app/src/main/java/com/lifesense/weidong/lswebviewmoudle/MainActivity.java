package com.lifesense.weidong.lswebviewmoudle;

import android.Manifest;
import android.os.Build;
import android.os.Bundle;


import android.provider.Settings;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;
import com.lifesense.component.devicemanager.application.service.LZDeviceService;
import com.lifesense.component.devicemanager.component.receiver.BluetoothStatusChangeTrigger;
import com.lifesense.component.devicemanager.device.dto.device.DeviceUserInfo;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;

import com.lifesense.utils.LanguageUtil;
import com.lifesense.weidong.lswebview.logic.LogicServices;
import com.lifesense.weidong.lswebview.logic.webview.LSWebViewManager;
import com.lifesense.weidong.lswebview.util.ToastUtil;
import com.lifesense.weidong.lswebviewmoudle.login.LoginResponse;

import com.lifesense.weidong.lzbinddivicelibs.common.BaseActivity;
import com.lifesense.weidong.lzbinddivicelibs.deviceconfig.ui.DeviceStatusListActivity;
import com.lifesense.weidong.lzsimplenetlibs.cookie.LZCookieManager;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;
import com.lifesense.weidong.lzsimplenetlibs.net.dispatcher.DefaultApiDispatcher;
import com.lifesense.weidong.lswebviewmoudle.login.LoginDispatcher;
import com.lifesense.weidong.lswebviewmoudle.login.LoginEntity;
import java.net.URI;


public class MainActivity extends BaseActivity {

    private static final String domain = "https://sports-beta.lifesense.com";
    private TextView tvWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_main;
    }

    @Override
    protected void initViews(Bundle bundle) {
        setContentView(R.layout.activity_main);
        Button btHome = findViewById(R.id.toWebView);
        btHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogicServices.shareInstance().getJumpActionManage().parseLsUri(MainActivity.this, "lswearable://web?notitlebar=false&title=体重&url=https%3A%2F%2Fstatic-qa.lifesense.com%2Fweight-realme%2Fhome.html&");
            }
        });
        tvWeight = findViewById(R.id.tv_weight);
        findViewById(R.id.toDeviceList).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(DeviceStatusListActivity.getIntent(MainActivity.this));
            }
        });

        Button btChangeLanguage = findViewById(R.id.bt_change_language);
        btChangeLanguage.setText(String.format(getString(R.string.current_language),LanguageUtil.getLocale().getLanguage()));
        btChangeLanguage.setText(String.format(getString(R.string.current_language),LanguageUtil.getLocale().getLanguage()));
        btChangeLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(LanguageUtil.isChinese(MainActivity.this)) {
                    LanguageUtil.setLocale(MainActivity.this,LanguageUtil.ENGLISH);
                } else {
                    LanguageUtil.setLocale(MainActivity.this,LanguageUtil.CHINESE);
                }
                recreate();
            }
        });
    }

    @Override
    protected void initData(Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 23) {
            if(checkPermission()) {
                login();
            }
        } else {
            login();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1001) {
            if(checkPermission()) {
                login();
            } else {
                ToastUtil.showSingletonToast("缺少权限!");
            }
        }
    }

    private boolean checkPermission() {
        return checkReadPermission(new String[] {Manifest.permission.BLUETOOTH,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION},1001);
    }

    private void login() {
        DefaultApiDispatcher.changeDomain(domain);
        String ANDROID_ID = Settings.System.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        LoginDispatcher.getInstance().login(1, 6, ANDROID_ID, new IRequestCallBack<LoginResponse>() {
            @Override
            public void onRequestSuccess(LoginResponse response) {
                LoginEntity entity = response.getLoginEntity();
                if (entity == null) {
                    Log.e("login--------", "login data is null");
                    return;
                }
                String cookie =  LZCookieManager.getInstance().getUriCookie(URI.create("https://sports-beta.lifesense.com/")).toString();
                LSWebViewManager.getInstance().init(entity.getUserId(), entity.getAccessToken());
                LSWebViewManager.getInstance().setCookie("//.lifesense.com/", cookie);
                BluetoothStatusChangeTrigger.getInstance().startBluetoothBroadcastReceiver();
                LZDeviceService.getInstance().init(MainActivity.this, Long.parseLong(entity.getUserId()), null, new OnDataReceiveListener() {
                    @Override
                    public void onReceiveWeightData(WeightData weightData) {
                        tvWeight.setText(weightData.toString());
                        Log.e("onReceiveWeightData", weightData.toString());
                    }

                    @Override
                    public void onDeviceStatusChange(DeviceStatus deviceStatus) {

                    }
                });
                Log.e("login---------", entity.toString());
                DeviceUserInfo deviceUserInfo = new DeviceUserInfo();
                deviceUserInfo.setUserId(Long.parseLong(entity.getUserId()));
            }

            @Override
            public void onRequestError(int i, String s, LoginResponse response) {
                Log.e("login---------", "msg : " + s + ", code : " + i);
            }
        });
    }
}
