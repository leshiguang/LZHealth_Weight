package com.lifesense.component.devicemanager.infrastructure.repository.net;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

public abstract class DefaultNetworkDelegate<T, R> implements IRequestCallBack {

    public abstract void onSuccess(R data);

    public abstract void onFailed(String errMsg, int errCode);

    /**
     * 获取真实类型
     * @param response
     * @return
     */
    public T getProtoType(BaseResponse response) {
        return (T) response;
    }

    /**
     * 返回的数据类型
     * @param response
     * @return
     */
    public abstract R getResponseData(BaseResponse response);
}
