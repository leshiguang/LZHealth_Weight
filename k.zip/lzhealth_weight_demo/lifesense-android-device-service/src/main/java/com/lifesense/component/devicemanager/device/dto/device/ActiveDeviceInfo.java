package com.lifesense.component.devicemanager.device.dto.device;

import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.LSJSONSerializable;

import java.util.Date;

/**
 * Created by zhouzhaoyan on 2017/6/14.
 */

public class ActiveDeviceInfo implements LSJSONSerializable {
    private int id;
    private String deviceId;
    private int userId;
    private int isActive;
    private Date lastDataTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int active) {
        isActive = active;
    }

    public Date getLastDataTime() {
        return lastDataTime;
    }

    public void setLastDataTime(Date lastDataTime) {
        this.lastDataTime = lastDataTime;
    }
}
