package com.lifesense.component.devicemanager.utils;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.Filter;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.SyncFromServerData;

import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lee on 2016/1/19.
 */
public class DeviceManagerUtils {

    /**
     * 解析服务器数据，存储用户设备到本地
     *
     * @param fromServerData
     * @return
     */
    public static long saveSyncDataFromServer(SyncFromServerData fromServerData) {
        long maxTs = fromServerData.getMaxTs();
        List<Device> devices = fromServerData.getDevices();
        if (CollectionUtils.isNotEmpty(devices)) {
            for (Device device : devices) {
                device.setUploadFlag(true);
            }
            RepositoryRegistry.deviceRepository().save(devices);

        }
        List<DeviceSetting> deviceSettings = fromServerData.getDeviceSettings();
        if (CollectionUtils.isNotEmpty(deviceSettings)) {
            for (DeviceSetting deviceSetting : deviceSettings) {
                deviceSetting.setUploadFlag(true);
                maxTs = Math.max(maxTs, deviceSetting.getUpdated());
            }
            RepositoryRegistry.getDeviceSettingRepository().save(deviceSettings);
        }

        List<DeviceUser> deviceUsers = fromServerData.getDeviceUsers();
        if (CollectionUtils.isNotEmpty(deviceUsers)) {
            for (DeviceUser deviceUser : deviceUsers) {
                deviceUser.setUploadFlag(true);
                maxTs = Math.max(maxTs, deviceUser.getUpdated());
            }
            RepositoryRegistry.deviceUserRepository().save(deviceUsers);
        }
        return maxTs;
    }


    public static void setDevices() {
        List<Device> devices = RepositoryRegistry.deviceRepository().queryByUser(LDAppHolder.getUserId(), new Filter<Device>() {
            @Override
            public boolean doTest(Device value) {
                return value.isBluetooth();
            }
        });
        List<LsDeviceInfo> deviceInfos = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(devices)) {
            for (Device device : devices) {
                deviceInfos.add(device.toDeviceInfo());
            }
            LsBleManager.getInstance().setMeasureDevice(deviceInfos);
        }
    }


    public static Map<String, LsDeviceInfo> getAllBluetoothDevice() {
        /**
         * 获取所有设备
         */
        List<Device> devices = RepositoryRegistry.deviceRepository().queryByUser(LDAppHolder.getUserId());
        if (devices != null && devices.size() > 0) {
            Map<String, LsDeviceInfo> deviceInfoMap = new HashMap<>();
            for (Device device : devices) {
                if (device.getCommunicationType() == 4) {
                    LsDeviceInfo deviceInfo = ObjectConvertTool.device2LsDeviceInfo(device);
                    deviceInfoMap.put(device.getId(), deviceInfo);
                }
            }
            return deviceInfoMap;
        }
        return null;
    }

    public static boolean diffDeviceInfos(Map<String, LsDeviceInfo> oldMap, Map<String, LsDeviceInfo> newMap) {
        for (Map.Entry<String, LsDeviceInfo> entry : oldMap.entrySet()) {
            if (!newMap.containsKey(entry.getKey())) {
                return true;
            }
        }

        for (Map.Entry<String, LsDeviceInfo> entry : newMap.entrySet()) {
            if (!oldMap.containsKey(entry.getKey())) {
                return true;
            }
        }
        return false;
    }


}
