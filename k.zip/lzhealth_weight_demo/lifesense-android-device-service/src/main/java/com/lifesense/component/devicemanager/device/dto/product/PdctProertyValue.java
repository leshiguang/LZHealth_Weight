package com.lifesense.component.devicemanager.device.dto.product;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xwei
 * on 2017/3/29/0029.
 */

public class PdctProertyValue implements Parcelable {

    private String url;
    private String name;
    private int style;

    public PdctProertyValue() {

    }

    protected PdctProertyValue(Parcel in) {
        url = in.readString();
        name = in.readString();
        style = in.readInt();
    }

    public static final Creator<PdctProertyValue> CREATOR = new Creator<PdctProertyValue>() {
        @Override
        public PdctProertyValue createFromParcel(Parcel in) {
            return new PdctProertyValue(in);
        }

        @Override
        public PdctProertyValue[] newArray(int size) {
            return new PdctProertyValue[size];
        }
    };

    public void setUrl(String url) {
        this.url = url;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStyle(int style) {
        this.style = style;
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public int getStyle() {
        return style;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(url);
        dest.writeString(name);
        dest.writeInt(style);
    }
    @Override
    public String toString() {
        return "PdctProertyValue{" +
                "url=" + url +
                " name=" + name +
                " style=" + style +
                '}';
    }
}
