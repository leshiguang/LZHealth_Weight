package com.lifesense.component.devicemanager.infrastructure.repository;

import android.util.Log;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSettingDao;

import org.apache.commons.collections4.CollectionUtils;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

public class DeviceSettingRepository extends DefaultDatabaseRepository<DeviceSetting> {



    public DeviceSetting get(String uniqueKey, String settingClass) {
        List<DeviceSetting> deviceSettings = null;
        try {
            QueryBuilder<DeviceSetting> qb = getDaoSession().getDeviceSettingDao().queryBuilder();
            qb.where(DeviceSettingDao.Properties.DeviceId.eq(uniqueKey),
                    DeviceSettingDao.Properties.SettingClass.eq(settingClass),
                    DeviceSettingDao.Properties.Deleted.eq(false),
                    DeviceSettingDao.Properties.SettingTime.lt(System.currentTimeMillis()))
                    .orderDesc(DeviceSettingDao.Properties.SettingTime)
                    .limit(1);
            deviceSettings = qb.list();
        } catch (Exception e) {
            Log.e("DeviceSettingRepository", e.getMessage());
        }
        if (CollectionUtils.isEmpty(deviceSettings)) {
            return null;
        }
        return deviceSettings.get(0);

    }

    @Override
    public DeviceSetting get(String uniqueKey) {

        return null;
    }

    @Override
    public List<DeviceSetting> queryByUser(long userId) {
        return null;
    }

    @Override
    public List<DeviceSetting> queryByUniqueIds(List<String> uniqueIds) {
        return null;
    }

    @Override
    public List<DeviceSetting> queryByUser(long userId, Filter<DeviceSetting> filter) {
        return null;
    }

    @Override
    public void save(DeviceSetting instance) {
        getDaoSession().getDeviceSettingDao().insertOrReplace(instance);

    }

    @Override
    public void save(List<DeviceSetting> instances) {
        if (CollectionUtils.isEmpty(instances)) {
            return;
        }
        for (DeviceSetting deviceSetting : instances) {
            DeviceSetting setting = this.get(deviceSetting.getDeviceId(), deviceSetting.getSettingClass());
            if (setting == null || setting.getSettingTime() <= deviceSetting.getSettingTime()) {
                this.save(deviceSetting);
            }
        }
    }

    @Override
    public void update(DeviceSetting instance) {

    }

    @Override
    public void delete(String uniqueId, long userId) {
        QueryBuilder<DeviceSetting> qb = getDaoSession().getDeviceSettingDao().queryBuilder();
        qb.where(DeviceSettingDao.Properties.DeviceId.eq(uniqueId))
                .buildDelete()
                .executeDeleteWithoutDetachingEntities();
    }
}
