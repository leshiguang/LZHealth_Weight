package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class ApplyDeviceIdRequest extends BaseRequest {

    private static final String kRequestParam_Mac = "mac";
    private static final String kRequestParam_HardwareVersion = "hardwareVersion";
    private static final String kRequestParam_softwareVersion = "softwareVersion";
    private static final String kRequestParam_VenderId = "venderId";
    private static final String kRequestParam_Model = "model";
    private static final String kRequestParam_SalesModel = "salesModel";
    private static final String kRequestParam_ProductTypeCode = "productTypeCode";
    private static final String kRequestParam_Name = "name";
    private static final String kRequestParam_CommunicationType = "communicationType";

    public ApplyDeviceIdRequest(LsDeviceInfo lsDeviceInfo) {
        super();
        setRequestMethod(HTTP_POST);
        addStringValue(kRequestParam_Mac, lsDeviceInfo.getMacAddress().replace(":", ""));
        addStringValue(kRequestParam_HardwareVersion, lsDeviceInfo.getHardwareVersion());
        addStringValue(kRequestParam_softwareVersion, lsDeviceInfo.getSoftwareVersion());
        addStringValue(kRequestParam_VenderId, lsDeviceInfo.getManufactureId());
        addStringValue(kRequestParam_Model, lsDeviceInfo.getDeviceName());
        addStringValue(kRequestParam_SalesModel, lsDeviceInfo.getManufactureName());
        addStringValue(kRequestParam_ProductTypeCode, lsDeviceInfo.getDeviceType());
        addStringValue(kRequestParam_Name, lsDeviceInfo.getModelNumber());
        addIntValue(kRequestParam_CommunicationType, Device.COMM_BLE);
    }



    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/device_info/apply_device_id";
    }

    @Override
    public String getResponseClassName() {
        return ApplyDeviceIdResponse.class.getName();
    }
}
