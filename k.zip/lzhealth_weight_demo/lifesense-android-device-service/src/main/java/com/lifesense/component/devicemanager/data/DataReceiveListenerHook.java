package com.lifesense.component.devicemanager.data;


import com.lifesense.ble.LsBleManager;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.device.dto.receive.MeasureData;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;

import com.lifesense.component.devicemanager.data.weight.IWeightDataInterface;
import com.lifesense.component.devicemanager.data.weight.WeightDataManager;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceStatus;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 11:22
 * @describe:
 */
public class DataReceiveListenerHook {
    private static volatile DataReceiveListenerHook singleton = null;

    private DataReceiveListenerHook() {

    }

    public static DataReceiveListenerHook getInstance() {
        if (singleton == null) {
            synchronized (DataReceiveListenerHook.class) {
                if (singleton == null) {
                    singleton = new DataReceiveListenerHook();
                }
            }
        }
        return singleton;
    }

    public IWeightDataInterface shareWeightDataInterface() {
        return WeightDataManager.getInstance();
    }

    private OnDataReceiveListener mAppOnDataReceiveListener;

    public void setOnDataReceiveListener(OnDataReceiveListener dataReceiveListener) {
        mAppOnDataReceiveListener = dataReceiveListener;
    }

    /**
     * 获取内部数据监听实现。
     *
     * @return
     */
    public OnDataReceiveListener getDataReceiveListener() {
        return mOnDataReceiveListener;
    }


    /**
     * 内部接收数据处理逻辑
     */
    private OnDataReceiveListener mOnDataReceiveListener = new OnDataReceiveListener() {
        @Override
        public void onReceiveWeightData(final WeightData data) {
            if (isIllegalWeightData(data)) {
                LsBleManager.getInstance().setLogMessage("illegal WeightData::" + data);
                return;
            }
            //体重模块增加了原始数据存储模块，就不需要透传给APP了
            WeightDataManager.getInstance().addBleWeightData(data);
            postMainThread(new Runnable() {
                @Override
                public void run() {
                    if(mAppOnDataReceiveListener != null) {
                        mAppOnDataReceiveListener.onReceiveWeightData(data);
                    }
                }
            });

        }

        @Override
        public void onDeviceStatusChange(final DeviceStatus deviceStatus) {
            postMainThread(new Runnable() {
                @Override
                public void run() {
                    if (mAppOnDataReceiveListener != null) {
                        mAppOnDataReceiveListener.onDeviceStatusChange(deviceStatus);
                    }
                }
            });
        }
    };


    private boolean isIllegalData(MeasureData data) {
        //2013-01-01 00:00:00 → 1356969600
        if (data == null) {
            return true;
        }
        if (data.getMeasurementTime() <= 1356969600) {
            return true;
        }
        long nowTs = System.currentTimeMillis() / 1000 + 3600;
        if (data.getMeasurementTime() > nowTs) {
            return true;
        }
        return false;
    }

    private boolean isIllegalWeightData(WeightData data) {
        if (data == null) {
            return true;
        }
        if(isIllegalData(data)){
            return true;
        }
        if (data.getWeight() <= 0) {
            return true;
        }

        return false;
    }


    private void postMainThread(Runnable action) {
        Task.runOnMainThreadAsync(action);
    }

}
