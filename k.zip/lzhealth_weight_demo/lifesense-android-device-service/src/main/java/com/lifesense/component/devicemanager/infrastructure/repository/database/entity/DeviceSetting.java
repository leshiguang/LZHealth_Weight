package com.lifesense.component.devicemanager.infrastructure.repository.database.entity;


import android.os.Parcel;
import android.os.Parcelable;


import com.lifesense.component.devicemanager.utils.StringUtil;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Keep;
import org.greenrobot.greendao.annotation.Property;

import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class DeviceSetting implements Parcelable {

    @Id
    @Property(nameInDb = "ID")
    private String id;
    private String deviceId;
    private String settingClass;    //类名
    private long settingTime;       //设置时间
    private String content;         //JSON格式的设备设置
    private Date created; //数据创建时间
    private long updated;           //数据更新时间
    private boolean uploadFlag;     //数据是否已更新到服务器
    private boolean deleted;        //数据是否已删除

    @Keep
    public DeviceSetting(String id, String deviceId, String settingClass,
                         long settingTime, String content, Date created, long updated,
                         boolean uploadFlag, boolean deleted) {
        this.id = id;
        this.deviceId = deviceId;
        this.settingClass = settingClass;
        this.settingTime = settingTime;
        this.content = content;
        this.created = created;
        this.updated = updated;
        this.uploadFlag = uploadFlag;
        this.deleted = deleted;
    }

    public DeviceSetting() {
    }

    public DeviceSetting(String deviceId, String settingClass, String content) {
        this.id = StringUtil.genUUID();
        this.deviceId = deviceId;
        this.settingClass = settingClass;
        this.settingTime = System.currentTimeMillis();
        this.content = content;
        this.deleted = false;
        this.uploadFlag = false;
        this.created = new Date(System.currentTimeMillis());
    }

    public void update(String content) {
        this.content = content;
        this.deleted = false;
        this.uploadFlag = false;
        this.settingTime = System.currentTimeMillis();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSettingClass() {
        return settingClass;
    }

    public void setSettingClass(String settingClass) {
        this.settingClass = settingClass;
    }

    public long getSettingTime() {
        return settingTime;
    }

    public void setSettingTime(long settingTime) {
        this.settingTime = settingTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public long getUpdated() {
        return updated;
    }

    public void setUpdated(long updated) {
        this.updated = updated;
    }

    public void setUploadFlag(boolean uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean getUploadFlag() {
        return this.uploadFlag;
    }

    public boolean getDeleted() {
        return this.deleted;
    }

    @Override
    public String toString() {
        return "DeviceSetting{" +
                "id='" + id + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", settingClass='" + settingClass + '\'' +
                ", settingTime=" + settingTime +
                ", content='" + content + '\'' +
                ", created=" + created +
                ", updated=" + updated +
                ", uploadFlag=" + uploadFlag +
                ", deleted=" + deleted +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.deviceId);
        dest.writeString(this.settingClass);
        dest.writeLong(this.settingTime);
        dest.writeString(this.content);
        dest.writeLong(this.created != null ? this.created.getTime() : -1);
        dest.writeLong(this.updated);
        dest.writeByte(this.uploadFlag ? (byte) 1 : (byte) 0);
        dest.writeByte(this.deleted ? (byte) 1 : (byte) 0);
    }

    protected DeviceSetting(Parcel in) {
        this.id = in.readString();
        this.deviceId = in.readString();
        this.settingClass = in.readString();
        this.settingTime = in.readLong();
        this.content = in.readString();
        long tmpCreated = in.readLong();
        this.created = tmpCreated == -1 ? null : new Date(tmpCreated);
        this.updated = in.readLong();
        this.uploadFlag = in.readByte() != 0;
        this.deleted = in.readByte() != 0;
    }

    public static final Creator<DeviceSetting> CREATOR = new Creator<DeviceSetting>() {
        @Override
        public DeviceSetting createFromParcel(Parcel source) {
            return new DeviceSetting(source);
        }

        @Override
        public DeviceSetting[] newArray(int size) {
            return new DeviceSetting[size];
        }
    };
}
