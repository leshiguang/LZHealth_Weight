package com.lifesense.component.devicemanager.device.dto.receive;

import android.os.Parcel;

/**
 * Created by lee on 2016/1/16.
 */
public class WeightData extends MeasureData {
    private int userNo;
    private double weight;
    private double weightLevel;//体重水平
    private double resistance5k;//电阻值
    private double resistance50k;//电阻值
    private int battery;//电量1-10，不支持为0


    public WeightData() {
        super();
    }

    protected WeightData(Parcel in) {
        super(in);
        userNo = in.readInt();
        weight = in.readDouble();
        weightLevel = in.readDouble();
        resistance5k = in.readDouble();
        battery = in.readInt();
    }

    public static final Creator CREATOR = new Creator() {
        @Override
        public WeightData createFromParcel(Parcel in) {
            return new WeightData(in);
        }

        @Override
        public WeightData[] newArray(int size) {
            return new WeightData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(userNo);
        dest.writeDouble(weight);

        dest.writeDouble(resistance5k);
        dest.writeDouble(resistance50k);
        dest.writeInt(battery);

    }

    public int getUserNo() {
        return userNo;
    }

    public void setUserNo(int userNo) {
        this.userNo = userNo;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }




    public double getWeightLevel() {
        return weightLevel;
    }

    public void setWeightLevel(double weightLevel) {
        this.weightLevel = weightLevel;
    }

    public double getResistance5K() {
        return resistance5k;
    }

    public void setResistance5k(double resistance5K) {
        this.resistance5k = resistance5K;
    }

    public double getResistance50k() {
        return resistance50k;
    }

    public void setResistance50k(double resistance50k) {
        this.resistance50k = resistance50k;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    @Override
    public String toString() {
        return "WeightData{" +
                "userId=" + userId +
                ", deviceId='" + deviceId + '\'' +
                ", measurementTime=" + measurementTime + " " + formatDate(measurementTime) +
                ", userNo=" + userNo +
                ", weight=" + weight +
                ", weightLevel=" + weightLevel +
                ", resistance5K=" + resistance5k +
                ", resistance50K=" + resistance50k +
                ", battery=" + battery +
                '}';
    }
}
