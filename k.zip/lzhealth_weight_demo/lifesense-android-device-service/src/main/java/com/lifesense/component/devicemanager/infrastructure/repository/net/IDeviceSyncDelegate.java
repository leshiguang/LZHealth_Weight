package com.lifesense.component.devicemanager.infrastructure.repository.net;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.List;

/**
 * Created by rolandxu on 2017/7/3.
 */

public interface IDeviceSyncDelegate extends IRequestCallBack {
    public void onSuccess(List<Device> devices, List<DeviceSetting> deviceSetting);
    public void onFailed(String errmsg, int errcode);
}
