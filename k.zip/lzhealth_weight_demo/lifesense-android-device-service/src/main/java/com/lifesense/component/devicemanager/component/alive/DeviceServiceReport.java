package com.lifesense.component.devicemanager.component.alive;

/**
 * Created by maiweibiao on 17/1/19.
 */

public class DeviceServiceReport {
    private static IDeviceServiceReport deviceServiceReport;

    public static void setDeviceServiceReport(IDeviceServiceReport iDeviceServiceReport) {
        deviceServiceReport = iDeviceServiceReport;
    }

    public static void report() {
        if (deviceServiceReport != null) {
            deviceServiceReport.report();
        }
    }

    public interface IDeviceServiceReport {
        void report();
    }

}
