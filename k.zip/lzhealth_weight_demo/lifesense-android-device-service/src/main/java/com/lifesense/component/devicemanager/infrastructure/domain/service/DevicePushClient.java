package com.lifesense.component.devicemanager.infrastructure.domain.service;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lifesense.ble.LsBleManager;

import com.lifesense.ble.OnSettingCallBack;
import com.lifesense.ble.bean.WeightUserInfo;
import com.lifesense.ble.bean.constant.BindUserState;
import com.lifesense.ble.bean.constant.DeviceConfigInfoType;
import com.lifesense.ble.bean.constant.HeartRateSwitch;
import com.lifesense.ble.bean.constant.SexType;

import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.ble.protocol.ProtocolCommand;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.device.settings.config.DeviceHeartRateCfg;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.component.devicemanager.device.dto.device.DeviceUserInfo;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;
import com.lifesense.component.devicemanager.device.settings.config.DeviceUnitCfg;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;

import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadDeviceInformationResponse;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.Arrays;


/**
 * Created by lee
 * On Date 2017/2/24
 */

public class DevicePushClient {


    private DevicePushClient() {
    }

    public static void setWeightUserInfo(final String deviceId, final OnSettingCallBack callBack) {
        final Device device = RepositoryRegistry.deviceRepository().get(deviceId);
        DeviceUserInfo deviceUserInfo = DeviceManagerPreference.readUserInfo();
        final WeightUserInfo weightUserInfo = new WeightUserInfo();
        weightUserInfo.setAge(deviceUserInfo.getAge());
        weightUserInfo.setDeviceId(deviceId);
        weightUserInfo.setHeight((float) deviceUserInfo.getHeight() / 100f);
        weightUserInfo.setSex(deviceUserInfo.getSex() == 1 ? SexType.MALE : SexType.FEMALE);
        weightUserInfo.setWeight((float) deviceUserInfo.getWeight());
        weightUserInfo.setWaistline(deviceUserInfo.getWaistline());
        weightUserInfo.setGoalWeight(deviceUserInfo.getGoalWeight());
        byte[] bytes = weightUserInfo.getBytes();
        WeightUserInfo lastWeightUserInfo = DeviceManagerPreference.readLastSetWeightUserInfo(deviceId);
        byte[] lastBytes = lastWeightUserInfo.getBytes();
        boolean isEquals = true;
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] != lastBytes[i]) {
                isEquals = false;
            }
        }
        if (lastWeightUserInfo.getWeight() != weightUserInfo.getWeight()) {
            isEquals = false;
        }
        if (isEquals) {
            LsBleManager.getInstance().setLogMessage("set weight user info:equals return" + device.getMacConvert() + " weightUserInfo:" + weightUserInfo);
            Log.d("DM", "repeat setWeightUserInfo:" + weightUserInfo);
            handleSuccess(callBack);
            return;
        } else {
            LsBleManager.getInstance().setLogMessage("start set weight user info:" + device.getMacConvert() + ":" + weightUserInfo);
        }
        LsBleManager.getInstance().updateWeightScaleSetting(device.getMacConvert(), DeviceConfigInfoType.A6_WEIGHT_SCALE_USER_INFO, weightUserInfo, new OnSettingCallBack() {
            @Override
            public void onSuccess(final String s) {
                super.onSuccess(s);
                LsBleManager.getInstance().setLogMessage(s + ">>update weight user info:success" + weightUserInfo);

                DeviceManagerPreference.saveLastSetWeightUserInfo(deviceId, weightUserInfo);
                if (callBack != null) {
                    runOnMainThread(new Runnable() {
                        @Override
                        public void run() {
                            callBack.onSuccess(s);
                        }
                    });
                }
            }

            @Override
            public void onFailure(final int i) {
                super.onFailure(i);
                LsBleManager.getInstance().setLogMessage(device.getMacConvert() + ">>update weight user info error :" + i);

                Log.e("DM", "SET WEIGHT UserInfo FAIL: ");
                if (callBack != null) {
                    runOnMainThread(new Runnable() {
                        @Override
                        public void run() {
                            callBack.onFailure(i);
                        }
                    });
                }
            }

            @Override
            public void onConfigInfo(Object o) {
                super.onConfigInfo(o);
            }
        });
    }

    public static void unbindWeightScale(final Device device, final DeviceUser deviceUser, final OnSettingCallBack callBack) {
        BindUserState bindUserState = ProtocolCommand.getUserNumberByUserNo(deviceUser.getUserNo());
        LsBleManager.getInstance().updateWeightScaleSetting(device.getMacConvert(), DeviceConfigInfoType.A6_WEIGHT_SCALE_UNBIND, bindUserState, new OnSettingCallBack() {
            @Override
            public void onSuccess(String macAddress) {
                super.onSuccess(macAddress);
                LsBleManager.getInstance().setLogMessage(">>unbind a6 weight" + device.getMac() + " succeed userNo:" + deviceUser.getUserNo());
                if (callBack != null) {
                    callBack.onSuccess(macAddress);
                }
            }

            @Override
            public void onFailure(int errorCode) {
                super.onFailure(errorCode);
                LsBleManager.getInstance().setLogMessage(">>unbind a6 weight" + device.getMac() + " error userNo:" + deviceUser.getUserNo() + " code:" + errorCode);
                if (callBack != null) {
                    callBack.onFailure(errorCode);
                }
            }

            @Override
            public void onConfigInfo(Object obj) {
                super.onConfigInfo(obj);
            }
        });
    }


    /**
     * 设置体重单位
     * @param device
     * @param unitType
     * @param callBack
     */
    public static void setWeightUnit(final Device device, final UnitType unitType, final OnSettingCallBack callBack) {

        LsBleManager.getInstance().updateWeightScaleSetting(device.getMacConvert(), DeviceConfigInfoType.A6_WEIGHT_SCALE_UNIT, unitType, new OnSettingCallBack() {
            @Override
            public void onSuccess(final String macAddress) {
                /**
                 * 更新到数据库
                 */
                DeviceUnitCfg deviceUnitCfg = new DeviceUnitCfg();
                deviceUnitCfg.setUnit(unitType.getCommand());
                DeviceSetting deviceSetting = RepositoryRegistry.getDeviceSettingRepository().get(device.getId(), deviceUnitCfg.getClass().getSimpleName());
                if (deviceSetting == null) {
                    deviceSetting = new DeviceSetting(device.getId(), deviceUnitCfg.getClass().getSimpleName(), JSON.toJSONString(deviceUnitCfg));
                } else {
                    deviceSetting.update(JSON.toJSONString(deviceUnitCfg));
                }
                RepositoryRegistry.getDeviceSettingRepository().save(deviceSetting);
                /**
                 * 同步到服务器， 这里先不做强校验
                 */
                DeviceNetManager.getInstance().setWeightUnit(device.getId(), unitType.getCommand());
                /**
                 * 回调
                 */
                runOnMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (callBack != null) {
                            callBack.onSuccess(macAddress);
                        }
                    }
                });
            }

            @Override
            public void onFailure(final int errorCode) {
                runOnMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (callBack != null) {
                            callBack.onFailure(errorCode);
                        }
                    }
                });

            }
        });
    }

    /**
     * 设置心率开关
     * @param device
     * @param heartRateSwitch
     * @param callBack
     */
    public static void setHeartRateSwitch(final Device device, final HeartRateSwitch heartRateSwitch, final OnSettingCallBack callBack) {
        LsBleManager.getInstance().updateWeightScaleSetting(device.getMacConvert(), DeviceConfigInfoType.A6_HEART_RATE_SWITCH, heartRateSwitch, new OnSettingCallBack() {
            @Override
            public void onSuccess(final String macAddress) {
                /**
                 * 更新到数据库
                 */
                DeviceHeartRateCfg deviceHeartRateCfg = new DeviceHeartRateCfg();
                deviceHeartRateCfg.setState(heartRateSwitch.getCommand());
                DeviceSetting deviceSetting = RepositoryRegistry.getDeviceSettingRepository().get(device.getId(), deviceHeartRateCfg.getClass().getSimpleName());
                if (deviceSetting == null) {
                    deviceSetting = new DeviceSetting(device.getId(), deviceHeartRateCfg.getClass().getSimpleName(), JSON.toJSONString(deviceHeartRateCfg));
                } else {
                    deviceSetting.update(JSON.toJSONString(deviceHeartRateCfg));
                }
                RepositoryRegistry.getDeviceSettingRepository().save(deviceSetting);

                DeviceNetManager.getInstance().updateDeviceInformation(null, Arrays.asList(deviceSetting), new IRequestCallBack<UploadDeviceInformationResponse>() {
                    @Override
                    public void onRequestSuccess(UploadDeviceInformationResponse uploadDeviceInformationResponse) {

                    }

                    @Override
                    public void onRequestError(int i, String s, UploadDeviceInformationResponse uploadDeviceInformationResponse) {

                    }
                });
                /**
                 * 同步到服务器， 这里先不做强校验
                 */
//                DeviceNetManager.getInstance().setWeightUnit(device.getId(), unitType.getCommand());
                /**
                 * 回调
                 */
                runOnMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (callBack != null) {
                            callBack.onSuccess(macAddress);
                        }
                    }
                });
            }

            @Override
            public void onFailure(final int errorCode) {
                runOnMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (callBack != null) {
                            callBack.onFailure(errorCode);
                        }
                    }
                });

            }
        });

    }




    private static void handleSuccess(final OnSettingCallBack callBack) {
        if (callBack != null) {
            runOnMainThread(new Runnable() {
                @Override
                public void run() {
                    callBack.onSuccess(null);
                }
            });
        }
    }


    private static void runOnMainThread(Runnable action) {
        Task.runOnMainThreadAsync(action);
    }


}
