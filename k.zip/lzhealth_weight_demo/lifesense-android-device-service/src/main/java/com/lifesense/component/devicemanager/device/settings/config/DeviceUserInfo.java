package com.lifesense.component.devicemanager.device.settings.config;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by lee on 2016/1/16.
 */
public class DeviceUserInfo implements Parcelable {

    private double weight;
    private double height;
    private int age;
    private int sex;

    public DeviceUserInfo() {
    }

    protected DeviceUserInfo(Parcel in) {
        weight = in.readDouble();
        height = in.readDouble();
        age = in.readInt();
        sex = in.readInt();
    }

    public static final Creator<DeviceUserInfo> CREATOR = new Creator<DeviceUserInfo>() {
        @Override
        public DeviceUserInfo createFromParcel(Parcel in) {
            return new DeviceUserInfo(in);
        }

        @Override
        public DeviceUserInfo[] newArray(int size) {
            return new DeviceUserInfo[size];
        }
    };

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(weight);
        dest.writeDouble(height);
        dest.writeInt(age);
        dest.writeInt(sex);
    }

    @Override
    public String toString() {
        return "DeviceUserInfo{" +
                "weight=" + weight +
                ", height=" + height +
                ", age=" + age +
                ", sex=" + sex +
                '}';
    }
}
