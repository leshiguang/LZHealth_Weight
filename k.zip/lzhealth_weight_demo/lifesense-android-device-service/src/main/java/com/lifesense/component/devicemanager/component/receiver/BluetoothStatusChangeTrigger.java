package com.lifesense.component.devicemanager.component.receiver;

import android.content.Context;
import android.content.Intent;

import com.lifesense.ble.LsBleManager;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.component.alive.DeviceServiceReport;
import com.lifesense.component.devicemanager.component.service.DeviceKeepAliveService;
import com.lifesense.component.devicemanager.utils.DeviceManagerPreference;

public class BluetoothStatusChangeTrigger {

    private LsBleManager bleManager = LsBleManager.getInstance();

    private boolean isRegisted = false;


    private static class BluetoothStatusSingletonHolder {
        private static BluetoothStatusChangeTrigger holder = new BluetoothStatusChangeTrigger();
        public static BluetoothStatusChangeTrigger getHolder() {
            return holder;
        }
    }

    public static BluetoothStatusChangeTrigger getInstance() {
        return BluetoothStatusSingletonHolder.getHolder();
    }

    /**
     * 开启DeviceService。接收蓝牙广播
     */
    public void startBluetoothBroadcastReceiver() {
        isRegisted = true;
        Task.execute(new Runnable() {
            @Override
            public void run() {
                DeviceManagerPreference.saveFileName();
                if (bleManager.isSupportLowEnergy()) {
                    Context context = LDAppHolder.getContext();
                    try {
                        context.stopService(new Intent(context, DeviceKeepAliveService.class));
                        context.startService(new Intent(context, DeviceKeepAliveService.class));
                    } catch (Exception e) {
                        try {
                            context.startService(new Intent(context, DeviceKeepAliveService.class));
                        } catch (Exception e1) {
                        }
                    }
                    DeviceServiceReport.report();
                }
            }
        });
    }

    /**
     * 停止接收蓝牙广播
     */
    public void stopBluetoothBroadcastReceiver() {
        isRegisted = false;
        bleManager.unregisterBluetoothBroadcastReceiver();
    }


    public boolean isRegisted() {
        return isRegisted;
    }
}
