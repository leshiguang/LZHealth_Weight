package com.lifesense.component.devicemanager.data.weight;

import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.data.weight.delegate.IWeightDataGetDelegate;
import com.lifesense.component.devicemanager.data.weight.observer.IWeightDataUpdateObserver;

import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 11:28
 * @describe:
 */
public interface IWeightDataInterface {

	void addWeightDataUpdateObserver(IWeightDataUpdateObserver observer);
	void removeWeightDataUpdateObserver(IWeightDataUpdateObserver observer);
	void getUntreatedWeightData(IWeightDataGetDelegate delegate);
	void setWeightDataProcessed(List<WeightData> weightDatas);
	void setWeightDataProcessedById(String id);
	void setWeightDataProcessedByIds(List<String> ids);
	int getUntreatedWeightDataCount();

}
