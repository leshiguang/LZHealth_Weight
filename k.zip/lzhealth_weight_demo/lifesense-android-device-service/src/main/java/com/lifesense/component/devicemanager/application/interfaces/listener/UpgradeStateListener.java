package com.lifesense.component.devicemanager.application.interfaces.listener;

/**
 * Created by lee on 2016/1/16.
 */
public interface UpgradeStateListener {
    void onStart();

    void onProgress(int progress);

    void onFinish(boolean success, int errorCode, String msg);
}
