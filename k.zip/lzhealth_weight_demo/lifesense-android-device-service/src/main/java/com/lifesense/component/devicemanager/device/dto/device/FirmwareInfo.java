package com.lifesense.component.devicemanager.device.dto.device;

import android.os.Parcel;
import android.os.Parcelable;

import com.lifesense.component.devicemanager.constant.SaleType;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.LSJSONSerializable;

import java.io.Serializable;

/**
 * Created by lee on 2016/1/19.
 */
public class FirmwareInfo implements Parcelable, Serializable, LSJSONSerializable {
    private String id;// 主键
    private String model;// 工厂设备型号
    private String hardwareVersion;// 硬件版本
    private String softwareVersion; // 软件版本
    private String fileUrl;// 文件地址
    private int size;// 文件大小
    private String describe;// 更新描述
    private String name;//固件名称
    private String md5; // 检验下载文件的文件完整性
    private String type;// 固件类型


    public FirmwareInfo() {

    }

    public SaleType getSaleType() {
        return SaleType.getSaleType(model);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getHardwareVersion() {
        return hardwareVersion;
    }

    public void setHardwareVersion(String hardwareVersion) {
        this.hardwareVersion = hardwareVersion;
    }

    public String getSoftwareVersion() {
        return softwareVersion;
    }

    public void setSoftwareVersion(String softwareVersion) {
        this.softwareVersion = softwareVersion;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    protected FirmwareInfo(Parcel in) {
        id = in.readString();
        model = in.readString();
        hardwareVersion = in.readString();
        softwareVersion = in.readString();
        fileUrl = in.readString();
        size = in.readInt();
        describe = in.readString();
        name = in.readString();
        md5 = in.readString();
        type = in.readString();
    }

    public static final Creator<FirmwareInfo> CREATOR = new Creator<FirmwareInfo>() {
        @Override
        public FirmwareInfo createFromParcel(Parcel in) {
            return new FirmwareInfo(in);
        }

        @Override
        public FirmwareInfo[] newArray(int size) {
            return new FirmwareInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(model);
        dest.writeString(hardwareVersion);
        dest.writeString(softwareVersion);
        dest.writeString(fileUrl);
        dest.writeInt(size);
        dest.writeString(describe);
        dest.writeString(name);
        dest.writeString(md5);
        dest.writeString(type);
    }

    @Override
    public String toString() {
        return "FirmwareInfo{" +
                "id='" + id + '\'' +
                ", model='" + model + '\'' +
                ", hardwareVersion='" + hardwareVersion + '\'' +
                ", softwareVersion='" + softwareVersion + '\'' +
                ", fileUrl='" + fileUrl + '\'' +
                ", size=" + size +
                ", describe='" + describe + '\'' +
                ", name='" + name + '\'' +
                ", md5='" + md5 + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
