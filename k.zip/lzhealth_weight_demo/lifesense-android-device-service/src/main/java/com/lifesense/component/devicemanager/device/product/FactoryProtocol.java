package com.lifesense.component.devicemanager.device.product;

/**
 * 工厂设备协议
 */
public enum FactoryProtocol {
    Wechat("Wechat"), A5("A5"), InterConnection("InterConnection"),
    A6("A6"), Standard("Standard"), Sleepace("Sleepace");
    public String msg;

    FactoryProtocol(String msg) {
        this.msg = msg;
    }

    public static FactoryProtocol toFactoryProtocal(String msg){
        FactoryProtocol factoryProtocol = FactoryProtocol.A5;
        for (FactoryProtocol factoryProtocolTmp : FactoryProtocol.values()) {
            if (factoryProtocolTmp.msg.equals(msg)){
                factoryProtocol = factoryProtocolTmp;
                break;
            }
        }
        return factoryProtocol;
    }
}
