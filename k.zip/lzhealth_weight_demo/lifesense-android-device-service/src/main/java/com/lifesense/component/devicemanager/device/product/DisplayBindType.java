package com.lifesense.component.devicemanager.device.product;

/**
 * 绑定类型
 */
public enum DisplayBindType {
    qrcode(1),
    sn_qrcode(2),
    bluetooth(3),
    device_1597(4);
    public int code;

    DisplayBindType(int code) {
        this.code = code;
    }

    public static DisplayBindType toDisplayBindType(int code){
        DisplayBindType displayProductType = DisplayBindType.qrcode;
        for (DisplayBindType displayProductTypeTmp : DisplayBindType.values()) {
            if (displayProductTypeTmp.code == code){
                displayProductType = displayProductTypeTmp;
                break;
            }
        }
        return displayProductType;
    }
}
