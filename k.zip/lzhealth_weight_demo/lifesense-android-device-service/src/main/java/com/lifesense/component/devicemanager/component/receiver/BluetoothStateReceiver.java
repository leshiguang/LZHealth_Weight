package com.lifesense.component.devicemanager.component.receiver;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.utils.DMLog;

/**
 * Created by lee on 2016/2/15.
 */
public class BluetoothStateReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
        switch (state) {
            case BluetoothAdapter.STATE_ON: {
                DMLog.d("test msg >> state broadcast...,state on");

                if (LDAppHolder.getUserId() != 0) {
                    DMLog.d("test msg >> state broadcast...,start device manager");
                    BluetoothStatusChangeTrigger.getInstance().startBluetoothBroadcastReceiver();
                }
            }
            break;
            case BluetoothAdapter.STATE_OFF: {
                DMLog.d("test msg >> state broadcast...,state off");
            }
            break;
        }
    }
}
