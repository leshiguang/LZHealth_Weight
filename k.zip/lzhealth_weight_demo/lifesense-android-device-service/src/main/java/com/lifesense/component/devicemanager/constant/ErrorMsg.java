package com.lifesense.component.devicemanager.constant;

/**
 * Created by lee on 2016/1/20.
 */
public class ErrorMsg {
    public final static String DEV_NOT_FOUND = "Device Not Found !";
    public final static String BLE_NOT_CONNECT = "手机未打开蓝牙，请先打开手机蓝牙";//"Bluetooth is not available !";
    public final static String FILE_NOT_FOUND = "File Not Found !";
    public final static String DEV_NOT_SUPPORT = "Device Not Support !";
    public final static String DEV_NOT_CONNECT = "Device Not Connect !";
    public final static String CANCEL_UPDATE = "Upgrading Cancel !";
    public final static String INVALED_QRCODE = "Invalid Qrcode !";
}
