package com.lifesense.component.devicemanager.application.interfaces.callback;

import android.util.Log;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.ReceiveDataCallback;

import com.lifesense.ble.bean.LsDeviceInfo;

import com.lifesense.ble.bean.WeightData_A3;
import com.lifesense.ble.bean.constant.DeviceConnectState;

import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDeviceConnectStateListener;
import com.lifesense.component.devicemanager.utils.DeviceDataHandler;
import com.lifesense.component.devicemanager.utils.ObjectConvertTool;



/**
 * Created by lee
 * On Date 2017/2/24
 */
public class BleReceiveCallback extends ReceiveDataCallback {

    private OnDataReceiveListener receiveListener;
    private OnDeviceConnectStateListener connectStateListener;

    @Override
    public void onDeviceConnectStateChange(DeviceConnectState deviceConnectState, String s) {
        Log.e("sky-test", "onDeviceManager callback >> mac=" + s + "   >>连接状态改变:" + deviceConnectState);

        DeviceDataHandler.handleDeviceConnectState(deviceConnectState, s, connectStateListener);
    }

    @Override
    public void onReceiveDeviceInfo(LsDeviceInfo lsDeviceInfo) {
        super.onReceiveDeviceInfo(lsDeviceInfo);
        if (lsDeviceInfo != null) {
            ObjectConvertTool.showMsg(lsDeviceInfo);
        } else {
            LsBleManager.getInstance().setLogMessage("onReceiveDeviceInfo :null");
        }
        DeviceDataHandler.handleDeviceInfo(lsDeviceInfo);
    }


    @Override
    public void onReceiveWeightData_A3(WeightData_A3 weightData_a3) {
        DeviceDataHandler.handleWeightData(weightData_a3, receiveListener);
    }

    public OnDeviceConnectStateListener getConnectStateListener() {
        return connectStateListener;
    }

    public void setConnectStateListener(OnDeviceConnectStateListener connectStateListener) {
        this.connectStateListener = connectStateListener;
    }

    public OnDataReceiveListener getReceiveListener() {
        return receiveListener;
    }

    public void setReceiveListener(OnDataReceiveListener receiveListener) {
        this.receiveListener = receiveListener;
    }


}
