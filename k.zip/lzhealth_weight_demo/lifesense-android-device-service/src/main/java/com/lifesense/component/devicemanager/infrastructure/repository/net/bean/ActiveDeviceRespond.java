package com.lifesense.component.devicemanager.infrastructure.repository.net.bean;

import com.lifesense.component.devicemanager.device.dto.device.ActiveDeviceInfo;

import java.util.List;

/**
 * Created by zhouzhaoyan on 2017/6/14.
 */

public class ActiveDeviceRespond implements LSJSONSerializable {
    private List<ActiveDeviceInfo> list;

    public List<ActiveDeviceInfo> getList() {
        return list;
    }

    public void setList(List<ActiveDeviceInfo> list) {
        this.list = list;
    }
}
