package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class ApplyDeviceIdResponse extends JsonResponse {

    String deviceId;
    String mac;

    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
        if (jsonData == null) {
            return;
        }
        try {
            deviceId = jsonData.getString("deviceId");
            mac = jsonData.getString("mac");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getMac() {
        return mac;
    }
}
