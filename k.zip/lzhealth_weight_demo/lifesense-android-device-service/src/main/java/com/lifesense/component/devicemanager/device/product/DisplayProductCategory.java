package com.lifesense.component.devicemanager.device.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.alibaba.fastjson.annotation.JSONField;

import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Transient;

import java.util.List;

/**
 * 产品类别
 */
//@Entity
public class DisplayProductCategory implements Parcelable {
	@Id(autoincrement = true)
	private Long id;
	//展示产品类型.1:手环 2:手表
	//3:智能秤 4:血压计 5:乐心互联
	private int productType;
	//展示产品类型名称
	private String productTypeName;
	//高亮图标图片地址
	private String highlightImageUrl;
	//未高亮图标图片地址
	private String noHighlightImageUrl;
	@Transient
	@JSONField(name = "iotDisplayProducts")
	private List<DisplayProduct> displayProducts;

	@Generated(hash = 866771648)
	public DisplayProductCategory(Long id, int productType, String productTypeName,
									String highlightImageUrl, String noHighlightImageUrl) {
					this.id = id;
					this.productType = productType;
					this.productTypeName = productTypeName;
					this.highlightImageUrl = highlightImageUrl;
					this.noHighlightImageUrl = noHighlightImageUrl;
	}

	@Generated(hash = 260439627)
	public DisplayProductCategory() {
	}

	public Long getId() {
					return this.id;
	}

	public void setId(Long id) {
					this.id = id;
	}

	public int getProductType() {
					return this.productType;
	}

	public void setProductType(int productType) {
					this.productType = productType;
	}

	public String getProductTypeName() {
					return this.productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
					this.productTypeName = productTypeName;
	}

	public String getHighlightImageUrl() {
					return this.highlightImageUrl;
	}

	public void setHighlightImageUrl(String highlightImageUrl) {
					this.highlightImageUrl = highlightImageUrl;
	}

	public String getNoHighlightImageUrl() {
					return this.noHighlightImageUrl;
	}

	public void setNoHighlightImageUrl(String noHighlightImageUrl) {
					this.noHighlightImageUrl = noHighlightImageUrl;
	}

	public List<DisplayProduct> getDisplayProducts() {
		return displayProducts;
	}

	public void setDisplayProducts(List<DisplayProduct> displayProducts) {
		this.displayProducts = displayProducts;
	}

	public DisplayProductType getDisplayProductType(){
		return DisplayProductType.toProductType(productType);
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeValue(this.id);
		dest.writeInt(this.productType);
		dest.writeString(this.productTypeName);
		dest.writeString(this.highlightImageUrl);
		dest.writeString(this.noHighlightImageUrl);
		dest.writeTypedList(this.displayProducts);
	}

	protected DisplayProductCategory(Parcel in) {
		this.id = (Long) in.readValue(Long.class.getClassLoader());
		this.productType = in.readInt();
		this.productTypeName = in.readString();
		this.highlightImageUrl = in.readString();
		this.noHighlightImageUrl = in.readString();
		this.displayProducts = in.createTypedArrayList(DisplayProduct.CREATOR);
	}

	public static final Creator<DisplayProductCategory> CREATOR = new Creator<DisplayProductCategory>() {
		@Override
		public DisplayProductCategory createFromParcel(Parcel source) {
			return new DisplayProductCategory(source);
		}

		@Override
		public DisplayProductCategory[] newArray(int size) {
			return new DisplayProductCategory[size];
		}
	};

	@Override
	public String toString() {
		return "DisplayProductCategory{" +
				"id=" + id +
				", productType=" + productType +
				", productTypeName='" + productTypeName + '\'' +
				", highlightImageUrl='" + highlightImageUrl + '\'' +
				", noHighlightImageUrl='" + noHighlightImageUrl + '\'' +
				", displayProducts=" + displayProducts +
				'}';
	}
}
