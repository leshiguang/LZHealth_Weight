package com.lifesense.component.devicemanager.device.settings.config;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhouzhaoyan on 2016/1/21.
 * 称的目标
 */
public class LSEScaleTargetCfg implements Parcelable {
    public static int LSEWeightType = 1;
    /**
     * 用户号
     */
    private int userNumber;
    /**
     * 目标类型
     */
    private int targetType;
    /**
     * 目标体重值
     */
    private float targetWeight;

    public LSEScaleTargetCfg() {
    }

    protected LSEScaleTargetCfg(Parcel in) {
        userNumber = in.readInt();
        targetType = in.readInt();
        targetWeight = in.readFloat();
    }

    public static final Creator<DeviceUnitCfg> CREATOR = new Creator<DeviceUnitCfg>() {
        @Override
        public DeviceUnitCfg createFromParcel(Parcel in) {
            return new DeviceUnitCfg(in);
        }

        @Override
        public DeviceUnitCfg[] newArray(int size) {
            return new DeviceUnitCfg[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(userNumber);
        dest.writeInt(targetType);
        dest.writeFloat(targetWeight);
    }

    public int getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(int userNumber) {
        this.userNumber = userNumber;
    }

    public int getTargetType() {
        return targetType;
    }

    public void setTargetType(int targetType) {
        this.targetType = targetType;
    }

    public float getTargetWeight() {
        return targetWeight;
    }

    public void setTargetWeight(float targetWeight) {
        this.targetWeight = targetWeight;
    }

    @Override
    public String toString() {
        return "LSEScaleTargetCfg{" +
                "userNumber=" + userNumber +
                ", targetType=" + targetType +
                ", targetWeight=" + targetWeight +
                '}';
    }
}
