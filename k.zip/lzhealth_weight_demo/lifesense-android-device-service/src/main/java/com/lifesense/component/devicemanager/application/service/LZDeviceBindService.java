package com.lifesense.component.devicemanager.application.service;

import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.SearchCallback;
import com.lifesense.ble.bean.LsDeviceInfo;
import com.lifesense.ble.bean.constant.BroadcastType;
import com.lifesense.ble.bean.constant.ManagerStatus;

import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.device.dto.device.LSEDeviceInfo;
import com.lifesense.component.devicemanager.device.product.DisplayProduct;
import com.lifesense.component.devicemanager.device.product.GetProductListRespond;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceBindService;
import com.lifesense.component.devicemanager.application.interfaces.ILZDeviceSyncService;
import com.lifesense.component.devicemanager.application.interfaces.callback.BindResultCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.DefaultPairCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.DefaultSearchCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.OnResultCallback;
import com.lifesense.component.devicemanager.application.interfaces.callback.SearchResultCallback;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UnBindDeviceResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.List;


public class LZDeviceBindService extends LZDeviceSyncService implements ILZDeviceBindService {

    @Override
    public void getProduct(IRequestCallBack<GetProductListRespond> callback) {
        DeviceNetManager.getInstance().getProductList(callback);
    }

    @Override
    public void searchDevice(DisplayProduct displayProduct, final SearchResultCallback callback) {
        bleManager.stopSearch();
        cacheDeviceInfos.clear();
        this.stopDataReceive();
        SearchCallback searchCallback = new DefaultSearchCallback(new SearchResultCallback() {
            @Override
            public void onSearchResult(LSEDeviceInfo lseDeviceInfo, int rssi) {
                if (callback != null) {
                    callback.onSearchResult(lseDeviceInfo, rssi);
                }
            }
        }, displayProduct);
        LsBleManager lsBleManager = LsBleManager.getInstance();
        lsBleManager.searchLsDevice(searchCallback, displayProduct.getDeviceTypes(), BroadcastType.ALL);
    }

    @Override
    public void stopSearch() {
        if (bleManager.getLsBleManagerStatus() == ManagerStatus.DEVICE_SEARCH) {
            bleManager.stopSearch();
            this.startDataReceive();
        }
    }


    @Override
    public void bindDeviceBySearchResult(LSEDeviceInfo lseDeviceInfo, BindResultCallback callback) {
        if (bleManager.getLsBleManagerStatus() != ManagerStatus.DEVICE_PAIR) {
            cacheDeviceInfos.clear();
            this.stopDataReceive();
            bleManager.stopSearch();
            LsDeviceInfo lsDeviceInfo = lseDeviceInfo.getLsDeviceInfo();
            bleManager.pairingWithDevice(lsDeviceInfo, new DefaultPairCallback(callback, lsDeviceInfo));
        } else {
            String msg = "repeat pair device";
            bleManager.setLogMessage(msg);
        }
    }

    @Override
    public void interruptBindDevice(LSEDeviceInfo lseDeviceInfo) {
        LsBleManager.getInstance().cancelDevicePairing(lseDeviceInfo.getLsDeviceInfo());
    }


    @Override
    public void unBindDevice(final String deviceId, final OnResultCallback callback) {
        DeviceNetManager.getInstance().unbindDevice(deviceId, new IRequestCallBack<UnBindDeviceResponse>() {
            @Override
            public void onRequestSuccess(UnBindDeviceResponse response) {
                //删除设备
                RepositoryRegistry.deviceRepository().delete(deviceId, LDAppHolder.getUserId());
                //删除绑定关系
                RepositoryRegistry.deviceUserRepository().delete(deviceId, LDAppHolder.getUserId());

                ILZDeviceSyncService lzDeviceService = (ILZDeviceSyncService) LZDeviceService.getInstance();
                lzDeviceService.startDataReceive();
                if (callback != null) {
                    Task.runOnMainThreadAsync(new Runnable() {
                        @Override
                        public void run() {
                            callback.onSuccess();
                        }
                    });
                }
            }

            @Override
            public void onRequestError(final int code, final String msg, final UnBindDeviceResponse response) {
                if (callback != null) {
                    Task.runOnMainThreadAsync(new Runnable() {
                        @Override
                        public void run() {
                            callback.onFailed(code, msg);
                        }
                    });
                }
            }
        });
    }


    /**
     * 根据用户ID获取设备列表
     */
    @Override
    public List<Device> getBondedDevices() {
        return RepositoryRegistry.deviceRepository().queryByUser(LDAppHolder.getUserId());
    }


}
