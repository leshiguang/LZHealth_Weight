package com.lifesense.component.devicemanager.device.settings.function;


import com.lifesense.ble.bean.constant.UnitType;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;


/**
 * Created by zhouzhaoyan on 2017/7/20.
 * 中文版
 */

class LSDeviceFunctionChinese extends LSDeviceFunction {

    public LSDeviceFunctionChinese(Device device) {
        super(device);
    }



    @Override
    public int getWeightUnitDefault() {
        return UnitType.UNIT_KG.getCommand();
    }

}
