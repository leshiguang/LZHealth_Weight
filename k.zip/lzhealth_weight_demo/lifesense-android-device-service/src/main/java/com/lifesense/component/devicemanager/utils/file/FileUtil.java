package com.lifesense.component.devicemanager.utils.file;


import java.io.File;

/**
 * Created by lee on 2016/2/28.
 */
public class FileUtil {

    private FileUtil() {
    }

    public static boolean deletedFile(String path) {
        boolean flag = false;
        File file = new File(path);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            flag = file.delete();
        }
        return flag;
    }

    public static void deletedFile(String[] paths) {
        if (paths != null && paths.length > 0) {
            for (String path : paths) {
                deletedFile(path);
            }
        }
    }

    public static boolean deleteFile(File file) {
        if (file == null) {
            return false;
        }
        boolean flag = false;
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            flag = file.delete();
        }
        return flag;
    }

    public static void deleteFile(File[] files) {
        if (files == null || files.length == 0) {
            return ;
        }
        for (File file : files) {
            deleteFile(file);
        }
    }
}
