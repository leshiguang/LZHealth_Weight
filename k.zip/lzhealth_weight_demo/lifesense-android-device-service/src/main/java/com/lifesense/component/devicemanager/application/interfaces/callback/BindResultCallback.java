package com.lifesense.component.devicemanager.application.interfaces.callback;


import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceUser;

import java.util.List;

/**
 * Created by lee on 2016/1/16.
 */
public abstract class BindResultCallback {

    public abstract void onSuccess(Device device, List<DeviceUser> deviceUsers);

    public abstract void onFailed(int errorCode, String msg);

}
