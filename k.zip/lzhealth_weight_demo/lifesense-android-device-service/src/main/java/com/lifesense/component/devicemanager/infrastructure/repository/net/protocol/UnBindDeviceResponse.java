package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import com.alibaba.fastjson.JSON;
import com.lifesense.component.devicemanager.infrastructure.repository.net.bean.ActiveDeviceRespond;
import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;
import com.lifesense.weidong.lzsimplenetlibs.net.invoker.JsonResponse;

import org.json.JSONObject;

/**
 * Created by rolandxu on 2017/6/27.
 */

public class UnBindDeviceResponse extends JsonResponse {
    private ActiveDeviceRespond mActiveDeviceRespond;
    @Override
    protected void parseJsonData(JSONObject jsonData) throws ProtocolException {
        if (jsonData == null) {
            return;
        }
        mActiveDeviceRespond = JSON.parseObject(jsonData.toString(), ActiveDeviceRespond.class);
    }

    public ActiveDeviceRespond getActiveDeviceRespond() {
        return mActiveDeviceRespond;
    }
}
