package com.lifesense.component.devicemanager.data.weight;

import android.util.Log;

import com.lifesense.commonlogic.logic.BaseAppLogicManager;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.device.dto.receive.WeightData;
import com.lifesense.component.devicemanager.data.DataDbTask;
import com.lifesense.component.devicemanager.data.weight.db.IWeightDataDbInterface;
import com.lifesense.component.devicemanager.data.weight.db.WeightDataDbManager;
import com.lifesense.component.devicemanager.data.weight.delegate.IWeightDataGetDelegate;
import com.lifesense.component.devicemanager.data.weight.observer.IWeightDataUpdateObserver;
import com.lifesense.component.devicemanager.infrastructure.repository.DefaultDatabaseRepository;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadWeightResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

import java.util.Arrays;
import java.util.List;

/**
 * @author Sinyi.liu
 * @date 2017/9/7 11:27
 * @describe:
 */
public class WeightDataManager extends BaseAppLogicManager implements IWeightDataInterface {

	private static volatile WeightDataManager singleton = null;
	private IWeightDataDbInterface mdbInterface;
	public static final String WEIGHT_DATA_UPDATE_OBSERVER = "weight_data_update_observer";
	private WeightDataManager() {
		mdbInterface = new WeightDataDbManager(
				DefaultDatabaseRepository.getDaoSession().getWeightDbDataDao());
	}

	public IWeightDataDbInterface getIWeightDataDbInterface() {
		if (mdbInterface == null) {
			mdbInterface = new WeightDataDbManager(
					DefaultDatabaseRepository.getDaoSession().getWeightDbDataDao());
		}
		return mdbInterface;
	}

	public static WeightDataManager getInstance() {
		if (singleton == null) {
			synchronized (WeightDataManager.class) {
				if (singleton == null) {
					singleton = new WeightDataManager();
				}
			}
		}
		return singleton;
	}

	/**
	 * 添加蓝牙过来的原始数据。
	 * @param weightData
	 */
	public void addBleWeightData(final WeightData weightData) {
		DataDbTask.getInstance().executeWriteDbTask(new Runnable() {
			@Override
			public void run() {
				getIWeightDataDbInterface().addWeightData(weightData);
				final List<WeightData> untreatedWeightData = getIWeightDataDbInterface().getUntreatedWeightData();

				DeviceNetManager.getInstance().uploadWeightData(untreatedWeightData, new IRequestCallBack<UploadWeightResponse>() {
					@Override
					public void onRequestSuccess(UploadWeightResponse uploadWeightResponse) {
						getIWeightDataDbInterface().setWeightDataProcessed(untreatedWeightData);
					}

					@Override
					public void onRequestError(int i, String s, UploadWeightResponse uploadWeightResponse) {
						Log.e("NET_ERROR", "UPLOAD WEIGHT DATA ERROR!");
					}
				});

				notifyWeightDataUpdateObserver();
			}
		});
	}

	private void notifyWeightDataUpdateObserver() {
		Task.runOnMainThreadSync(new Runnable() {
			@Override
			public void run() {
				List<Object> objects = getObservers(WEIGHT_DATA_UPDATE_OBSERVER);
				if (objects != null) {
					for (int i = 0; i < objects.size(); i++) {
						IWeightDataUpdateObserver iWeightDataUpdateObserver = (IWeightDataUpdateObserver) objects.get(i);
						iWeightDataUpdateObserver.onWeightDataUpdate();
					}
				}

			}
		});
	}
	@Override
	public void addWeightDataUpdateObserver(IWeightDataUpdateObserver observer) {
		addObserver(WEIGHT_DATA_UPDATE_OBSERVER, observer);
	}

	@Override
	public void removeWeightDataUpdateObserver(IWeightDataUpdateObserver observer) {
		removeObserver(WEIGHT_DATA_UPDATE_OBSERVER,observer);
	}

	@Override
	public void getUntreatedWeightData(final IWeightDataGetDelegate delegate) {
		DataDbTask.getInstance().executeReadDbTask(new Runnable() {
			@Override
			public void run() {
				final List<WeightData> weightDatas = getIWeightDataDbInterface()
						.getUntreatedWeightData();
				Task.runOnMainThreadSync(new Runnable() {
					@Override
					public void run() {
						if (delegate != null) {
							delegate.onWeightGetSucceed(weightDatas);
						}
					}
				});
			}
		});
	}

	@Override
	public void setWeightDataProcessed(final List<WeightData> weightDatas) {
		DataDbTask.getInstance().executeWriteDbTask(new Runnable() {
			@Override
			public void run() {
				getIWeightDataDbInterface().setWeightDataProcessed(weightDatas);
			}
		});
	}

	@Override
	public void setWeightDataProcessedById(final String id) {
		DataDbTask.getInstance().executeWriteDbTask(new Runnable() {
			@Override
			public void run() {
				getIWeightDataDbInterface().setWeightDataProcessedById(id);
			}
		});
	}

	@Override
	public void setWeightDataProcessedByIds(final List<String> ids) {
		DataDbTask.getInstance().executeWriteDbTask(new Runnable() {
			@Override
			public void run() {
				getIWeightDataDbInterface().setWeightDataProcessedByIds(ids);
			}
		});
	}

	@Override
	public int getUntreatedWeightDataCount() {
		return getIWeightDataDbInterface().getUntreatedWeightDataCount();
	}
}
