package com.lifesense.component.devicemanager.infrastructure.repository.net.protocol;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DeviceSetting;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class UploadDeviceInformationRequest extends BaseRequest {

    private static final String kRequestParam_Devices = "devices";
    private static final String kRequestParam_DeviceSettings = "deviceSettings";

    private List<Device> devices;
    private List<DeviceSetting> deviceSettings;

    public UploadDeviceInformationRequest(List<Device> devices, List<DeviceSetting> deviceSettings) {
        super();
        setRequestMethod(HTTP_POST);
        if (CollectionUtils.isNotEmpty(devices)) {
            JSONArray array = new JSONArray();
            for (Device device : devices) {
                try {
                    array.put(new JSONObject(JSON.toJSONString(device)));
                } catch (JSONException e) {
                    Log.e("ERROR", e.getMessage(), e);
                }
            }
            addValue(kRequestParam_Devices, array);
        }
        if (CollectionUtils.isNotEmpty(deviceSettings)) {
            JSONArray array = new JSONArray();
            for (DeviceSetting setting : deviceSettings) {
                try {
                    array.put(new JSONObject(JSON.toJSONString(setting)));
                } catch (JSONException e) {
                    Log.e("ERROR", e.getMessage(), e);
                }
            }
            addValue(kRequestParam_DeviceSettings, array);
        }
        this.devices = devices;
        this.deviceSettings = deviceSettings;
    }

    public List<Device> getDevices() {
        return this.devices;
    }

    public List<DeviceSetting> getDeviceSettings() {
        return this.deviceSettings;
    }

    @Override
    public String getUrlWithoutProtocol() {
        return "/device_service/sync/upload";
    }

    @Override
    public String getResponseClassName() {
        return UploadDeviceInformationResponse.class.getName();
    }
}
