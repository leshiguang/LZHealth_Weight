package com.lifesense.component.devicemanager.infrastructure.repository;

import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DaoMaster;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.DaoSession;
import com.lifesense.foundation.ApplicationHolder;

public abstract class DefaultDatabaseRepository<T> implements IRepository<T> {

    private static volatile DaoSession daoSession;
    private static final String DB_NAME = "DeviceManger.db";

    /**
     * 取得DaoSession
     *
     * @return
     */
    public synchronized static DaoSession getDaoSession() {
        if (daoSession == null) {
            synchronized (DefaultDatabaseRepository.class) {
                if (daoSession == null) {
                    DaoMaster.OpenHelper helper = new DaoMaster.OpenHelper(ApplicationHolder.getmApplication(), DB_NAME) {};
                    helper.setWriteAheadLoggingEnabled(true);
                    daoSession = new DaoMaster(helper.getWritableDb()).newSession();
                }
            }
        }
        return daoSession;
    }
}
