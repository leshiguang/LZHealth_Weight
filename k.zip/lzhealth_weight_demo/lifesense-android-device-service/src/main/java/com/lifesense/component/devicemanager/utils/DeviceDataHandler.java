package com.lifesense.component.devicemanager.utils;

import android.text.TextUtils;


import com.lifesense.ble.LsBleManager;
import com.lifesense.ble.bean.LsDeviceInfo;

import com.lifesense.ble.bean.WeightData_A3;
import com.lifesense.ble.bean.constant.DeviceConnectState;
import com.lifesense.commonlogic.logic.task.Task;
import com.lifesense.component.devicemanager.context.LDAppHolder;
import com.lifesense.component.devicemanager.infrastructure.repository.RepositoryRegistry;
import com.lifesense.component.devicemanager.infrastructure.repository.database.entity.Device;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDataReceiveListener;
import com.lifesense.component.devicemanager.application.interfaces.listener.OnDeviceConnectStateListener;
import com.lifesense.component.devicemanager.infrastructure.domain.service.DevicePushClient;
import com.lifesense.component.devicemanager.infrastructure.repository.net.DeviceNetManager;
import com.lifesense.component.devicemanager.infrastructure.repository.net.protocol.UploadDeviceInformationResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;


import java.util.Arrays;
import java.util.List;

import static com.lifesense.component.devicemanager.utils.ObjectConvertTool.toWeightData;
import static com.lifesense.component.devicemanager.utils.StringUtil.getMacWithoutColon;

/**
 * Created by lee on 2016/5/4.
 */
public class DeviceDataHandler {

    private DeviceDataHandler() {
    }

    public static void handleWeightData(final Object data, final OnDataReceiveListener listener) {
        if (!checkDataReceiveListener(listener, data)) {
            return;
        }
        runOnBackground(new Runnable() {
            @Override
            public void run() {
                if (data instanceof WeightData_A3) {
                    WeightData_A3 weightDataA3 = (WeightData_A3) data;
                    listener.onReceiveWeightData(toWeightData(weightDataA3));

                }
            }
        });
    }


    public static void handleDeviceInfo(final LsDeviceInfo lsDeviceInfo) {
        if (lsDeviceInfo == null) {
            return;
        }

        Device device = RepositoryRegistry.deviceRepository().get(lsDeviceInfo.getDeviceId());

        if (device != null && device.hasChangeInfo(lsDeviceInfo)) {
            LsBleManager.getInstance().setLogMessage("device info chanage:" + device.getSoftwareVersion());
            RepositoryRegistry.deviceRepository().save(device);
            DeviceNetManager.getInstance().updateDeviceInformation(Arrays.asList(device), null, new IRequestCallBack<UploadDeviceInformationResponse>() {
                @Override
                public void onRequestSuccess(UploadDeviceInformationResponse uploadDeviceInformationResponse) {

                }

                @Override
                public void onRequestError(int i, String s, UploadDeviceInformationResponse uploadDeviceInformationResponse) {

                }
            });
        } else {
            LsBleManager.getInstance().setLogMessage("device info no change:");
        }
    }

    public static void handleDeviceConnectState(final DeviceConnectState state, final String s, final OnDeviceConnectStateListener listener) {
        if (listener == null || state == null || TextUtils.isEmpty(s)) {
            return;
        }
        final String mac = getMacWithoutColon(s);

        if (state == DeviceConnectState.CONNECTED_SUCCESS) {
            List<Device> devices = RepositoryRegistry.deviceRepository().queryByUser(LDAppHolder.getUserId());
            if (devices == null || devices.size() < 0) {
                return;
            }

            for (Device device : devices) {
                if (!device.getMacConvert().equals(mac)) {
                    continue;
                }
                if (state == DeviceConnectState.CONNECTED_SUCCESS) {
                    DevicePushClient.setWeightUserInfo(device.getId(), null);
                }
            }
        }

        Task.execute(new Runnable() {
            @Override
            public void run() {

                listener.onDeviceConnectStateChange(mac, state);
            }
        });
    }

    private static boolean checkDataReceiveListener(OnDataReceiveListener listener, Object data) {
        if (listener == null) {
            LsBleManager.getInstance().setLogMessage("没有注册监听，数据丢弃");
            return false;
        }
        if (data == null) {
            LsBleManager.getInstance().setLogMessage("数据为空");
            return false;
        }
        return true;
    }

    private static void runOnBackground(Runnable runnable) {
        Task.handlerPost(runnable);
    }


}
