package com.lifesense.component.devicemanager.infrastructure.repository;

import java.util.List;

public interface Filter<T> {

    boolean doTest(T value);
}