package com.lifesense.weidong.lzsimplenetlibs.net;

public interface IRequestCallBack {
    void onResponse(String str);
}
