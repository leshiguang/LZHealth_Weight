package com.lifesense.weidong.lzsimplenetlibs.file;

import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

/**
 * Create by qwerty
 * Create on 2020/5/29
 **/
public interface IDownloadRequestCallback extends IRequestCallBack<DownloadResponse> {
    void onDownloading(int progress);
}
