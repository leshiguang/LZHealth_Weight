package com.lifesense.weidong.lzsimplenetlibs.net.dispatcher;


import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;
import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.callback.IRequestCallBack;

public interface ApiDispatcher {
    /**
     * 发送网络请求
     * @param request 请求内容定义
     * @param callBack 回调方法， 需要根据自身需求实现
     */
    void dispatch(BaseRequest request, IRequestCallBack<? extends BaseResponse> callBack);
}