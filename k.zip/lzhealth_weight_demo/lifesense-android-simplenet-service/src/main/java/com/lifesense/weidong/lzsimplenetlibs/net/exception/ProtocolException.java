package com.lifesense.weidong.lzsimplenetlibs.net.exception;

/**
 * 协议异常
 */
public class ProtocolException extends BaseException {

    private static final long serialVersionUID = 3252234250603642437L;


    /**
     * @param requestName 请求名
     * @param message     消息
     * @param cause
     * @param params
     */
    public ProtocolException(String requestName, String message, Throwable cause, Object... params) {
        super(String.format("request(%s)exception:%s", requestName, message), cause, params);
    }

    public ProtocolException(String requestName, String message) {
        super(String.format("request(%s)exception:%s", requestName, message));
    }
}
