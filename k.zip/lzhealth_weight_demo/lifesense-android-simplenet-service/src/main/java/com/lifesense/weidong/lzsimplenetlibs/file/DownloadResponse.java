package com.lifesense.weidong.lzsimplenetlibs.file;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;

/**
 * Create by qwerty
 * Create on 2020/6/1
 **/
public class DownloadResponse extends BaseResponse {
    private String filePath;

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFilePath() {
        return filePath;
    }
}
