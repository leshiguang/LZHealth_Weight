package com.lifesense.weidong.lzsimplenetlibs.file;

import android.net.Uri;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

import java.io.File;
import java.util.Set;

/**
 * Create by qwerty
 * Create on 2020/5/29
 **/
public class DownloadRequest extends BaseRequest {
    private String target;
    private String sourceUrl;
    private boolean canceled;
    private OnLoadingListener onLoadingListener;
    private boolean isResume = true; //是否断点续传，默认断点续传
    public DownloadRequest(String target, String sourceUrl) {
        setRequestMethod(HTTP_GET);
        init(target, sourceUrl);
    }

    private void init(String target, String sourceUrl) {
        File file = new File(target);
        final long fileLen = file.length();
        if (isResume && fileLen > 0) {
            addHeaderParams("Range", "bytes=" + fileLen + "-");
        }
        this.target = target;
        Uri uri = Uri.parse(sourceUrl);
        setDomain(uri.getScheme() + "://" + uri.getHost());
        this.sourceUrl = uri.getPath();
        Set<String> queryParamNames = uri.getQueryParameterNames();
        for (String paramName:queryParamNames) {
            addUrlParams(paramName,uri.getQueryParameter(paramName));
        }
    }

    @Override
    public String getUrlWithoutProtocol() {
        return sourceUrl;
    }

    @Override
    public String getResponseClassName() {
        return DownloadResponse.class.getName();
    }

    public String getTarget() {
        return target;
    }

    public boolean isResume() {
        return isResume;
    }

    public void setResume(boolean resume) {
        isResume = resume;
    }

    public boolean isCanceled() {
        return canceled;
    }

    public void cancel() {
        this.canceled = true;
    }

    public void setOnLoadingListener(OnLoadingListener onLoadingListener) {
        this.onLoadingListener = onLoadingListener;
    }

    public OnLoadingListener getOnLoadingListener() {
        return onLoadingListener;
    }

    public interface OnLoadingListener {
        void onLoading(long count, long current);
    }

    public void execute(IDownloadRequestCallback callBack) {
        super.execute(callBack);
    }
}
