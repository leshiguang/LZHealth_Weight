package com.lifesense.weidong.lzsimplenetlibs.util;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseRequest;

import java.security.Key;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RequestCommonParamsUtils {
    public static final String SECRETKEY = "2a6bfL45*2219cZi44c7f78231e3cF80ensea13072eSb672_!";
    //请求token， 用于校验请求合法性
    public static final String kRequestParam_Token = "requestToken";
    //当前时间，秒
    public static final String kRequestParam_TimeStamp = "ts";
    //8位的随机码
    public static final String kRequestParam_Random = "rnd";
    public static final String kRequestParam_AppType = "appType";

    private static Map<String, Object> commonParameters = new ConcurrentHashMap<>();

    /**
     * 设置公共参数
     * @param key
     * @param value
     */
    public static void put(String key, Object value) {
        if (!commonParameters.containsKey(key) || commonParameters.get(key) != value) {
            commonParameters.put(key, value);
        }
    }

    /**
     * 添加公共参数
     * @param request
     */
    public static void addCommonParams(BaseRequest request) {
        generateRequestToken(request);
        for (Map.Entry<String, Object> entry : commonParameters.entrySet()) {
            request.addValue(entry.getKey(), entry.getValue());
        }
    }
    //生成请求token， 校验请求合法性
    private static void generateRequestToken(BaseRequest baseRequest) {
        int currentTimeStamp = (int) (System.currentTimeMillis() / 1000);
        String uuid = UUID.randomUUID().toString();
        String random = uuid.substring(uuid.length() - 8);
        String unEncryptToken = random + SECRETKEY + currentTimeStamp;
        String encryptToken = MD5.getMD5Str(unEncryptToken);
        baseRequest.addUrlParams(kRequestParam_Token, encryptToken);
        baseRequest.addUrlParams(kRequestParam_TimeStamp, "" + currentTimeStamp);
        baseRequest.addUrlParams(kRequestParam_Random, random);
    }
}
