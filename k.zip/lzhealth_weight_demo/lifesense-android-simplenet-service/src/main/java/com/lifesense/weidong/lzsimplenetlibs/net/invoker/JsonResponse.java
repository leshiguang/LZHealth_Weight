package com.lifesense.weidong.lzsimplenetlibs.net.invoker;

import com.lifesense.weidong.lzsimplenetlibs.base.BaseResponse;
import com.lifesense.weidong.lzsimplenetlibs.net.exception.ProtocolException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public abstract class JsonResponse extends BaseResponse {
    public static final int RET_SUCCESS = 200;
    static final String PROTOCOL_JSON_KEY_RET = "code";
    static final String PROTOCOL_JSON_KEY_MSG = "msg";
    public static final String PROTOCOL_JSON_KEY_DATA = "data";

    public static final int RET_DEFAULT_ERROR = -1;
    static final String DEFAULT_ERROR_MSG = "no message";
    public static final String PROTOCOL_JSON_KEY_LIST_IN_DATA = "list";
    private JSONObject mRootJSON;
    /**
     * data节点的jsonObject
     */
    private JSONObject mJSONData;

    public JSONObject getRootJSON() {
        return mRootJSON;
    }

    @Override
    public final void parse() throws ProtocolException {
        super.parse();
        if (content != null) {
            try {
                mRootJSON = new JSONObject(content);
                parseRootJSON(mRootJSON);
            } catch (JSONException e) {
                e.printStackTrace();
                throw new ProtocolException(getmRequest().getRequestName(),
                        "data format json error ");
            }
        } else {
            throw new ProtocolException(getmRequest().getRequestName(), "data is Empty ");
        }
    }

    public void parseRootJSON(JSONObject rootJSON) throws ProtocolException {
        int code = RET_DEFAULT_ERROR;
        try {
            code = rootJSON.getInt(PROTOCOL_JSON_KEY_RET);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String msg = DEFAULT_ERROR_MSG;
        msg = rootJSON.optString(PROTOCOL_JSON_KEY_MSG);
        setmMsg(msg);
        setmRet(code);
        if (code == RET_SUCCESS) {
            this.mJSONData = rootJSON.optJSONObject(PROTOCOL_JSON_KEY_DATA);
            //调用子类解析json数据
            if (mJSONData == null) {
                retryParseArrayData(rootJSON);
            }
        } else {
            this.setmRet(code);
            this.setmMsg(msg);
        }
        if (this.mJSONData != null) {
            parseJsonData(mJSONData);
        }
    }

    /**
     * 重新尝试解析data字段,有一些服务给回来的data并没有按照规范给回object，所以要拼接一下看看
     */
    private void retryParseArrayData(JSONObject jsonData) {
        JSONArray array = jsonData.optJSONArray(PROTOCOL_JSON_KEY_DATA);
        if (array != null) {
            mJSONData = new JSONObject();
            try {
                mJSONData.put(PROTOCOL_JSON_KEY_LIST_IN_DATA, array);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 由之类解析data里面的数据
     */
    protected abstract void parseJsonData(JSONObject jsonData) throws ProtocolException;


}
